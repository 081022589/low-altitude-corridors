"""Physical shaft/mainline intersection registry for G25-derived scenes."""

from __future__ import annotations

import hashlib
import json
import math
from typing import Any, Dict, Iterable, List, Sequence, Tuple


def _canonical_hash(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _point_segment_distance_sq(px: float, py: float, a: Sequence[float], b: Sequence[float]) -> float:
    vx, vy = b[0] - a[0], b[1] - a[1]
    wx, wy = px - a[0], py - a[1]
    length_sq = vx * vx + vy * vy
    if length_sq == 0.0:
        return wx * wx + wy * wy
    ratio = max(0.0, min(1.0, (wx * vx + wy * vy) / length_sq))
    dx, dy = px - (a[0] + ratio * vx), py - (a[1] + ratio * vy)
    return dx * dx + dy * dy


def _distance_to_polyline_xy(point: Sequence[float], polyline: Sequence[Sequence[float]]) -> float:
    if len(polyline) < 2:
        return math.inf
    return math.sqrt(
        min(_point_segment_distance_sq(point[0], point[1], start, end) for start, end in zip(polyline, polyline[1:]))
    )


def _shaft_records(network: Dict[str, Any], shaft_radius_m: float) -> List[Dict[str, Any]]:
    grouped: Dict[Tuple[str, float, float], List[Dict[str, Any]]] = {}
    for interface in network["access_interfaces"]:
        axis = interface["shaft_axis_xy"]
        grouped.setdefault((interface["direction_id"], round(axis[0], 9), round(axis[1], 9)), []).append(interface)
    shafts = []
    for (direction_id, _, _), interfaces in sorted(grouped.items()):
        axes = {tuple(item["shaft_axis_xy"]) for item in interfaces}
        if len(axes) != 1:
            raise ValueError("AMBIGUOUS_PHYSICAL_SHAFT_MAPPING")
        source_refs = sorted({resource for item in interfaces for resource in item["resource_chain"]})
        node_ids = sorted({item["service_node_id"] for item in interfaces})
        shaft_key = _canonical_hash({"direction_id": direction_id, "axis_xy": list(next(iter(axes))), "source_shaft_refs": source_refs})[:24]
        shaft_id = "G25-S10:shaft:" + shaft_key
        shafts.append(
            {
                "physical_shaft_id": shaft_id,
                "source_shaft_refs": source_refs,
                "axis_xy": list(next(iter(axes))),
                "z_min_m": min(item["shaft_scope_end_z_m"] for item in interfaces),
                "z_max_m": max(item["shaft_top_z_m"] for item in interfaces),
                "cross_section": {"type": "CIRCLE", "radius_m": float(shaft_radius_m)},
                "cross_section_provenance": "SYNTHETIC_TEST_ONLY",
                "associated_node_ids": node_ids,
                "direction_id": direction_id,
                "source_interface_ids": sorted(item["interface_id"] for item in interfaces),
            }
        )
    return shafts


def _crossing_resource_identity(
    network: Dict[str, Any], shaft: Dict[str, Any], mainline: Dict[str, Any]
) -> Tuple[str, str, List[str]]:
    """Return the resource segment represented by one crossing.

    ``resource_chain`` is the complete vertical route for an access
    interface.  It is deliberately not used as the crossing identity: the
    crossing at this mainline layer represents only the first segment in the
    matching layer-specific interface chain.
    """

    matches = [
        interface
        for interface in network["access_interfaces"]
        if interface["service_node_id"] in shaft["associated_node_ids"]
        and interface["direction_id"] == mainline["direction_id"]
        and interface["source_layer_id"] == mainline["layer_id"]
        and tuple(interface["shaft_axis_xy"]) == tuple(shaft["axis_xy"])
    ]
    if len(matches) != 1:
        raise ValueError(
            "CROSSING_SEGMENT_MAPPING_CARDINALITY:{}:{}:{}".format(
                shaft["physical_shaft_id"], mainline["mainline_id"], len(matches)
            )
        )
    resource_chain = [str(value) for value in matches[0].get("resource_chain", ())]
    if not resource_chain:
        raise ValueError(
            "CROSSING_SEGMENT_RESOURCE_MISSING:{}:{}".format(
                shaft["physical_shaft_id"], mainline["mainline_id"]
            )
        )
    segment_resource_id = resource_chain[0]
    column_id = segment_resource_id.rsplit(":", 1)[0]
    if not column_id or column_id == segment_resource_id:
        raise ValueError("CROSSING_SEGMENT_COLUMN_MISSING:" + segment_resource_id)
    return segment_resource_id, column_id, resource_chain


def build_crossing_resources(network: Dict[str, Any], shaft_radius_m: float = 4.0) -> List[Dict[str, Any]]:
    """Calculate V_a ∩ H_b using source polylines and declared shaft geometry.

    The S10 bindings put each shaft axis on its assigned mainline axis.  When the
    circular shaft lies wholly inside the 20 m swept width, the exact finite 3-D
    intersection is the cylinder slice bounded by the mainline's vertical faces.
    """

    if shaft_radius_m <= 0.0:
        raise ValueError("shaft_radius_m must be positive")
    resources: List[Dict[str, Any]] = []
    for shaft in _shaft_records(network, shaft_radius_m):
        for mainline in network["mainlines"]:
            distance_m = _distance_to_polyline_xy(shaft["axis_xy"], mainline["polyline_3d"])
            horizontal_half_width = mainline["width_m"] / 2.0
            z_low = max(shaft["z_min_m"], mainline["center_z_m"] - mainline["height_m"] / 2.0)
            z_high = min(shaft["z_max_m"], mainline["center_z_m"] + mainline["height_m"] / 2.0)
            if distance_m > horizontal_half_width + shaft_radius_m or z_high <= z_low:
                continue
            if distance_m + shaft_radius_m > horizontal_half_width + 1e-7:
                raise ValueError("UNSUPPORTED_CROSSING_GEOMETRY: partially clipped circular shaft")
            audited_distance = 0.0 if distance_m <= 1e-7 else distance_m
            geometry = {
                "type": "FINITE_CYLINDER",
                "axis_xy": list(shaft["axis_xy"]),
                "radius_m": float(shaft_radius_m),
                "z_min_m": z_low,
                "z_max_m": z_high,
                "representation": "EXACT_FULL_SHAFT_SECTION_WITHIN_MAINLINE_SWEEP",
                "cross_section_provenance": shaft["cross_section_provenance"],
                "mainline_axis_distance_m": audited_distance,
                "numeric_tolerance_m": 1e-7,
            }
            crossing_id = "G25-S10:crossing:{}:{}".format(shaft["physical_shaft_id"], mainline["mainline_id"])
            segment_resource_id, column_id, resource_chain = _crossing_resource_identity(
                network, shaft, mainline
            )
            resources.append(
                {
                    "crossing_id": crossing_id,
                    # ``resource_id`` is retained as a compatibility alias;
                    # both fields identify the current crossing's segment,
                    # never the complete resource chain.
                    "resource_id": segment_resource_id,
                    "segment_resource_id": segment_resource_id,
                    "column_id": column_id,
                    "resource_chain": resource_chain,
                    "physical_shaft_id": shaft["physical_shaft_id"],
                    "mainline_id": mainline["mainline_id"],
                    "layer_id": mainline["layer_id"],
                    "direction_id": mainline["direction_id"],
                    "shaft_direction_id": shaft["direction_id"],
                    "geometry": geometry,
                    "associated_node_ids": list(shaft["associated_node_ids"]),
                    "source_registry_id": ";".join(shaft["source_interface_ids"]),
                    "geometry_hash": _canonical_hash(geometry),
                }
            )
    return sorted(resources, key=lambda item: item["crossing_id"])


def build_physical_shafts(network: Dict[str, Any], shaft_radius_m: float = 4.0) -> List[Dict[str, Any]]:
    return _shaft_records(network, shaft_radius_m)
