"""Deterministic subnetwork extraction while retaining source segment lineage."""

from __future__ import annotations

import copy
import hashlib
import json
import math
from typing import Any, Dict, List, Sequence, Tuple


def _hash(value: Any) -> str:
    raw = json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def cumulative_lengths(polyline: Sequence[Sequence[float]]) -> List[float]:
    result = [0.0]
    for first, second in zip(polyline, polyline[1:]):
        result.append(result[-1] + math.dist(first[:2], second[:2]))
    return result


def project_station_xy(polyline: Sequence[Sequence[float]], xy: Sequence[float]) -> Tuple[float, float, int, float]:
    cumulative = cumulative_lengths(polyline)
    best = (math.inf, 0.0, 0, 0.0)
    for index, (first, second) in enumerate(zip(polyline, polyline[1:])):
        vx, vy = second[0] - first[0], second[1] - first[1]
        length_sq = vx * vx + vy * vy
        ratio = 0.0 if length_sq == 0.0 else max(0.0, min(1.0, ((xy[0] - first[0]) * vx + (xy[1] - first[1]) * vy) / length_sq))
        px, py = first[0] + ratio * vx, first[1] + ratio * vy
        distance = math.hypot(xy[0] - px, xy[1] - py)
        station = cumulative[index] + ratio * math.sqrt(length_sq)
        candidate = (distance, station, index, ratio)
        if candidate < best:
            best = candidate
    return best[1], best[0], best[2], best[3]


def interpolate_station(polyline: Sequence[Sequence[float]], station: float) -> Tuple[List[float], int, float]:
    cumulative = cumulative_lengths(polyline)
    station = max(0.0, min(float(station), cumulative[-1]))
    for index in range(len(polyline) - 1):
        if station <= cumulative[index + 1] or index == len(polyline) - 2:
            span = cumulative[index + 1] - cumulative[index]
            ratio = 0.0 if span == 0.0 else (station - cumulative[index]) / span
            point = [polyline[index][axis] + ratio * (polyline[index + 1][axis] - polyline[index][axis]) for axis in range(3)]
            return point, index, ratio
    raise ValueError("empty polyline")


def clip_polyline(polyline: Sequence[Sequence[float]], start: float, end: float) -> Tuple[List[List[float]], List[Dict[str, float]]]:
    cumulative = cumulative_lengths(polyline)
    if start < 0.0 or end > cumulative[-1] or start >= end:
        raise ValueError("MIN_SUBNETWORK_NOT_FEASIBLE: requested buffer leaves source geometry")
    start_point, start_index, start_ratio = interpolate_station(polyline, start)
    end_point, end_index, end_ratio = interpolate_station(polyline, end)
    points = [start_point]
    points.extend([list(polyline[index]) for index in range(start_index + 1, end_index + 1)])
    if math.dist(points[-1], end_point) > 1e-9:
        points.append(end_point)
    refs = []
    for index in range(start_index, end_index + 1):
        refs.append(
            {
                "source_segment_index": index,
                "start_fraction": start_ratio if index == start_index else 0.0,
                "end_fraction": end_ratio if index == end_index else 1.0,
            }
        )
    return points, refs


def _select_pair(network: Dict[str, Any], requested: Sequence[str]) -> Tuple[List[str], str]:
    by_node: Dict[str, List[Dict[str, Any]]] = {}
    for interface in network["access_interfaces"]:
        by_node.setdefault(interface["service_node_id"], []).append(interface)
    eligible = []
    for node_id, interfaces in by_node.items():
        layers = {item["source_layer_id"] for item in interfaces}
        directions = {item["direction_id"] for item in interfaces}
        if layers == {"L1", "L2", "L3"} and len(directions) == 1:
            eligible.append((next(iter(directions)), min(item["source_chainage_m"] for item in interfaces), node_id))
    eligible.sort()
    if requested:
        requested_set = list(requested)
        records = [item for item in eligible if item[2] in requested_set]
        if len(records) != 2 or records[0][0] != records[1][0]:
            raise ValueError("MIN_SUBNETWORK_NOT_FEASIBLE: explicit nodes are not one legal same-direction pair")
        records.sort(key=lambda item: (item[1], item[2]))
        return [item[2] for item in records], records[0][0]
    for index, first in enumerate(eligible):
        for second in eligible[index + 1 :]:
            if first[0] == second[0] and first[1] < second[1]:
                return [first[2], second[2]], first[0]
    raise ValueError("MIN_SUBNETWORK_NOT_FEASIBLE: no same-direction two-node pair")


def extract_subnetwork(network: Dict[str, Any], selection_config: Dict[str, Any]) -> Dict[str, Any]:
    selected, direction = _select_pair(network, selection_config.get("source_service_node_ids", []))
    upstream = float(selection_config.get("upstream_buffer_m", 100.0))
    downstream = float(selection_config.get("downstream_buffer_m", 100.0))
    interfaces = [copy.deepcopy(item) for item in network["access_interfaces"] if item["service_node_id"] in selected]
    selected_axes = [item["shaft_axis_xy"] for item in interfaces if item["source_layer_id"] == "L1"]
    clipped_lines = []
    for line in network["mainlines"]:
        projections = [project_station_xy(line["polyline_3d"], axis)[0] for axis in selected_axes]
        start, end = min(projections) - upstream, max(projections) + downstream
        clipped, refs = clip_polyline(line["polyline_3d"], start, end)
        result = copy.deepcopy(line)
        result["source_parent_id"] = line["mainline_id"]
        result["source_chainage_range"] = [start, end]
        result["source_segment_refs"] = refs
        result["polyline_3d"] = clipped
        result["clipped_polyline_3d"] = clipped
        result["geometry_hash"] = _hash(clipped)
        clipped_lines.append(result)
    result = copy.deepcopy(network)
    result["profile_type"] = "G25_MIN"
    result["selected_service_node_ids"] = selected
    result["active_traffic_direction"] = direction
    result["mainlines"] = sorted(clipped_lines, key=lambda item: item["mainline_id"])
    result["access_interfaces"] = sorted(interfaces, key=lambda item: item["interface_id"])
    result["selection_config"] = copy.deepcopy(selection_config)
    return result
