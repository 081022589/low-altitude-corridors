"""Geometry and scenario contracts for the algorithm interfaces."""
