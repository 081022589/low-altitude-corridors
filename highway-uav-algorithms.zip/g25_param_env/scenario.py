"""SCENARIO_BUNDLE_V3_0 construction and deterministic hashing."""

from __future__ import annotations

import copy
import hashlib
import json
from typing import Any, Dict, List

from .crossings import build_crossing_resources, build_physical_shafts
from .trajectory_builder import build_traffic_plans


def canonical_hash(value: Any) -> str:
    # Sorting replaces only top-level lists. JSON serialization reads nested
    # values without modifying them; a full copy of all motion tables is wasted.
    normalized = dict(value) if isinstance(value, dict) else value
    if isinstance(normalized, dict) and "meta" in normalized:
        sort_keys = {
            "layers": "layer_id",
            "mainlines": "mainline_id",
            "service_nodes": "service_node_id",
            "physical_shafts": "physical_shaft_id",
            "access_interfaces": "interface_id",
            "access_routes": "route_id",
            "crossing_resources": "crossing_id",
            "plans": "plan_id",
        }
        for field, key in sort_keys.items():
            if field in normalized:
                normalized[field] = sorted(normalized[field], key=lambda item: item.get(key, ""))
    raw = json.dumps(normalized, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def build_scenario_bundle(
    subnetwork: Dict[str, Any], fixture_id: str = "G25_MIN_OPTIONS", timing_fixture: str = "OPTIONS", seed: int = 20261010,
    plans: List[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    crossings = build_crossing_resources(subnetwork)
    shafts = build_physical_shafts(subnetwork)
    plans = build_traffic_plans(subnetwork, timing_fixture) if plans is None else copy.deepcopy(plans)
    node_records = []
    node_ids = sorted({item["service_node_id"] for item in subnetwork["access_interfaces"]})
    for node_id in node_ids:
        interfaces = [item for item in subnetwork["access_interfaces"] if item["service_node_id"] == node_id]
        node_records.append(
            {
                "service_node_id": node_id,
                "source_service_id": node_id,
                "source_chainage_m": min(item["source_chainage_m"] for item in interfaces),
                "direction_id": interfaces[0]["direction_id"],
                "physical_facility_location_optional": None,
                "eligible_interface_ids": sorted(item["interface_id"] for item in interfaces),
            }
        )
    routes = []
    layer_order = {"L1": 1, "L2": 2, "L3": 3}
    for interface in subnetwork["access_interfaces"]:
        related = [item for item in crossings if interface["service_node_id"] in item["associated_node_ids"]]
        ordered = [
            item["crossing_id"]
            for item in sorted(related, key=lambda value: layer_order[value["layer_id"]], reverse=True)
            if layer_order[item["layer_id"]] <= layer_order[interface["source_layer_id"]]
        ]
        routes.append(
            {
                "route_id": f"route:{interface['interface_id']}",
                "source_interface_id": interface["interface_id"],
                "destination_node_id": interface["service_node_id"],
                "physical_shaft_id": next(item["physical_shaft_id"] for item in shafts if interface["interface_id"] in item["source_interface_ids"]),
                "transition_path_ref": "DECLARED_SYNTHETIC_TIMING_ON_SOURCE_POLYLINE",
                "crossing_ids_ordered": ordered,
            }
        )
    horizon = max((plan["activity_end_s"] for plan in plans), default=0.0) + 1.0
    bundle: Dict[str, Any] = {
        "meta": {
            "scenario_id": fixture_id,
            "fixture_id": fixture_id,
            "schema_version": "SCENARIO_BUNDLE_V3_0",
            "profile_type": subnetwork.get("profile_type", "G25_FULL"),
            "snapshot_id": fixture_id + ":SNAPSHOT:0",
            "t0_s": min((plan["activity_start_s"] for plan in plans), default=0.0),
            "horizon_s": horizon,
            "coordinate_frame": "G25_LOCAL_AEQD_XYZ_METRES",
            "unit_contract": {"position": "m", "time": "s", "z_axis": "up"},
            "seed": int(seed),
            "geometry_source_status": "G25_DERIVED_WITH_DECLARED_SYNTHETIC_MOTION_PARAMETERS",
            "scenario_hash": "",
        },
        "source_lineage": copy.deepcopy(subnetwork["source_lineage"]),
        "layers": copy.deepcopy(subnetwork["layers"]),
        "mainlines": copy.deepcopy(subnetwork["mainlines"]),
        "service_nodes": sorted(node_records, key=lambda item: item["service_node_id"]),
        "physical_shafts": shafts,
        "access_interfaces": copy.deepcopy(subnetwork["access_interfaces"]),
        "access_routes": sorted(routes, key=lambda item: item["route_id"]),
        "crossing_resources": crossings,
        "plans": plans,
        "time_profile": {
            "time_axis": "ABSOLUTE_SCENARIO_SECONDS",
            "numeric_tolerance_s": 1e-9,
            "optional_guard_s": 0.5,
            "horizon_semantics": "HALF_OPEN",
        },
        "traffic_profile": {
            "arrival_seed": int(seed),
            "request_generation_version": "G25_TRAFFIC_FIXTURE_V3_0",
            "speed_model_id": "DECLARED_SYNTHETIC_CONSTANT_SPEED_V1",
            "source_layer_mix": {"L2": 1, "L3": 1},
            "fixed_load_profile": "ONE_COMPLETE_L2_THROUGH_PLAN",
            "candidate_policy": "TWO_SAME_DIRECTION_REAL_SERVICE_NODES",
            "timing_fixture": timing_fixture,
            "whole_shaft_capacity_assumption": None,
        },
    }
    hash_input = copy.deepcopy(bundle)
    hash_input["meta"]["scenario_hash"] = ""
    bundle["meta"]["scenario_hash"] = canonical_hash(hash_input)
    return bundle
