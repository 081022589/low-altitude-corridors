"""Declared synthetic timing on immutable, source-derived G25 geometry."""

from __future__ import annotations

import math
from typing import Any, Dict, List, Sequence

from .extractor import cumulative_lengths, interpolate_station, project_station_xy


def _path_between(polyline: Sequence[Sequence[float]], start: float, end: float) -> List[List[float]]:
    cumulative = cumulative_lengths(polyline)
    start_point, start_index, _ = interpolate_station(polyline, start)
    end_point, end_index, _ = interpolate_station(polyline, end)
    points = [start_point]
    for index in range(start_index + 1, end_index + 1):
        if cumulative[index] < end - 1e-9:
            points.append(list(polyline[index]))
    if math.dist(points[-1], end_point) > 1e-9:
        points.append(end_point)
    return points


def _timed(points: Sequence[Sequence[float]], start_s: float, speed_mps: float) -> List[List[float]]:
    result = [[float(start_s), *map(float, points[0])]]
    current = float(start_s)
    for first, second in zip(points, points[1:]):
        current += math.dist(first, second) / speed_mps
        result.append([current, *map(float, second)])
    return result


def _candidate_plan(
    network: Dict[str, Any], uav_id: str, source_layer: str, node_id: str, start_s: float, cruise_speed_mps: float, descent_speed_mps: float
) -> Dict[str, Any]:
    direction = network["active_traffic_direction"]
    line = next(item for item in network["mainlines"] if item["layer_id"] == source_layer and item["direction_id"] == direction)
    interface = next(item for item in network["access_interfaces"] if item["service_node_id"] == node_id and item["source_layer_id"] == source_layer)
    target_station, axis_error, _, _ = project_station_xy(line["polyline_3d"], interface["shaft_axis_xy"])
    if axis_error > 1e-5:
        raise ValueError("INTERFACE_NOT_COAXIAL_WITH_SOURCE_MAINLINE")
    path_start = 0.0
    exit_start = max(path_start, target_station - 20.0)
    cruise_points = _path_between(line["polyline_3d"], path_start, exit_start)
    exit_points = _path_between(line["polyline_3d"], exit_start, target_station)
    cruise = _timed(cruise_points, start_s, cruise_speed_mps)
    source_exit = _timed(exit_points, cruise[-1][0], cruise_speed_mps)
    if source_exit[0] == cruise[-1]:
        source_exit = source_exit[1:]
    axis_x, axis_y = interface["shaft_axis_xy"]
    descent_end_s = source_exit[-1][0] + (interface["shaft_top_z_m"] - interface["shaft_scope_end_z_m"]) / descent_speed_mps
    descent = [[descent_end_s, axis_x, axis_y, interface["shaft_scope_end_z_m"]]]
    trajectory = cruise + source_exit + descent
    cruise_end = cruise[-1][0]
    exit_end = source_exit[-1][0]
    suffix = node_id.replace(":", "_")
    phases = [
        {"phase_id": f"{uav_id}_{suffix}_H", "phase_type": "H_CRUISE", "start_s": start_s, "end_s": cruise_end},
        {"phase_id": f"{uav_id}_{suffix}_EXIT", "phase_type": "SOURCE_EXIT", "start_s": cruise_end, "end_s": exit_end, "precoordinated": True},
        {"phase_id": f"{uav_id}_{suffix}_V", "phase_type": "V_DESCENT", "start_s": exit_end, "end_s": descent_end_s},
    ]
    return {
        "uav_id": uav_id,
        "plan_id": f"{uav_id}:{suffix}",
        "plan_status": "CANDIDATE",
        "mode": "DESCENT_OPTION",
        "source_mainline_id": line["mainline_id"],
        "source_layer_id": source_layer,
        "source_direction_id": direction,
        "service_node_id": node_id,
        "option_group_id": f"{uav_id}_OPTIONS",
        "is_current_assignment": node_id == network["selected_service_node_ids"][0],
        "committed": False,
        "activity_start_s": start_s,
        "activity_end_s": descent_end_s,
        "termination_reason": "ENGINEERING_BOUNDARY_REACHED",
        "trajectory_coverage_status": "COMPLETE_TO_ENGINEERING_BOUNDARY",
        "coverage_window": [start_s, descent_end_s],
        "trajectory": trajectory,
        "phases": phases,
        "route_id": f"route:{interface['interface_id']}",
        "motion_parameter_provenance": "SYNTHETIC_TEST_ONLY",
    }


def _fixed_plan(network: Dict[str, Any], start_s: float, speed_mps: float) -> Dict[str, Any]:
    direction = network["active_traffic_direction"]
    line = next(item for item in network["mainlines"] if item["layer_id"] == "L2" and item["direction_id"] == direction)
    trajectory = _timed(line["polyline_3d"], start_s, speed_mps)
    return {
        "uav_id": "U3",
        "plan_id": "U3:FIXED:L2",
        "plan_status": "FIXED",
        "mode": "H_CRUISE",
        "source_mainline_id": line["mainline_id"],
        "source_layer_id": "L2",
        "source_direction_id": direction,
        "service_node_id": None,
        "option_group_id": None,
        "is_current_assignment": False,
        "committed": True,
        "activity_start_s": start_s,
        "activity_end_s": trajectory[-1][0],
        "termination_reason": "LEFT_MONITORED_REGION",
        "trajectory_coverage_status": "LEFT_MONITORED_REGION",
        "coverage_window": [start_s, trajectory[-1][0]],
        "trajectory": trajectory,
        "phases": [{"phase_id": "U3_H", "phase_type": "H_CRUISE", "start_s": start_s, "end_s": trajectory[-1][0]}],
        "route_id": None,
        "motion_parameter_provenance": "SYNTHETIC_TEST_ONLY",
    }


def build_traffic_plans(network: Dict[str, Any], timing_fixture: str = "OPTIONS") -> List[Dict[str, Any]]:
    offsets = {
        "OPTIONS": {"U1": 0.0, "U2": 3.0, "U3": 0.0},
        "VV": {"U1": 0.0, "U2": 3.0, "U3": 100.0},
        "VH": {"U1": 0.0, "U2": 100.0, "U3": 0.0},
        "NO_OVERLAP": {"U1": 0.0, "U2": 100.0, "U3": 100.0},
    }
    if timing_fixture not in offsets:
        raise ValueError("unknown timing fixture: " + timing_fixture)
    timing = offsets[timing_fixture]
    plans = []
    for node_id in network["selected_service_node_ids"]:
        plans.append(_candidate_plan(network, "U1", "L3", node_id, timing["U1"], 50.0, 5.0))
        plans.append(_candidate_plan(network, "U2", "L2", node_id, timing["U2"], 50.0, 5.0))
    plans.append(_fixed_plan(network, timing["U3"], 20.0))
    return sorted(plans, key=lambda item: item["plan_id"])
