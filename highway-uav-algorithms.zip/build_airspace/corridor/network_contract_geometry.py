"""Arc-preserving geometry operations shared by network export and loading.

Coordinates are engineering XYZ. Planar paths are embedded explicitly in XYZ;
the local coordinate is physical arc length, never a scale-adjusted proxy.
"""
from __future__ import annotations

from bisect import bisect_right
import hashlib
import json
import math


def canonical_hash(value):
    data = json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def polyline(path_id, points, **metadata):
    points = [list(map(float, p)) for p in points]
    if len(points) < 2 or any(len(p) != 3 or not all(map(math.isfinite, p)) for p in points):
        raise ValueError("INVALID_GEOMETRY_POINTS")
    stations = [0.0]
    for a, b in zip(points, points[1:]):
        distance = math.dist(a, b)
        if distance <= 1e-10:
            raise ValueError("ZERO_LENGTH_GEOMETRY_EDGE")
        stations.append(stations[-1] + distance)
    return dict(path_id=path_id, centerline_xyz=points, arc_stations_m=stations,
                length_m=stations[-1], geometry_fidelity="C0_TRAFFIC_ARC_MODEL", **metadata)


def point_at_arc(path, distance):
    stations, points = path["arc_stations_m"], path["centerline_xyz"]
    if not math.isfinite(distance) or not -1e-8 <= distance <= stations[-1]+1e-8:
        raise ValueError("GEOMETRY_PROGRESS_OUTSIDE_PATH")
    distance = min(stations[-1], max(0.0, distance))
    index = min(len(points)-2, max(0, bisect_right(stations, distance)-1))
    fraction = (distance-stations[index])/(stations[index+1]-stations[index])
    return [a+fraction*(b-a) for a, b in zip(points[index], points[index+1])]


def subpath(path, start, end, path_id):
    if not 0 <= start < end <= path["length_m"]+1e-8:
        raise ValueError("INVALID_SUBPATH_INTERVAL")
    points = [point_at_arc(path, start)]
    points += [p for p, s in zip(path["centerline_xyz"], path["arc_stations_m"])
               if start+1e-8 < s < end-1e-8]
    points.append(point_at_arc(path, end))
    return polyline(path_id, points)


def validate_path(path, tolerance=1e-6):
    recalculated = polyline(path["path_id"], path["centerline_xyz"])
    if len(recalculated["arc_stations_m"]) != len(path["arc_stations_m"]):
        raise ValueError("ARC_SAMPLE_COUNT_MISMATCH")
    if abs(recalculated["length_m"]-path["length_m"]) > tolerance:
        raise ValueError("PATH_LENGTH_MISMATCH")
    if any(abs(a-b) > tolerance for a,b in zip(recalculated["arc_stations_m"],path["arc_stations_m"])):
        raise ValueError("PATH_ARCLENGTH_MISMATCH")


def planar_error(path, origin, horizontal_unit):
    """Maximum signed-distance magnitude from the horizontal--vertical plane."""
    if abs(math.hypot(*horizontal_unit)-1.0) > 1e-8:
        raise ValueError("PLANE_AXIS_NOT_NORMALIZED")
    normal = (-horizontal_unit[1], horizontal_unit[0])
    return max(abs((p[0]-origin[0])*normal[0]+(p[1]-origin[1])*normal[1])
               for p in path["centerline_xyz"])


def segment_distance(a, b, c, d):
    """Exact closest distance between finite straight segments in XYZ."""
    dot = lambda x,y: sum(i*j for i,j in zip(x,y))
    u, v, w = ([j-i for i,j in zip(a,b)], [j-i for i,j in zip(c,d)],
               [i-j for i,j in zip(a,c)])
    aa, bb, cc, dd, ee = dot(u,u), dot(u,v), dot(v,v), dot(u,w), dot(v,w)
    if min(aa, cc) <= 1e-18:
        raise ValueError("DEGENERATE_SEGMENT")
    denominator = aa*cc-bb*bb
    if denominator > 1e-18:
        s = min(1., max(0., (bb*ee-cc*dd)/denominator))
    else:
        s = 0.
    t = (bb*s+ee)/cc
    if t < 0:
        t, s = 0., min(1., max(0., -dd/aa))
    elif t > 1:
        t, s = 1., min(1., max(0., (bb-dd)/aa))
    return math.dist([i+s*j for i,j in zip(a,u)], [i+t*j for i,j in zip(c,v)])


def path_distance(first, second):
    return min(segment_distance(a,b,c,d)
               for a,b in zip(first["centerline_xyz"],first["centerline_xyz"][1:])
               for c,d in zip(second["centerline_xyz"],second["centerline_xyz"][1:]))


def segment_box_distance(a, b, lower, upper):
    """Exact distance from a line segment to an axis-aligned closed box."""
    velocity = [y-x for x,y in zip(a,b)]
    cuts = {0.,1.}
    for start,speed,lo,hi in zip(a,velocity,lower,upper):
        if abs(speed)>1e-15:
            for boundary in (lo,hi):
                t=(boundary-start)/speed
                if 0<t<1:cuts.add(t)
    cuts=sorted(cuts)
    def squared(t):
        return sum(max(lo-(start+t*speed),0.,start+t*speed-hi)**2
                   for start,speed,lo,hi in zip(a,velocity,lower,upper))
    best=min(map(squared,cuts))
    for lo,hi in zip(cuts,cuts[1:]):
        mid=(lo+hi)/2
        terms=[]
        for start,speed,left,right in zip(a,velocity,lower,upper):
            position=start+mid*speed
            if position<left:terms.append((start-left,speed))
            elif position>right:terms.append((start-right,speed))
        aa=sum(v*v for _,v in terms)
        if aa:
            t=min(hi,max(lo,-sum(x*v for x,v in terms)/aa))
            best=min(best,squared(t))
    return math.sqrt(best)


def path_mainline_box_distance(mainline_path, other_path):
    """Distance to the union of oriented 20 m by 10 m mainline prisms."""
    best=math.inf
    for a,b in zip(mainline_path['centerline_xyz'],mainline_path['centerline_xyz'][1:]):
        dx,dy=b[0]-a[0],b[1]-a[1]
        length=math.hypot(dx,dy)
        tx,ty=dx/length,dy/length
        def local(p):
            x,y=p[0]-a[0],p[1]-a[1]
            return [x*tx+y*ty,-x*ty+y*tx,p[2]-a[2]]
        points=[local(p) for p in other_path['centerline_xyz']]
        best=min(best,min(segment_box_distance(c,d,[0.,-10.,-5.],[length,10.,5.])
                          for c,d in zip(points,points[1:])))
    return best
