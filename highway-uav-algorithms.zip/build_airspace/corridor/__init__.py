"""Corridor designs and shared graph construction for airspace experiments."""

AVAILABLE_CORRIDOR_RULES = {
    "adaptive_mission_layers": "build_airspace.corridor.adaptive_mission_layers",
}

__all__ = ["AVAILABLE_CORRIDOR_RULES"]
