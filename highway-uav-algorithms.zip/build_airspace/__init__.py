"""Airspace geometry support."""
