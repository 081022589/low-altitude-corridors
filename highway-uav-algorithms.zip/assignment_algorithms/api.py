"""One experiment-facing interface for ECJA and external assignment methods."""
from __future__ import annotations

from ecja_qsap.algorithm import ECJAInput, ECJAOutput, assign_ecja, assign_with_algorithm
from .access_cost_greedy import AccessCostGreedy
from .contracts import AssignmentAlgorithm

AssignmentInput = ECJAInput
AssignmentOutput = ECJAOutput
_algorithms: dict[str, AssignmentAlgorithm] = {AccessCostGreedy.policy: AccessCostGreedy()}


def register_assignment_algorithm(algorithm: AssignmentAlgorithm) -> None:
    """Register an external policy once per process, before running an experiment."""
    if algorithm.policy in {"ECJA_QSAP", "ECJA_QSAP_B0", "UNARY_GREEDY"} or algorithm.policy in _algorithms:
        raise ValueError(f"ASSIGNMENT_POLICY_ALREADY_DEFINED_OR_RETIRED:{algorithm.policy}")
    if not algorithm.policy or algorithm.objective_profile not in {"B0", "V3_CORE"}:
        raise ValueError("INVALID_ASSIGNMENT_ALGORITHM_DEFINITION")
    if not callable(algorithm.select):
        raise ValueError("ASSIGNMENT_SELECTOR_REQUIRED")
    _algorithms[algorithm.policy] = algorithm


def assign_nodes(inputs: AssignmentInput, *, algorithm: AssignmentAlgorithm | None = None,
                 _compatibility_override=None) -> AssignmentOutput:
    """Replace a strategy here, without changing candidates or runtime commit.

    External implementations supply policy, objective_profile and select().
    Unknown/retired names fail explicitly; no alias to historical algorithms.
    """
    if algorithm is None and inputs.policy in {"ECJA_QSAP", "ECJA_QSAP_B0"}:
        return assign_ecja(inputs, _compatibility_override=_compatibility_override)
    if algorithm is None:
        algorithm = _algorithms.get(inputs.policy)
    if algorithm is None:
        raise ValueError(f"UNKNOWN_ASSIGNMENT_POLICY:{inputs.policy}")
    if inputs.policy != algorithm.policy:
        raise ValueError("ASSIGNMENT_ALGORITHM_POLICY_MISMATCH")
    return assign_with_algorithm(inputs, algorithm=algorithm,
                                 _compatibility_override=_compatibility_override)
