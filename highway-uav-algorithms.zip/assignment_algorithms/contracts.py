"""Selection interface shared by external assignment algorithms."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Mapping, Protocol, TYPE_CHECKING

if TYPE_CHECKING:
    from ecja_qsap.algorithm import ECJAInput


@dataclass(frozen=True)
class Selection:
    candidate_ids: Mapping[str, str]
    algorithm_version: str
    diagnostics: Mapping[str, Any] = field(default_factory=dict)


class AssignmentAlgorithm(Protocol):
    """Choose one legal candidate per admitted UAV, without committing state.

    The shared pipeline prepares the declared objective profile and validates
    selections. Implementations must not mutate the input or prepared model.
    """
    policy: str
    objective_profile: str

    def select(self, model: Mapping[str, Any], inputs: ECJAInput) -> Selection: ...
