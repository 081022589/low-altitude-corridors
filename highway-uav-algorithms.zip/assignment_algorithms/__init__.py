"""Independent assignment implementations; use assignment_algorithms.api.assign_nodes."""
