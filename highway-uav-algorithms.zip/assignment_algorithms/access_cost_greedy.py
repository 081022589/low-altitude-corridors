"""Request-time ordered J0 greedy, with residual K-feasibility protection."""
from __future__ import annotations

import math
from typing import Any, Mapping

from ecja_qsap.load_balance import remaining_assignment_feasible
from .contracts import Selection


class AccessCostGreedy:
    policy = "ACCESS_COST_GREEDY_V1"
    objective_profile = "B0"

    def select(self, model: Mapping[str, Any], inputs) -> Selection:
        times = inputs.request_created_times_s
        now = {r.uav_id: r.snapshot_time_s for r in inputs.current_batch_requests}
        for uid in model["uavs"]:
            if uid not in times or not math.isfinite(float(times[uid])):
                raise ValueError(f"REQUEST_CREATION_TIME_REQUIRED:{uid}")
            if float(times[uid]) > float(now[uid]):
                raise ValueError(f"REQUEST_CREATION_TIME_IN_FUTURE:{uid}")
        order = sorted(model["uavs"], key=lambda uid: (float(times[uid]), uid))
        costs = model["linear_access_cost"]
        cap = model.get("peak_load_cap_effective")
        keys = model.get("candidate_to_load_key", {})
        counts: dict[str, int] = {}
        chosen: dict[str, str] = {}
        for index, uid in enumerate(order):
            candidates = model["candidate_ids_by_uav"][uid]
            if any(not math.isfinite(float(costs[c])) for c in candidates):
                raise ValueError("NONFINITE_ACCESS_COST")
            for candidate in sorted(candidates, key=lambda c: (float(costs[c]), c)):
                if cap is not None:
                    key = keys[candidate]
                    if counts.get(key, 0) >= cap:
                        continue
                    trial = dict(counts)
                    trial[key] = trial.get(key, 0) + 1
                    if not remaining_assignment_feasible(model, cap, trial, order[index + 1:]):
                        continue
                    counts = trial
                chosen[uid] = candidate
                break
            else:
                raise ValueError("NO_FEASIBLE_GREEDY_ASSIGNMENT")
        return Selection(chosen, self.policy, {
            "request_order": order,
            "capacity_enforced": cap is not None,
            "peak_load_cap_effective": cap,
            "peak_load_cap_status": model.get("peak_load_cap_status"),
            "selected_load_counts": counts if cap is not None else None,
            "score": "J0_ONLY",
            "solver_status": "ACCESS_COST_GREEDY_FEASIBLE",
            "termination_reason": "REQUEST_ORDER_GREEDY_COMPLETE",
        })
