"""Current C-MLPM timing API; runtime motion confirmation precedes publication."""

from .active import solve_cmlpm

__all__ = ["solve_cmlpm"]
