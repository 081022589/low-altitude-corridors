"""Diagnostic certification of a candidate's joint schedule time windows.

The resulting evidence is solver-side diagnostics only. It is not a resource
authorization and is not copied into the formal dispatch record.
"""

from hashlib import sha256
import json
import math
import time

from .schema import descent_entry_event_id


def certify(snapshot, builder, columns, values, event_times, uses, waiting, snapshot_hash):
    started = time.perf_counter()
    identity = sha256(json.dumps([snapshot_hash, event_times, uses, waiting],
                                 sort_keys=True).encode()).hexdigest()
    report = dict(certification_id=identity, snapshot_hash=snapshot_hash,
                  certification_level="JOINT_SCHEDULE_WINDOW_CERTIFIED",
                  window_schema_version="CMLPM_JOINT_WINDOW_V1")
    if getattr(snapshot, 'physical_entry_conditions', ()):
        report.update(execution_contract_version=snapshot.execution_contract_version,
            physical_entry_condition_ids=[c.condition_id for c in snapshot.physical_entry_conditions],
            observation_slots={name:float(values[i]) for i,name in enumerate(builder.names) if name.startswith('o:CPFF:')})
    try:
        report.update(_windows(snapshot, builder, columns, values, event_times, uses))
    except ValueError as error:
        report.update(status="UNAVAILABLE", failure_code=str(error))
        report.pop("certification_level")
    report.update(certification_seconds=time.perf_counter() - started,
                  waiting_uav_ids=waiting)
    return report


def _windows(snapshot, builder, columns, values, event_times, uses):
    active = {columns[event]: event for event in event_times}
    graph = {event: [] for event in event_times}
    edges = [(a.predecessor_id, a.successor_id, a.travel_min)
             for a in snapshot.arcs if a.travel_min == a.travel_max]
    for left, right, offset in edges:
        if left in graph and right in graph:
            graph[left].append((right, offset))
            graph[right].append((left, -offset))

    groups, bounds = {}, {}
    tolerance = snapshot.tolerance
    for anchor in sorted(graph):
        if anchor in groups:
            continue
        groups[anchor] = (anchor, 0.)
        stack = [anchor]
        low, high = -math.inf, math.inf
        while stack:
            event = stack.pop()
            offset = groups[event][1]
            nominal = event_times[anchor] + offset
            if abs(nominal - event_times[event]) > tolerance:
                raise ValueError("ANCHOR_MAPPING_FAILED")
            idx = columns[event]
            low = max(low, builder.lb[idx] - event_times[event])
            high = min(high, builder.ub[idx] - event_times[event])
            for neighbor, delta in graph[event]:
                candidate = offset + delta
                if neighbor not in groups:
                    groups[neighbor] = (anchor, candidate)
                    stack.append(neighbor)
                elif abs(groups[neighbor][1] - candidate) > tolerance:
                    raise ValueError("ANCHOR_MAPPING_FAILED")
        if low > tolerance or high < -tolerance:
            raise ValueError("NOMINAL_WITNESS_FAILED")
        bounds[anchor] = (min(0., low), max(0., high))

    # Substitute the exact incumbent for binary and inactive columns. A row
    # involving an objective auxiliary is a delay definition in this model.
    aux = {i for i, name in enumerate(builder.names) if name.startswith(("dV:", "dH:"))}
    rows = []
    for coeff, lower, upper in zip(builder.rows, builder.row_lb, builder.row_ub):
        if aux.intersection(coeff):
            continue
        by_anchor = {}
        for idx, factor in coeff.items():
            if idx in active:
                anchor = groups[active[idx]][0]
                by_anchor[anchor] = by_anchor.get(anchor, 0.) + factor
        center = math.fsum(factor * values[idx] for idx, factor in coeff.items())
        # Paired one-column bounds (including policy and frozen events) pin
        # the corresponding side before applying the common expansion.
        if len(by_anchor) == 1:
            anchor, factor = next(iter(by_anchor.items()))
            if factor:
                left, right = sorted(((lower-center)/factor, (upper-center)/factor))
                low, high = bounds[anchor]
                bounds[anchor] = max(low, min(0., left)), min(high, max(0., right))
        rows.append((by_anchor, center-lower, upper-center))

    alpha = 1.
    limits = []
    for coeff, lower_margin, upper_margin in rows:
        low = math.fsum(factor * bounds[anchor][factor < 0] for anchor, factor in coeff.items())
        high = math.fsum(factor * bounds[anchor][factor >= 0] for anchor, factor in coeff.items())
        for margin, growth in ((lower_margin, -low), (upper_margin, high)):
            if margin < -tolerance:
                raise ValueError("NOMINAL_WITNESS_FAILED")
            if growth > 0:
                alpha = min(alpha, max(0., margin) / growth)
            limits.append((margin, growth))
    minimum = min((m - alpha*g for m, g in limits), default=math.inf)
    if minimum < -tolerance:
        raise ValueError("NUMERICAL_CERTIFICATION_FAILED")

    events = {}
    for event, (anchor, offset) in groups.items():
        low, high = bounds[anchor]
        nominal = event_times[event]
        events[event] = dict(anchor_event_id=anchor, offset_s=offset,
                             nominal_time_s=nominal, window_lb_s=nominal+alpha*low,
                             window_ub_s=nominal+alpha*high)
    resources = []
    use_by_id = {use.use_id: use for use in snapshot.resource_uses}
    for use in uses:
        if use.get("frozen"):
            continue
        spec = use_by_id[use["use_id"]]
        event = events[spec.anchor_event_id]
        resources.append(dict(use, anchor_event_id=event["anchor_event_id"],
            entry_window_lb_s=event["window_lb_s"]+spec.start_offset,
            entry_window_ub_s=event["window_ub_s"]+spec.start_offset,
            exit_window_lb_s=event["window_lb_s"]+spec.end_offset,
            exit_window_ub_s=event["window_ub_s"]+spec.end_offset))
    positive = any(w["window_lb_s"] < w["window_ub_s"] for w in events.values())
    return dict(status="CERTIFIED_POSITIVE_WIDTH" if positive else "CERTIFIED_ZERO_WIDTH",
                expansion_alpha=alpha, event_windows=events, resource_windows=resources,
                anchor_count=len(bounds), constraint_count=len(rows),
                minimum_constraint_margin=minimum if math.isfinite(minimum) else None)
