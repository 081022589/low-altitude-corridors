"""Reconstruct necessary event relations from the declared physical state.

FIFO is a separate zero-gap order. These bounds do not certify continuous motion.
"""
from __future__ import annotations
from dataclasses import dataclass
import math

VERSION = "DYNAMIC_FOLLOWING_EVENT_DOMAIN_V2"


@dataclass(frozen=True)
class FollowingAircraft:
    uav_id: str
    lane_id: str
    direction: str
    layer: str
    position_m: float
    speed_mps: float
    motion_version: str
    vmax_mps: float
    braking_mps2: float
    e_station_m: float | None = None
    e_entry_speed_mps: float | None = None
    published_e_time_s: float | None = None
    resource_entry_station_m: float | None = None


@dataclass(frozen=True)
class FollowingDomain:
    state_version: int
    observed_at_s: float
    valid_until_s: float
    min_gap_m: float
    aircraft: tuple[FollowingAircraft, ...]
    version: str = VERSION


@dataclass(frozen=True)
class MainlineFIFO:
    leader_id: str
    follower_id: str
    leader_event_id: str
    follower_event_id: str


def optimistic_clearance_s(distance_m, *, vmax, braking, terminal_speed):
    values = (distance_m, vmax, braking)
    if not all(math.isfinite(v) for v in values) or distance_m < 0 or min(vmax, braking) <= 0:
        raise ValueError("INVALID_FOLLOWING_CLEARANCE_INPUT")
    if terminal_speed is None:
        return distance_m / vmax
    if not math.isfinite(terminal_speed) or not 0 < terminal_speed <= vmax:
        raise ValueError("INVALID_FOLLOWING_TERMINAL_SPEED")
    peak = min(vmax, math.sqrt(terminal_speed**2 + 2 * braking * distance_m))
    brake_distance = (peak**2 - terminal_speed**2) / (2 * braking)
    return (peak - terminal_speed) / braking + max(0., distance_m - brake_distance) / peak


def lane(row):
    return row.lane_id, row.direction, row.layer


def derive_conditions(domain, events, descents, resource_uses):
    """One deterministic, curve-independent contract for every applicable pair."""
    from .schema import FollowingTimeCondition
    rows = {a.uav_id: a for a in domain.aircraft}
    event_ids = {e.event_id for e in events}
    from .schema import descent_entry_event_id
    departures = {d.uav_id: descent_entry_event_id(d) for d in descents
                  if descent_entry_event_id(d) is not None}
    entries = {u.uav_id: u.anchor_event_id for u in resource_uses if u.role == "M"}
    entries.update({e.uav_id: e.event_id for e in events
                    if getattr(e, "phase", None) == "MAINLINE" and getattr(e, "resource_id", None) is not None})
    targets = [(uid, eid, rows[uid].e_station_m, rows[uid].e_entry_speed_mps)
               for uid, eid in departures.items()]
    targets += [(uid, eid, rows[uid].resource_entry_station_m, None) for uid, eid in entries.items()]
    conditions = []
    for uid, event_id, destination, terminal in targets:
        follower = rows[uid]
        for leader in rows.values():
            if lane(leader) != lane(follower) or (-leader.position_m, leader.uav_id) >= (-follower.position_m, uid):
                continue
            published = None
            if leader.uav_id in departures:
                leader_event, station, kind = departures[leader.uav_id], leader.e_station_m, "MAINLINE_RESOURCE_ENTRY"
            elif leader.published_e_time_s is not None:
                leader_event, station, kind = None, leader.e_station_m, "MAINLINE_RESOURCE_ENTRY"
                published = leader.published_e_time_s
            elif leader.uav_id in entries:
                leader_event, station, kind = entries[leader.uav_id], leader.resource_entry_station_m, "MAINLINE_RESOURCE_ENTRY"
            else:
                continue  # Unscheduled H/waiting remains in the physical domain.
            if destination is None or station is None or (leader_event is not None and leader_event not in event_ids):
                raise ValueError("FOLLOWING_EVENT_GEOMETRY_MISSING")
            distance = domain.min_gap_m + destination - station
            if distance <= 0:
                continue
            bound = optimistic_clearance_s(distance, vmax=follower.vmax_mps,
                                           braking=follower.braking_mps2, terminal_speed=terminal)
            conditions.append(FollowingTimeCondition(
                condition_id=f"FOLLOW:{leader.uav_id}:{event_id}", leader_id=leader.uav_id,
                follower_id=uid, follower_event_id=event_id, minimum_travel_s=bound,
                leader_event_id=leader_event, published_leader_time_s=published,
                state_version=domain.state_version, lane_id=leader.lane_id,
                leader_motion_version=leader.motion_version, valid_until_s=domain.valid_until_s,
                proof_kind="OPTIMISTIC_DEPARTURE_NECESSARY" if kind == "MAINLINE_DEPARTURE" else "OPTIMISTIC_MAINLINE_EVENT_NECESSARY",
                evidence={"leader_event_station_m": station, "leader_event_kind": kind,
                    "target_station_m": destination, "distance_after_departure_m": distance,
                    "min_gap_m": domain.min_gap_m, "vmax_mps": follower.vmax_mps,
                    "braking_mps2": follower.braking_mps2, "e_entry_speed_mps": terminal,
                    "initial_speed_relaxed": True, "observed_follower_position_m": follower.position_m,
                    "observed_follower_speed_mps": follower.speed_mps,
                    "scope": "SAME_DIRECTED_MAINLINE_UNTIL_EVENT_OR_DEPARTURE",
                    "certification_level": "NECESSARY_ONLY"}))
    return tuple(conditions)


def validate_domain(snapshot):
    from .schema import ContractError
    def reject(detail):
        raise ContractError("DYNAMIC_MODEL_INCOMPLETE", detail)
    domain = snapshot.following_domain
    if domain is None or domain.version != VERSION:
        reject("current following_domain is required")
    if (type(domain.state_version) is not int or domain.state_version != snapshot.metadata.get("state_version")
            or domain.observed_at_s != snapshot.t_now or domain.valid_until_s < (
                snapshot.t_clear if snapshot.t_clear is not None else
                max((event.time_ub for event in snapshot.events), default=snapshot.t_now))
            or not all(math.isfinite(v) for v in (domain.observed_at_s, domain.valid_until_s, domain.min_gap_m))
            or domain.min_gap_m < 50.):
        reject("invalid following domain version, horizon or distance")
    ids = set()
    for row in domain.aircraft:
        values = (row.position_m, row.speed_mps, row.vmax_mps, row.braking_mps2)
        optional = (row.e_station_m, row.e_entry_speed_mps, row.published_e_time_s, row.resource_entry_station_m)
        if (not row.uav_id or row.uav_id in ids or not row.lane_id or not row.motion_version
                or row.direction not in {"forward", "reverse"} or row.layer not in {"L1", "L2", "L3"}
                or not all(math.isfinite(v) for v in values)
                or any(v is not None and not math.isfinite(v) for v in optional)
                or row.speed_mps < 0 or min(row.vmax_mps, row.braking_mps2) <= 0
                or (row.e_entry_speed_mps is not None and not 0 < row.e_entry_speed_mps <= row.vmax_mps)
                or (row.published_e_time_s is not None and row.e_station_m is None)):
            reject(f"invalid physical aircraft: {row.uav_id}")
        ids.add(row.uav_id)
    required_ids = {d.uav_id for d in snapshot.descents} | {h.uav_id for h in snapshot.mainline_flows}
    if not required_ids <= ids:
        reject("physical aircraft missing for scheduled or waiting requests")
    rows = {r.uav_id: r for r in domain.aircraft}
    for d in snapshot.descents:
        if rows[d.uav_id].e_station_m is None or rows[d.uav_id].e_entry_speed_mps is None:
            reject(f"descent terminal geometry missing: {d.uav_id}")
        if rows[d.uav_id].published_e_time_s is not None:
            reject(f"published departure cannot re-enter decisions: {d.uav_id}")
    try:
        expected = {c.condition_id: c for c in derive_conditions(domain, snapshot.events, snapshot.descents, snapshot.resource_uses)}
    except (KeyError, ValueError, TypeError) as error:
        reject(str(error))
    actual = {c.condition_id: c for c in snapshot.following_time_conditions}
    if len(actual) != len(snapshot.following_time_conditions) or set(actual) != set(expected):
        reject("missing, duplicate or unexpected following time conditions")
    for cid, reference in expected.items():
        item = actual[cid]
        identity = ("leader_id", "follower_id", "follower_event_id", "leader_event_id", "published_leader_time_s",
                    "state_version", "lane_id", "leader_motion_version", "valid_until_s", "proof_kind")
        if (any(getattr(item, k) != getattr(reference, k) for k in identity)
                or not math.isclose(item.minimum_travel_s, reference.minimum_travel_s, rel_tol=1e-12, abs_tol=1e-10)
                or dict(item.evidence) != dict(reference.evidence)):
            reject(f"following condition disagrees with physical derivation: {cid}")
    # FIFO covers every pair at the same physical resource entry, independently
    # of the positive, capability-derived following time bounds above.
    uses = [(e.uav_id, e.event_id, e.resource_id) for e in snapshot.events
            if e.phase == "MAINLINE" and e.resource_id is not None]
    expected_fifo = set()
    for leader in uses:
        for follower in uses:
            a, b = rows[leader[0]], rows[follower[0]]
            if (leader[2] == follower[2] and lane(a) == lane(b)
                    and (-a.position_m, a.uav_id) < (-b.position_m, b.uav_id)):
                expected_fifo.add((a.uav_id, b.uav_id, leader[1], follower[1]))
    actual_fifo = [(f.leader_id, f.follower_id, f.leader_event_id, f.follower_event_id) for f in snapshot.mainline_fifo]
    if len(actual_fifo) != len(set(actual_fifo)) or set(actual_fifo) != expected_fifo:
        reject(f"mainline FIFO coverage mismatch: expected={sorted(expected_fifo)!r}, actual={actual_fifo!r}")
