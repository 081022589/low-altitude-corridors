"""Numerical certification for the unchanged C-MLPM mathematical model.

HiGHS presolve has produced wrong optimality claims on recorded conditional
models. Disable it uniformly; never infer an objective proof from feasibility.
"""
import math
import time
import warnings
import numpy as np
from scipy.optimize import Bounds,LinearConstraint,OptimizeResult

NUMERICAL_POLICY_ID='CMLPM_NO_PRESOLVE_CONSTANT_ROW_CERTIFIED_V2_20261028'
MATRIX_TOL=1e-8

def objective_tolerance(a,b):return max(1e-5,1e-7*max(abs(a),abs(b)))

def solve(b,objective,*,time_limit,milp):
    deadline=time.perf_counter()+time_limit
    # Fixed-event substitution can leave 0 >= 1. With presolve disabled,
    # HiGHS may return Unknown on precisely this trivially infeasible model.
    # Certify the contradiction directly, without changing any constraint or
    # interpreting an arbitrary backend failure as mathematical infeasibility.
    for i,(row,lower,upper) in enumerate(zip(b.rows,b.row_lb,b.row_ub)):
        if not any(row.values()) and (lower>MATRIX_TOL or upper < -MATRIX_TOL):
            return OptimizeResult(status=2,x=None,message=f'CONTRADICTORY_CONSTANT_ROW:{i}',
                numerical_policy=NUMERICAL_POLICY_ID,numerical_status='PROVEN_INFEASIBLE_CONSTANT_ROW',
                infeasibility_certificate=dict(row=i,constant=0.,
                    lower=lower if math.isfinite(lower) else None,
                    upper=upper if math.isfinite(upper) else None))
    matrix=b.arrays();row_lo=np.asarray(b.row_lb);row_hi=np.asarray(b.row_ub)
    lo=np.asarray(b.lb);hi=np.asarray(b.ub);integer=np.asarray(b.integrality)
    constraints=LinearConstraint(matrix,row_lo,row_hi)
    remaining=deadline-time.perf_counter()
    if remaining<=0:
        return OptimizeResult(status=1,x=None,message='BUDGET_EXHAUSTED_BEFORE_OPTIMIZER',
            numerical_status='NO_INCUMBENT_BUDGET')
    options=dict(time_limit=max(.0001,remaining-min(.05,.05*remaining)),mip_rel_gap=0.,presolve=False,
        mip_feasibility_tolerance=1e-9,primal_feasibility_tolerance=1e-9,dual_feasibility_tolerance=1e-9)
    def call(bounds,integrality,opts):
        with warnings.catch_warnings():
            warnings.filterwarnings('ignore',message='Unrecognized options detected:.*',category=RuntimeWarning)
            return milp(c=objective,integrality=integrality,bounds=bounds,constraints=constraints,options=opts)
    result=call(Bounds(lo,hi),integer,options)
    result.numerical_policy=NUMERICAL_POLICY_ID
    if result.x is None:
        result.numerical_status='PROVEN_INFEASIBLE_NO_PRESOLVE' if result.status==2 else 'NO_INCUMBENT'
        return result
    original_status=int(result.status)
    bound=getattr(result,'mip_dual_bound',None)
    if bound is None and result.status==0:bound=float(result.fun)
    values=np.asarray(result.x).copy();mask=integer!=0
    values[mask]=np.rint(values[mask])
    def violation(x):
        if not np.all(np.isfinite(x)):return math.inf
        rows=matrix@x
        return max(0.,float(np.max(lo-x,initial=0.)),float(np.max(x-hi,initial=0.)),
            float(np.max(row_lo-rows,initial=0.)),float(np.max(rows-row_hi,initial=0.)))
    residual=violation(values)
    polish_status=None
    if residual>MATRIX_TOL:
        remaining=deadline-time.perf_counter()
        if remaining<=0:
            result.x=None;result.status=1;result.numerical_status='NUMERICAL_CANDIDATE_REJECTED_BUDGET'
            return result
        fixed_lo=lo.copy();fixed_hi=hi.copy()
        fixed_lo[mask]=fixed_hi[mask]=values[mask]
        polished=call(Bounds(fixed_lo,fixed_hi),np.zeros(len(integer)),
            dict(options,presolve=False,time_limit=remaining))
        polish_status=int(polished.status)
        if polished.x is None or violation(polished.x)>MATRIX_TOL:
            result.x=None;result.status=1;result.numerical_status='NUMERICAL_CANDIDATE_REJECTED'
            return result
        values=np.asarray(polished.x);residual=violation(values)
    cost=float(np.dot(objective,values))
    valid_bound=bound is not None and math.isfinite(bound) and bound<=cost+objective_tolerance(cost,bound)
    proved=original_status==0 and (polish_status in (None,0)) and valid_bound and abs(cost-bound)<=objective_tolerance(cost,bound)
    result.x=values;result.fun=cost;result.status=0 if proved else 1
    result.mip_dual_bound=bound if valid_bound else None
    result.mip_gap=None if not valid_bound else max(0.,(cost-bound)/max(abs(cost),1e-12))
    result.numerical_status='CERTIFIED_OPTIMAL_WITHIN_TOLERANCE' if proved else 'CERTIFIED_FEASIBLE_PROOF_INCOMPLETE'
    result.numerical_max_residual=residual
    result.numerical_polish_status=polish_status
    return result
