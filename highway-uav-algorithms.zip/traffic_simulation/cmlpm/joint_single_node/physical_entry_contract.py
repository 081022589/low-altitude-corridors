"""CPFF-1.1 necessary event conditions, never a resource release token."""
from __future__ import annotations
from dataclasses import dataclass
import math

VERSION='CPFF-1.1'
PROOF='SYMMETRIC_MAX_ENTRY_STOP_RECOVERY_V1'

@dataclass(frozen=True)
class PhysicalEntryCondition:
    condition_id:str
    h_use_id:str
    entry_speed_mps:float
    max_speed_mps:float
    acceleration_mps2:float
    braking_mps2:float
    resource_length_m:float
    entry_station_m:float
    stop_station_m:float
    observation_dt_s:float
    observation_origin_s:float
    state_version:int
    model_signature:str
    v_use_id:str|None=None
    v_reservation_id:str|None=None
    proof_kind:str=PROOF

    @property
    def recovery_s(self):
        v,b=self.entry_speed_mps,self.braking_mps2
        epsilon=self.entry_station_m-self.stop_station_m
        return (v-math.sqrt(v*v/2-b*epsilon))/b

    def observed_at(self,exit_time):
        # Same future-event band as the measured executor; never an actual event.
        k=math.ceil((exit_time-self.observation_origin_s-1e-9)/self.observation_dt_s)
        return self.observation_origin_s+k*self.observation_dt_s


def validate_conditions(snapshot):
    from .schema import ContractError
    conditions=snapshot.physical_entry_conditions
    if not conditions:
        if snapshot.execution_contract_version not in (None,VERSION):
            raise ContractError('UNSUPPORTED_EXECUTION_CONTRACT',str(snapshot.execution_contract_version))
        return
    def reject(detail):
        raise ContractError('UNSUPPORTED_DOMAIN',detail)
    if snapshot.execution_contract_version!=VERSION:
        reject('physical entry contract version')
    if len({c.condition_id for c in conditions})!=len(conditions):
        reject('duplicate condition identity')
    uses={u.use_id:u for u in snapshot.resource_uses}
    frozen={u.reservation_id:u for u in snapshot.frozen_reservations}
    aircraft={a.uav_id:a for a in snapshot.following_domain.aircraft}
    for c in conditions:
        values=(c.entry_speed_mps,c.max_speed_mps,c.acceleration_mps2,c.braking_mps2,
                c.resource_length_m,c.entry_station_m,c.stop_station_m,c.observation_dt_s,c.observation_origin_s)
        if not all(isinstance(v,(int,float)) and math.isfinite(v) for v in values):
            reject('nonfinite condition')
        if (c.proof_kind!=PROOF or not c.model_signature or not c.condition_id
                or c.state_version!=snapshot.following_domain.state_version
                or min(c.entry_speed_mps,c.acceleration_mps2,c.braking_mps2,c.resource_length_m,c.observation_dt_s)<=0
                or abs(c.entry_speed_mps-c.max_speed_mps)>1e-8
                or abs(c.acceleration_mps2-c.braking_mps2)>1e-8
                or abs(c.entry_station_m-c.stop_station_m-1e-6)>1e-9
                or c.entry_speed_mps**2/2<=c.braking_mps2*(c.entry_station_m-c.stop_station_m)
                or bool(c.v_use_id)==bool(c.v_reservation_id)):
            reject('proof assumptions')
        h=uses.get(c.h_use_id)
        v=uses.get(c.v_use_id) if c.v_use_id else frozen.get(c.v_reservation_id)
        if (h is None or v is None or h.role!='M' or v.role!='V'
                or h.resource_id!=v.resource_id or h.uav_id==v.uav_id):
            reject('resource identities')
        a=aircraft.get(h.uav_id)
        if (a is None or abs(a.vmax_mps-c.max_speed_mps)>1e-8
                or abs(a.braking_mps2-c.braking_mps2)>1e-8
                or a.resource_entry_station_m is None
                or abs(a.resource_entry_station_m-c.entry_station_m)>1e-6
                or abs(c.resource_length_m/(h.end_offset-h.start_offset)-c.entry_speed_mps)>1e-7):
            reject('motion or terminal contract mismatch')


def compile_conditions(snapshot,b,x,order,active,restrictions):
    uses={u.use_id:u for u in snapshot.resource_uses}
    frozen={u.reservation_id:u for u in snapshot.frozen_reservations}
    for c in snapshot.physical_entry_conditions:
        h=uses[c.h_use_id]
        guards=active(h.uav_id)
        if c.v_use_id:
            v=uses[c.v_use_id]
            guards=active(h.uav_id,v.uav_id)
            key=f'VH:{v.use_id}:{h.use_id}'
            fixed=(restrictions.fixed_vh_orders or {}).get((v.use_id,h.use_id))
            if fixed=='M_FIRST':continue
            if fixed!='V_FIRST':
                if key in order:guards+=((order[key],1),)
                elif b.ub[x[v.anchor_event_id]]+v.end_offset<=b.lb[x[h.anchor_event_id]]+h.start_offset:
                    pass
                elif b.ub[x[h.anchor_event_id]]+h.end_offset<=b.lb[x[v.anchor_event_id]]+v.start_offset:
                    continue
                else:raise ValueError('CPFF_ORDER_GUARD_MISSING')
            exit_coeff={x[v.anchor_event_id]:1.}
            offset=v.end_offset
            lower=b.lb[x[v.anchor_event_id]]+offset
            upper=b.ub[x[v.anchor_event_id]]+offset
        else:
            v=frozen[c.v_reservation_id]
            key=f'FROZEN:{h.use_id}:{v.reservation_id}'
            if key in order:guards+=((order[key],0),)
            elif v.occupancy_end<=b.lb[x[h.anchor_event_id]]+h.start_offset:pass
            elif b.ub[x[h.anchor_event_id]]+h.end_offset<=v.occupancy_start:continue
            else:raise ValueError('CPFF_ORDER_GUARD_MISSING')
            exit_coeff={};offset=v.occupancy_end
            lower=upper=offset
        dt,origin=c.observation_dt_s,c.observation_origin_s
        k=b.var('o:CPFF:'+c.condition_id,math.floor((lower-origin)/dt),math.ceil((upper-origin)/dt),True)
        b.imply_ge({k:dt,**{i:-value for i,value in exit_coeff.items()}},offset-origin-1e-9,guards)
        b.imply_ge({x[h.anchor_event_id]:1.,k:-dt},origin+c.recovery_s-h.start_offset,guards)


def check_conditions(snapshot,result,is_active,add):
    """Recompute from event facts and input identities, not solver columns."""
    uses={u.use_id:u for u in snapshot.resource_uses}
    frozen={u.reservation_id:u for u in snapshot.frozen_reservations}
    for c in snapshot.physical_entry_conditions:
        h=uses[c.h_use_id]
        if not is_active(h.uav_id):continue
        h_in=result.event_times[h.anchor_event_id]+h.start_offset
        if c.v_use_id:
            v=uses[c.v_use_id]
            if not is_active(v.uav_id):continue
            v_in=result.event_times[v.anchor_event_id]+v.start_offset
            v_out=result.event_times[v.anchor_event_id]+v.end_offset
        else:
            v=frozen[c.v_reservation_id]
            v_in,v_out=v.occupancy_start,v.occupancy_end
        # Existing independent resource checks reject contradictory order/overlap.
        if h_in<v_in-snapshot.tolerance:continue
        required=c.observed_at(v_out)+c.recovery_s
        if h_in<required-snapshot.tolerance:
            add('CPFF_RECOVERY_BOUND',condition_id=c.condition_id,actual=h_in,required=required)
