from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
import math

from .schema import (NodeSnapshot, waiting_delay_proxy, timing_owner,
                     descent_entry_event_id)
from .milp_reference import SolveResult
from .conflict_builder import (
    SHARED_RESOURCE_ENTRY_HEADWAY_S,
    build_frozen_vv_merge_conflicts,
    build_vv_merge_conflicts,
    is_cross_layer_vh_frozen,
    is_cross_layer_vh_use,
)


@dataclass(frozen=True)
class CheckReport:
    passed: bool
    violations: tuple[dict, ...]
    audit_counts: dict[str, int]


def _rebuilt_occupancies(snapshot: NodeSnapshot, result: SolveResult) -> list[dict]:
    rebuilt: list[dict] = []
    for use in snapshot.resource_uses:
        if snapshot.waiting_policy is not None and not result.candidate_completion.get(timing_owner(snapshot, use.uav_id), 1):
            continue
        anchor = result.event_times[use.anchor_event_id]
        rebuilt.append({"use_id": use.use_id, "uav_id": use.uav_id,
                        "resource_id": use.resource_id, "role": use.role,
                        "source_layer": use.source_layer,
                        "start": anchor + use.start_offset, "end": anchor + use.end_offset})
    for frozen in snapshot.frozen_reservations:
        rebuilt.append({"use_id": frozen.reservation_id, "uav_id": frozen.uav_id,
                        "resource_id": frozen.resource_id, "role": frozen.role,
                        "source_layer": frozen.source_layer,
                        "start": frozen.occupancy_start, "end": frozen.occupancy_end,
                        "frozen": True})
    return rebuilt


def historical_frozen_conflicts(snapshot: NodeSnapshot) -> tuple[dict, ...]:
    """Diagnose conflicts between immutable historical resource reservations."""

    conflicts: list[dict] = []
    for first, second in combinations(snapshot.frozen_reservations, 2):
        if first.resource_id != second.resource_id or first.role == second.role:
            continue
        vertical, mainline = (
            (first, second) if first.role == "V" else (second, first)
        )
        if not is_cross_layer_vh_frozen(vertical, mainline):
            continue
        separation = snapshot.vh_separation[vertical.resource_id]
        vh_safe = (
            vertical.occupancy_end + separation.first_to_second <= mainline.occupancy_start + snapshot.tolerance
            or mainline.occupancy_end + separation.second_to_first <= vertical.occupancy_start + snapshot.tolerance
        )
        earlier, later = (
            (first, second)
            if first.occupancy_start <= second.occupancy_start
            else (second, first)
        )
        headway = later.occupancy_start - earlier.occupancy_start
        if not vh_safe:
            conflicts.append({
                "code": "HISTORICAL_FROZEN_RESOURCE_CONFLICT",
                "conflict_type": "VH_SEPARATION",
                "first": first.reservation_id,
                "second": second.reservation_id,
                "resource_id": first.resource_id,
            })
        if headway < SHARED_RESOURCE_ENTRY_HEADWAY_S - snapshot.tolerance:
            conflicts.append({
                "code": "HISTORICAL_FROZEN_RESOURCE_CONFLICT",
                "conflict_type": "ENTRY_HEADWAY",
                "first": earlier.reservation_id,
                "second": later.reservation_id,
                "resource_id": first.resource_id,
                "actual": headway,
                "required": SHARED_RESOURCE_ENTRY_HEADWAY_S,
            })
    return tuple(conflicts)


def check_solution(snapshot: NodeSnapshot, result: SolveResult) -> CheckReport:
    from ..active.contract_validation import validate_complete_snapshot
    validate_complete_snapshot(snapshot)
    if not result.event_times and not (snapshot.waiting_policy is not None and result.candidate_completion):
        return CheckReport(False, ({"code": "NO_SOLUTION"},), {"NO_SOLUTION": 1})
    tol = snapshot.tolerance
    times, complete = result.event_times, result.candidate_completion
    violations: list[dict] = []

    def add(code: str, **detail): violations.append({"code": code, **detail})

    expected_ids = {item.uav_id for item in snapshot.descents}
    if set(complete) != expected_ids:
        add("COMPLETION_ID_MISMATCH", missing=sorted(expected_ids-set(complete)),
            extra=sorted(set(complete)-expected_ids))
    policy = snapshot.waiting_policy
    pending = {r.uav_id: r for r in policy.requests} if policy else {}

    def is_active(uid):
        return policy is None or complete.get(timing_owner(snapshot, uid), 1) == 1

    for uav_id in sorted(expected_ids):
        if policy is None and complete.get(uav_id) != 1:
            add("ALL_REQUESTS_NOT_SCHEDULED", uav_id=uav_id)
        elif policy is not None:
            if type(complete.get(uav_id)) is not int or complete.get(uav_id) not in (0, 1):
                add("WAITING_DECISION_INVALID", uav_id=uav_id)
            elif not complete[uav_id] and not pending[uav_id].can_hold:
                add("WAITING_NOT_ALLOWED", uav_id=uav_id)
            elif complete[uav_id] and not pending[uav_id].timing_available:
                add("TIMING_CANDIDATE_UNAVAILABLE", uav_id=uav_id)

    if policy is not None:
        scheduled = {uid for uid in expected_ids if complete.get(uid) == 1}
        waiting = expected_ids - scheduled
        if (set(result.input_uav_ids) != expected_ids or len(result.input_uav_ids) != len(expected_ids)
                or set(result.candidate_scheduled_uav_ids) != scheduled or len(result.candidate_scheduled_uav_ids) != len(scheduled)
                or set(result.candidate_waiting_uav_ids) != waiting or len(result.candidate_waiting_uav_ids) != len(waiting)):
            add("RESULT_PARTITION_MISMATCH")
        if result.candidate_requires_hold_certification != bool(waiting):
            add("HOLD_CERTIFICATION_FLAG_MISMATCH")
        if result.candidate_pending_states != {uid: "SCHEDULED" if uid in scheduled else "WAITING" for uid in expected_ids}:
            add("PENDING_STATE_MISMATCH")

    # Reject malformed/nonfinite data before arithmetic; NaN cannot pass by
    # making every inequality false, and missing keys must not raise KeyError.
    expected_event_ids = {e.event_id for e in snapshot.events if is_active(e.uav_id)}
    for event_id in expected_event_ids - set(times):
        add("EVENT_TIME_MISSING", event_id=event_id)
    for event_id in set(times) - expected_event_ids:
        add("EVENT_TIME_EXTRA", event_id=event_id)
    for event_id, value in times.items():
        if not isinstance(value, (int, float)) or not math.isfinite(value):
            add("EVENT_TIME_NONFINITE", event_id=event_id)
    for field in ("v_cost", "h_cost", "joint_cost"):
        value = getattr(result, field)
        if not isinstance(value, (int, float)) or not math.isfinite(value):
            add("OBJECTIVE_NONFINITE", field=field)
    for row in result.resource_occupancies:
        if (any(k not in row for k in ("use_id", "uav_id", "resource_id", "role", "start", "end"))
                or any(not isinstance(row.get(k), (int, float)) or not math.isfinite(row[k])
                       for k in ("start", "end"))):
            add("RESOURCE_USE_INVALID")
    if any(v["code"] in {"EVENT_TIME_MISSING", "EVENT_TIME_EXTRA", "EVENT_TIME_NONFINITE",
                         "OBJECTIVE_NONFINITE", "RESOURCE_USE_INVALID", "COMPLETION_ID_MISMATCH",
                         "WAITING_DECISION_INVALID", "TIMING_CANDIDATE_UNAVAILABLE"} for v in violations):
        counts = {code: sum(v["code"] == code for v in violations) for code in {v["code"] for v in violations}}
        return CheckReport(False, tuple(violations), counts)

    if policy is not None:
        # Reconstruct order identities from the INPUT, not solver variable
        # names/values. Inactive or unknown orders are not timing_certified data.
        order_rules = {}
        descents_by_id = {d.uav_id: d for d in snapshot.descents}
        for pair in snapshot.vv_constraints:
            owners = (pair.first_id, pair.second_id)
            first, second = (descents_by_id[uid] for uid in owners)
            order_rules[f"VV:{pair.first_id}:{pair.second_id}"] = (
                owners, lambda value, p=pair, a=first, b=second:
                (times[descent_entry_event_id(b)]-times[descent_entry_event_id(a)] >= p.first_before_second_gap-tol
                 if value else times[descent_entry_event_id(a)]-times[descent_entry_event_id(b)] >= p.second_before_first_gap-tol))
        for v in snapshot.resource_uses:
            if v.role != "V":
                continue
            for m in snapshot.resource_uses:
                if m.role != "M" or m.resource_id != v.resource_id or v.uav_id == m.uav_id:
                    continue
                if not is_cross_layer_vh_use(v, m):
                    continue
                def vh_order(value, v=v, m=m):
                    sep = snapshot.vh_separation[v.resource_id]
                    va, ma = times[v.anchor_event_id], times[m.anchor_event_id]
                    return ((va+v.end_offset+sep.first_to_second <= ma+m.start_offset+tol
                             and va+v.start_offset+SHARED_RESOURCE_ENTRY_HEADWAY_S <= ma+m.start_offset+tol)
                            if value else
                            (ma+m.end_offset+sep.second_to_first <= va+v.start_offset+tol
                             and ma+m.start_offset+SHARED_RESOURCE_ENTRY_HEADWAY_S <= va+v.start_offset+tol))
                order_rules[f"VH:{v.use_id}:{m.use_id}"] = ((v.uav_id, m.uav_id), vh_order)
        for use in snapshot.resource_uses:
            for frozen in snapshot.frozen_reservations:
                if use.role == frozen.role or use.resource_id != frozen.resource_id or use.uav_id == frozen.uav_id:
                    continue
                    vertical, mainline = (use, frozen) if use.role == "V" else (frozen, use)
                    if not is_cross_layer_vh_frozen(vertical, mainline):
                        continue
                def frozen_order(value, use=use, frozen=frozen):
                    sep = snapshot.vh_separation[use.resource_id]
                    before = sep.first_to_second if use.role == "V" else sep.second_to_first
                    after = sep.second_to_first if use.role == "V" else sep.first_to_second
                    anchor = times[use.anchor_event_id]
                    return ((anchor+use.end_offset+before <= frozen.occupancy_start+tol
                             and anchor+use.start_offset+SHARED_RESOURCE_ENTRY_HEADWAY_S <= frozen.occupancy_start+tol)
                            if value else
                            (frozen.occupancy_end+after <= anchor+use.start_offset+tol
                             and frozen.occupancy_start+SHARED_RESOURCE_ENTRY_HEADWAY_S <= anchor+use.start_offset+tol))
                order_rules[f"FROZEN:{use.use_id}:{frozen.reservation_id}"] = ((use.uav_id,), frozen_order)
        for pair in snapshot.frozen_vv_constraints:
            frozen = next(f for f in snapshot.frozen_reservations if f.reservation_id == pair.frozen_reservation_id)
            d = descents_by_id[pair.new_uav_id]
            order_rules[f"FROZEN_VV:{pair.constraint_id}"] = (
                (pair.new_uav_id,), lambda value, p=pair, f=frozen, d=d:
                (times[descent_entry_event_id(d)]-f.q_reference_time >= p.frozen_to_new_gap-tol
                 if value else f.q_reference_time-times[descent_entry_event_id(d)] >= p.new_to_frozen_gap-tol))
        for key, value in result.orders.items():
            rule = order_rules.get(key)
            if rule is None:
                add("ORDER_ID_UNKNOWN", order=key)
            elif not all(is_active(uid) for uid in rule[0]):
                add("INACTIVE_ORDER_PUBLISHED", order=key)
            elif type(value) is not int or value not in (0, 1) or not rule[1](value):
                add("ORDER_TIMING_MISMATCH", order=key)

    for event in snapshot.events:
        if not is_active(event.uav_id):
            continue
        if event.event_id not in times:
            add("EVENT_TIME_MISSING", event_id=event.event_id); continue
        value = times[event.event_id]
        if value < event.time_lb-tol or value > event.time_ub+tol: add("EVENT_WINDOW", event_id=event.event_id)
        if event.committed_time is not None and abs(value-event.committed_time) > tol: add("FROZEN_EVENT_CHANGED", event_id=event.event_id)
    for arc in snapshot.arcs:
        if not is_active(arc.uav_id):
            continue
        delta = times[arc.successor_id]-times[arc.predecessor_id]
        if delta < arc.travel_min-tol or delta > arc.travel_max+tol: add("E1_CONTINUITY", successor=arc.successor_id, delta=delta)
    desc = {item.uav_id:item for item in snapshot.descents}
    for item in snapshot.descents:
        if not is_active(item.uav_id):
            continue
        anchor = descent_entry_event_id(item)
        if snapshot.t_request is not None and times[descent_entry_event_id(item)]+item.service_offset > snapshot.t_request+tol:
            add("SERVICE_HORIZON", uav_id=item.uav_id)

    queues: dict[str, list] = {}
    for item in snapshot.descents:
        queues.setdefault(item.fifo_queue_id or item.source_layer, []).append(item)
    for queue_id, requests in queues.items():
        requests.sort(key=lambda item: item.fifo_rank)
        for leader, follower in zip(requests, requests[1:]):
            if policy is not None and complete.get(leader.uav_id, 0) < complete.get(follower.uav_id, 0):
                add("FIFO_COMPLETION_PREFIX", queue_id=queue_id, leader_id=leader.uav_id, follower_id=follower.uav_id)
            if not is_active(leader.uav_id) or not is_active(follower.uav_id):
                continue
            if times[descent_entry_event_id(follower)] < times[descent_entry_event_id(leader)]-tol:
                add("FIFO_PASSAGE_ORDER", queue_id=queue_id, leader_id=leader.uav_id,
                    follower_id=follower.uav_id)
    for fifo in snapshot.mainline_fifo:
        if is_active(fifo.leader_id) and is_active(fifo.follower_id):
            if times[fifo.follower_event_id] < times[fifo.leader_event_id]-tol:
                add("MAINLINE_RESOURCE_FIFO", leader=fifo.leader_id, follower=fifo.follower_id)
    for condition in snapshot.following_time_conditions:
        if not is_active(condition.follower_id):
            continue
        if condition.leader_event_id is not None:
            if not is_active(condition.leader_id):
                continue
            leader_time = times[condition.leader_event_id]
        else:
            leader_time = condition.published_leader_time_s
        margin = times[condition.follower_event_id] - leader_time - condition.minimum_travel_s
        if margin < -tol:
            add("DYNAMIC_FOLLOWING_TIME", condition_id=condition.condition_id, margin=margin)
    for item in snapshot.vv_constraints:
        if not is_active(item.first_id) or not is_active(item.second_id):
            continue
        first_q, second_q = (times[descent_entry_event_id(desc[item.first_id])],
                             times[descent_entry_event_id(desc[item.second_id])])
        valid_first = second_q-first_q >= item.first_before_second_gap-tol
        valid_second = first_q-second_q >= item.second_before_first_gap-tol
        if item.fixed_order == item.first_id: valid_second = False
        if item.fixed_order == item.second_id: valid_first = False
        if not (valid_first or valid_second): add("VV_SEPARATION", first=item.first_id, second=item.second_id)
    frozen = {item.reservation_id:item for item in snapshot.frozen_reservations}
    for item in snapshot.frozen_vv_constraints:
        if not is_active(item.new_uav_id):
            continue
        q_f = frozen[item.frozen_reservation_id].q_reference_time
        q_n = times[descent_entry_event_id(desc[item.new_uav_id])]
        frozen_first = q_n-q_f >= item.frozen_to_new_gap-tol
        new_first = q_f-q_n >= item.new_to_frozen_gap-tol
        if item.fixed_order == "frozen": new_first = False
        if item.fixed_order == "new": frozen_first = False
        if not (frozen_first or new_first): add("FROZEN_VV_SEPARATION", constraint_id=item.constraint_id, frozen_q=q_f, new_q=q_n)

    rebuilt = _rebuilt_occupancies(snapshot, result)
    decoded = {item["use_id"]:item for item in result.resource_occupancies}
    expected = {item["use_id"]:item for item in rebuilt}
    if set(decoded) != set(expected):
        add("RESOURCE_USE_MISSING_OR_EXTRA", missing=sorted(set(expected)-set(decoded)), extra=sorted(set(decoded)-set(expected)))
    for use_id in sorted(set(decoded) & set(expected)):
        left, right = decoded[use_id], expected[use_id]
        if (any(left.get(key) != right.get(key) for key in ("uav_id","resource_id","role"))
                or abs(left["start"]-right["start"]) > tol or abs(left["end"]-right["end"]) > tol):
            add("RESOURCE_USE_DECODE_MISMATCH", use_id=use_id)
    for index, first in enumerate(rebuilt):
        for second in rebuilt[index+1:]:
            if first["uav_id"] == second["uav_id"] or first["resource_id"] != second["resource_id"]: continue
            if first["role"] == second["role"]: continue
            vertical, mainline = (first, second) if first["role"] == "V" else (second, first)
            if (vertical.get("source_layer") is not None
                    and mainline.get("source_layer") is not None
                    and vertical["source_layer"] == mainline["source_layer"]):
                continue
            sep = snapshot.vh_separation[first["resource_id"]]
            vertical, mainline = (first,second) if first["role"] == "V" else (second,first)
            safe = (vertical["end"]+sep.first_to_second <= mainline["start"]+tol
                    or mainline["end"]+sep.second_to_first <= vertical["start"]+tol)
            historical_pair = bool(first.get("frozen")) and bool(second.get("frozen"))
            if not safe:
                add(
                    "HISTORICAL_FROZEN_RESOURCE_CONFLICT" if historical_pair else "VH_RESOURCE_CONFLICT",
                    first=first["use_id"], second=second["use_id"],
                    resource_id=first["resource_id"], conflict_type="VH_SEPARATION",
                )
            earlier, later = (first, second) if first["start"] <= second["start"] else (second, first)
            if later["start"]-earlier["start"] < SHARED_RESOURCE_ENTRY_HEADWAY_S-tol:
                add(
                    "HISTORICAL_FROZEN_RESOURCE_CONFLICT" if historical_pair else "SHARED_RESOURCE_HEADWAY_LT_2P5",
                    first=earlier["use_id"], second=later["use_id"],
                    resource_id=first["resource_id"], conflict_type="ENTRY_HEADWAY",
                    actual=later["start"]-earlier["start"],
                    required=SHARED_RESOURCE_ENTRY_HEADWAY_S,
                )
    rebuilt_by_id = {item["use_id"]: item for item in rebuilt}
    for conflict in build_vv_merge_conflicts(snapshot):
        if conflict.first_use_id not in rebuilt_by_id or conflict.second_use_id not in rebuilt_by_id:
            continue
        first, second = rebuilt_by_id[conflict.first_use_id], rebuilt_by_id[conflict.second_use_id]
        earlier, later = (first, second) if first["start"] <= second["start"] else (second, first)
        if later["start"] < earlier["end"]-tol:
            add("VV_MERGE_RESOURCE_CONFLICT", first=earlier["use_id"], second=later["use_id"],
                resource_id=conflict.resource_id)
        if later["start"]-earlier["start"] < SHARED_RESOURCE_ENTRY_HEADWAY_S-tol:
            add("SHARED_RESOURCE_HEADWAY_LT_2P5", first=earlier["use_id"], second=later["use_id"],
                resource_id=conflict.resource_id, actual=later["start"]-earlier["start"])
    for conflict in build_frozen_vv_merge_conflicts(snapshot):
        first = rebuilt_by_id.get(conflict.new_use_id)
        second = rebuilt_by_id.get(conflict.frozen_reservation_id)
        if first is None or second is None:
            continue
        earlier, later = (first, second) if first["start"] <= second["start"] else (second, first)
        if later["start"] < earlier["end"]-tol:
            add("VV_MERGE_RESOURCE_CONFLICT", first=earlier["use_id"], second=later["use_id"],
                resource_id=conflict.resource_id)
        if later["start"]-earlier["start"] < SHARED_RESOURCE_ENTRY_HEADWAY_S-tol:
            add("SHARED_RESOURCE_HEADWAY_LT_2P5", first=earlier["use_id"], second=later["use_id"],
                resource_id=conflict.resource_id, actual=later["start"]-earlier["start"])
    use_keys = [(item["uav_id"],item["resource_id"],item["role"]) for item in rebuilt if not item.get("frozen")]
    if len(use_keys) != len(set(use_keys)): add("DUPLICATE_RESOURCE_OCCUPANCY")
    for flow in snapshot.mainline_flows:
        if not is_active(flow.uav_id):
            continue
        value=times[flow.exit_event_id]
        if snapshot.t_clear is not None and value > snapshot.t_clear+tol: add("H_CLEAR_HORIZON", uav_id=flow.uav_id)
        if value > flow.nominal_exit_time+flow.max_delay+tol: add("H_PROTECTION", uav_id=flow.uav_id)

    from .physical_entry_contract import check_conditions
    check_conditions(snapshot,result,is_active,add)
    expected_k = sum(complete.get(uid, 0) for uid in expected_ids) if policy else len(expected_ids)
    expected_v = snapshot.lambda_v*sum(max(0.0,times[descent_entry_event_id(item)]+item.service_offset-item.nominal_service_time)
                                      for item in snapshot.descents if is_active(item.uav_id))
    expected_wait = snapshot.lambda_v*sum(waiting_delay_proxy(snapshot, uid)
                                        for uid in expected_ids if not is_active(uid))
    if policy is not None:
        if (not isinstance(result.candidate_scheduled_v_cost, (int, float)) or not math.isfinite(result.candidate_scheduled_v_cost)
                or abs(result.candidate_scheduled_v_cost-expected_v) > 5*tol):
            add("SCHEDULED_V_COST_MISMATCH")
        if (not isinstance(result.candidate_waiting_proxy_cost, (int, float)) or not math.isfinite(result.candidate_waiting_proxy_cost)
                or abs(result.candidate_waiting_proxy_cost-expected_wait) > 5*tol):
            add("WAITING_PROXY_COST_MISMATCH")
    expected_v += expected_wait
    expected_h = snapshot.lambda_h*sum(max(0.0,times[item.exit_event_id]-item.nominal_exit_time)
                                      for item in snapshot.mainline_flows if is_active(item.uav_id))
    if result.candidate_scheduled_count != expected_k: add("SCHEDULED_COUNT_MISMATCH", decoded=result.candidate_scheduled_count, recomputed=expected_k)
    if result.v_cost is None or abs(result.v_cost-expected_v) > 5*tol: add("OBJECTIVE_V_COST_MISMATCH", decoded=result.v_cost, recomputed=expected_v)
    if result.h_cost is None or abs(result.h_cost-expected_h) > 5*tol: add("OBJECTIVE_H_COST_MISMATCH", decoded=result.h_cost, recomputed=expected_h)
    if result.joint_cost is None or abs(result.joint_cost-expected_v-expected_h) > 10*tol: add("OBJECTIVE_JOINT_COST_MISMATCH", decoded=result.joint_cost, recomputed=expected_v+expected_h)

    counts: dict[str,int] = {}
    for item in violations: counts[item["code"]]=counts.get(item["code"],0)+1
    for code in ("ALL_REQUESTS_NOT_SCHEDULED","COMPLETION_ID_MISMATCH","FIFO_PASSAGE_ORDER",
                 "FIFO_COMPLETION_PREFIX","E1_CONTINUITY","E2_TURN_OFFSET",
                 "VV_SEPARATION","FROZEN_VV_SEPARATION","VH_RESOURCE_CONFLICT","FROZEN_EVENT_CHANGED",
                 "VV_MERGE_RESOURCE_CONFLICT","SHARED_RESOURCE_HEADWAY_LT_2P5",
                 "HISTORICAL_FROZEN_RESOURCE_CONFLICT",
                 "H_CLEAR_HORIZON","H_PROTECTION","ACTIVE_PENDING_DISAPPEARED","DUPLICATE_RESOURCE_OCCUPANCY",
                 "RESOURCE_USE_DECODE_MISMATCH","RESOURCE_USE_MISSING_OR_EXTRA","SCHEDULED_COUNT_MISMATCH",
                 "OBJECTIVE_V_COST_MISMATCH","OBJECTIVE_H_COST_MISMATCH","OBJECTIVE_JOINT_COST_MISMATCH"):
        counts.setdefault(code,0)
    return CheckReport(not violations, tuple(violations), counts)
