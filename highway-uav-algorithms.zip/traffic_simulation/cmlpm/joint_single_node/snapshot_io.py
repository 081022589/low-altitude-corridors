"""Strict serialization for the current dynamic-following model."""
from __future__ import annotations

from dataclasses import asdict, fields
import hashlib
import json
from pathlib import Path

from .schema import (ContractError, DescentRequest, Event, FrozenReservation,
                     FrozenVVConstraint, MainlineFlow, NodeSnapshot,
                     ResourceUse, Separation, TravelArc, VVConstraint,
                     PendingTimingRequest, WaitingPolicy, FollowingTimeCondition,
                     validate_snapshot)
from .following_contract import FollowingAircraft, FollowingDomain, MainlineFIFO
from .physical_entry_contract import PhysicalEntryCondition


def canonical_json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def snapshot_to_dict(snapshot: NodeSnapshot) -> dict:
    data = asdict(snapshot)
    for flow in data["mainline_flows"]:
        if flow["waiting_leader_id"] is None:
            flow.pop("waiting_leader_id")
    if snapshot.waiting_policy is None:
        data.pop("waiting_policy")
    if not snapshot.physical_entry_conditions and snapshot.execution_contract_version is None:
        data.pop('physical_entry_conditions')
        data.pop('execution_contract_version')
    return data


def snapshot_semantic_hash(snapshot: NodeSnapshot) -> str:
    return sha256_text(canonical_json(snapshot_to_dict(snapshot)))


def snapshot_from_dict(data: dict) -> NodeSnapshot:
    if "hh_constraints" in data:
        raise ContractError("HISTORICAL_HH_INPUT_FORBIDDEN", "HH inputs are not part of the current model")
    unknown = set(data) - {f.name for f in fields(NodeSnapshot)}
    if unknown:
        raise ContractError("UNKNOWN_CONTRACT_FIELD", ",".join(sorted(unknown)))
    required = {"model_version", "mainline_fifo", "following_domain", "following_time_conditions"}
    if required - data.keys():
        raise ContractError("MISSING_REQUIRED_CONTRACT_FIELD", ",".join(sorted(required - data.keys())))
    from .schema import MODEL_VERSION
    if data["model_version"] != MODEL_VERSION:
        raise ContractError("UNSUPPORTED_CMLPM_MODEL", str(data["model_version"]))
    raw_domain = data["following_domain"]
    if not isinstance(raw_domain, dict):
        raise ContractError("DYNAMIC_MODEL_INCOMPLETE", "following_domain must be explicit")
    try:
        domain = FollowingDomain(**{**raw_domain, "aircraft": tuple(FollowingAircraft(**r) for r in raw_domain["aircraft"])})
    except (KeyError, TypeError) as error:
        raise ContractError("DYNAMIC_MODEL_INCOMPLETE", str(error)) from error
    separations = {key: Separation(**value) for key, value in data["vh_separation"].items()}
    waiting_data = data.get("waiting_policy")
    waiting = None if waiting_data is None else WaitingPolicy(**{
        **waiting_data,
        "requests": tuple(PendingTimingRequest(**{**r, "resource_chain": tuple(r.get("resource_chain", ()))})
                          for r in waiting_data["requests"]),
        "previous_pending_ids": tuple(waiting_data.get("previous_pending_ids", ())),
        "newly_eligible_ids": tuple(waiting_data.get("newly_eligible_ids", ())),
    })
    snapshot = NodeSnapshot(
        node_id=data["node_id"], t_now=data["t_now"], t_commit=data["t_commit"],
        t_request=data.get("t_request"), t_clear=data.get("t_clear"),
        events=tuple(Event(**item) for item in data["events"]),
        arcs=tuple(TravelArc(**item) for item in data["arcs"]),
        descents=tuple(DescentRequest(**item) for item in data["descents"]),
        mainline_flows=tuple(MainlineFlow(**item) for item in data["mainline_flows"]),
        resource_uses=tuple(ResourceUse(**item) for item in data["resource_uses"]),
        vv_constraints=tuple(VVConstraint(**{**item, "shared_segments": tuple(item.get("shared_segments",()))}) for item in data["vv_constraints"]),
        vh_separation=separations,
        frozen_reservations=tuple(FrozenReservation(**item) for item in data.get("frozen_reservations",())),
        frozen_vv_constraints=tuple(FrozenVVConstraint(**item) for item in data.get("frozen_vv_constraints",())),
        lambda_v=data.get("lambda_v",1.0), lambda_h=data.get("lambda_h",1.0),
        tolerance=data.get("tolerance",2e-6), srcm_version=data.get("srcm_version","SRCM_CROSSING_V3_0_1"),
        metadata=data.get("metadata",{}), model_version=data["model_version"],
        following_domain=domain, mainline_fifo=tuple(MainlineFIFO(**f) for f in data["mainline_fifo"]),
        waiting_policy=waiting,
        following_time_conditions=tuple(FollowingTimeCondition(**item)
                                       for item in data["following_time_conditions"]),
        physical_entry_conditions=tuple(PhysicalEntryCondition(**item) for item in data.get('physical_entry_conditions',())),
        execution_contract_version=data.get('execution_contract_version'),
    )
    validate_snapshot(snapshot)
    return snapshot


def write_snapshot(path: Path, snapshot: NodeSnapshot) -> None:
    path.write_text(canonical_json(snapshot_to_dict(snapshot)) + "\n", encoding="utf-8")


def read_snapshot(path: Path) -> NodeSnapshot:
    return snapshot_from_dict(json.loads(path.read_text(encoding="utf-8")))


