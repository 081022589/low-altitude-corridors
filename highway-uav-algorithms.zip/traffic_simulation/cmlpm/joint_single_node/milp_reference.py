from __future__ import annotations

from dataclasses import dataclass, replace
import hashlib
import math
import time

import numpy as np
from scipy.sparse import csc_matrix
from scipy.optimize import Bounds, LinearConstraint, milp
from .numerics import NUMERICAL_POLICY_ID,objective_tolerance,solve as numerical_solve

from .conflict_builder import (
    SHARED_RESOURCE_ENTRY_HEADWAY_S,
    build_frozen_vv_merge_conflicts,
    build_vh_conflicts,
    build_vv_merge_conflicts,
    potential_frozen_conflicts,
    reachable_interval,
)
from .schema import (MODEL_VERSION, NodeSnapshot, event_map, model_version_for,
                     validate_snapshot, waiting_delay_proxy, timing_candidate_available,
                     descent_entry_event_id)


@dataclass(frozen=True)
class SchedulingRestrictions:
    """Policy-only restrictions; never changes physical/safety input data."""
    fixed_event_times: dict[str, float] | None = None
    fixed_vv_orders: dict[tuple[str, str], str] | None = None
    fixed_vh_orders: dict[tuple[str, str], str] | None = None  # V_FIRST | M_FIRST


@dataclass(frozen=True)
class SolveResult:
    """Mathematical C-MLPM candidate and solver evidence.

    The ``candidate_*`` fields are produced before CPFF feedback, the final
    independent Checker, and execution-handoff certification. They must not
    be interpreted as published scheduling decisions.
    """
    solver_status: str
    termination: str
    candidate_scheduled_count: int | None
    joint_cost: float | None
    v_cost: float | None
    h_cost: float | None
    mip_gap: float | None
    candidate_all_requests_scheduled: bool
    candidate_all_requests_timing_feasible: bool | None
    event_times: dict[str, float]
    candidate_completion: dict[str, int]
    orders: dict[str, int]
    resource_occupancies: tuple[dict, ...]
    candidate_pending_states: dict[str, str]
    solve_seconds: float
    input_snapshot_hash: str
    big_m_values: tuple[float, ...]
    model_version: str = MODEL_VERSION
    input_uav_ids: tuple[str, ...] = ()
    candidate_scheduled_uav_ids: tuple[str, ...] = ()
    candidate_waiting_uav_ids: tuple[str, ...] = ()
    candidate_scheduled_v_cost: float | None = None
    candidate_waiting_proxy_cost: float | None = None
    full_attempt_termination: str | None = None
    candidate_requires_hold_certification: bool = False
    mip_dual_bound: float | None = None
    numerical_status: str | None = None
    solver_attempts: tuple[dict, ...] = ()
    diagnostic_joint_time_windows: dict | None = None


class _Builder:
    def __init__(self):
        self.names: list[str] = []
        self.lb: list[float] = []
        self.ub: list[float] = []
        self.integrality: list[int] = []
        self.rows: list[dict[int, float]] = []
        self.row_lb: list[float] = []
        self.row_ub: list[float] = []
        self.big_m: list[float] = []
        self.order_owners: dict[str, tuple[str, ...]] = {}

    def var(self, name: str, lb: float, ub: float, integer: bool = False) -> int:
        if not math.isfinite(lb) or not math.isfinite(ub) or lb > ub:
            raise ValueError(f"variable {name} requires finite ordered bounds")
        idx = len(self.names)
        self.names.append(name); self.lb.append(lb); self.ub.append(ub); self.integrality.append(int(integer))
        return idx

    def row(self, coeff: dict[int, float], lb: float = -math.inf, ub: float = math.inf) -> None:
        self.rows.append({key: value for key, value in coeff.items() if abs(value) > 1e-14})
        self.row_lb.append(lb); self.row_ub.append(ub)

    def _expr_max(self, coeff: dict[int, float]) -> float:
        return sum(value * (self.ub[idx] if value >= 0 else self.lb[idx]) for idx, value in coeff.items())

    def imply_le(self, coeff: dict[int, float], rhs: float, conditions: tuple[tuple[int, int], ...]) -> None:
        """Add expr<=rhs when all binary literals hold, using bound-derived M."""
        if not conditions:
            self.row(coeff, ub=rhs)
            return
        m_value = max(0.0, self._expr_max(coeff) - rhs)
        self.big_m.append(m_value)
        adjusted = dict(coeff)
        adjusted_rhs = rhs
        for idx, value in conditions:
            if value == 1:  # false amount = 1-x
                adjusted[idx] = adjusted.get(idx, 0.0) + m_value
                adjusted_rhs += m_value
            else:  # false amount = x
                adjusted[idx] = adjusted.get(idx, 0.0) - m_value
        self.row(adjusted, ub=adjusted_rhs)

    def imply_ge(self, coeff: dict[int, float], rhs: float, conditions: tuple[tuple[int, int], ...]) -> None:
        self.imply_le({idx: -value for idx, value in coeff.items()}, -rhs, conditions)

    def arrays(self):
        row_indices: list[int] = []
        col_indices: list[int] = []
        values: list[float] = []
        for row_idx, coeff in enumerate(self.rows):
            for col_idx, value in coeff.items():
                row_indices.append(row_idx)
                col_indices.append(col_idx)
                values.append(value)
        # Preserve the builder's row/column order while avoiding an
        # O(rows*columns) dense allocation for large rolling instances.
        return csc_matrix(
            (np.asarray(values, dtype=float), (row_indices, col_indices)),
            shape=(len(self.rows), len(self.names)),
        )


def _reduce_fixed_event_columns(builder: _Builder, x: dict[str, int], objective: np.ndarray):
    """Return a solver-only projection with unconditional fixed event columns removed.

    The original builder and indices remain authoritative for decoding.  Each
    eliminated column is substituted into every row, including conditional
    Big-M rows; only the row bounds change.  Fixed columns are restricted to
    event variables whose declared domain is exactly one point and whose
    objective coefficient is zero.  A constant-only contradictory row is
    retained as an empty bounded row so infeasibility cannot be lost.
    """
    fixed = {
        old_idx: float(builder.lb[old_idx])
        for old_idx in x.values()
        if builder.lb[old_idx] == builder.ub[old_idx] and objective[old_idx] == 0.0
    }
    if not fixed:
        return builder, objective, {}, {}
    old_to_new = {}
    for old_idx in range(len(builder.names)):
        if old_idx not in fixed:
            old_to_new[old_idx] = len(old_to_new)
    reduced = _Builder()
    reduced.names = [builder.names[idx] for idx in old_to_new]
    reduced.lb = [builder.lb[idx] for idx in old_to_new]
    reduced.ub = [builder.ub[idx] for idx in old_to_new]
    reduced.integrality = [builder.integrality[idx] for idx in old_to_new]
    reduced.big_m = list(builder.big_m)
    reduced.order_owners = dict(builder.order_owners)
    reduced.rows = []
    reduced.row_lb = []
    reduced.row_ub = []
    for coeff, lower, upper in zip(builder.rows, builder.row_lb, builder.row_ub):
        fixed_value = sum(value * fixed[idx] for idx, value in coeff.items() if idx in fixed)
        projected = {old_to_new[idx]: value for idx, value in coeff.items() if idx not in fixed}
        reduced.rows.append(projected)
        reduced.row_lb.append(lower - fixed_value)
        reduced.row_ub.append(upper - fixed_value)
    reduced_objective = np.asarray([objective[idx] for idx in old_to_new], dtype=float)
    return reduced, reduced_objective, old_to_new, fixed


def _hash_snapshot(snapshot: NodeSnapshot) -> str:
    payload = repr(snapshot).encode("utf-8")
    return hashlib.sha256(payload).hexdigest()


def _build(snapshot: NodeSnapshot, restrictions: SchedulingRestrictions | None = None,
           *, allow_waiting: bool = False, _use_precomputed_conflicts: bool = True):
    from ..active.contract_validation import validate_complete_snapshot
    validate_complete_snapshot(snapshot)
    restrictions = restrictions or SchedulingRestrictions()
    fixed_event_times = restrictions.fixed_event_times or {}
    fixed_vv_orders = restrictions.fixed_vv_orders or {}
    fixed_vh_orders = restrictions.fixed_vh_orders or {}
    b = _Builder()
    events = event_map(snapshot)
    entry_event = descent_entry_event_id
    x = {item.event_id: b.var(f"x:{item.event_id}", item.time_lb, item.time_ub) for item in snapshot.events}
    desc = {item.uav_id: item for item in snapshot.descents}
    waiting = {}
    waiting_policy_present = snapshot.waiting_policy is not None
    if waiting_policy_present:
        pending = {r.uav_id: r for r in snapshot.waiting_policy.requests}
        if allow_waiting:
            # The second-stage WAITING fallback retains the original binary
            # variables and activation semantics exactly.
            waiting = {uid: b.var(f"w:{uid}", 0., float(pending[uid].can_hold), True)
                       for uid in desc}
            for uid in desc:
                if not pending[uid].timing_available:
                    b.row({waiting[uid]: 1.}, lb=1.)
        else:
            # The full attempt is the all-scheduled domain.  Do not create
            # fixed w:* columns: their only semantic purpose was to encode
            # the fallback.  An unavailable timing request must nevertheless
            # keep the full attempt infeasible, so retain a direct
            # contradictory row instead of silently dropping the request.
            for uid in desc:
                if not pending[uid].timing_available:
                    b.row({}, lb=1.)

    def active(*uids):
        from .schema import timing_owner
        owners = dict.fromkeys(timing_owner(snapshot, uid) for uid in uids)
        return tuple((waiting[uid], 0) for uid in owners if uid in waiting)

    for event in snapshot.events:
        if event.committed_time is not None:
            b.imply_ge({x[event.event_id]: 1.0}, event.committed_time, active(event.uav_id))
            b.imply_le({x[event.event_id]: 1.0}, event.committed_time, active(event.uav_id))
    for event_id, value in fixed_event_times.items():
        if event_id not in events or value < events[event_id].time_lb or value > events[event_id].time_ub:
            raise ValueError(f"POLICY_RESTRICTION_INVALID: fixed event {event_id}={value}")
        b.imply_ge({x[event_id]: 1.0}, value, active(events[event_id].uav_id))
        b.imply_le({x[event_id]: 1.0}, value, active(events[event_id].uav_id))
    for arc in snapshot.arcs:
        coeff = {x[arc.successor_id]: 1.0, x[arc.predecessor_id]: -1.0}
        b.imply_ge(coeff, arc.travel_min, active(arc.uav_id))
        b.imply_le(coeff, arc.travel_max, active(arc.uav_id))
    for item in snapshot.descents:
        if not timing_candidate_available(snapshot, item.uav_id):
            continue
        anchor = entry_event(item)
        if snapshot.t_request is not None:
            b.imply_le({x[anchor]: 1.0}, snapshot.t_request - item.service_offset, active(item.uav_id))
    for fifo in snapshot.mainline_fifo:
        b.imply_ge({x[fifo.follower_event_id]:1., x[fifo.leader_event_id]:-1.},
                   0., active(fifo.leader_id, fifo.follower_id))
    for condition in snapshot.following_time_conditions:
        coeff = {x[condition.follower_event_id]: 1.}
        lower = condition.minimum_travel_s
        uids = [condition.follower_id]
        if condition.leader_event_id is not None:
            coeff[x[condition.leader_event_id]] = -1.
            uids.append(condition.leader_id)
        else:
            lower += condition.published_leader_time_s
        b.imply_ge(coeff, lower, active(*uids))
    # All requests are mandatory. FIFO now constrains passage order directly,
    # rather than constraining which completion prefix can be selected.
    by_layer: dict[str, list] = {}
    for item in snapshot.descents:
        by_layer.setdefault(item.fifo_queue_id or item.source_layer, []).append(item)
    for requests in by_layer.values():
        requests.sort(key=lambda item: item.fifo_rank)
        for leader, follower in zip(requests, requests[1:]):
            if waiting:
                b.row({waiting[leader.uav_id]: 1., waiting[follower.uav_id]: -1.}, ub=0.)
            if not (timing_candidate_available(snapshot, leader.uav_id)
                    and timing_candidate_available(snapshot, follower.uav_id)):
                continue
            b.imply_ge({x[entry_event(follower)]: 1.0, x[entry_event(leader)]: -1.0},
                       0., active(leader.uav_id, follower.uav_id))
    order: dict[str, int] = {}
    uses = {item.use_id: item for item in snapshot.resource_uses}
    if _use_precomputed_conflicts:
        resource_intervals = {
            use.use_id: reachable_interval(snapshot, use, events)
            for use in snapshot.resource_uses
        }
        vh_conflicts = build_vh_conflicts(snapshot, events=events, intervals=resource_intervals)
        frozen_conflict_pairs = potential_frozen_conflicts(snapshot, events=events, intervals=resource_intervals)
        vv_merge_conflicts = build_vv_merge_conflicts(snapshot, events=events, descents=desc)
        frozen_vv_merge_conflicts = build_frozen_vv_merge_conflicts(snapshot, events=events, descents=desc)
    else:
        vh_conflicts = build_vh_conflicts(snapshot)
        frozen_conflict_pairs = potential_frozen_conflicts(snapshot)
        vv_merge_conflicts = build_vv_merge_conflicts(snapshot)
        frozen_vv_merge_conflicts = build_frozen_vv_merge_conflicts(snapshot)
    vv_merge = {
        (item.first_uav_id, item.second_uav_id): item
        for item in vv_merge_conflicts
    }
    for idx, item in enumerate(snapshot.vv_constraints):
        if not (timing_candidate_available(snapshot, item.first_id)
                and timing_candidate_available(snapshot, item.second_id)):
            continue
        first, second = desc[item.first_id], desc[item.second_id]
        conditions = active(item.first_id, item.second_id)
        policy_order = fixed_vv_orders.get((item.first_id,item.second_id), fixed_vv_orders.get((item.second_id,item.first_id)))
        effective_order = policy_order or item.fixed_order
        if effective_order not in {None,item.first_id,item.second_id}:
            raise ValueError(f"POLICY_RESTRICTION_INVALID: VV {item.first_id}/{item.second_id}")
        merge = vv_merge.get((item.first_id, item.second_id))
        first_use = uses[merge.first_use_id] if merge else None
        second_use = uses[merge.second_use_id] if merge else None
        def imply_first_before_second(extra_conditions):
            b.imply_ge({x[entry_event(second)]: 1.0, x[entry_event(first)]: -1.0}, item.first_before_second_gap, extra_conditions)
            if merge:
                b.imply_ge({x[second_use.anchor_event_id]: 1.0, x[first_use.anchor_event_id]: -1.0},
                           first_use.end_offset-second_use.start_offset, extra_conditions)
                b.imply_ge({x[second_use.anchor_event_id]: 1.0, x[first_use.anchor_event_id]: -1.0},
                           first_use.start_offset+SHARED_RESOURCE_ENTRY_HEADWAY_S-second_use.start_offset,
                           extra_conditions)
        def imply_second_before_first(extra_conditions):
            b.imply_ge({x[entry_event(first)]: 1.0, x[entry_event(second)]: -1.0}, item.second_before_first_gap, extra_conditions)
            if merge:
                b.imply_ge({x[first_use.anchor_event_id]: 1.0, x[second_use.anchor_event_id]: -1.0},
                           second_use.end_offset-first_use.start_offset, extra_conditions)
                b.imply_ge({x[first_use.anchor_event_id]: 1.0, x[second_use.anchor_event_id]: -1.0},
                           second_use.start_offset+SHARED_RESOURCE_ENTRY_HEADWAY_S-first_use.start_offset,
                           extra_conditions)
        if effective_order == item.first_id:
            imply_first_before_second(conditions)
        elif effective_order == item.second_id:
            imply_second_before_first(conditions)
        else:
            z = b.var(f"z:VV:{idx}:{item.first_id}:{item.second_id}", 0.0, 1.0, True)
            order[f"VV:{item.first_id}:{item.second_id}"] = z
            b.order_owners[f"VV:{item.first_id}:{item.second_id}"] = (item.first_id, item.second_id)
            imply_first_before_second(conditions + ((z, 1),))
            imply_second_before_first(conditions + ((z, 0),))
    for use in snapshot.resource_uses:
        b.imply_ge({x[use.anchor_event_id]: 1.0}, snapshot.t_commit - use.start_offset, active(use.uav_id))
    for idx, conflict in enumerate(vh_conflicts):
        v, m = uses[conflict.vertical_use_id], uses[conflict.mainline_use_id]
        sep = snapshot.vh_separation[conflict.resource_id]
        conditions = active(v.uav_id, m.uav_id)
        policy_order = fixed_vh_orders.get((v.use_id,m.use_id))
        if policy_order == "V_FIRST":
            b.imply_le({x[v.anchor_event_id]: 1.0, x[m.anchor_event_id]: -1.0}, -(v.end_offset + sep.first_to_second - m.start_offset), conditions)
            b.imply_le({x[v.anchor_event_id]: 1.0, x[m.anchor_event_id]: -1.0}, -(v.start_offset + SHARED_RESOURCE_ENTRY_HEADWAY_S - m.start_offset), conditions)
        elif policy_order == "M_FIRST":
            b.imply_le({x[m.anchor_event_id]: 1.0, x[v.anchor_event_id]: -1.0}, -(m.end_offset + sep.second_to_first - v.start_offset), conditions)
            b.imply_le({x[m.anchor_event_id]: 1.0, x[v.anchor_event_id]: -1.0}, -(m.start_offset + SHARED_RESOURCE_ENTRY_HEADWAY_S - v.start_offset), conditions)
        elif policy_order is not None:
            raise ValueError(f"POLICY_RESTRICTION_INVALID: VH {v.use_id}/{m.use_id}")
        else:
            z = b.var(f"z:VH:{idx}:{v.use_id}:{m.use_id}", 0.0, 1.0, True)
            order[f"VH:{v.use_id}:{m.use_id}"] = z
            b.order_owners[f"VH:{v.use_id}:{m.use_id}"] = (v.uav_id, m.uav_id)
            b.imply_le({x[v.anchor_event_id]: 1.0, x[m.anchor_event_id]: -1.0}, -(v.end_offset + sep.first_to_second - m.start_offset), conditions + ((z, 1),))
            b.imply_le({x[v.anchor_event_id]: 1.0, x[m.anchor_event_id]: -1.0}, -(v.start_offset + SHARED_RESOURCE_ENTRY_HEADWAY_S - m.start_offset), conditions + ((z, 1),))
            b.imply_le({x[m.anchor_event_id]: 1.0, x[v.anchor_event_id]: -1.0}, -(m.end_offset + sep.second_to_first - v.start_offset), conditions + ((z, 0),))
            b.imply_le({x[m.anchor_event_id]: 1.0, x[v.anchor_event_id]: -1.0}, -(m.start_offset + SHARED_RESOURCE_ENTRY_HEADWAY_S - v.start_offset), conditions + ((z, 0),))
    frozen_by_id = {item.reservation_id: item for item in snapshot.frozen_reservations}
    for idx, (use_id, reservation_id) in enumerate(frozen_conflict_pairs):
        use, frozen = uses[use_id], frozen_by_id[reservation_id]
        sep = snapshot.vh_separation[use.resource_id]
        z = b.var(f"z:FROZEN:{idx}:{use_id}:{reservation_id}", 0.0, 1.0, True)
        order[f"FROZEN:{use_id}:{reservation_id}"] = z
        b.order_owners[f"FROZEN:{use_id}:{reservation_id}"] = (use.uav_id,)
        conditions = active(use.uav_id)
        before_gap = sep.first_to_second if use.role == "V" else sep.second_to_first
        after_gap = sep.second_to_first if use.role == "V" else sep.first_to_second
        b.imply_le({x[use.anchor_event_id]: 1.0}, frozen.occupancy_start - use.end_offset - before_gap, conditions + ((z, 1),))
        b.imply_le({x[use.anchor_event_id]: 1.0}, frozen.occupancy_start - use.start_offset - SHARED_RESOURCE_ENTRY_HEADWAY_S, conditions + ((z, 1),))
        b.imply_ge({x[use.anchor_event_id]: 1.0}, frozen.occupancy_end + after_gap - use.start_offset, conditions + ((z, 0),))
        b.imply_ge({x[use.anchor_event_id]: 1.0}, frozen.occupancy_start + SHARED_RESOURCE_ENTRY_HEADWAY_S - use.start_offset, conditions + ((z, 0),))
    frozen_vv_merge = {item.constraint_id: item for item in frozen_vv_merge_conflicts}
    for idx, item in enumerate(snapshot.frozen_vv_constraints):
        if not timing_candidate_available(snapshot, item.new_uav_id):
            continue
        frozen = frozen_by_id[item.frozen_reservation_id]
        new = desc[item.new_uav_id]
        conditions = active(item.new_uav_id)
        merge = frozen_vv_merge.get(item.constraint_id)
        new_use = uses[merge.new_use_id] if merge else None
        def imply_frozen_before_new(extra_conditions):
            if merge:
                b.imply_ge({x[new_use.anchor_event_id]: 1.0}, frozen.occupancy_end-new_use.start_offset, extra_conditions)
                b.imply_ge({x[new_use.anchor_event_id]: 1.0}, frozen.occupancy_start+SHARED_RESOURCE_ENTRY_HEADWAY_S-new_use.start_offset, extra_conditions)
        def imply_new_before_frozen(extra_conditions):
            if merge:
                b.imply_le({x[new_use.anchor_event_id]: 1.0}, frozen.occupancy_start-new_use.end_offset, extra_conditions)
                b.imply_le({x[new_use.anchor_event_id]: 1.0}, frozen.occupancy_start-SHARED_RESOURCE_ENTRY_HEADWAY_S-new_use.start_offset, extra_conditions)
        if item.fixed_order == "frozen":
            b.imply_ge({x[entry_event(new)]: 1.0}, frozen.q_reference_time + item.frozen_to_new_gap, conditions)
            imply_frozen_before_new(conditions)
        elif item.fixed_order == "new":
            b.imply_le({x[entry_event(new)]: 1.0}, frozen.q_reference_time - item.new_to_frozen_gap, conditions)
            imply_new_before_frozen(conditions)
        else:
            z = b.var(f"z:FROZEN_VV:{idx}:{item.constraint_id}", 0.0, 1.0, True)
            order[f"FROZEN_VV:{item.constraint_id}"] = z
            b.order_owners[f"FROZEN_VV:{item.constraint_id}"] = (item.new_uav_id,)
            b.imply_ge({x[entry_event(new)]: 1.0}, frozen.q_reference_time + item.frozen_to_new_gap, conditions + ((z, 1),))
            b.imply_le({x[entry_event(new)]: 1.0}, frozen.q_reference_time - item.new_to_frozen_gap, conditions + ((z, 0),))
            imply_frozen_before_new(conditions + ((z, 1),))
            imply_new_before_frozen(conditions + ((z, 0),))
    d_v, d_h = {}, {}
    for item in snapshot.descents:
        if not timing_candidate_available(snapshot, item.uav_id):
            cost = waiting_delay_proxy(snapshot, item.uav_id)
            d_v[item.uav_id] = b.var(f"dV:{item.uav_id}", cost, cost)
            continue
        anchor = entry_event(item)
        q_event = events[anchor]
        upper = max(0.0, q_event.time_ub + item.service_offset - item.nominal_service_time)
        if waiting_policy_present:
            upper = max(upper, waiting_delay_proxy(snapshot, item.uav_id))
        d_v[item.uav_id] = b.var(f"dV:{item.uav_id}", 0.0, upper)
        b.imply_ge({d_v[item.uav_id]: 1.0, x[anchor]: -1.0},
                   item.service_offset - item.nominal_service_time, active(item.uav_id))
        if waiting:
            b.row({d_v[item.uav_id]: 1., waiting[item.uav_id]: -waiting_delay_proxy(snapshot, item.uav_id)}, lb=0.)
    for item in snapshot.mainline_flows:
        exit_event = events[item.exit_event_id]
        upper = max(0.0, exit_event.time_ub - item.nominal_exit_time)
        d_h[item.uav_id] = b.var(f"dH:{item.uav_id}", 0.0, upper)
        b.imply_ge({d_h[item.uav_id]: 1.0, x[item.exit_event_id]: -1.0},
                   -item.nominal_exit_time, active(item.uav_id))
        b.imply_le({x[item.exit_event_id]: 1.0},
                   min(snapshot.t_clear, item.nominal_exit_time + item.max_delay)
                   if snapshot.t_clear is not None else item.nominal_exit_time + item.max_delay,
                   active(item.uav_id))
    from .physical_entry_contract import compile_conditions
    compile_conditions(snapshot,b,x,order,active,restrictions)
    return b, x, order, d_v, d_h, waiting


def _run(b: _Builder, objective: np.ndarray, *, time_limit=30.0):
    return numerical_solve(b,objective,time_limit=time_limit,milp=milp)


def solve_timing(snapshot: NodeSnapshot, *, time_limit: float = 30.0,
                 restrictions: SchedulingRestrictions | None = None) -> SolveResult:
    """Optimize the complete input, optionally returning explicit waiting.

    An explicit WaitingPolicy first tries all requests, then allows waiting
    in the SAME joint model within one time budget. Waiting decisions are not
    physical hold certificates and must not be executed as descent clearances.
    Without a waiting policy, every input request requires a timing schedule.
    """
    if not math.isfinite(time_limit) or time_limit <= 0:
        raise ValueError("time_limit must be finite and positive")
    started = time.perf_counter()
    policy = snapshot.waiting_policy
    full = _solve_timing_once(snapshot, restrictions, started=started,
                              time_limit=time_limit if policy is None else time_limit * policy.full_attempt_fraction,
                              allow_waiting=False)
    if policy is None or full.event_times or full.termination not in {"INFEASIBLE", "TIME_LIMIT_NO_INCUMBENT"}:
        return full
    remaining = time_limit - (time.perf_counter() - started)
    if remaining <= 0:
        return full
    return _solve_timing_once(snapshot, restrictions, started=started,
                             time_limit=remaining, allow_waiting=True,
                             full_attempt=full)


def _solve_timing_once(snapshot, restrictions, *, started, time_limit,
                       allow_waiting, full_attempt=None):
    attempt_deadline = time.perf_counter() + time_limit
    b, x, order, d_v, d_h, waiting = _build(snapshot, restrictions, allow_waiting=allow_waiting)
    objective_delay = np.zeros(len(b.names))
    for idx in d_v.values(): objective_delay[idx] = snapshot.lambda_v
    for idx in d_h.values(): objective_delay[idx] = snapshot.lambda_h
    remaining = attempt_deadline - time.perf_counter()
    if remaining <= 0:
        return replace(_empty_result(snapshot, started, "TIME_LIMIT_NO_INCUMBENT", b),
                       full_attempt_termination=full_attempt.termination if full_attempt else "TIME_LIMIT_NO_INCUMBENT",
                       solver_attempts=full_attempt.solver_attempts if full_attempt else ())
    solver_builder, solver_objective, old_to_new, fixed = _reduce_fixed_event_columns(b, x, objective_delay)
    backend_started = time.perf_counter()
    solved = _run(solver_builder, solver_objective, time_limit=remaining)
    attempt = dict(allow_waiting=allow_waiting,status=int(solved.status),message=str(getattr(solved,'message','')),
        has_incumbent=solved.x is not None,seconds=time.perf_counter()-backend_started,
        time_limit_s=remaining,variables=len(solver_builder.names),rows=len(solver_builder.rows),
        numerical_status=getattr(solved,"numerical_status",None),
        infeasibility_certificate=getattr(solved,"infeasibility_certificate",None))
    attempts = (full_attempt.solver_attempts if full_attempt else ()) + (attempt,)
    if solved.x is None:
        termination = {1: "TIME_LIMIT_NO_INCUMBENT", 2: "INFEASIBLE"}.get(solved.status, "SOLVER_FAILURE")
        numerical_status=getattr(solved,"numerical_status",None)
        if numerical_status and numerical_status.startswith("NUMERICAL_CANDIDATE_REJECTED"):
            termination="NUMERICAL_NO_CERTIFIED_INCUMBENT"
        return replace(_empty_result(snapshot, started, termination, b),
                       full_attempt_termination=full_attempt.termination if full_attempt else termination,
                       numerical_status=numerical_status,solver_attempts=attempts)
    if fixed:
        values = np.empty(len(b.names), dtype=float)
        for old_idx, new_idx in old_to_new.items():
            values[old_idx] = solved.x[new_idx]
        for old_idx, fixed_value in fixed.items():
            values[old_idx] = fixed_value
    else:
        values = solved.x
    completion = {item.uav_id: int(item.uav_id not in waiting or values[waiting[item.uav_id]] < .5)
                  for item in snapshot.descents}
    from .schema import timing_owner
    def is_active(uid):
        return completion.get(timing_owner(snapshot, uid), 1)
    event_owners = {e.event_id: e.uav_id for e in snapshot.events}
    times = {event_id: float(values[idx]) for event_id, idx in x.items()
             if is_active(event_owners[event_id])}
    uses = []
    for item in snapshot.resource_uses:
        if not is_active(item.uav_id):
            continue
        anchor = times[item.anchor_event_id]
        uses.append({"use_id": item.use_id, "uav_id": item.uav_id, "resource_id": item.resource_id, "role": item.role, "start": anchor + item.start_offset, "end": anchor + item.end_offset})
    for item in snapshot.frozen_reservations:
        uses.append({"use_id": item.reservation_id, "uav_id": item.uav_id, "resource_id": item.resource_id, "role": item.role, "start": item.occupancy_start, "end": item.occupancy_end, "frozen": True, "version": item.version})
    scheduled_cost = snapshot.lambda_v * sum(
        max(0., times[descent_entry_event_id(d)] + d.service_offset - d.nominal_service_time)
        for d in snapshot.descents if completion[d.uav_id])
    waiting_cost = snapshot.lambda_v * sum(waiting_delay_proxy(snapshot, uid)
                                          for uid, complete in completion.items() if not complete)
    v_cost = scheduled_cost + waiting_cost
    h_cost = snapshot.lambda_h * sum(max(0., times[h.exit_event_id] - h.nominal_exit_time)
                                       for h in snapshot.mainline_flows if is_active(h.uav_id))
    bound = getattr(solved,"mip_dual_bound",None)
    # Some experiment-only LP adapters do not expose a MIP bound; their
    # status still refers solely to their explicitly restricted LP domain.
    proved = solved.status == 0 and (bound is None or abs(v_cost+h_cost-bound)<=objective_tolerance(v_cost+h_cost,bound))
    termination = "MILP_PROVED_OPTIMAL" if proved else "MILP_FEASIBLE_GAP_REMAINING"
    gap = getattr(solved, "mip_gap", None)
    solve_seconds = time.perf_counter() - started
    snapshot_hash = _hash_snapshot(snapshot)
    from .joint_window_certifier import certify
    windows = certify(snapshot, b, x, values, times, uses,
                      sorted(uid for uid, complete in completion.items() if not complete),
                      snapshot_hash)
    windows["model_version"] = model_version_for(snapshot)
    return SolveResult(
        "OPTIMAL" if proved else "FEASIBLE", termination, sum(completion.values()), float(v_cost + h_cost), float(v_cost), float(h_cost),
        None if gap is None else float(gap), all(completion.values()),
        True if all(completion.values()) else (False if full_attempt and full_attempt.termination == "INFEASIBLE" else None),
        times, completion, {name: int(values[idx] >= .5) for name, idx in order.items()
                            if all(is_active(uid) for uid in b.order_owners.get(name, ()))}, tuple(uses),
        {uid: "SCHEDULED" if complete else "WAITING" for uid, complete in completion.items()},
        solve_seconds, snapshot_hash, tuple(b.big_m),
        model_version=model_version_for(snapshot), input_uav_ids=tuple(sorted(completion)),
        candidate_scheduled_uav_ids=tuple(sorted(uid for uid, complete in completion.items() if complete)),
        candidate_waiting_uav_ids=tuple(sorted(uid for uid, complete in completion.items() if not complete)),
        candidate_scheduled_v_cost=float(scheduled_cost), candidate_waiting_proxy_cost=float(waiting_cost),
        full_attempt_termination=full_attempt.termination if full_attempt else termination,
        candidate_requires_hold_certification=not all(completion.values()),
        mip_dual_bound=None if bound is None else float(bound),
        numerical_status=getattr(solved,"numerical_status",None),
        solver_attempts=attempts,
        diagnostic_joint_time_windows=windows,
    )


def _empty_result(snapshot: NodeSnapshot, started: float, termination: str, b: _Builder) -> SolveResult:
    infeasible = termination == "INFEASIBLE"
    return SolveResult("INFEASIBLE" if infeasible else "NO_SOLUTION", termination, None, None, None, None, None, False, False if infeasible else None, {}, {}, {}, (), {}, time.perf_counter()-started, _hash_snapshot(snapshot), tuple(b.big_m),
                       model_version=model_version_for(snapshot),
                       input_uav_ids=tuple(sorted(d.uav_id for d in snapshot.descents)))
