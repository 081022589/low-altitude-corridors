from __future__ import annotations

from dataclasses import dataclass, field
import math
from typing import Mapping

# E-anchor is a new registered algorithm identity.  The previous v1.6
# identity exposed G/J compatibility projections and must not be reused for
# the E-only scheduling contract.
MODEL_VERSION = "CMLPM-SRCM-JDMILP-v1.7-E-ANCHOR-STRICT-DYNAMIC-FOLLOWING"
from .following_contract import FollowingDomain, MainlineFIFO
from .physical_entry_contract import PhysicalEntryCondition
SRCM_VERSION = "SRCM_CROSSING_V3_0_1"


@dataclass(frozen=True)
class Event:
    event_id: str
    uav_id: str
    phase: str
    section_id: str
    time_lb: float
    time_ub: float
    nominal_time: float
    activation: str = "always"  # always | completion
    resource_id: str | None = None
    committed_time: float | None = None


@dataclass(frozen=True)
class TravelArc:
    uav_id: str
    predecessor_id: str
    successor_id: str
    travel_min: float
    travel_max: float


@dataclass(frozen=True)
class DescentRequest:
    uav_id: str
    source_layer: str
    # E is the sole C-MLPM timing variable.  The motion layer owns the
    # downstream E->J/P realization; no G/J compatibility events belong in
    # this algorithm contract.
    entry_event_id: str
    service_offset: float
    nominal_service_time: float
    fifo_rank: float
    fifo_queue_id: str | None = None


@dataclass(frozen=True)
class MainlineFlow:
    uav_id: str
    exit_event_id: str
    nominal_exit_time: float
    max_delay: float
    # Uncommitted H cannot pass a stopped V ahead in its physical lane.
    # This is a dependency, not another selection/optimization variable.
    waiting_leader_id: str | None = None


@dataclass(frozen=True)
class ResourceUse:
    use_id: str
    uav_id: str
    resource_id: str
    role: str  # V | M
    anchor_event_id: str
    start_offset: float
    end_offset: float
    activation: str = "always"
    route_order: int = 0
    # Source/mainline layer is needed to distinguish same-layer following
    # from an orthogonal cross-layer V/H conflict at the same resource id.
    source_layer: str | None = None


@dataclass(frozen=True)
class FollowingTimeCondition:
    """Necessary event relation, never a continuous-motion certificate.

    Exactly one leader reference is used: a joint event variable or a published
    event constant. Curve-conditional feedback cannot enter this contract.
    """
    condition_id: str
    leader_id: str
    follower_id: str
    follower_event_id: str
    minimum_travel_s: float
    state_version: int
    lane_id: str
    leader_motion_version: str
    valid_until_s: float
    leader_event_id: str | None = None
    published_leader_time_s: float | None = None
    proof_kind: str = "OPTIMISTIC_DEPARTURE_NECESSARY"
    evidence: Mapping[str, object] = field(default_factory=dict)


@dataclass(frozen=True)
class VVConstraint:
    first_id: str
    second_id: str
    first_before_second_gap: float
    second_before_first_gap: float
    fixed_order: str | None = None
    shared_segments: tuple[str, ...] = ()


@dataclass(frozen=True)
class FrozenReservation:
    reservation_id: str
    uav_id: str
    resource_id: str
    role: str
    occupancy_start: float
    occupancy_end: float
    version: str
    q_reference_time: float | None = None
    q_reference_section: str | None = None
    q_reference_version: str | None = None
    q_start_offset: float | None = None
    q_end_offset: float | None = None
    source_layer: str | None = None


@dataclass(frozen=True)
class FrozenVVConstraint:
    constraint_id: str
    frozen_reservation_id: str
    new_uav_id: str
    resource_id: str
    frozen_to_new_gap: float
    new_to_frozen_gap: float
    separation_version: str
    fixed_order: str | None = None  # frozen | new | None


@dataclass(frozen=True)
class Separation:
    first_to_second: float
    second_to_first: float
    version: str


@dataclass(frozen=True)
class PendingTimingRequest:
    """Persistent request inputs, not a certified physical waiting command.

    ``can_hold`` permits a mathematical waiting decision. Publication still
    requires the execution layer to certify the actual hold and following.
    """
    uav_id: str
    request_id: str
    nominal_service_time_s: float
    first_eligible_time_s: float
    wait_rounds: int
    restart_time_lb_s: float
    can_hold: bool
    timing_available: bool = True
    resource_chain: tuple[str, ...] = ()


@dataclass(frozen=True)
class WaitingPolicy:
    next_check_time_s: float
    wait_step_weight: float
    wait_age_weight: float
    full_attempt_fraction: float
    requests: tuple[PendingTimingRequest, ...]
    previous_pending_ids: tuple[str, ...] = ()
    newly_eligible_ids: tuple[str, ...] = ()


@dataclass(frozen=True)
class NodeSnapshot:
    node_id: str
    t_now: float
    t_commit: float
    t_request: float | None
    t_clear: float | None  # Optional deadline for existing snapshot contracts.
    events: tuple[Event, ...]
    arcs: tuple[TravelArc, ...]
    descents: tuple[DescentRequest, ...]
    mainline_flows: tuple[MainlineFlow, ...]
    resource_uses: tuple[ResourceUse, ...]
    vv_constraints: tuple[VVConstraint, ...]
    vh_separation: Mapping[str, Separation]
    frozen_reservations: tuple[FrozenReservation, ...] = ()
    frozen_vv_constraints: tuple[FrozenVVConstraint, ...] = ()
    lambda_v: float = 1.0
    lambda_h: float = 1.0
    # HiGHS primal feasibility is checked independently at a slightly wider,
    # explicitly frozen tolerance; safety margins themselves are not reduced.
    tolerance: float = 2e-6
    srcm_version: str = SRCM_VERSION
    metadata: Mapping[str, object] = field(default_factory=dict)
    # A mathematical waiting decision still requires aircraft hold confirmation.
    waiting_policy: WaitingPolicy | None = None
    following_time_conditions: tuple[FollowingTimeCondition, ...] = ()
    mainline_fifo: tuple[MainlineFIFO, ...] = ()
    following_domain: FollowingDomain | None = None
    model_version: str = MODEL_VERSION
    physical_entry_conditions: tuple[PhysicalEntryCondition, ...] = ()
    execution_contract_version: str | None = None


def model_version_for(snapshot: NodeSnapshot) -> str:
    if snapshot.model_version != MODEL_VERSION:
        raise ContractError("UNSUPPORTED_CMLPM_MODEL", snapshot.model_version)
    return MODEL_VERSION


def timing_owner(snapshot: NodeSnapshot, uav_id: str) -> str:
    return next((h.waiting_leader_id for h in snapshot.mainline_flows
                 if h.uav_id == uav_id and h.waiting_leader_id is not None), uav_id)


def timing_candidate_available(snapshot: NodeSnapshot, uav_id: str) -> bool:
    if snapshot.waiting_policy is None:
        return True
    return next(r.timing_available for r in snapshot.waiting_policy.requests if r.uav_id == uav_id)


def descent_entry_event_id(request: DescentRequest) -> str:
    """Return the sole E event optimized for a descent request."""

    return request.entry_event_id


def waiting_delay_proxy(snapshot: NodeSnapshot, uav_id: str) -> float:
    policy = snapshot.waiting_policy
    if policy is None:
        raise ValueError("WAITING_POLICY_REQUIRED")
    request = next(item for item in policy.requests if item.uav_id == uav_id)
    delta = policy.next_check_time_s - snapshot.t_now
    return (max(0.0, policy.next_check_time_s + request.restart_time_lb_s
                - request.nominal_service_time_s)
            + policy.wait_step_weight * delta * (1 + policy.wait_age_weight * request.wait_rounds))


class ContractError(ValueError):
    def __init__(self, code: str, detail: str):
        super().__init__(f"{code}: {detail}")
        self.code = code
        self.detail = detail


def validate_snapshot(snapshot: NodeSnapshot) -> None:
    model_version_for(snapshot)
    if any(k in snapshot.metadata for k in ("mainline_resource_fifo", "following_time_contract")):
        raise ContractError("LEGACY_MATHEMATICAL_METADATA", "use explicit FIFO and following domain fields")
    numerical = (snapshot.t_now, snapshot.t_commit,
                 snapshot.tolerance, snapshot.lambda_v, snapshot.lambda_h)
    if (not all(math.isfinite(v) for v in numerical) or snapshot.tolerance <= 0
            or snapshot.lambda_v <= 0 or snapshot.lambda_h < 0):
        raise ContractError("INPUT_SCHEMA_INVALID", "invalid horizons, tolerance or objective weights")
    if snapshot.srcm_version != SRCM_VERSION:
        raise ContractError("INPUT_SCHEMA_INVALID", "unexpected SRCM version")
    if not snapshot.t_now <= snapshot.t_commit or (
        snapshot.t_request is not None and (
            not math.isfinite(snapshot.t_request) or snapshot.t_commit > snapshot.t_request)
    ) or (
        snapshot.t_clear is not None and (
            not math.isfinite(snapshot.t_clear)
            or (snapshot.t_request if snapshot.t_request is not None else snapshot.t_commit) > snapshot.t_clear)
    ):
        raise ContractError("INPUT_SCHEMA_INVALID", "evaluation horizons are unordered")
    events = {item.event_id: item for item in snapshot.events}
    if len(events) != len(snapshot.events):
        raise ContractError("INPUT_SCHEMA_INVALID", "duplicate event_id")
    physical_ids = {item.uav_id for item in snapshot.descents} | {item.uav_id for item in snapshot.mainline_flows}
    if len(physical_ids) != len(snapshot.descents) + len(snapshot.mainline_flows):
        raise ContractError("INPUT_SCHEMA_INVALID", "a physical UAV is duplicated as V and straight H")
    policy = snapshot.waiting_policy
    if policy is not None:
        ids = {d.uav_id for d in snapshot.descents}
        rows = {r.uav_id: r for r in policy.requests}
        previous, new = policy.previous_pending_ids, policy.newly_eligible_ids
        if (len(rows) != len(policy.requests) or set(rows) != ids
                or len(set(previous)) != len(previous) or len(set(new)) != len(new)
                or set(previous) & set(new) or set(previous) | set(new) != ids):
            raise ContractError("PENDING_UNIVERSE_MISMATCH", "previous pending union new must equal the complete input")
        values = (policy.next_check_time_s, policy.wait_step_weight,
                  policy.wait_age_weight, policy.full_attempt_fraction, snapshot.lambda_v, snapshot.lambda_h)
        if (not all(math.isfinite(v) for v in values)
                or policy.next_check_time_s <= snapshot.t_now
                or policy.wait_step_weight <= 0 or policy.wait_age_weight < 0
                or snapshot.lambda_v <= 0 or snapshot.lambda_h < 0
                or not 0 < policy.full_attempt_fraction < 1):
            raise ContractError("WAITING_POLICY_INVALID", "invalid period, weights or budget fraction")
        if len({r.request_id for r in policy.requests}) != len(policy.requests):
            raise ContractError("PENDING_IDENTITY_INVALID", "duplicate request_id")
        for d in snapshot.descents:
            r = rows[d.uav_id]
            values = (r.nominal_service_time_s, r.first_eligible_time_s, r.restart_time_lb_s)
            if (not r.request_id or not all(math.isfinite(v) for v in values)
                    or r.first_eligible_time_s > snapshot.t_now or r.restart_time_lb_s < 0
                    or type(r.wait_rounds) is not int or r.wait_rounds < 0
                    or type(r.can_hold) is not bool
                    or type(r.timing_available) is not bool
                    or abs(r.nominal_service_time_s - d.nominal_service_time) > snapshot.tolerance):
                raise ContractError("PENDING_IDENTITY_INVALID", d.uav_id)
            if not math.isfinite(waiting_delay_proxy(snapshot, d.uav_id)):
                raise ContractError("WAITING_POLICY_INVALID", "nonfinite waiting proxy")
    for event in snapshot.events:
        if not all(math.isfinite(value) for value in (event.time_lb, event.time_ub, event.nominal_time)):
            raise ContractError("INPUT_SCHEMA_INVALID", f"nonfinite event time: {event.event_id}")
        if event.time_lb > event.time_ub or event.activation not in {"always", "completion"}:
            raise ContractError("INPUT_SCHEMA_INVALID", f"invalid event bounds/activation: {event.event_id}")
        if event.committed_time is not None and not event.time_lb <= event.committed_time <= event.time_ub:
            raise ContractError("INPUT_SCHEMA_INVALID", f"committed time outside bounds: {event.event_id}")
    for arc in snapshot.arcs:
        if (not all(math.isfinite(v) for v in (arc.travel_min, arc.travel_max))
                or arc.predecessor_id not in events or arc.successor_id not in events or arc.travel_min > arc.travel_max):
            raise ContractError("INPUT_SCHEMA_INVALID", f"invalid arc {arc.predecessor_id}->{arc.successor_id}")
        left, right = events[arc.predecessor_id], events[arc.successor_id]
        if left.uav_id != arc.uav_id or right.uav_id != arc.uav_id:
            raise ContractError("INPUT_SCHEMA_INVALID", "arc crosses physical identities")
        if right.time_ub - left.time_lb < arc.travel_min - snapshot.tolerance or right.time_lb - left.time_ub > arc.travel_max + snapshot.tolerance:
            raise ContractError("INPUT_TIME_TEMPLATE_INCONSISTENT", f"arc has no reachable interval: {arc.successor_id}")
    descents = {item.uav_id: item for item in snapshot.descents}
    queue_ranks: set[tuple[str, float]] = set()
    for item in snapshot.descents:
        if not all(math.isfinite(v) for v in (item.service_offset, item.nominal_service_time)):
            raise ContractError("INPUT_SCHEMA_INVALID", f"nonfinite descent timing: {item.uav_id}")
        available = timing_candidate_available(snapshot, item.uav_id)
        if not available:
            r = rows[item.uav_id]
            if (item.source_layer not in {"L1", "L2", "L3"}
                    or not r.resource_chain
                    or any(e.uav_id == item.uav_id for e in snapshot.events)
                    or any(u.uav_id == item.uav_id for u in snapshot.resource_uses)):
                raise ContractError("WAIT_ONLY_TEMPLATE_INVALID", item.uav_id)
        elif item.source_layer not in {"L1", "L2", "L3"}:
            raise ContractError("INPUT_SCHEMA_INVALID", f"invalid descent request {item.uav_id}")
        if available:
            entry_id = descent_entry_event_id(item)
            if entry_id is None or entry_id not in events:
                raise ContractError("INPUT_SCHEMA_INVALID", f"missing E entry event for {item.uav_id}")
            entry = events[entry_id]
            if entry.uav_id != item.uav_id:
                raise ContractError("INPUT_SCHEMA_INVALID", "descent entry event identity mismatch")
        queue_id = item.fifo_queue_id or item.source_layer
        if not queue_id or not math.isfinite(item.fifo_rank) or item.fifo_rank < 0 or (queue_id, item.fifo_rank) in queue_ranks:
            raise ContractError("INPUT_SCHEMA_INVALID", f"invalid/duplicate FIFO rank for {item.uav_id}")
        queue_ranks.add((queue_id, item.fifo_rank))
    for flow in snapshot.mainline_flows:
        if flow.waiting_leader_id is not None:
            if policy is None or flow.waiting_leader_id not in descents:
                raise ContractError("H_WAITING_DEPENDENCY_INVALID", flow.uav_id)
            if any(e.uav_id == flow.uav_id and e.committed_time is not None
                   and e.committed_time > snapshot.t_now + snapshot.tolerance for e in snapshot.events):
                raise ContractError("H_WAITING_DEPENDENCY_INVALID", flow.uav_id)
            if any(r.uav_id == flow.uav_id and r.occupancy_end > snapshot.t_now + snapshot.tolerance
                   for r in snapshot.frozen_reservations):
                raise ContractError("H_WAITING_DEPENDENCY_INVALID", flow.uav_id)
        if flow.exit_event_id not in events or events[flow.exit_event_id].uav_id != flow.uav_id:
            raise ContractError("INPUT_SCHEMA_INVALID", f"invalid H exit event for {flow.uav_id}")
        exit_event = events[flow.exit_event_id]
        if not all(math.isfinite(value) for value in (flow.nominal_exit_time, flow.max_delay)) or flow.max_delay < 0:
            raise ContractError("INPUT_SCHEMA_INVALID", f"invalid H exit semantics for {flow.uav_id}")
        allowed_exit_ub = flow.nominal_exit_time + flow.max_delay
        if allowed_exit_ub < exit_event.time_lb - snapshot.tolerance or allowed_exit_ub > exit_event.time_ub + snapshot.tolerance:
            raise ContractError("INPUT_TIME_TEMPLATE_INCONSISTENT", f"H allowed exit upper outside reachable window: {flow.uav_id}")
        if snapshot.t_clear is not None and exit_event.time_lb > snapshot.t_clear + snapshot.tolerance:
            raise ContractError("H_CLEAR_HORIZON_INSUFFICIENT", flow.uav_id)
    use_ids: set[str] = set()
    physical_use_keys: set[tuple[str, str, str]] = set()
    for use in snapshot.resource_uses:
        if (not all(math.isfinite(v) for v in (use.start_offset, use.end_offset))
                or use.use_id in use_ids or use.anchor_event_id not in events or use.end_offset <= use.start_offset):
            raise ContractError("INPUT_SCHEMA_INVALID", f"invalid resource use {use.use_id}")
        use_ids.add(use.use_id)
        if events[use.anchor_event_id].uav_id != use.uav_id or use.role not in {"V", "M"} or use.activation not in {"always", "completion"}:
            raise ContractError("INPUT_SCHEMA_INVALID", f"resource use identity/role mismatch {use.use_id}")
        key = (use.uav_id, use.resource_id, use.role)
        if key in physical_use_keys:
            raise ContractError("INPUT_SCHEMA_INVALID", f"duplicate physical resource occupancy {key}")
        physical_use_keys.add(key)
        if (use.role == "V" or use.activation == "completion") and use.uav_id not in descents:
            raise ContractError("INPUT_SCHEMA_INVALID", "completion use without descent request")
    if any(not item.version or not all(math.isfinite(v) for v in (item.first_to_second,item.second_to_first))
           or min(item.first_to_second, item.second_to_first) < 0 for item in snapshot.vh_separation.values()):
        raise ContractError("INPUT_SEPARATION_PARAMETER_MISSING", "VH separation version missing")
    frozen_ids: set[str] = set()
    for item in snapshot.frozen_reservations:
        if (not all(math.isfinite(v) for v in (item.occupancy_start,item.occupancy_end))
                or item.reservation_id in frozen_ids or item.role not in {"V", "M"} or item.occupancy_end <= item.occupancy_start or not item.version):
            raise ContractError("INPUT_SCHEMA_INVALID", f"invalid frozen reservation {item.reservation_id}")
        if item.source_layer is not None and item.source_layer not in {"L1", "L2", "L3"}:
            raise ContractError("INPUT_SCHEMA_INVALID", f"invalid frozen source layer {item.reservation_id}")
        frozen_ids.add(item.reservation_id)
        if item.role == "V":
            reference = (
                item.q_reference_time, item.q_reference_section,
                item.q_reference_version, item.q_start_offset, item.q_end_offset,
            )
            if any(value is None or value == "" for value in reference):
                raise ContractError("FROZEN_VV_REFERENCE_MISSING", item.reservation_id)
            if not all(math.isfinite(v) for v in (item.q_reference_time, item.q_start_offset, item.q_end_offset)):
                raise ContractError("FROZEN_VV_REFERENCE_MISSING", item.reservation_id)
            if abs(item.q_reference_time + item.q_start_offset - item.occupancy_start) > snapshot.tolerance or abs(item.q_reference_time + item.q_end_offset - item.occupancy_end) > snapshot.tolerance:
                raise ContractError("FROZEN_VV_REFERENCE_MISSING", f"inconsistent q anchor: {item.reservation_id}")
    frozen_by_id = {item.reservation_id: item for item in snapshot.frozen_reservations}
    frozen_vv_ids: set[str] = set()
    frozen_vv_pairs: set[tuple[str, str, str]] = set()
    for item in snapshot.frozen_vv_constraints:
        frozen = frozen_by_id.get(item.frozen_reservation_id)
        if item.constraint_id in frozen_vv_ids or frozen is None or frozen.role != "V":
            raise ContractError("INPUT_SCHEMA_INVALID", f"invalid frozen VV constraint {item.constraint_id}")
        frozen_vv_ids.add(item.constraint_id)
        if item.new_uav_id not in descents or item.resource_id != frozen.resource_id:
            raise ContractError("INPUT_SCHEMA_INVALID", f"frozen VV identity/resource mismatch {item.constraint_id}")
        if item.fixed_order not in {None, "frozen", "new"}:
            raise ContractError("INPUT_SCHEMA_INVALID", f"invalid frozen VV order {item.constraint_id}")
        if (not item.separation_version or not all(math.isfinite(v) for v in (item.frozen_to_new_gap,item.new_to_frozen_gap))
                or min(item.frozen_to_new_gap, item.new_to_frozen_gap) < 0):
            raise ContractError("INPUT_SEPARATION_PARAMETER_MISSING", item.constraint_id)
        pair = (item.frozen_reservation_id, item.new_uav_id, item.resource_id)
        if pair in frozen_vv_pairs:
            raise ContractError("INPUT_SCHEMA_INVALID", f"duplicate frozen VV pair {pair}")
        frozen_vv_pairs.add(pair)
    condition_ids = set()
    for item in snapshot.following_time_conditions:
        follower = events.get(item.follower_event_id)
        leader = events.get(item.leader_event_id)
        if (item.condition_id in condition_ids or item.leader_id == item.follower_id
                or follower is None or follower.uav_id != item.follower_id
                or (item.leader_event_id is None) == (item.published_leader_time_s is None)
                or (item.leader_event_id is not None and (leader is None or leader.uav_id != item.leader_id))
                or item.proof_kind not in {"OPTIMISTIC_DEPARTURE_NECESSARY", "OPTIMISTIC_MAINLINE_EVENT_NECESSARY"}
                or item.state_version != snapshot.metadata.get("state_version")
                or not item.lane_id or not item.leader_motion_version
                or not math.isfinite(item.minimum_travel_s) or item.minimum_travel_s < 0
                or not math.isfinite(item.valid_until_s)
                or item.valid_until_s < (snapshot.t_clear if snapshot.t_clear is not None else follower.time_ub)
                or (item.published_leader_time_s is not None and not math.isfinite(item.published_leader_time_s))):
            raise ContractError("INVALID_FOLLOWING_TIME_CONDITION", item.condition_id)
        condition_ids.add(item.condition_id)
    for item in snapshot.vv_constraints:
        if item.first_id not in descents or item.second_id not in descents or item.first_id == item.second_id:
            raise ContractError("INPUT_SCHEMA_INVALID", "invalid VV identities")
        if item.fixed_order not in {None, item.first_id, item.second_id}:
            raise ContractError("INPUT_SCHEMA_INVALID", "invalid VV fixed order")
        if (not all(math.isfinite(v) for v in (item.first_before_second_gap,item.second_before_first_gap))
                or min(item.first_before_second_gap, item.second_before_first_gap) < 0):
            raise ContractError("INPUT_SEPARATION_PARAMETER_MISSING", "negative VV headway")
    roles_by_resource: dict[str, set[str]] = {}
    for use in snapshot.resource_uses:
        roles_by_resource.setdefault(use.resource_id, set()).add(use.role)
    for frozen in snapshot.frozen_reservations:
        roles_by_resource.setdefault(frozen.resource_id, set()).add(frozen.role)
    from .conflict_builder import is_cross_layer_vh_frozen, is_cross_layer_vh_use
    missing_vh = []
    for resource, roles in roles_by_resource.items():
        if roles != {"V", "M"} or resource in snapshot.vh_separation:
            continue
        uses = [use for use in snapshot.resource_uses if use.resource_id == resource]
        frozen = [item for item in snapshot.frozen_reservations if item.resource_id == resource]
        cross_layer = any(
            is_cross_layer_vh_use(v, m)
            for v in uses if v.role == "V"
            for m in uses if m.role == "M"
        ) or any(
            is_cross_layer_vh_frozen(v, m)
            for v in [*uses, *frozen] if v.role == "V"
            for m in [*uses, *frozen] if m.role == "M"
        )
        if cross_layer:
            missing_vh.append(resource)
    if missing_vh:
        raise ContractError("INPUT_SEPARATION_PARAMETER_MISSING", ",".join(missing_vh))
    # Every potentially interacting frozen/new vertical pair requires explicit,
    # versioned pairwise headways.  It is never replaced by channel capacity 1.
    for frozen in snapshot.frozen_reservations:
        if frozen.role != "V":
            continue
        for use in snapshot.resource_uses:
            if use.role != "V" or use.resource_id != frozen.resource_id or use.uav_id == frozen.uav_id:
                continue
            pair = (frozen.reservation_id, use.uav_id, use.resource_id)
            if pair not in frozen_vv_pairs:
                raise ContractError("INPUT_SEPARATION_PARAMETER_MISSING", f"frozen VV pair {pair}")

    from .following_contract import validate_domain
    validate_domain(snapshot)
    from .physical_entry_contract import validate_conditions
    validate_conditions(snapshot)


def event_map(snapshot: NodeSnapshot) -> dict[str, Event]:
    return {item.event_id: item for item in snapshot.events}
