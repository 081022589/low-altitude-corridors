from __future__ import annotations

from dataclasses import dataclass

from .schema import (ContractError, NodeSnapshot, ResourceUse, event_map,
                     timing_candidate_available, descent_entry_event_id)


SHARED_RESOURCE_ENTRY_HEADWAY_S = 2.5
_LAYER_INDEX = {"L1": 1, "L2": 2, "L3": 3}


@dataclass(frozen=True)
class VHConflict:
    vertical_use_id: str
    mainline_use_id: str
    resource_id: str
    vertical_uav_id: str
    mainline_uav_id: str


@dataclass(frozen=True)
class VVMergeConflict:
    first_use_id: str
    second_use_id: str
    resource_id: str
    first_uav_id: str
    second_uav_id: str


@dataclass(frozen=True)
class FrozenVVMergeConflict:
    new_use_id: str
    frozen_reservation_id: str
    constraint_id: str
    resource_id: str


def is_cross_layer_vh_use(vertical, mainline) -> bool:
    """Whether a V/M pair needs orthogonal VH separation.

    Older external fixtures may omit source layers.  Such rows retain the
    historical conservative behavior; production rows carry the layer and
    same-layer pairs are deliberately left to the following/FIFO contract.
    """

    if vertical.role != "V" or mainline.role != "M":
        return False
    if vertical.source_layer is None or mainline.source_layer is None:
        return True
    return str(vertical.source_layer) != str(mainline.source_layer)


def is_cross_layer_vh_frozen(vertical, mainline) -> bool:
    """Layer-aware V/M classification when one side is frozen."""

    if vertical.role != "V" or mainline.role != "M":
        return False
    if vertical.source_layer is None or mainline.source_layer is None:
        return True
    return str(vertical.source_layer) != str(mainline.source_layer)


def reachable_interval(snapshot: NodeSnapshot, use: ResourceUse, events=None) -> tuple[float, float, float, float]:
    event = (events or event_map(snapshot))[use.anchor_event_id]
    return (
        event.time_lb + use.start_offset,
        event.time_ub + use.start_offset,
        event.time_lb + use.end_offset,
        event.time_ub + use.end_offset,
    )


def build_vh_conflicts(snapshot: NodeSnapshot, *, events=None, intervals=None) -> tuple[VHConflict, ...]:
    """Enumerate from full reachable domains, never nominal overlap lists."""
    vertical = [item for item in snapshot.resource_uses if item.role == "V"]
    mainline = [item for item in snapshot.resource_uses if item.role == "M"]
    result = []
    intervals = intervals or {
        use.use_id: reachable_interval(snapshot, use, events)
        for use in snapshot.resource_uses
    }
    for v in vertical:
        v_start_lb, v_start_ub, v_end_lb, v_end_ub = intervals[v.use_id]
        for m in mainline:
            if v.resource_id != m.resource_id or v.uav_id == m.uav_id:
                continue
            if not is_cross_layer_vh_use(v, m):
                continue
            m_start_lb, m_start_ub, m_end_lb, m_end_ub = intervals[m.use_id]
            # A pair is safely irrelevant only when every reachable realization
            # has a fixed order even before applying the provided separation.
            sep = snapshot.vh_separation.get(v.resource_id)
            if sep is None:
                raise ValueError(f"INPUT_SEPARATION_PARAMETER_MISSING: {v.resource_id}")
            always_v_first = (
                v_end_ub + sep.first_to_second <= m_start_lb
                and v_start_ub + SHARED_RESOURCE_ENTRY_HEADWAY_S <= m_start_lb
            )
            always_m_first = (
                m_end_ub + sep.second_to_first <= v_start_lb
                and m_start_ub + SHARED_RESOURCE_ENTRY_HEADWAY_S <= v_start_lb
            )
            if not (always_v_first or always_m_first):
                result.append(VHConflict(v.use_id, m.use_id, v.resource_id, v.uav_id, m.uav_id))
    return tuple(result)


def _vertical_uses(snapshot: NodeSnapshot) -> dict[str, dict[str, ResourceUse]]:
    result: dict[str, dict[str, ResourceUse]] = {}
    for use in snapshot.resource_uses:
        if use.role == "V":
            result.setdefault(use.uav_id, {})[use.resource_id] = use
    return result


def _merge_resource_use(snapshot: NodeSnapshot, lower_uav_id: str, events=None, descents=None) -> ResourceUse:
    descents = descents or {item.uav_id: item for item in snapshot.descents}
    request = descents[lower_uav_id]
    resource_id = (events or event_map(snapshot))[descent_entry_event_id(request)].resource_id
    candidates = [
        use for use in snapshot.resource_uses
        if use.uav_id == lower_uav_id and use.role == "V" and use.resource_id == resource_id
    ]
    if resource_id is None or len(candidates) != 1 or candidates[0].route_order != 0:
        raise ContractError("MERGE_RESOURCE_USE_MISSING", lower_uav_id)
    return candidates[0]


def build_vv_merge_conflicts(snapshot: NodeSnapshot, *, events=None, descents=None) -> tuple[VVMergeConflict, ...]:
    """Classify only the approved lower-source-layer physical merge resource."""
    descents = descents or {item.uav_id: item for item in snapshot.descents}
    uses = _vertical_uses(snapshot)
    result = []
    for item in snapshot.vv_constraints:
        if not (timing_candidate_available(snapshot, item.first_id)
                and timing_candidate_available(snapshot, item.second_id)):
            continue
        first, second = descents[item.first_id], descents[item.second_id]
        if first.source_layer == second.source_layer:
            continue
        lower = first if _LAYER_INDEX[first.source_layer] < _LAYER_INDEX[second.source_layer] else second
        higher = second if lower is first else first
        lower_use = _merge_resource_use(snapshot, lower.uav_id, events, descents)
        higher_use = uses.get(higher.uav_id, {}).get(lower_use.resource_id)
        if higher_use is None or lower_use.resource_id not in item.shared_segments:
            raise ContractError(
                "MERGE_RESOURCE_USE_MISSING",
                f"{item.first_id}/{item.second_id}:{lower_use.resource_id}",
            )
        if higher_use.route_order <= lower_use.route_order:
            raise ContractError(
                "MERGE_RESOURCE_ROUTE_ORDER_INCONSISTENT",
                f"{item.first_id}/{item.second_id}:{lower_use.resource_id}",
            )
        first_use = lower_use if lower.uav_id == item.first_id else higher_use
        second_use = lower_use if lower.uav_id == item.second_id else higher_use
        result.append(VVMergeConflict(
            first_use.use_id, second_use.use_id, lower_use.resource_id,
            item.first_id, item.second_id,
        ))
    return tuple(result)


def build_frozen_vv_merge_conflicts(snapshot: NodeSnapshot, *, events=None, descents=None) -> tuple[FrozenVVMergeConflict, ...]:
    """Classify frozen/new merge conflicts only when both source layers are explicit."""
    descents = descents or {item.uav_id: item for item in snapshot.descents}
    frozen = {item.reservation_id: item for item in snapshot.frozen_reservations}
    uses = _vertical_uses(snapshot)
    result = []
    for item in snapshot.frozen_vv_constraints:
        if not timing_candidate_available(snapshot, item.new_uav_id):
            continue
        reservation = frozen[item.frozen_reservation_id]
        new = descents[item.new_uav_id]
        if reservation.source_layer is None or reservation.source_layer == new.source_layer:
            continue
        if reservation.source_layer not in _LAYER_INDEX:
            raise ContractError("INPUT_SCHEMA_INVALID", f"frozen source layer: {reservation.reservation_id}")
        if _LAYER_INDEX[new.source_layer] < _LAYER_INDEX[reservation.source_layer]:
            merge_use = _merge_resource_use(snapshot, new.uav_id, events, descents)
            merge_resource = merge_use.resource_id
            if merge_resource != item.resource_id:
                # Other common downstream resources keep the ordinary frozen
                # per-resource VV constraints; only the physical merge uses
                # the cross-layer merge rule. Never erase the source layer.
                continue
        else:
            merge_resource = reservation.resource_id
            merge_use = uses.get(new.uav_id, {}).get(merge_resource)
        if merge_use is None or merge_resource != item.resource_id:
            raise ContractError("MERGE_RESOURCE_USE_MISSING", item.constraint_id)
        result.append(FrozenVVMergeConflict(
            merge_use.use_id, reservation.reservation_id, item.constraint_id, merge_resource,
        ))
    return tuple(result)


def potential_frozen_conflicts(snapshot: NodeSnapshot, *, events=None, intervals=None) -> tuple[tuple[str, str], ...]:
    pairs = []
    intervals = intervals or {
        use.use_id: reachable_interval(snapshot, use, events)
        for use in snapshot.resource_uses
    }
    for use in snapshot.resource_uses:
        lo_s, hi_s, lo_e, hi_e = intervals[use.use_id]
        for frozen in snapshot.frozen_reservations:
            if use.resource_id != frozen.resource_id or use.uav_id == frozen.uav_id:
                continue
            # Only orthogonal V/M use is interval-exclusive. Same-direction
            # V/V and M/M frozen neighbours must be supplied as explicit
            # VV or HH constraints so longitudinal following remains allowed.
            if use.role == frozen.role:
                continue
            vertical, mainline = (use, frozen) if use.role == "V" else (frozen, use)
            if not is_cross_layer_vh_frozen(vertical, mainline):
                continue
            sep = snapshot.vh_separation.get(use.resource_id)
            if sep is None:
                raise ValueError(f"INPUT_SEPARATION_PARAMETER_MISSING: {use.resource_id}")
            before_gap = sep.first_to_second if use.role == "V" else sep.second_to_first
            after_gap = sep.second_to_first if use.role == "V" else sep.first_to_second
            always_before = (
                hi_e + before_gap <= frozen.occupancy_start
                and hi_s + SHARED_RESOURCE_ENTRY_HEADWAY_S <= frozen.occupancy_start
            )
            always_after = (
                frozen.occupancy_end + after_gap <= lo_s
                and frozen.occupancy_start + SHARED_RESOURCE_ENTRY_HEADWAY_S <= lo_s
            )
            if not (always_before or always_after):
                pairs.append((use.use_id, frozen.reservation_id))
    return tuple(pairs)
