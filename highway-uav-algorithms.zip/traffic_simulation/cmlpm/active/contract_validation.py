"""Strict validation at the canonical C-MLPM public boundary."""

from __future__ import annotations

from itertools import combinations

from ..joint_single_node.schema import ContractError, NodeSnapshot, validate_snapshot, timing_candidate_available


def _missing(detail: str) -> ContractError:
    return ContractError("MISSING_REQUIRED_CONTRACT_FIELD", detail)


def validate_complete_snapshot(snapshot: NodeSnapshot) -> None:
    """Validate a complete single-node contract, rejecting reduced V2 inputs."""

    validate_snapshot(snapshot)
    if not snapshot.node_id.strip():
        raise _missing("node_id")

    legal_paths = snapshot.metadata.get("legal_paths")
    if snapshot.descents and not isinstance(legal_paths, dict):
        raise _missing("metadata.legal_paths")

    vertical_uses: dict[str, list] = {}
    mainline_uses: dict[str, list] = {}
    for use in snapshot.resource_uses:
        target = vertical_uses if use.role == "V" else mainline_uses
        target.setdefault(use.uav_id, []).append(use)

    for request in snapshot.descents:
        declared = legal_paths.get(request.source_layer) if isinstance(legal_paths, dict) else None
        if not declared:
            raise _missing(f"metadata.legal_paths.{request.source_layer}")
        if not timing_candidate_available(snapshot, request.uav_id):
            pending = next(r for r in snapshot.waiting_policy.requests if r.uav_id == request.uav_id)
            if tuple(pending.resource_chain) != tuple(declared):
                raise ContractError("INCOMPLETE_SRCM_RESOURCE_PATH", request.uav_id)
            continue
        actual = tuple(
            use.resource_id
            for use in sorted(vertical_uses.get(request.uav_id, ()), key=lambda item: item.route_order)
        )
        if actual != tuple(declared):
            raise ContractError(
                "INCOMPLETE_SRCM_RESOURCE_PATH",
                f"{request.uav_id}: expected {tuple(declared)!r}, got {actual!r}",
            )

    for flow in snapshot.mainline_flows:
        if not mainline_uses.get(flow.uav_id):
            raise _missing(f"mainline resource use for {flow.uav_id}")

    queues: dict[str, set[str]] = {}
    for request in snapshot.descents:
        queues.setdefault(request.fifo_queue_id or request.source_layer, set()).add(request.source_layer)
    mixed = sorted(queue_id for queue_id, layers in queues.items() if len(layers) != 1)
    if mixed:
        raise ContractError("INVALID_CROSS_LAYER_FIFO", ",".join(mixed))

    vv_pairs = {frozenset((item.first_id, item.second_id)) for item in snapshot.vv_constraints}
    resources = {uav_id: {use.resource_id for use in uses} for uav_id, uses in vertical_uses.items()}
    for first, second in combinations(snapshot.descents, 2):
        if resources.get(first.uav_id, set()) & resources.get(second.uav_id, set()):
            pair = frozenset((first.uav_id, second.uav_id))
            if pair not in vv_pairs:
                raise _missing(f"VV constraint for {first.uav_id}/{second.uav_id}")

