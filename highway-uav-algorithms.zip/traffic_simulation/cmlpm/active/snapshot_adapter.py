"""Side-effect-free construction of the canonical complete snapshot."""

from __future__ import annotations

from collections.abc import Mapping

from .contract_validation import validate_complete_snapshot
from ..joint_single_node.schema import ContractError, NodeSnapshot
from ..joint_single_node.snapshot_io import snapshot_from_dict


_REQUIRED_ROOT_FIELDS = {
    "node_id", "t_now", "t_commit", "events", "arcs",
    "descents", "mainline_flows", "resource_uses", "following_domain",
    "following_time_conditions", "mainline_fifo", "model_version",
    "vv_constraints", "vh_separation",
}


def build_complete_snapshot(payload: Mapping[str, object]) -> NodeSnapshot:
    """Build one node snapshot without inventing absent physical semantics."""

    data = dict(payload)
    missing = sorted(_REQUIRED_ROOT_FIELDS - set(data))
    if missing:
        raise ContractError("MISSING_REQUIRED_CONTRACT_FIELD", ",".join(missing))
    try:
        snapshot = snapshot_from_dict(data)
    except ContractError:
        raise
    except (TypeError, ValueError, KeyError, AttributeError) as error:
        raise ContractError("INPUT_SCHEMA_INVALID", str(error)) from error
    validate_complete_snapshot(snapshot)
    return snapshot
