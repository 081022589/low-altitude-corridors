"""Pure C-MLPM solve entry point and simulation-side validation adapter.

The optimizer returns a mathematical candidate.  Independent validation is
kept available for the simulation coordinator, but is deliberately not part
of :func:`solve_cmlpm`.
"""

from __future__ import annotations

from .contract_validation import validate_complete_snapshot
from ..joint_single_node.milp_reference import SolveResult, solve_timing
from ..joint_single_node.schema import MODEL_VERSION, NodeSnapshot
from ..joint_single_node.snapshot_io import snapshot_semantic_hash


ALGORITHM_ID = "CMLPM"
SOLVER_METHOD = "JOINT_MILP_B3"


def certify_cmlpm_result(*args, **kwargs):
    """Load the simulation-owned independent Checker adapter lazily."""

    from .validation import certify_cmlpm_result as _certify

    return _certify(*args, **kwargs)


def solve_cmlpm(snapshot: NodeSnapshot, *, time_limit_s: float = 30.0) -> SolveResult:
    """Solve the C-MLPM timing model and return its unmodified candidate.

    This function owns no simulation state, publication, motion execution, or
    independent Checker decision.  Callers in the simulation layer must pass
    the returned candidate to :func:`certify_cmlpm_result` explicitly.
    """

    if time_limit_s <= 0:
        raise ValueError("time_limit_s must be positive")
    validate_complete_snapshot(snapshot)
    before = snapshot_semantic_hash(snapshot)
    if not snapshot.descents and not snapshot.mainline_flows:
        no_work = SolveResult(
            solver_status="NOT_RUN",
            termination="NO_DESCENT_REQUESTS",
            candidate_scheduled_count=0,
            joint_cost=0.0,
            v_cost=0.0,
            h_cost=0.0,
            mip_gap=None,
            candidate_all_requests_scheduled=True,
            candidate_all_requests_timing_feasible=True,
            event_times={},
            candidate_completion={},
            orders={},
            resource_occupancies=(),
            candidate_pending_states={},
            solve_seconds=0.0,
            input_snapshot_hash=before,
            big_m_values=(),
        )
        return no_work
    return solve_timing(snapshot, time_limit=time_limit_s)


