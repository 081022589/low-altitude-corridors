"""Simulation-side independent validation for C-MLPM candidates."""

from __future__ import annotations

from dataclasses import dataclass
from types import MappingProxyType
from typing import Mapping

from .contract_validation import validate_complete_snapshot
from ..joint_single_node.independent_checker import CheckReport, check_solution
from ..joint_single_node.milp_reference import SolveResult
from ..joint_single_node.schema import MODEL_VERSION, NodeSnapshot, model_version_for
from ..joint_single_node.snapshot_io import snapshot_semantic_hash


@dataclass(frozen=True)
class CMLPMRun:
    """Checker result plus candidate evidence, owned by simulation only."""

    result: SolveResult
    verification: CheckReport
    snapshot_semantic_sha256: str
    input_unchanged: bool
    timing_certified: bool
    optimality_proved: bool
    candidate_event_times: Mapping[str, float]
    candidate_resource_occupancies: tuple[Mapping[str, object], ...]
    requires_execution_handoff: bool = True
    algorithm_id: str = "CMLPM"
    model_version: str = MODEL_VERSION
    solver_method: str = "JOINT_MILP_B3"


def certify_cmlpm_result(
    snapshot: NodeSnapshot,
    result: SolveResult,
    *,
    expected_snapshot_sha256: str | None = None,
) -> CMLPMRun:
    """Independently check the exact candidate the simulation may publish."""

    validate_complete_snapshot(snapshot)
    current_hash = snapshot_semantic_hash(snapshot)
    expected_hash = expected_snapshot_sha256 or current_hash
    verification = check_solution(snapshot, result)
    expected_version = model_version_for(snapshot)
    if result.model_version != expected_version:
        counts = dict(verification.audit_counts)
        counts["MODEL_VERSION_MISMATCH"] = counts.get("MODEL_VERSION_MISMATCH", 0) + 1
        verification = CheckReport(
            False,
            verification.violations + ({
                "code": "MODEL_VERSION_MISMATCH",
                "expected": expected_version,
                "actual": result.model_version,
            },),
            counts,
        )
    unchanged = expected_hash == current_hash
    timing_certified = verification.passed and unchanged
    if timing_certified:
        event_times: Mapping[str, float] = MappingProxyType(dict(result.event_times))
        occupancies = tuple(MappingProxyType(dict(item)) for item in result.resource_occupancies)
    else:
        event_times = MappingProxyType({})
        occupancies = ()
    return CMLPMRun(
        result=result,
        verification=verification,
        snapshot_semantic_sha256=current_hash,
        input_unchanged=unchanged,
        timing_certified=timing_certified,
        optimality_proved=result.termination == "MILP_PROVED_OPTIMAL",
        candidate_event_times=event_times,
        candidate_resource_occupancies=occupancies,
        model_version=expected_version,
    )
