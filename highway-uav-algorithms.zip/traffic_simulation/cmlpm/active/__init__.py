"""Current dynamic-following timing contract; motion confirmation precedes CAS."""

from .api import (
    ALGORITHM_ID,
    MODEL_VERSION,
    SOLVER_METHOD,
    solve_cmlpm,
)
from .contract_validation import validate_complete_snapshot
from .snapshot_adapter import build_complete_snapshot
from ..joint_single_node.schema import PendingTimingRequest, WaitingPolicy, FollowingTimeCondition
from ..joint_single_node.following_contract import FollowingDomain, FollowingAircraft, MainlineFIFO

__all__ = [
    "ALGORITHM_ID", "MODEL_VERSION", "SOLVER_METHOD", "CMLPMRun",
    "build_complete_snapshot", "certify_cmlpm_result", "solve_cmlpm",
    "validate_complete_snapshot",
    "PendingTimingRequest", "WaitingPolicy", "FollowingTimeCondition",
    "FollowingDomain", "FollowingAircraft", "MainlineFIFO",
]


def __getattr__(name):
    """Load simulation-only validation symbols on demand."""

    if name == "CMLPMRun":
        from .validation import CMLPMRun
        return CMLPMRun
    if name == "certify_cmlpm_result":
        from .validation import certify_cmlpm_result
        return certify_cmlpm_result
    raise AttributeError(name)
