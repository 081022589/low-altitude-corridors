"""Traffic scheduling support."""
