"""Shared runtime parameter access for the motion environment.

Physical values live in the experiment configuration and vehicle registry,
never in individual motion phases. Callers with an active configuration must
pass it through; standalone tools load the same baseline configuration.
"""
from copy import deepcopy
import json
import math
from pathlib import Path

BASELINE_PATH = Path(__file__).resolve().parents[1] / 'experiments/ecja_cmlpm_dt_flow_v1/configs/baseline.yaml'


def runtime_config(config=None):
    return deepcopy(config) if config is not None else json.loads(BASELINE_PATH.read_text(encoding='utf-8'))


def positive(value, name):
    value = float(value)
    if not math.isfinite(value) or value <= 0:
        raise ValueError('INVALID_PROJECT_PARAMETER:' + name)
    return value


def layer_vehicle(config, layer):
    return config['network']['vehicle_type_by_layer'][layer]


def layer_altitude(config, layer):
    return positive(config['network']['layer_centers_m'][int(layer[1:])-1], 'layer_altitude')


def vehicle_motion(config, vehicle_type):
    from configs.mission_config import DEFAULT_UAV_TYPE_SPECS
    motion = config['motion']
    spec = DEFAULT_UAV_TYPE_SPECS[vehicle_type]
    speed = positive(motion['nominal_and_normal_max_speed_mps'][vehicle_type], 'normal_speed')
    acceleration = positive(motion['max_abs_acceleration_mps2'][vehicle_type], 'acceleration')
    climb = positive(motion['vertical_speed_mps'], 'vertical_speed')
    if speed > float(spec['max_speed']) or acceleration > float(spec['max_horizontal_acceleration_mps2']):
        raise ValueError('PROJECT_MOTION_EXCEEDS_VEHICLE_CAPABILITY:' + vehicle_type)
    if climb > float(spec['max_climb_speed']):
        raise ValueError('PROJECT_CLIMB_EXCEEDS_VEHICLE_CAPABILITY:' + vehicle_type)
    return dict(climb_speed_mps=climb, max_climb_speed_mps=float(spec['max_climb_speed']),
                acceleration_mps2=acceleration, max_acceleration_mps2=acceleration,
                max_speed_mps=speed)
