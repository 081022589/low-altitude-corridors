﻿"""Mission, UAV, and demand-profile configuration helpers."""

from __future__ import annotations

from dataclasses import dataclass, field
import math


DEFAULT_UAV_TYPE_SPECS = {
    "cargo_small": {
        "name": "cargo_small",
        "length_m": 1.2,
        "width_m": 1.2,
        "height_m": 0.5,
        # 2026-10-26 参数重整：三档巡航速度 10 / 12 / 15 m/s。
        # 上端 15 = 50 m 安全间距所允许的制动上界 sqrt(2*a*50)=16.57 m/s 的 90.5%。
        # 货运档保持 12.0：改为 12.5 会触发联合运动离散化不可行（见
        # docs 记录），为 0.5 m/s 的装饰性差异牺牲求解稳定性不值得。
        "cruise_speed": 12.0,
        "max_speed": 16.0,
        "climb_speed": 2.5,
        "max_climb_speed": 4.0,
        "max_descent_speed": 3.0,
        "payload_capacity_kg": 5.0,
        "empty_mass_kg": 7.0,
        "nominal_payload_kg": 2.75,
        "maximum_takeoff_mass_kg": 12.0,
        "passenger_capacity": 0,
        "battery_range_m": 12000.0,
        "hover_power_w": 346.0,
        "battery_capacity_wh": 96.0,
        "service_ceiling_m": 250.0,
        "mass_kg": 12.0,
        "min_total_thrust_n": 70.6,
        "max_total_thrust_n": 211.9,
        "max_tilt_deg": 25.0,
        # 由最大俯仰角导出：a = 0.6 * g * tan(25°) = 2.74 m/s²。
        # 0.6 为运营折扣，保留 40% 推力余量用于姿态控制与抗风扰动。
        "max_horizontal_acceleration_mps2": 2.7447,
        "max_vertical_acceleration_mps2": 2.0,
        "max_thrust_rate_nps": 235.4,
    },
    "medical_fast": {
        "name": "medical_fast",
        "length_m": 1.6,
        "width_m": 1.6,
        "height_m": 0.6,
        "cruise_speed": 15.0,
        "max_speed": 18.0,
        "climb_speed": 4.0,
        "max_climb_speed": 6.0,
        # 2026-10-15 decision: raised from 2.0 so that the uniform 3.0 m/s
        # shared-descent setting is inside every vehicle envelope.
        "max_descent_speed": 3.0,
        "payload_capacity_kg": 3.0,
        "empty_mass_kg": 12.5,
        "nominal_payload_kg": 1.6,
        "maximum_takeoff_mass_kg": 15.5,
        "passenger_capacity": 0,
        "battery_range_m": 18000.0,
        "hover_power_w": 432.0,
        "battery_capacity_wh": 144.0,
        "service_ceiling_m": 350.0,
        "mass_kg": 15.5,
        "min_total_thrust_n": 91.2,
        "max_total_thrust_n": 258.4,
        "max_tilt_deg": 25.0,
        # 由最大俯仰角导出：a = 0.6 * g * tan(25°) = 2.74 m/s²（同 cargo_small）。
        "max_horizontal_acceleration_mps2": 2.7447,
        "max_vertical_acceleration_mps2": 2.5,
        "max_thrust_rate_nps": 304.1,
    },
    "inspection_uav": {
        "name": "inspection_uav",
        "length_m": 0.8,
        "width_m": 0.8,
        "height_m": 0.4,
        "cruise_speed": 10.0,
        "max_speed": 12.0,
        "climb_speed": 3.0,
        "max_climb_speed": 5.0,
        "max_descent_speed": 4.0,
        "payload_capacity_kg": 2.0,
        "empty_mass_kg": 2.0,
        "nominal_payload_kg": 0.5,
        "maximum_takeoff_mass_kg": 4.0,
        "passenger_capacity": 0,
        "battery_range_m": 10000.0,
        "hover_power_w": 288.0,
        "battery_capacity_wh": 80.0,
        "service_ceiling_m": 220.0,
        "mass_kg": 4.0,
        "min_total_thrust_n": 23.5,
        "max_total_thrust_n": 78.5,
        "max_tilt_deg": 30.0,
        # 由最大俯仰角导出：a = 0.6 * g * tan(30°) = 3.40 m/s²。
        # 巡查机最轻（4 kg），可承受更大倾角，故高于另两类。
        "max_horizontal_acceleration_mps2": 3.3983,
        "max_vertical_acceleration_mps2": 3.0,
        "max_thrust_rate_nps": 98.1,
    },
    "passenger_evtol": {
        "name": "passenger_evtol",
        "length_m": 6.0,
        "width_m": 6.0,
        "height_m": 2.0,
        "cruise_speed": 22.0,
        "max_speed": 30.0,
        "climb_speed": 3.0,
        "max_climb_speed": 5.0,
        "max_descent_speed": 3.0,
        "payload_capacity_kg": 0.0,
        "empty_mass_kg": 0.0,
        "nominal_payload_kg": 0.0,
        "maximum_takeoff_mass_kg": 0.0,
        "passenger_capacity": 2,
        "battery_range_m": 25000.0,
        "service_ceiling_m": 450.0,
        "safety_radius_m": 15.0,
        "vertical_separation_m": 15.0,
    },
}

MISSION_DEFAULT_UAV_TYPES = {
    "emergency": "medical_fast",
    "medical_emergency": "medical_fast",
    "inspection": "inspection_uav",
    "passenger_commute": "passenger_evtol",
    "logistics_delivery": "cargo_small",
}

MISSION_PRIORITIES = {
    "logistics_delivery": 2,
    "emergency": 5,
    "medical_emergency": 5,
    "inspection": 3,
    "passenger_commute": 4,
}

LOW_DENSITY_REGULAR = "low_density_regular"
HIGH_DENSITY_REGULAR = "high_density_regular"
LOW_DENSITY_IRREGULAR = "low_density_irregular"

MISSION_OPERATION_CATEGORIES = (
    LOW_DENSITY_REGULAR,
    HIGH_DENSITY_REGULAR,
    LOW_DENSITY_IRREGULAR,
)

MISSION_OPERATION_CATEGORY_DISPLAY_NAMES = {
    LOW_DENSITY_REGULAR: "Low-density regular",
    HIGH_DENSITY_REGULAR: "High-density regular",
    LOW_DENSITY_IRREGULAR: "Low-density irregular",
}

MISSION_OPERATION_CATEGORY_CHINESE_NAMES = {
    LOW_DENSITY_REGULAR: "low-density regular",
    HIGH_DENSITY_REGULAR: "high-density regular",
    LOW_DENSITY_IRREGULAR: "low-density irregular",
}

MISSION_TO_OPERATION_CATEGORY = {
    "inspection": LOW_DENSITY_REGULAR,
    "logistics_delivery": HIGH_DENSITY_REGULAR,
    "passenger_commute": HIGH_DENSITY_REGULAR,
    "medical_emergency": LOW_DENSITY_IRREGULAR,
    "emergency": LOW_DENSITY_IRREGULAR,
    "medical": LOW_DENSITY_IRREGULAR,
    "low_battery_return": LOW_DENSITY_IRREGULAR,
}


def normalize_mission_type(value):
    mapping = {
        "logistics": "logistics_delivery",
        "fast_logistics": "logistics_delivery",
        "passenger": "passenger_commute",
        "medical": "emergency",
        "medical_emergency": "emergency",
        "emergency": "emergency",
    }
    return mapping.get(str(value), str(value))


def mission_operation_category(mission_type):
    normalized = normalize_mission_type(mission_type)
    return MISSION_TO_OPERATION_CATEGORY.get(normalized, normalized)


XYZ = tuple


@dataclass(frozen=True)
class UAVType:
    """UAV type parameters."""

    __annotations__ = {
        "name": object,
        "length_m": object,
        "width_m": object,
        "height_m": object,
        "cruise_speed": object,
        "max_speed": object,
        "climb_speed": object,
        "max_climb_speed": object,
        "max_descent_speed": object,
        "payload_capacity_kg": object,
        "empty_mass_kg": object,
        "nominal_payload_kg": object,
        "maximum_takeoff_mass_kg": object,
        "passenger_capacity": object,
        "battery_range_m": object,
        "hover_power_w": object,
        "battery_capacity_wh": object,
        "service_ceiling_m": object,
        "safety_radius_m": object,
        "vertical_separation_m": object,
        "mass_kg": object,
        "min_total_thrust_n": object,
        "max_total_thrust_n": object,
        "max_tilt_deg": object,
        "max_horizontal_acceleration_mps2": object,
        "max_vertical_acceleration_mps2": object,
        "max_thrust_rate_nps": object,
    }

    name = ""
    length_m = 1.0
    width_m = 1.0
    height_m = 0.5
    cruise_speed = 0.0
    max_speed = 0.0
    climb_speed = 0.0
    max_climb_speed = 0.0
    max_descent_speed = 0.0
    payload_capacity_kg = 0.0
    empty_mass_kg = 0.0
    nominal_payload_kg = 0.0
    maximum_takeoff_mass_kg = 0.0
    passenger_capacity = 0
    battery_range_m = 15000.0
    hover_power_w = 0.0
    battery_capacity_wh = 0.0
    service_ceiling_m = 300.0
    safety_radius_m = 0.0
    vertical_separation_m = 0.0
    mass_kg = 1.0
    min_total_thrust_n = 0.0
    max_total_thrust_n = 0.0
    max_tilt_deg = 0.0
    max_horizontal_acceleration_mps2 = 0.0
    max_vertical_acceleration_mps2 = 0.0
    max_thrust_rate_nps = 0.0

    def mass_condition(self, condition):
        masses = {
            "empty": self.empty_mass_kg,
            "nominal": self.empty_mass_kg + self.nominal_payload_kg,
            "maximum": self.maximum_takeoff_mass_kg,
        }
        try:
            return float(masses[str(condition)])
        except KeyError as exc:
            raise ValueError(f"unknown payload mass condition: {condition}") from exc

    def mass_for_payload(self, payload_kg):
        payload = float(payload_kg)
        if payload < 0.0 or payload > float(self.payload_capacity_kg):
            raise ValueError(
                f"payload {payload} kg is outside [0, {self.payload_capacity_kg}] kg for {self.name}"
            )
        operating_mass = float(self.empty_mass_kg) + payload
        if operating_mass > float(self.maximum_takeoff_mass_kg) + 1e-9:
            raise ValueError(
                f"operating mass {operating_mass} kg exceeds maximum takeoff mass "
                f"{self.maximum_takeoff_mass_kg} kg for {self.name}"
            )
        return operating_mass

    def payload_condition(self, payload_kg):
        payload = float(payload_kg)
        self.mass_for_payload(payload)
        if payload <= 1e-9:
            return "empty"
        if payload >= float(self.payload_capacity_kg) - 1e-9:
            return "maximum"
        return "nominal"


DEFAULT_UAV_TYPES = {name: UAVType(**spec) for name, spec in DEFAULT_UAV_TYPE_SPECS.items()}


def uav_cruise_speed_mps(vehicle_type: str) -> float:
    """Return the canonical nominal cruise speed for a configured UAV type."""

    name = str(vehicle_type)
    try:
        spec = DEFAULT_UAV_TYPE_SPECS[name]
    except KeyError as exc:
        raise ValueError(f"unknown UAV type: {name}") from exc
    speed = float(spec["cruise_speed"])
    maximum = float(spec["max_speed"])
    if speed <= 0.0 or speed > maximum:
        raise ValueError(
            f"invalid cruise speed {speed} m/s for {name}; "
            f"expected 0 < cruise_speed <= max_speed ({maximum})"
        )
    return speed


def uav_max_speed_mps(vehicle_type: str) -> float:
    """Return the maximum horizontal speed for a configured UAV type."""

    name = str(vehicle_type)
    try:
        speed = float(DEFAULT_UAV_TYPE_SPECS[name]["max_speed"])
    except KeyError as exc:
        raise ValueError(f"unknown UAV type: {name}") from exc
    if speed <= 0.0:
        raise ValueError(f"invalid max speed {speed} m/s for {name}")
    return speed


def operating_vehicle_spec(vehicle_type, payload_kg=0.0):
    """Return an OCP-ready vehicle envelope using the task's actual payload mass."""
    name = str(vehicle_type)
    try:
        uav = DEFAULT_UAV_TYPES[name]
        spec = dict(DEFAULT_UAV_TYPE_SPECS[name])
    except KeyError as exc:
        raise ValueError(f"unknown UAV type: {name}") from exc
    payload = float(payload_kg)
    spec.update(
        {
            "mass_kg": uav.mass_for_payload(payload),
            "payload_kg": payload,
            "payload_condition": uav.payload_condition(payload),
            "empty_mass_kg": float(uav.empty_mass_kg),
            "nominal_payload_kg": float(uav.nominal_payload_kg),
            "maximum_takeoff_mass_kg": float(uav.maximum_takeoff_mass_kg),
        }
    )
    return spec


@dataclass
class LocationSpec:
    """Mission location and terminal configuration."""

    __annotations__ = {
        "name": object,
        "object_type": object,
        "node_id": object,
        "location_type": object,
        "xyz": object,
        "xy_ratio": object,
        "z_ratio": object,
        "supported_missions": object,
        "mission_type_limits": object,
        "parking_stands": object,
        "takeoff_channels": object,
        "landing_channels": object,
        "queue_capacity": object,
        "service_time_s": object,
        "throughput_per_hour": object,
        "takeoff_interval_s": object,
        "landing_interval_s": object,
        "node_radius_m": object,
        "node_radius_voxels": object,
        "resources": object,
        "operations": object,
        "open_time": object,
        "close_time": object,
    }

    name = ""
    object_type = "uam_node"
    node_id = ""
    location_type = "generic"
    xyz = None
    xy_ratio = None
    z_ratio = 0.25
    supported_missions = field(default_factory=tuple)
    mission_type_limits = field(default_factory=tuple)

    # Terminal capacity constraints.
    parking_stands = 1
    takeoff_channels = 1
    landing_channels = 1
    queue_capacity = 20
    service_time_s = 30.0
    throughput_per_hour = 0
    takeoff_interval_s = 2.0
    landing_interval_s = 3.0
    node_radius_m = 0.0
    node_radius_voxels = 0
    resources = field(default_factory=dict)
    operations = field(default_factory=dict)

    # Open time in simulation seconds.
    open_time = 0.0
    close_time = math.inf

    @staticmethod
    def from_dict(data):
        operations = data.get("operations", {})
        if not isinstance(operations, dict):
            operations = {}

        geometry = data.get("geometry", {})
        if not isinstance(geometry, dict):
            geometry = {}

        xyz = data.get("xyz")
        if xyz is not None:
            xyz = tuple(float(v) for v in xyz)

        xy_ratio = data.get("xy_ratio")
        if xy_ratio is not None:
            xy_ratio = (float(xy_ratio[0]), float(xy_ratio[1]))

        supported_missions = tuple(
            str(v)
            for v in data.get(
                "supported_missions",
                data.get("mission_type_limits", operations.get("mission_type_limits", ())),
            )
        )
        mission_type_limits = tuple(
            str(v)
            for v in data.get(
                "mission_type_limits",
                operations.get("mission_type_limits", supported_missions),
            )
        )

        return LocationSpec(
            name=str(data["name"]),
            object_type=str(data.get("object_type", "uam_node")),
            node_id=str(data.get("node_id", data["name"])),
            location_type=str(data.get("location_type", data.get("type", "generic"))),
            xyz=xyz,
            xy_ratio=xy_ratio,
            z_ratio=float(data.get("z_ratio", 0.25)),
            supported_missions=supported_missions,
            mission_type_limits=mission_type_limits,
            parking_stands=max(
                1,
                int(data.get("parking_stands", operations.get("parking_stands", data.get("pad_count", 1)))),
            ),
            takeoff_channels=max(
                1,
                int(data.get("takeoff_channels", operations.get("takeoff_channels", data.get("pad_count", 1)))),
            ),
            landing_channels=max(
                1,
                int(data.get("landing_channels", operations.get("landing_channels", data.get("pad_count", 1)))),
            ),
            queue_capacity=max(0, int(data.get("queue_capacity", operations.get("queue_capacity", 20)))),
            service_time_s=max(
                0.0,
                float(data.get("service_time_s", operations.get("service_time_s", data.get("service_time_mean", 30.0)))),
            ),
            throughput_per_hour=max(
                0,
                int(data.get("throughput_per_hour", operations.get("throughput_per_hour", 0))),
            ),
            takeoff_interval_s=max(
                0.0,
                float(data.get("takeoff_interval_s", operations.get("takeoff_interval_s", data.get("takeoff_headway", 2.0)))),
            ),
            landing_interval_s=max(
                0.0,
                float(data.get("landing_interval_s", operations.get("landing_interval_s", data.get("landing_headway", 3.0)))),
            ),
            node_radius_m=max(0.0, float(data.get("node_radius_m", geometry.get("radius_m", 0.0)))),
            node_radius_voxels=max(0, int(data.get("node_radius_voxels", geometry.get("radius_voxels", 0)))),
            resources=dict(data.get("resources", {})),
            operations=dict(operations),
            open_time=float(data.get("open_time", 0.0)),
            close_time=float(data.get("close_time", math.inf)),
        )

    def is_open(self, t):
        return self.open_time <= t <= self.close_time


@dataclass
class ODPair:
    __annotations__ = {"origin": object, "destination": object, "weight": object, "metadata": object}

    origin = ""
    destination = ""
    weight = 1.0
    metadata = field(default_factory=dict)

    @staticmethod
    def from_dict(data):
        metadata = {
            str(key): value
            for key, value in dict(data).items()
            if key not in {"origin", "destination", "weight"}
        }
        return ODPair(
            origin=str(data["origin"]),
            destination=str(data["destination"]),
            weight=float(data.get("weight", 1.0)),
            metadata=metadata,
        )


@dataclass
class MissionProfile:
    """Mission type configuration."""

    __annotations__ = {
        "mission_type": object,
        "display_name": object,
        "weight": object,
        "priority": object,
        "uav_type": object,
        "od_pairs": object,
        "od_generation_rule": object,
        "payload_kg_range": object,
        "passenger_count_range": object,
        "service_time_range": object,
        "latest_arrival_offset_range": object,
        "max_delay": object,
        "return_to_base": object,
        "waypoint_count_range": object,
        "dwell_time_range": object,
    }

    mission_type = ""
    display_name = ""
    weight = 1.0
    priority = 1
    uav_type = "cargo_small"
    od_pairs = field(default_factory=list)
    od_generation_rule = ""

    payload_kg_range = (0.0, 0.0)
    passenger_count_range = (0, 0)
    service_time_range = (0.0, 0.0)
    latest_arrival_offset_range = (600.0, 1800.0)
    max_delay = 300.0
    return_to_base = False

    # Inspection missions may use waypoint chains.
    waypoint_count_range = (0, 0)
    dwell_time_range = (0.0, 0.0)

    @staticmethod
    def from_dict(data):
        mission_type = str(data.get("type", data.get("mission_type", "generic")))
        return MissionProfile(
            mission_type=mission_type,
            display_name=str(data.get("display_name", mission_type)),
            weight=max(0.0, float(data.get("weight", 1.0))),
            priority=int(data.get("priority", 1)),
            uav_type=str(data.get("uav_type", _default_uav_type_for_mission(mission_type))),
            od_pairs=[ODPair.from_dict(item) for item in data.get("od_pairs", [])],
            od_generation_rule=str(data.get("od_generation_rule", "")),
            payload_kg_range=_float_pair(data.get("payload_kg_range", (0.0, 0.0))),
            passenger_count_range=_int_pair(data.get("passenger_count_range", (0, 0))),
            service_time_range=_float_pair(data.get("service_time_range", (0.0, 0.0))),
            latest_arrival_offset_range=_float_pair(
                data.get("latest_arrival_offset_range", (600.0, 1800.0))
            ),
            max_delay=max(0.0, float(data.get("max_delay", 300.0))),
            return_to_base=bool(data.get("return_to_base", False)),
            waypoint_count_range=_int_pair(data.get("waypoint_count_range", (0, 0))),
            dwell_time_range=_float_pair(data.get("dwell_time_range", (0.0, 0.0))),
        )


@dataclass
class TimeWindowDemand:
    """Time-varying demand window.

    ``rate_per_hour`` is the average arrival rate within the window.
    ``profile_weights`` can override mission-type weights.
    ``od_weights`` can override OD weights using ``origin->destination`` keys.
    """

    __annotations__ = {
        "start": object,
        "end": object,
        "rate_per_hour": object,
        "profile_weights": object,
        "od_weights": object,
    }

    start = 0.0
    end = math.inf
    rate_per_hour = 0.0
    profile_weights = field(default_factory=dict)
    od_weights = field(default_factory=dict)

    @staticmethod
    def from_dict(data):
        return TimeWindowDemand(
            start=float(data.get("start", 0.0)),
            end=float(data.get("end", math.inf)),
            rate_per_hour=max(0.0, float(data.get("rate_per_hour", 0.0))),
            profile_weights={str(k): float(v) for k, v in data.get("profile_weights", {}).items()},
            od_weights={str(k): float(v) for k, v in data.get("od_weights", {}).items()},
        )

    def contains(self, t):
        return self.start <= t < self.end


def load_uav_types(data=None):
    """Load UAV type configuration; use defaults when no data is provided."""
    uav_types = dict(DEFAULT_UAV_TYPES)
    if not data:
        return uav_types

    for name, item in data.items():
        payload_capacity = float(item.get("payload_capacity_kg", 0.0))
        legacy_mass = float(item.get("mass_kg", 0.0))
        maximum_takeoff_mass = float(
            item.get("maximum_takeoff_mass_kg", legacy_mass if legacy_mass > 0.0 else 1.0 + payload_capacity)
        )
        empty_mass = float(item.get("empty_mass_kg", max(0.0, maximum_takeoff_mass - payload_capacity)))
        uav_types[str(name)] = UAVType(
            name=str(name),
            length_m=float(item.get("length_m", item.get("uav_length_m", 1.0))),
            width_m=float(item.get("width_m", item.get("uav_width_m", 1.0))),
            height_m=float(item.get("height_m", item.get("uav_height_m", 0.5))),
            cruise_speed=float(item.get("cruise_speed", 12.0)),
            max_speed=float(item.get("max_speed", 16.0)),
            climb_speed=float(item.get("climb_speed", 3.0)),
            max_climb_speed=float(item.get("max_climb_speed", 5.0)),
            max_descent_speed=float(item.get("max_descent_speed", 3.0)),
            payload_capacity_kg=payload_capacity,
            empty_mass_kg=empty_mass,
            nominal_payload_kg=float(item.get("nominal_payload_kg", payload_capacity * 0.5)),
            maximum_takeoff_mass_kg=maximum_takeoff_mass,
            passenger_capacity=int(item.get("passenger_capacity", 0)),
            battery_range_m=float(item.get("battery_range_m", 15000.0)),
            hover_power_w=float(item.get("hover_power_w", 0.0)),
            battery_capacity_wh=float(item.get("battery_capacity_wh", 0.0)),
            service_ceiling_m=float(item.get("service_ceiling_m", 300.0)),
            safety_radius_m=float(item.get("safety_radius_m", 0.0)),
            vertical_separation_m=float(item.get("vertical_separation_m", 0.0)),
            mass_kg=legacy_mass if legacy_mass > 0.0 else maximum_takeoff_mass,
            min_total_thrust_n=float(item.get("min_total_thrust_n", 0.0)),
            max_total_thrust_n=float(item.get("max_total_thrust_n", 0.0)),
            max_tilt_deg=float(item.get("max_tilt_deg", 0.0)),
            max_horizontal_acceleration_mps2=float(item.get("max_horizontal_acceleration_mps2", 0.0)),
            max_vertical_acceleration_mps2=float(item.get("max_vertical_acceleration_mps2", 0.0)),
            max_thrust_rate_nps=float(item.get("max_thrust_rate_nps", 0.0)),
        )
    return uav_types


def load_locations(data):
    return {loc.name: loc for loc in (LocationSpec.from_dict(item) for item in data)}


def load_profiles(data):
    return [MissionProfile.from_dict(item) for item in data]


def load_time_windows(data):
    windows = [TimeWindowDemand.from_dict(item) for item in data]
    windows.sort(key=lambda w: (w.start, w.end))
    return windows


def _default_uav_type_for_mission(mission_type):
    return MISSION_DEFAULT_UAV_TYPES.get(str(mission_type), "cargo_small")


def build_default_mission_config_from_city_locations(
    city_locations,
):
    """Build default mission-demand configuration from city locations."""

    locations = []
    for loc in city_locations:
        item = dict(loc)
        name = str(item.get("name", ""))

        if "hub" in name or "airport" in name:
            item.setdefault("parking_stands", 6)
            item.setdefault("takeoff_channels", 2)
            item.setdefault("landing_channels", 2)
            item.setdefault("queue_capacity", 60)
            item.setdefault("takeoff_interval_s", 2.0)
            item.setdefault("landing_interval_s", 3.0)
            item.setdefault("service_time_s", 40.0)
        elif "vertiport" in name or "residential" in name:
            item.setdefault("parking_stands", 4)
            item.setdefault("takeoff_channels", 1)
            item.setdefault("landing_channels", 1)
            item.setdefault("queue_capacity", 35)
            item.setdefault("takeoff_interval_s", 3.0)
            item.setdefault("landing_interval_s", 4.0)
            item.setdefault("service_time_s", 50.0)
        elif "hospital" in name or "emergency" in name:
            item.setdefault("parking_stands", 3)
            item.setdefault("takeoff_channels", 1)
            item.setdefault("landing_channels", 1)
            item.setdefault("queue_capacity", 25)
            item.setdefault("takeoff_interval_s", 1.5)
            item.setdefault("landing_interval_s", 2.0)
            item.setdefault("service_time_s", 25.0)
        else:
            item.setdefault("parking_stands", 2)
            item.setdefault("takeoff_channels", 1)
            item.setdefault("landing_channels", 1)
            item.setdefault("queue_capacity", 20)
            item.setdefault("takeoff_interval_s", 4.0)
            item.setdefault("landing_interval_s", 5.0)
            item.setdefault("service_time_s", 60.0)

        locations.append(item)

    return {
        "enabled": True,
        "locations": locations,
        "time_windows": [
            {
                "start": 0,
                "end": 1800,
                "rate_per_hour": 180,
                "profile_weights": {
                    "logistics_delivery": 0.50,
                    "emergency": 0.05,
                    "inspection": 0.30,
                    "passenger_commute": 0.15,
                },
            },
            {
                "start": 1800,
                "end": 3600,
                "rate_per_hour": 420,
                "profile_weights": {
                    "logistics_delivery": 0.30,
                    "emergency": 0.05,
                    "inspection": 0.10,
                    "passenger_commute": 0.55,
                },
                "od_weights": {
                    "residential_east->cbd_vertiport": 3.0,
                    "cbd_vertiport->residential_east": 2.0,
                },
            },
            {
                "start": 3600,
                "end": 7200,
                "rate_per_hour": 260,
                "profile_weights": {
                    "logistics_delivery": 0.55,
                    "emergency": 0.05,
                    "inspection": 0.30,
                    "passenger_commute": 0.10,
                },
            },
        ],
        "profiles": [
            {
                "type": "logistics_delivery",
                "display_name": "logistics delivery",
                "weight": 0.50,
                "priority": 2,
                "uav_type": "cargo_small",
                "payload_kg_range": [0.5, 5.0],
                "service_time_range": [20.0, 80.0],
                "latest_arrival_offset_range": [600.0, 2400.0],
                "max_delay": 600.0,
                "return_to_base": False,
                "od_generation_rule": "logistics_delivery",
                "od_pairs": [
                    {"origin": "logistics_hub", "destination": "residential_east", "weight": 0.35},
                    {"origin": "logistics_hub", "destination": "cbd_vertiport", "weight": 0.30},
                    {"origin": "airport_hub", "destination": "industrial_park", "weight": 0.20},
                    {"origin": "airport_hub", "destination": "logistics_hub", "weight": 0.15},
                ],
            },
            {
                "type": "emergency",
                "display_name": "medical emergency",
                "weight": 0.05,
                "priority": 5,
                "uav_type": "medical_fast",
                "payload_kg_range": [0.2, 3.0],
                "service_time_range": [5.0, 30.0],
                "latest_arrival_offset_range": [180.0, 600.0],
                "max_delay": 120.0,
                "return_to_base": False,
                "od_generation_rule": "emergency",
                "od_pairs": [
                    {"origin": "hospital", "destination": "emergency_center", "weight": 0.35},
                    {"origin": "emergency_center", "destination": "hospital", "weight": 0.35},
                    {"origin": "hospital", "destination": "residential_east", "weight": 0.15},
                    {"origin": "emergency_center", "destination": "industrial_park", "weight": 0.15},
                ],
            },
            {
                "type": "inspection",
                "display_name": "inspection mission",
                "weight": 0.25,
                "priority": 3,
                "uav_type": "inspection_uav",
                "payload_kg_range": [0.0, 1.0],
                "service_time_range": [60.0, 300.0],
                "latest_arrival_offset_range": [1200.0, 3600.0],
                "max_delay": 900.0,
                "return_to_base": True,
                "od_generation_rule": "inspection",
                "waypoint_count_range": [0, 2],
                "dwell_time_range": [30.0, 180.0],
                "od_pairs": [
                    {"origin": "power_substation", "destination": "bridge_checkpoint", "weight": 0.40},
                    {"origin": "industrial_park", "destination": "power_substation", "weight": 0.35},
                    {"origin": "bridge_checkpoint", "destination": "industrial_park", "weight": 0.25},
                ],
            },
            {
                "type": "passenger_commute",
                "display_name": "passenger commute",
                "weight": 0.20,
                "priority": 4,
                "uav_type": "passenger_evtol",
                "passenger_count_range": [1, 2],
                "service_time_range": [90.0, 240.0],
                "latest_arrival_offset_range": [600.0, 1800.0],
                "max_delay": 300.0,
                "return_to_base": False,
                "od_generation_rule": "passenger_commute",
                "od_pairs": [
                    {"origin": "residential_east", "destination": "cbd_vertiport", "weight": 0.45},
                    {"origin": "cbd_vertiport", "destination": "residential_east", "weight": 0.35},
                    {"origin": "airport_hub", "destination": "cbd_vertiport", "weight": 0.20},
                ],
            },
        ],
    }


def _float_pair(value):
    if value is None:
        return (0.0, 0.0)
    a, b = float(value[0]), float(value[1])
    return (min(a, b), max(a, b))


def _int_pair(value):
    if value is None:
        return (0, 0)
    a, b = int(value[0]), int(value[1])
    return (min(a, b), max(a, b))

