"""Central parameter package for the UAV navigation project.

Files in this package are configuration-only: constants, default values, and
plain parameter containers.  Domain logic should live in the corresponding
map, airspace, demand, planning, or simulation modules.
"""

