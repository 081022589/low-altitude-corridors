"""Auditable ECJA P0-R input contracts built without mutating frozen assets.

The active contract deliberately contains only non-energy candidate legality,
request identity, ETA, and traffic-state completeness.  The legacy energy
proxy definitions below remain import-compatible for archived diagnostics, but
the active contract builder never calls them or reads energy fields.
"""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Tuple

from srcm.plan_motion import iter_plan_motion_segments, motion_sha256


ENERGY_MODEL_VERSION = "ECJA_ENERGY_PROXY_TRAJECTORY_V1"
ETA_CONTRACT_VERSION = "ECJA_ETA_SOURCE_LAYER_SHAFT_GATE_V1"
TRAFFIC_CONTRACT_VERSION = "ECJA_SYNTHETIC_TRAFFIC_BACKGROUND_V1"


@dataclass(frozen=True)
class EnergyProxyModel:
    battery_capacity_wh: Mapping[str, float]
    hover_power_w: Mapping[str, float]
    nominal_range_m: Mapping[str, float]
    reserve_fraction: float
    remaining_fraction: float
    model_version: str = ENERGY_MODEL_VERSION
    evidence_mode: str = "RESEARCH_PROXY_ONLY"
    unit: str = "Wh"
    source_evidence: Tuple[str, ...] = (
        "docs/public_env_freeze_20261007/ENERGY_ACCOUNTING_CONTRACT.draft.json",
        "configs/mission_config.py",
        "RESEARCH_OBJECTIVE.md (L1 inspection / L2 logistics / L3 emergency research-layer mapping)",
    )

    @classmethod
    def default(cls) -> "EnergyProxyModel":
        return cls(
            battery_capacity_wh={"inspection_uav": 80.0, "cargo_small": 96.0, "medical_fast": 144.0},
            hover_power_w={"inspection_uav": 288.0, "cargo_small": 346.0, "medical_fast": 432.0},
            nominal_range_m={"inspection_uav": 10000.0, "cargo_small": 12000.0, "medical_fast": 18000.0},
            reserve_fraction=0.05,
            remaining_fraction=1.00,
        )


def _canonical_hash(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _uav_type(source_layer_id: str) -> str:
    return {"L1": "inspection_uav", "L2": "cargo_small", "L3": "medical_fast"}[source_layer_id]


def estimate_candidate_energy(plan: Mapping[str, Any], model: Optional[EnergyProxyModel] = None) -> Dict[str, Any]:
    model = model or EnergyProxyModel.default()
    uav_type = _uav_type(str(plan["source_layer_id"]))
    capacity = float(model.battery_capacity_wh[uav_type])
    range_m = float(model.nominal_range_m[uav_type])
    hover_w = float(model.hover_power_w[uav_type])
    components = {"horizontal": 0.0, "transfer": 0.0, "descent": 0.0, "waiting": 0.0}
    distances = {"horizontal_m": 0.0, "transfer_m": 0.0, "vertical_m": 0.0, "waiting_s": 0.0}
    for segment in iter_plan_motion_segments(plan):
        first = segment["point0_xyz"]
        second = segment["point1_xyz"]
        horizontal_m = math.hypot(second[0] - first[0], second[1] - first[1])
        vertical_m = abs(second[2] - first[2])
        duration_s = segment["end_s"] - segment["start_s"]
        phase_type = segment["phase_type"]
        if phase_type == "H_CRUISE":
            components["horizontal"] += capacity / range_m * horizontal_m
            distances["horizontal_m"] += horizontal_m
        elif phase_type == "SOURCE_EXIT":
            components["transfer"] += capacity / range_m * horizontal_m + hover_w * (vertical_m / max(vertical_m / duration_s, 1e-12) if vertical_m else 0.0) / 3600.0
            distances["transfer_m"] += horizontal_m
            distances["vertical_m"] += vertical_m
        elif phase_type == "V_DESCENT":
            components["descent"] += hover_w * duration_s / 3600.0
            distances["vertical_m"] += vertical_m
        else:
            components["waiting"] += hover_w * duration_s / 3600.0
            distances["waiting_s"] += duration_s
    total = sum(components.values())
    return {
        "model_version": model.model_version,
        "evidence_mode": model.evidence_mode,
        "physical_calibration_status": "NOT_CALIBRATED",
        "unit": model.unit,
        "uav_type": uav_type,
        "battery_capacity_wh": capacity,
        "proxy_required_wh": total,
        "components_wh": components,
        "measured_path_terms": distances,
        "formula": {
            "horizontal": "battery_capacity_wh / nominal_range_m * actual_horizontal_m",
            "transfer": "horizontal proxy plus hover-equivalent vertical duration",
            "descent": "hover_power_w * actual_vertical_phase_s / 3600",
            "waiting": "hover_power_w * actual_unclassified_or_wait_phase_s / 3600",
        },
        "applicable_plan_id": plan["plan_id"],
        "route_id": plan.get("route_id"),
        "trajectory_sha256": motion_sha256(plan),
        "source_evidence": list(model.source_evidence),
    }


def derive_candidate_eta(plan: Mapping[str, Any], scene: Mapping[str, Any]) -> Dict[str, Any]:
    if plan.get("mode") == "ROUTE_ONLY_SERVICE_NODE_ASSIGNMENT":
        return {
            "contract_version": "ECJA_ROUTE_ONLY_NO_ETA_V1",
            "eta_reference_point": "CMLPM_E_ANCHOR_PENDING",
            "reference_definition": "No ECJA motion time; resource timing is owned by C-MLPM",
            "reference_xyz_m": None,
            "estimated_arrival_s": None,
            "time_axis": scene.get("time_profile", {}).get("time_axis", "ABSOLUTE_SCENARIO_SECONDS"),
            "snapshot_id": scene["meta"]["snapshot_id"],
            "scenario_hash": scene["meta"]["scenario_hash"],
            "route_id": plan.get("route_id"),
            "source_phase_id": None,
            "trajectory_gate_error_m": None,
        }
    segments = list(iter_plan_motion_segments(plan))
    source_segments = [item for item in segments if item["phase_type"] == "SOURCE_EXIT"]
    if not source_segments:
        raise ValueError("MISSING_SOURCE_EXIT_PHASE")
    interface = next(
        (
            item for item in scene.get("access_interfaces", [])
            if item["service_node_id"] == plan.get("service_node_id") and item["source_layer_id"] == plan.get("source_layer_id")
        ),
        None,
    )
    if interface is None:
        raise ValueError("MISSING_SOURCE_LAYER_SHAFT_GATE")
    eta_s = max(item["end_s"] for item in source_segments)
    # Same traversal order, tolerance and interpolation as position_at_time;
    # retain the independent trajectory/gate check without expanding it again.
    trajectory_xyz = None
    for segment in segments:
        start, end = segment["start_s"], segment["end_s"]
        if start-1e-9 <= eta_s <= end+1e-9:
            ratio = min(1.0, max(0.0, (eta_s-start)/(end-start)))
            trajectory_xyz = [a+ratio*(b-a) for a,b in zip(segment["point0_xyz"], segment["point1_xyz"])]
            break
    if trajectory_xyz is None:
        raise ValueError("TIME_OUTSIDE_PLAN_MOTION")
    formal = plan.get("formal_motion_contract", {}).get("model") == "FORMAL_THREE_PHASE_ZHOU_PATH_TIME_V2"
    expected_xyz = [
        float(interface["shaft_axis_xy"][0]),
        float(interface["shaft_axis_xy"][1]),
        float(trajectory_xyz[2]) if formal else float(interface["shaft_top_z_m"]),
    ]
    error_m = math.dist(trajectory_xyz, expected_xyz)
    if error_m > 1e-5:
        raise ValueError("ETA_GATE_TRAJECTORY_MISMATCH")
    return {
        "contract_version": "ECJA_ETA_GENERATED_TRANSFER_VERTICAL_ENTRY_V3" if formal else ETA_CONTRACT_VERSION,
        "eta_reference_point": "GENERATED_TRANSFER_VERTICAL_ENTRY_J" if formal else "SOURCE_LAYER_SHAFT_GATE",
        "reference_definition": (
            "Generated G-to-J endpoint on shaft axis, equal to SOURCE_EXIT end and V_DESCENT start"
            if formal else
            "physical boundary at the source-layer mainline/shaft axis, equal to SOURCE_EXIT end and V_DESCENT start"
        ),
        "reference_xyz_m": expected_xyz,
        "estimated_arrival_s": eta_s,
        "time_axis": scene.get("time_profile", {}).get("time_axis", "ABSOLUTE_SCENARIO_SECONDS"),
        "snapshot_id": scene["meta"]["snapshot_id"],
        "scenario_hash": scene["meta"]["scenario_hash"],
        "route_id": plan.get("route_id"),
        "source_phase_id": source_segments[-1]["phase_id"],
        "trajectory_gate_error_m": error_m,
    }


def build_research_input_contract(
    scene: Mapping[str, Any],
    model: Optional[EnergyProxyModel] = None,
    request_state_overrides: Optional[Mapping[str, Mapping[str, Any]]] = None,
    *,
    _candidate_facts: Optional[Dict[str, Any]] = None,
) -> Dict[str, Any]:
    # ``model`` is retained as a compatibility parameter for archived callers.
    # ECJA no longer reads or evaluates any energy state.
    overrides = dict(request_state_overrides or {})
    candidate_plans = sorted((item for item in scene["plans"] if item["plan_status"] == "CANDIDATE"), key=lambda item: item["plan_id"])
    fixed_plans = sorted((item for item in scene["plans"] if item["plan_status"] == "FIXED"), key=lambda item: item["plan_id"])
    candidate_records = []
    by_uav: Dict[str, list] = {}
    for plan in candidate_plans:
        record = {
            "candidate_id": plan["plan_id"],
            "request_id": plan.get("option_group_id") or plan["uav_id"],
            "uav_id": plan["uav_id"],
            "service_node_id": plan.get("service_node_id"),
            "source_layer_id": plan.get("source_layer_id"),
            "eligibility": {
                "status": "NON_ENERGY_LEGAL",
                "basis": (
                    ["FORWARD_NODE", "FIXED_ROUTE_REGISTRY",
                     "CMLPM_OWNS_TIMING", "PASSAGE_COMMITMENT_COMPATIBILITY"]
                    if plan.get("mode") == "ROUTE_ONLY_SERVICE_NODE_ASSIGNMENT"
                    else ["FORWARD_NODE", "MOTION_GEOMETRY", "LEGAL_TIME_WINDOW",
                          "RESOURCE_RULES", "PASSAGE_COMMITMENT_COMPATIBILITY"]
                ),
            },
        }
        motion_hash = motion_sha256(plan)
        record["path"] = {"route_id": plan.get("route_id"), "trajectory_sha256": motion_hash}
        # Per-call facts survive admission filtering, not a changed motion or
        # interface. Still validate every generated candidate before filtering.
        # Snapshot fields are rebound after the admitted scene is finalized.
        fact_key = None
        if _candidate_facts is not None:
            interface = next((row for row in scene.get("access_interfaces", ())
                              if row["service_node_id"] == plan.get("service_node_id")
                              and row["source_layer_id"] == plan.get("source_layer_id")), None)
            fact_key = _canonical_hash({"motion": motion_hash, "route": plan.get("route_id"),
                                        "interface": interface,
                                        "formal": plan.get("formal_motion_contract", {})})
        if fact_key is not None and fact_key in _candidate_facts:
            eta = dict(_candidate_facts[fact_key])
            eta.update(snapshot_id=scene["meta"]["snapshot_id"], scenario_hash=scene["meta"]["scenario_hash"],
                       time_axis=scene.get("time_profile", {}).get("time_axis", "ABSOLUTE_SCENARIO_SECONDS"))
        else:
            eta = derive_candidate_eta(plan, scene)
            if fact_key is not None:
                _candidate_facts[fact_key] = dict(eta)
        record["eta"] = eta
        candidate_records.append(record)
        by_uav.setdefault(plan["uav_id"], []).append(record)

    requests = []
    exceptions = []
    eligible_uavs = set()
    exception_fixed = []
    request_metadata = {
        str(item["uav_id"]): item
        for item in scene.get("ecja_forward_request_audit", ())
        if item.get("uav_id") is not None
    }
    request_uav_ids = sorted(set(by_uav) | set(request_metadata))
    for uav_id in request_uav_ids:
        candidates = by_uav.get(uav_id, [])
        candidate_ids = [item["candidate_id"] for item in candidates]
        state = overrides.get(uav_id, {})
        if candidate_ids:
            eligible_uavs.add(uav_id)
            disposition = "OPTIMIZABLE"
        elif state.get("in_flight") is False:
            disposition = "EXCEPTION_NOT_IN_FLIGHT"
        elif state.get("fixed_horizon_plan") is not None:
            fixed = dict(state["fixed_horizon_plan"])
            if fixed.get("uav_id") != uav_id or fixed.get("plan_status") != "FIXED":
                raise ValueError("INVALID_EXCEPTION_FIXED_PLAN")
            exception_fixed.append(fixed)
            disposition = "EXCEPTION_IN_FLIGHT_FIXED_HORIZON"
        elif state.get("no_relevant_traffic_proof"):
            disposition = "EXCEPTION_NO_RELEVANT_TRAFFIC_PROVEN"
        else:
            disposition = request_metadata.get(uav_id, {}).get(
                "zero_candidate_reason", "NO_LEGAL_NON_ENERGY_CANDIDATE"
            )
            if not disposition:
                disposition = "NO_LEGAL_NON_ENERGY_CANDIDATE"
        metadata = request_metadata.get(uav_id, {})
        requests.append(
            {
                "request_id": metadata.get("request_id") or (candidates[0]["request_id"] if candidates else uav_id),
                "uav_id": uav_id,
                "in_flight": state.get("in_flight"),
                "state_source": state.get("state_source", "UNSPECIFIED"),
                "candidate_ids": candidate_ids,
                "traffic_disposition": disposition,
            }
        )
        if disposition != "OPTIMIZABLE":
            exceptions.append({"request_id": requests[-1]["request_id"], "uav_id": uav_id, "traffic_disposition": disposition})

    f_all = fixed_plans + exception_fixed
    fixed_uavs = {item["uav_id"] for item in f_all}
    intersection = sorted(eligible_uavs & fixed_uavs)
    unknown = any(item["traffic_disposition"] == "EXCEPTION_TRAFFIC_UNKNOWN" for item in exceptions)
    request_state_complete = all(item["state_source"] != "UNSPECIFIED" and item["in_flight"] is not None for item in requests)
    synthetic = bool(scene["plans"]) and all(
        item.get("motion_parameter_provenance") == "SYNTHETIC_TEST_ONLY"
        for item in scene["plans"]
    )
    # Provenance is declared by the caller, not inferred from the motion
    # representation.  A research generator scene is complete for its own
    # declared universe whether it uses the simplified or the formal
    # three-phase motion model; only an undeclared scene needs the runtime
    # traffic contract to be qualified.
    generator_state_sources = {
        "P3R_FORWARD_REQUEST_DECLARATION",
        "PARAMETERIZED_RESEARCH_GENERATOR_DECLARATION",
    }
    declared_sources = {
        str(overrides.get(uav_id, {}).get("state_source", ""))
        for uav_id in request_uav_ids
    }
    generator_declared = bool(declared_sources) and declared_sources <= generator_state_sources
    runtime = scene.get("traffic_state_contract", {})
    runtime_request_uavs = set(map(str, runtime.get("request_uav_ids", ())))
    runtime_fixed_uavs = set(map(str, runtime.get("fixed_uav_ids", ())))
    runtime_excluded_uavs = set(map(str, runtime.get("excluded_uav_ids", ())))
    runtime_state_uavs = set(map(str, runtime.get("state_uav_ids", ())))
    generated_request_uavs = {
        str(item.get("uav_id") or item.get("request", {}).get("uav_id"))
        for item in scene.get("ecja_forward_request_audit", ())
    }
    plan_set_sha256 = _canonical_hash(
        sorted((item["plan_id"], item["uav_id"], item["plan_status"]) for item in scene["plans"])
    )
    runtime_complete = (
        runtime.get("contract_version") == "ECJA_AUTHORITATIVE_TRAFFIC_SNAPSHOT_V1"
        and runtime.get("snapshot_id") == scene["meta"]["snapshot_id"]
        and runtime.get("plan_set_sha256") == plan_set_sha256
        and not (runtime_request_uavs & runtime_fixed_uavs)
        and not (runtime_request_uavs & runtime_excluded_uavs)
        and not (runtime_fixed_uavs & runtime_excluded_uavs)
        and runtime_state_uavs == runtime_request_uavs | runtime_fixed_uavs | runtime_excluded_uavs
        and generated_request_uavs == runtime_request_uavs
        and {item["uav_id"] for item in candidate_plans} <= runtime_request_uavs
        and {item["uav_id"] for item in fixed_plans} == runtime_fixed_uavs
        and all(
            item.get("motion_parameter_provenance")
            in {
                "ZHOU_2019_LOCAL_BSPLINE_TIME_ADJUSTMENT_V1",
                "AUTHORITATIVE_RUNTIME_STATE_V1",
                "STRUCTURED_CURRENT_SCENE_H_BACKGROUND_V1",
                "ECJA_ROUTE_ONLY_NO_MOTION_V1",
            }
            for item in scene["plans"]
        )
    )
    if synthetic:
        generator_scope = "SYNTHETIC_TEST_ONLY"
        complete_for_generator = True
    elif generator_declared:
        generator_scope = "GENERATOR_DECLARED_RESEARCH"
        complete_for_generator = True
    elif runtime_complete:
        generator_scope = "AUTHORITATIVE_RUNTIME_SNAPSHOT"
        complete_for_generator = True
    else:
        generator_scope = "REAL_SNAPSHOT_UNVERIFIED"
        complete_for_generator = False
    qualification = "PASS_ECJA_NON_ENERGY" if not unknown and not intersection and not exceptions and complete_for_generator and request_state_complete else "BLOCKED"
    return {
        "contract_version": "ECJA_P0R_INPUT_CONTRACT_V2_NON_ENERGY",
        "qualification": qualification,
        "decision_dependency_scope": "NON_ENERGY_ONLY",
        "snapshot_id": scene["meta"]["snapshot_id"],
        "scenario_hash": scene["meta"]["scenario_hash"],
        "requests": requests,
        "candidates": candidate_records,
        "fixed_plans": [{"plan_id": item["plan_id"], "uav_id": item["uav_id"]} for item in f_all],
        "exception_traffic": exceptions,
        "request_state_contract": {
            "complete": request_state_complete,
            "required_fields": ["in_flight", "state_source"],
            "missing_uav_ids": sorted(item["uav_id"] for item in requests if item["state_source"] == "UNSPECIFIED" or item["in_flight"] is None),
        },
        "identity_audit": {
            "u_e_uav_ids": sorted(eligible_uavs),
            "f_all_uav_ids": sorted(fixed_uavs),
            "u_e_intersection_f_all": intersection,
        },
        "f_all_completeness": {
            "contract_version": TRAFFIC_CONTRACT_VERSION,
            "scope": generator_scope,
            "complete_for_declared_generator": complete_for_generator,
            "real_snapshot_completeness_claimed": generator_scope == "AUTHORITATIVE_RUNTIME_SNAPSHOT",
            "source_plan_count": len(scene["plans"]),
            "candidate_plan_count": len(candidate_plans),
            "fixed_plan_count": len(f_all),
            "plan_set_sha256": plan_set_sha256,
        },
    }


def build_parameterized_request_states(scene: Mapping[str, Any]) -> Dict[str, Dict[str, Any]]:
    """Declare request state for the synthetic research generator.

    These records are generator inputs, not facts inferred from trajectories and
    not claims about a real online snapshot.
    """
    return {
        uav_id: {
            "in_flight": False,
            "state_source": "PARAMETERIZED_RESEARCH_GENERATOR_DECLARATION",
        }
        for uav_id in sorted({item["uav_id"] for item in scene["plans"] if item["plan_status"] == "CANDIDATE"})
    }
