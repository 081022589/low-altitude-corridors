"""Pure ECJA assignment interface.

The algorithm has one data boundary:

``ECJAInput(current_batch_requests, historical_fixed_plans, ...)``
    describes the requests that may be optimized in this batch and the
    already-assigned/background traffic that must remain fixed.

``assign_ecja(...) -> ECJAOutput``
    returns the current batch's service-node decisions, their deterministic
    fixed-path references, and their audit
    information.  It does not mutate a traffic store, execute motion, or run
    C-MLPM.

The surrounding experiment/runtime packages are adapters.  They may read a
traffic state and commit the returned decisions, but those responsibilities
are deliberately outside this module.
"""

from __future__ import annotations

import copy
import dataclasses
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Mapping

from g25_param_env.scenario import canonical_hash
from srcm.models import SRCM_VERSION
from srcm.plan_motion import motion_evaluation_scope

from .load_balance import validate_capacity_assignment
from .contracts import build_research_input_contract
from .formal_motion import FORMAL_MOTION_MODEL
from .history_context import passage_incompatibility, request_background_plan, validate_passage_history
from .p3r_forward import ForwardRequest, build_forward_scene
from .p3r_pipeline import P3Config, _PreparedBatch, ecja_assign
from .p3r_srcm import evaluate_p3r_srcm
from .qsap import MODEL_VERSION as QSAP_MODEL_VERSION, QsapConfig, build_qsap_model, evaluate_q3
from .cb_lns import CBLNSConfig


@dataclass(frozen=True)
class ECJARequestHistory:
    """Immutable request-local history needed for passage compatibility."""

    uav_id: str
    s_m: float
    event_version: int
    current_motion_plan: Mapping[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class ECJAInput:
    """Complete immutable input to one ECJA decision batch.

    ``current_batch_requests`` are the only decision variables.  Every item
    in ``historical_fixed_plans`` is context/constraint traffic and must not be
    reallocated by ECJA.
    """

    source: Mapping[str, Any]
    current_batch_requests: tuple[ForwardRequest, ...]
    historical_fixed_plans: tuple[Mapping[str, Any], ...] = ()
    seed: int = 0
    policy: str = "ECJA_QSAP"
    motion_model: str = FORMAL_MOTION_MODEL
    # Service level: maximum assignments in this batch per descent unit;
    # not simultaneous occupancy. None disables the batch cap.
    peak_load_cap: int | None = None
    traffic_state_contract: Mapping[str, Any] | None = None
    active_assignment_summary: Mapping[str, Any] | None = None
    request_state_overrides: Mapping[str, Mapping[str, Any]] | None = None
    request_history: Mapping[str, ECJARequestHistory] = field(default_factory=dict)
    scenario_id: str | None = None
    # Actual creation times, not the current batch observation time. Required
    # by request-ordered external policies; ECJA itself does not consume them.
    request_created_times_s: Mapping[str, float] = field(default_factory=dict)


@dataclass(frozen=True)
class ECJAOutput:
    """Current-batch allocation result and auditable solver evidence."""

    policy: str
    assignments: Mapping[str, str]
    candidate_ids: Mapping[str, str]
    selected_routes: Mapping[str, str]  # Derived from the selected node, never optimized.
    unassigned_uav_ids: tuple[str, ...]
    solver_status: str
    termination_reason: str
    objective_total: float
    potential_overlap_count: int
    potential_overlap_duration_s: float
    compute_ms: float
    algorithm_version: str
    qsap_model_version: str
    srcm_version: str
    actual_formal_call: bool
    scene: Mapping[str, Any]
    sparse_srcm: Mapping[str, Any]
    qsap_model: Mapping[str, Any]
    raw_result: Mapping[str, Any]
    # Graded optimality certificate.  ``TRIVIAL_*`` classes mean the label was
    # obtained without any neighbourhood search, so they must not be reported
    # as evidence of search quality.
    proof_class: str = "HEURISTIC"
    provable_coverage: float = 0.0
    # Pre-solver admission outcomes, never optimization rejection variables.
    admission_rejections: Mapping[str, str] = field(default_factory=dict)
    input_contract: Mapping[str, Any] = field(default_factory=dict)
    algorithm_ms: float = 0.0
    search_ms: float = 0.0
    timing: Mapping[str, Any] = field(default_factory=dict)
    # Deterministic search effort actually spent.  ``search_tasks == 0`` only
    # happens together with a TRIVIAL_* proof class, i.e. when no neighbourhood
    # work was needed to certify the incumbent.
    search_tasks: int = 0


def _validate_input(inputs: ECJAInput, *, external_algorithm: bool = False) -> None:
    """Reject ambiguous or semantically unsafe algorithm inputs early."""

    requests = tuple(inputs.current_batch_requests)
    if not requests:
        raise ValueError("NO_ASSIGNMENT_REQUESTS")
    if not external_algorithm and inputs.policy not in {"ECJA_QSAP", "ECJA_QSAP_B0"}:
        raise ValueError(f"UNKNOWN_ASSIGNMENT_POLICY:{inputs.policy}")
    request_uav_ids = [str(item.uav_id) for item in requests]
    if len(request_uav_ids) != len(set(request_uav_ids)):
        raise ValueError("DUPLICATE_CURRENT_REQUEST_UAV_ID")
    request_ids = [str(item.request_id) for item in requests if item.request_id]
    if len(request_ids) != len(set(request_ids)):
        raise ValueError("DUPLICATE_CURRENT_REQUEST_ID")

    fixed_plan_ids: set[str] = set()
    fixed_uav_ids: set[str] = set()
    for plan in inputs.historical_fixed_plans:
        plan_id = plan.get("plan_id")
        uav_id = plan.get("uav_id")
        if not plan_id or not uav_id:
            raise ValueError("HISTORICAL_FIXED_PLAN_ID_MISSING")
        if str(plan.get("plan_status")) != "FIXED":
            raise ValueError(f"HISTORICAL_PLAN_NOT_FIXED:{uav_id}")
        if str(plan_id) in fixed_plan_ids:
            raise ValueError(f"DUPLICATE_HISTORICAL_PLAN_ID:{plan_id}")
        if str(uav_id) in fixed_uav_ids:
            raise ValueError(f"DUPLICATE_HISTORICAL_PLAN_UAV_ID:{uav_id}")
        fixed_plan_ids.add(str(plan_id))
        fixed_uav_ids.add(str(uav_id))
    overlap = sorted(fixed_uav_ids.intersection(request_uav_ids))
    if overlap:
        raise ValueError("CURRENT_REQUEST_OVERLAPS_HISTORICAL_FIXED:" + ",".join(overlap))

    request_history_ids = {str(key) for key in inputs.request_history}
    unknown_history = sorted(request_history_ids.difference(request_uav_ids))
    if unknown_history:
        raise ValueError("HISTORY_FOR_NON_REQUEST:" + ",".join(unknown_history))
    for uav_id, history in inputs.request_history.items():
        if str(history.uav_id) != str(uav_id):
            raise ValueError(f"REQUEST_HISTORY_UAV_MISMATCH:{uav_id}")
        if not isinstance(history.current_motion_plan, Mapping):
            raise ValueError(f"REQUEST_HISTORY_PLAN_INVALID:{uav_id}")
        validate_passage_history(history)


def build_ecja_scene(inputs: ECJAInput) -> dict[str, Any]:
    """Materialize the algorithm scene from the two explicit input groups."""

    requests = tuple(inputs.current_batch_requests)
    if not requests:
        raise ValueError("NO_ASSIGNMENT_REQUESTS")
    scene = build_forward_scene(
        inputs.source,
        requests,
        inputs.seed,
        inputs.scenario_id
        or f"G25_DT_FLOW:{inputs.seed}:{requests[0].snapshot_time_s}",
    )
    scene["plans"].extend(copy.deepcopy(list(inputs.historical_fixed_plans)))
    if inputs.active_assignment_summary is not None:
        scene["ecja_active_assignment_summary"] = copy.deepcopy(
            dict(inputs.active_assignment_summary)
        )
    scene["meta"]["t0_s"] = min(
        (float(plan["activity_start_s"]) for plan in scene["plans"]), default=0.0
    )
    summary_end_s = max(
        (
            float(row.get("exit_s", row.get("end_s")))
            for plan in scene["plans"]
            for row in plan.get("cmlpm_resource_passages", ())
            if str(row.get("status", "")).upper() != "RELEASED"
        ),
        default=0.0,
    )
    scene["meta"]["horizon_s"] = max(
        max((float(plan["activity_end_s"]) for plan in scene["plans"]), default=0.0),
        summary_end_s,
    ) + 1.0
    if inputs.motion_model == FORMAL_MOTION_MODEL:
        scene["time_profile"]["optional_guard_s"] = 0.5
        scene["traffic_profile"].update(
            {
                "motion_model": FORMAL_MOTION_MODEL,
                "vertical_speed_mps": 3.0,
                "transfer_method": "ZHOU_2019_LOCAL_BSPLINE_TIME_ADJUSTMENT_V1",
            }
        )
    elif inputs.motion_model == "ECJA_ROUTE_ONLY_SERVICE_NODE_V1":
        scene["time_profile"]["optional_guard_s"] = 0.0
        scene["traffic_profile"].update(
            {
                "motion_model": inputs.motion_model,
                "transfer_method": "CMLPM_E_ANCHOR_DEFERRED",
            }
        )
    else:
        raise ValueError("FORMAL_FIXED_PATH_REQUIRED")
    if inputs.traffic_state_contract is not None:
        for item in requests:
            scene["ecja_request_state_overrides"][item.uav_id].update(
                {
                    "state_source": "AUTHORITATIVE_TRAFFIC_SNAPSHOT",
                    "request_id": item.request_id,
                    "request_reason": item.request_reason,
                }
            )
        contract = copy.deepcopy(dict(inputs.traffic_state_contract))
        contract["snapshot_id"] = scene["meta"]["snapshot_id"]
        contract["plan_set_sha256"] = canonical_hash(
            sorted(
                (item["plan_id"], item["uav_id"], item["plan_status"])
                for item in scene["plans"]
            )
        )
        scene["traffic_state_contract"] = contract
    if inputs.request_state_overrides:
        for uav_id, values in inputs.request_state_overrides.items():
            scene["ecja_request_state_overrides"].setdefault(uav_id, {}).update(
                copy.deepcopy(dict(values))
            )
    scene["meta"]["scenario_hash"] = ""
    scene["meta"]["scenario_hash"] = canonical_hash(scene)
    return scene


def _common_model(
    scene: Mapping[str, Any],
    active_assignment_summary: Mapping[str, Any] | None,
    *,
    peak_load_cap: int | None = None,
    objective_profile: str = "V3_CORE",
    _candidate_facts: dict[str, Any] | None = None,
) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any], dict[str, Any]]:
    states = copy.deepcopy(scene.get("ecja_request_state_overrides", {}))
    contract = build_research_input_contract(scene, request_state_overrides=states, _candidate_facts=_candidate_facts)
    if contract.get("qualification") != "PASS_ECJA_NON_ENERGY":
        raise ValueError("ECJA_RESEARCH_INPUT_CONTRACT_BLOCKED")
    if contract.get("exception_traffic"):
        raise ValueError("BLOCKED_NO_VALID_ASSIGNMENT")
    eligible = {item["candidate_id"] for item in contract["candidates"]}
    filtered = dict(scene)
    filtered["plans"] = [
        plan
        for plan in scene["plans"]
        if plan["plan_status"] == "FIXED" or plan["plan_id"] in eligible
    ]
    sparse = evaluate_p3r_srcm(filtered)
    model = build_qsap_model(
        contract,
        sparse,
        filtered["plans"],
        QsapConfig(peak_load_cap=peak_load_cap, objective_profile=objective_profile),
        active_assignment_summary=active_assignment_summary,
    )
    return filtered, sparse, model, contract


def _selection_details(
    scene: Mapping[str, Any], assignment: Mapping[str, str]
) -> tuple[dict[str, str], dict[str, str]]:
    plans = {item["plan_id"]: item for item in scene["plans"]}
    nodes = {
        uav: str(plans[candidate]["service_node_id"])
        for uav, candidate in assignment.items()
    }
    routes = {
        uav: str(plans[candidate]["route_id"])
        for uav, candidate in assignment.items()
    }
    return nodes, routes


def _history_compatibility_checker(
    inputs: ECJAInput,
) -> Callable[[Mapping[str, Any]], str | None] | None:
    if not inputs.request_history:
        return None
    request_times = {
        str(item.uav_id): float(item.snapshot_time_s)
        for item in inputs.current_batch_requests
    }

    def check(candidate_plan: Mapping[str, Any]) -> str | None:
        uav_id = str(candidate_plan.get("uav_id", ""))
        history = inputs.request_history.get(uav_id)
        if history is None:
            return None
        return passage_incompatibility(
            history,
            candidate_plan,
            sim_time_s=request_times[uav_id],
        )

    return check


def _admit_requests(inputs: ECJAInput, scene: dict[str, Any], checker, *, _candidate_facts=None) -> dict[str, str]:
    """Admit nonempty legal domains; retain non-admitted traffic as fixed H."""

    # Inspect completeness before changing the request/fixed partition. A local
    # empty domain cannot mask a malformed authoritative snapshot.
    contract = build_research_input_contract(scene, request_state_overrides=scene["ecja_request_state_overrides"],
                                             _candidate_facts=_candidate_facts)
    if (not contract["request_state_contract"]["complete"]
            or not contract["f_all_completeness"]["complete_for_declared_generator"]
            or contract["identity_audit"]["u_e_intersection_f_all"]):
        raise ValueError("ECJA_RESEARCH_INPUT_CONTRACT_BLOCKED")
    metadata = {row["uav_id"]: row for row in scene["ecja_forward_request_audit"]}
    before = {u: 0 for u in metadata}
    retained, audit, after = [], [], {}
    for plan in scene["plans"]:
        if plan.get("plan_status") != "CANDIDATE":
            retained.append(plan)
            continue
        uav = str(plan["uav_id"])
        before[uav] += 1
        reason = checker(plan) if checker is not None else None
        # Only a complete, incompatible promise is an individual rejection.
        if reason is not None and not (str(reason) == "FORK_PRECEDES_COMMITTED_PASSAGE"
                                       or str(reason).startswith("FORK_PRECEDES_COMMITTED_PASSAGE:")):
            raise ValueError(f"ECJA_HISTORY_DATA_INVALID:{uav}:{reason}")
        audit.append({"uav_id": uav, "candidate_id": plan["plan_id"], "compatible": reason is None, "reason": reason})
        if reason is None:
            retained.append(plan)
            after[uav] = after.get(uav, 0) + 1
    available = set(after)
    rejected = {}
    admission = []
    excluded = set()
    for request in inputs.current_batch_requests:
        uav = request.uav_id
        count = after.get(uav, 0)
        reason = None
        if uav not in available:
            reason = ("EXISTING_PASSAGE_COMMITMENT_INCOMPATIBLE" if before[uav] > 0
                      else metadata[uav].get("zero_candidate_reason") or "NO_LEGAL_NON_ENERGY_CANDIDATE")
            rejected[uav] = reason
            background = request_background_plan(inputs.source, request, inputs.request_history.get(uav))
            if background is None:
                excluded.add(uav)
            else:
                retained.append(background)
        admission.append({"uav_id": uav, "request_id": request.request_id,
                          "status": "ADMITTED" if reason is None else "NOT_ADMITTED",
                          "reason": reason, "candidate_count_before_history": before[uav],
                          "candidate_count_after_history": count,
                          "candidate_generation_audit": copy.deepcopy(metadata[uav])})
    scene["plans"] = retained
    scene["ecja_admission_audit"] = admission
    scene["passage_commitment_compatibility_audit"] = audit
    scene["ecja_forward_request_audit"] = [r for r in scene["ecja_forward_request_audit"] if r["uav_id"] in available]
    if "traffic_state_contract" in scene:
        traffic = scene["traffic_state_contract"]
        traffic["request_uav_ids"] = sorted(available)
        traffic["fixed_uav_ids"] = sorted({p["uav_id"] for p in retained if p["plan_status"] == "FIXED"})
        traffic["excluded_uav_ids"] = sorted(set(traffic["excluded_uav_ids"]) | excluded)
        traffic["plan_set_sha256"] = canonical_hash(sorted((p["plan_id"], p["uav_id"], p["plan_status"]) for p in retained))
    scene["meta"]["horizon_s"] = max(float(scene["meta"]["horizon_s"]), max((float(p["activity_end_s"]) for p in retained), default=0.) + 1.)
    scene["meta"]["scenario_hash"] = ""
    scene["meta"]["scenario_hash"] = canonical_hash(scene)
    return rejected


def _assign_ecja(
    inputs: ECJAInput,
    *,
    _compatibility_override: Callable[[Mapping[str, Any]], str | None] | None = None,
    _algorithm=None,
) -> ECJAOutput:
    """Run one ECJA batch without mutating external state.

    Request-local historical commitments are read from ``inputs``.  The
    private compatibility override exists only for legacy experiment tests;
    new callers must provide typed ``request_history`` instead.
    """

    _validate_input(inputs, external_algorithm=_algorithm is not None)
    if _compatibility_override is not None and inputs.request_history:
        raise ValueError("MULTIPLE_PASSAGE_COMPATIBILITY_SOURCES")
    candidate_compatibility = _compatibility_override or _history_compatibility_checker(
        inputs
    )
    started = time.perf_counter()
    scene = build_ecja_scene(inputs)
    candidate_facts = {}
    admission_rejections = _admit_requests(inputs, scene, candidate_compatibility, _candidate_facts=candidate_facts)
    if len(admission_rejections) == len(inputs.current_batch_requests):
        # Validate remaining traffic/resources, but never call a QSAP solver
        # with zero decision requests.
        sparse = evaluate_p3r_srcm(scene)
        contract = build_research_input_contract(scene, request_state_overrides=scene["ecja_request_state_overrides"])
        return ECJAOutput(
            policy=inputs.policy, assignments={}, candidate_ids={}, selected_routes={},
            unassigned_uav_ids=tuple(sorted(admission_rejections)),
            solver_status="NO_ADMITTED_REQUESTS", termination_reason="NO_ADMITTED_REQUESTS",
            objective_total=0., potential_overlap_count=0, potential_overlap_duration_s=0.,
            compute_ms=(time.perf_counter() - started) * 1000.,
            algorithm_version="ECJA_REQUEST_ADMISSION_V1", qsap_model_version=QSAP_MODEL_VERSION,
            srcm_version=SRCM_VERSION, actual_formal_call=False, scene=scene,
            sparse_srcm=sparse, qsap_model={}, raw_result={}, admission_rejections=admission_rejections,
            input_contract=contract,
        )

    filtered, sparse, model, contract = _common_model(
        scene, inputs.active_assignment_summary,
        peak_load_cap=inputs.peak_load_cap, _candidate_facts=candidate_facts,
        objective_profile=(_algorithm.objective_profile if _algorithm is not None
                           else "B0" if inputs.policy == "ECJA_QSAP_B0" else "V3_CORE"),
    )
    if _algorithm is not None:
        selection = _algorithm.select(model, inputs)
        assignment = dict(selection.candidate_ids)
        if set(assignment) != set(model["uavs"]) or any(
            candidate not in model["candidate_ids_by_uav"][uid]
            for uid, candidate in assignment.items()
        ):
            raise ValueError("INVALID_EXTERNAL_ASSIGNMENT")
        if model.get("peak_load_cap_effective") is not None:
            validate_capacity_assignment(model, assignment, int(model["peak_load_cap_effective"]))
        objective = evaluate_q3(model, assignment)
        raw: Mapping[str, Any] = dict(selection.diagnostics)
        compute_ms = 0.0
        algorithm = selection.algorithm_version
        actual_formal = False
        proof_info: Mapping[str, Any] = {}
    elif inputs.policy in {"ECJA_QSAP", "ECJA_QSAP_B0"}:
        result = ecja_assign(
            filtered,
            P3Config(
                request_id=f"G25_DT_FLOW:{inputs.seed}",
                qsap_model=model,
            ),
            _prepared=_PreparedBatch(filtered, contract, sparse, model),
        )
        dto = result["candidate_dto"]
        if dto.get("result_validity") != "VALID_CANDIDATE_ONLY":
            raise ValueError(
                f"ECJA_FORMAL_CALL_BLOCKED:{dto.get('termination_reason')}"
            )
        assignment = {
            row["uav_id"]: row["candidate_id"]
            for rows in dto.get("service_queues", {}).values()
            for row in rows
        }
        objective = dto["diagnostics"]["objective_final"]
        raw = result
        compute_ms = float(result["timing_receipt"]["total_decision_wall_ms"])
        algorithm = str(dto["algorithm"])
        actual_formal = True
        proof_info = dto.get("global_optimality_proof") or {}
    else:
        raise ValueError(f"UNKNOWN_ASSIGNMENT_POLICY:{inputs.policy}")
    admitted = {r.uav_id for r in inputs.current_batch_requests} - set(admission_rejections)
    if set(assignment) != admitted:
        raise ValueError("ECJA_INCOMPLETE_ADMITTED_ASSIGNMENT")
    nodes, routes = _selection_details(filtered, assignment)
    selected = set(assignment.values())
    selected_events = [
        event
        for event in sparse["events"]
        if event["plan_a_id"] in selected and event["plan_b_id"] in selected
    ]
    requested_ids = {item.uav_id for item in inputs.current_batch_requests}
    return ECJAOutput(
        policy=inputs.policy,
        assignments=nodes,
        candidate_ids=dict(assignment),
        selected_routes=routes,
        unassigned_uav_ids=tuple(sorted(requested_ids - set(nodes))),
        solver_status=str(
            raw.get("solver_status")
            or raw.get("candidate_dto", {}).get("solver_status")
        ),
        termination_reason=str(
            raw.get("termination_reason")
            or raw.get("candidate_dto", {}).get("termination_reason")
        ),
        objective_total=float(objective["total"]),
        potential_overlap_count=len(selected_events),
        potential_overlap_duration_s=sum(
            float(item["nominal_overlap_s"]) for item in selected_events
        ),
        compute_ms=compute_ms or (time.perf_counter() - started) * 1000.0,
        algorithm_version=algorithm,
        qsap_model_version=QSAP_MODEL_VERSION,
        srcm_version=SRCM_VERSION,
        actual_formal_call=actual_formal,
        scene=filtered,
        sparse_srcm=sparse,
        qsap_model=model,
        raw_result=raw,
        proof_class=str(proof_info.get("proof_class", "HEURISTIC")),
        provable_coverage=float(proof_info.get("provable_coverage", 0.0)),
        admission_rejections=admission_rejections,
        input_contract=contract,
    )


def _timed_assignment(
    inputs: ECJAInput,
    *,
    _compatibility_override: Callable[[Mapping[str, Any]], str | None] | None = None,
    _algorithm=None,
) -> ECJAOutput:
    """Measure the entire algorithm, including validation and preprocessing.

    There is no completion deadline.  The search stops on deterministic work
    limits, so one snapshot reproduces one incumbent on any machine.  The wall
    clock is measured and reported, never used as a stopping rule.
    """
    started = time.perf_counter_ns()
    with motion_evaluation_scope():
        result = _assign_ecja(inputs, _compatibility_override=_compatibility_override,
                              _algorithm=_algorithm)
    receipt = result.raw_result.get("timing_receipt", {})
    elapsed = (time.perf_counter_ns()-started)/1e6
    search_ms = float(receipt.get("search_wall_ms", 0.0))
    scheduler = (result.raw_result.get("candidate_dto", {}) or {}).get("diagnostics", {}).get("scheduler", {})
    tasks = int(scheduler.get("tasks_attempted", 0) or 0)
    return dataclasses.replace(
        result, compute_ms=elapsed, algorithm_ms=elapsed, search_ms=search_ms,
        search_tasks=tasks,
        timing={"schema_version": "ECJA_TIMING_V3_WORK_LIMIT_ONLY",
                "algorithm_ms": elapsed, "search_ms": search_ms,
                "pipeline_ms": float(receipt.get("total_decision_wall_ms", 0.0)),
                "search_tasks": tasks},
    )


def assign_ecja(inputs: ECJAInput, *, _compatibility_override=None) -> ECJAOutput:
    """Run ECJA or its B0 ablation; external baselines use assign_nodes()."""
    return _timed_assignment(inputs, _compatibility_override=_compatibility_override)


def assign_with_algorithm(inputs: ECJAInput, *, algorithm, _compatibility_override=None) -> ECJAOutput:
    """Shared preparation, selection validation and timing for external policies."""
    return _timed_assignment(inputs, _algorithm=algorithm,
                             _compatibility_override=_compatibility_override)


__all__ = [
    "ECJAInput",
    "ECJAOutput",
    "ECJARequestHistory",
    "assign_ecja",
    "build_ecja_scene",
]
