"""Peak-load measurement and service-level feasibility for descent units.

The load term of the QSAP objective is a cardinality effect on the descent unit
``(service_node_id, source_layer_id)``: what matters is how many aircraft chose
one unit, not which two of them did.  Peak load therefore depends only on the
assignment's counts.

That makes two questions answerable exactly, without any weight sweep:

* what peak does a given assignment produce;
* what peak is *achievable at all* for a given legal domain, i.e. the smallest
  ``K`` for which some assignment keeps every unit at or below ``K``.

The second is a capacitated bipartite matching and is decided here by max flow,
so it is exact.  A caller can then state a service level ``K`` and check whether
the network geometry can support it at all, before asking the solver for the
cheapest assignment that respects it.
"""
from __future__ import annotations

from collections import deque
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence

LOAD_KEY_SEPARATOR = "|"


def load_key(model: Mapping[str, Any], candidate_id: str) -> Optional[str]:
    """Descent unit of one candidate, or None when the model carries no keys."""

    return (model.get("candidate_to_load_key") or {}).get(candidate_id)


def available_units(model: Mapping[str, Any]) -> List[str]:
    """Every descent unit reachable by at least one candidate, sorted."""

    mapping = model.get("candidate_to_load_key") or {}
    return sorted({
        mapping[candidate]
        for candidates in model["candidate_ids_by_uav"].values()
        for candidate in candidates
        if candidate in mapping
    })


def load_distribution(model: Mapping[str, Any], assignment: Mapping[str, str]) -> Dict[str, int]:
    """Aircraft per descent unit for one assignment."""

    counts: Dict[str, int] = {}
    mapping = model.get("candidate_to_load_key") or {}
    for candidate in assignment.values():
        key = mapping.get(candidate)
        if key is not None:
            counts[key] = counts.get(key, 0) + 1
    return counts


def peak_load(model: Mapping[str, Any], assignment: Mapping[str, str]) -> int:
    counts = load_distribution(model, assignment)
    return max(counts.values()) if counts else 0


def uniform_floor(aircraft: int, units: int) -> int:
    """Best peak any assignment could reach if every unit were equally usable."""

    if units <= 0:
        return aircraft
    return -(-aircraft // units)


class _Residual:
    """Minimal max-flow over a residual network; sizes here are tiny."""

    def __init__(self, size: int) -> None:
        self.size = size
        self.adjacency: List[List[List[int]]] = [[] for _ in range(size)]

    def add(self, tail: int, head: int, capacity: int):
        forward = [head, capacity, len(self.adjacency[head])]
        self.adjacency[tail].append(forward)
        self.adjacency[head].append([tail, 0, len(self.adjacency[tail]) - 1])
        return forward

    def max_flow(self, source: int, sink: int) -> int:
        total = 0
        while True:
            previous: List[Optional[tuple]] = [None] * self.size
            previous[source] = (-1, -1)
            queue = deque([source])
            while queue and previous[sink] is None:
                node = queue.popleft()
                for index, edge in enumerate(self.adjacency[node]):
                    head, capacity, _ = edge
                    if capacity > 0 and previous[head] is None:
                        previous[head] = (node, index)
                        queue.append(head)
            if previous[sink] is None:
                return total
            push = float("inf")
            node = sink
            while node != source:
                tail, index = previous[node]
                push = min(push, self.adjacency[tail][index][1])
                node = tail
            node = sink
            while node != source:
                tail, index = previous[node]
                edge = self.adjacency[tail][index]
                edge[1] -= push
                self.adjacency[node][edge[2]][1] += push
                node = tail
            total += push


def _candidate_units(model: Mapping[str, Any]) -> Dict[str, List[str]]:
    mapping = model.get("candidate_to_load_key") or {}
    return {
        uav: sorted({mapping[candidate] for candidate in candidates if candidate in mapping})
        for uav, candidates in model["candidate_ids_by_uav"].items()
    }


def feasible_with_cap(model: Mapping[str, Any], cap: int) -> bool:
    """Can every UAV take one unit while keeping every unit at or below ``cap``?"""

    if cap <= 0:
        return False
    units_by_uav = _candidate_units(model)
    if any(not units for units in units_by_uav.values()):
        return False
    uavs = sorted(units_by_uav)
    units = sorted({unit for values in units_by_uav.values() for unit in values})
    uav_index = {uav: index for index, uav in enumerate(uavs)}
    unit_index = {unit: index for index, unit in enumerate(units)}
    source = 0
    uav_base = 1
    unit_base = uav_base + len(uavs)
    sink = unit_base + len(units)
    network = _Residual(sink + 1)
    for uav in uavs:
        network.add(source, uav_base + uav_index[uav], 1)
        for unit in units_by_uav[uav]:
            network.add(uav_base + uav_index[uav], unit_base + unit_index[unit], 1)
    for unit in units:
        network.add(unit_base + unit_index[unit], sink, cap)
    return network.max_flow(source, sink) == len(uavs)


def min_achievable_peak(model: Mapping[str, Any]) -> Optional[int]:
    """Smallest cap that still admits a complete assignment, or None.

    Feasibility is monotone in the cap, so this is a binary search rather than a
    linear scan.  ``None`` means some UAV has no legal unit at all.
    """

    uavs = list(model["uavs"])
    if not uavs:
        return 0
    low, high = 1, len(uavs)
    if not feasible_with_cap(model, high):
        return None
    while low < high:
        middle = (low + high) // 2
        if feasible_with_cap(model, middle):
            high = middle
        else:
            low = middle + 1
    return low


def _flow_completion(model, cap, counts, remaining):
    """Complete a partial assignment with max flow; None when impossible."""

    mapping = model.get("candidate_to_load_key") or {}
    options = {}
    for uav in remaining:
        rows = []
        for candidate in model["candidate_ids_by_uav"][uav]:
            key = mapping.get(candidate)
            if key is None:
                continue
            if int(cap) - counts.get(key, 0) <= 0:
                continue
            rows.append((key, candidate))
        if not rows:
            return None
        options[uav] = rows
    units = sorted({key for rows in options.values() for key, _ in rows})
    unit_index = {unit: index for index, unit in enumerate(units)}
    source = 0
    uav_base = 1
    unit_base = uav_base + len(remaining)
    sink = unit_base + len(units)
    network = _Residual(sink + 1)
    edges = {}
    for index, uav in enumerate(remaining):
        network.add(source, uav_base + index, 1)
        for key, candidate in options[uav]:
            edges[(uav, key)] = network.add(uav_base + index, unit_base + unit_index[key], 1)
    for unit in units:
        residual = int(cap) - counts.get(unit, 0)
        if residual > 0:
            network.add(unit_base + unit_index[unit], sink, residual)
    if network.max_flow(source, sink) != len(remaining):
        return None
    completion = {}
    for (uav, key), edge in edges.items():
        if edge[1] == 0:
            completion[uav] = next(c for k, c in options[uav] if k == key)
    return completion if len(completion) == len(remaining) else None


def remaining_assignment_feasible(model, cap, counts, remaining) -> bool:
    """Check residual K feasibility without minimizing any assignment cost."""
    return _flow_completion(model, cap, counts, remaining) is not None


def capacitated_initial_assignment(model: Mapping[str, Any], cap: int) -> Dict[str, str]:
    """Cheapest-first complete assignment that respects ``cap``.

    Greedy by linear cost with capacity, then a max-flow completion for any UAV
    the greedy could not place.  Raises when the legal domain admits no
    cap-feasible assignment, which callers avoid by relaxing the cap to
    ``min_achievable_peak`` before building the model.
    """

    mapping = model.get("candidate_to_load_key") or {}
    costs = model["linear_costs"]
    order = sorted(model["uavs"],
                   key=lambda uav: (len(model["candidate_ids_by_uav"][uav]), uav))
    counts: Dict[str, int] = {}
    assignment: Dict[str, str] = {}
    for uav in order:
        remaining_after = [item for item in order if item != uav and item not in assignment]
        placed = False
        for candidate in sorted(model["candidate_ids_by_uav"][uav],
                                key=lambda c: (float(costs[c]), c)):
            key = mapping.get(candidate)
            if key is None:
                continue
            if counts.get(key, 0) < int(cap):
                trial_counts = dict(counts)
                trial_counts[key] = trial_counts.get(key, 0) + 1
                if _flow_completion(model, cap, trial_counts, remaining_after) is None:
                    continue
                assignment[uav] = candidate
                counts = trial_counts
                placed = True
                break
        if not placed:
            raise ValueError("INFEASIBLE_PEAK_LOAD_CAP")
    validate_capacity_assignment(model, assignment, cap)
    return {uav: assignment[uav] for uav in sorted(assignment)}


def validate_capacity_assignment(
    model: Mapping[str, Any], assignment: Mapping[str, str], cap: int
) -> Dict[str, int]:
    """Validate one complete assignment against a descent-unit capacity."""

    if isinstance(cap, bool) or not isinstance(cap, int) or cap < 1:
        raise ValueError("INVALID_PEAK_LOAD_CAP")
    if set(assignment) != set(model["uavs"]):
        raise ValueError("CAPACITY_ASSIGNMENT_UAV_SET_MISMATCH")
    mapping = model.get("candidate_to_load_key") or {}
    counts: Dict[str, int] = {}
    for uav, candidate in assignment.items():
        if candidate not in model["candidate_ids_by_uav"].get(uav, ()):
            raise ValueError(f"CAPACITY_ASSIGNMENT_INVALID_CANDIDATE:{uav}")
        key = mapping.get(candidate)
        if key is None:
            raise ValueError(f"CAPACITY_ASSIGNMENT_LOAD_KEY_MISSING:{candidate}")
        counts[key] = counts.get(key, 0) + 1
    if any(value > cap for value in counts.values()):
        raise ValueError("PEAK_LOAD_CAP_VIOLATED")
    return dict(sorted(counts.items()))


def report(model: Mapping[str, Any], assignment: Mapping[str, str]) -> Dict[str, Any]:
    """One auditable row: current peak, reachable floor, and headroom."""

    counts = load_distribution(model, assignment)
    units = available_units(model)
    floor = min_achievable_peak(model)
    return {
        "aircraft": len(model["uavs"]),
        "descent_units": len(units),
        "peak_load": max(counts.values()) if counts else 0,
        "units_used": len(counts),
        "load_distribution": dict(sorted(counts.items())),
        "min_achievable_peak": floor,
        "uniform_floor": uniform_floor(len(model["uavs"]), len(units)),
        "geometry_allows_balance": floor is not None and floor < (max(counts.values()) if counts else 0),
    }


__all__ = [
    "LOAD_KEY_SEPARATOR",
    "available_units",
    "capacitated_initial_assignment",
    "feasible_with_cap",
    "load_distribution",
    "load_key",
    "min_achievable_peak",
    "peak_load",
    "report",
    "validate_capacity_assignment",
    "uniform_floor",
]
