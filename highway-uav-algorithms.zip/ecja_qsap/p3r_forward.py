"""P3-R forward-all-reachable candidate adapter over the read-only G25 catalog."""

from __future__ import annotations

import bisect
import copy
import hashlib
import json
import math
from dataclasses import asdict, dataclass
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple

from g25_param_env.extractor import cumulative_lengths, interpolate_station, project_station_xy
from g25_param_env.scenario import build_scenario_bundle, canonical_hash
from srcm.plan_motion import motion_sha256

from .formal_motion import FORMAL_MOTION_MODEL, build_formal_motion_prediction


GENERATOR_VERSION = "ECJA_FORWARD_ALL_REACHABLE_V1"
CATALOG_VERSION = "ECJA_G25_FORWARD_SERVICE_CATALOG_V1"
SWITCH_CONTRACT_VERSION = "ECJA_PHYSICAL_DECISION_DEADLINE_CONTRACT_V2"
ROUTE_ONLY_MOTION_MODEL = "ECJA_ROUTE_ONLY_SERVICE_NODE_V1"
STATION_EPS_M = 1e-6


def _hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


@dataclass(frozen=True)
class ForwardRequest:
    uav_id: str
    direction_id: str
    source_layer_id: str
    current_directed_station_m: float
    allowed_end_directed_station_m: float
    snapshot_time_s: float
    speed_mps: float
    # Retained as optional compatibility fields for callers that still carry
    # public traffic-state energy data.  ECJA deliberately ignores them.
    remaining_energy_wh: float | None = None
    reserve_energy_wh: float | None = None
    original_service_node_id: str | None = None
    committed: bool = False
    in_flight: bool = False
    task_compatible_node_ids: Tuple[str, ...] = ()
    route_plan_id: str = "P3R_DECLARED_REMAINING_CORRIDOR_SCOPE"
    motion_model: str = FORMAL_MOTION_MODEL
    request_id: str | None = None
    request_reason: str | None = None
    # ``None`` preserves the historical unconstrained candidate contract.
    # A tuple is an authoritative energy-filtered node allow-list shared by
    # every assignment policy at the common candidate-generation seam.
    allowed_energy_candidate_node_ids: Tuple[str, ...] | None = None
    allow_stop_start: bool = False

    def validate(self) -> None:
        if self.motion_model not in {FORMAL_MOTION_MODEL, ROUTE_ONLY_MOTION_MODEL}:
            raise ValueError("FORMAL_FIXED_PATH_REQUIRED")
        if self.direction_id not in {"forward", "reverse"} or self.source_layer_id not in {"L1", "L2", "L3"}:
            raise ValueError("INVALID_DIRECTION_OR_LAYER")
        values = (self.current_directed_station_m, self.allowed_end_directed_station_m,
                  self.snapshot_time_s, self.speed_mps)
        if (any(not math.isfinite(float(value)) for value in values) or self.speed_mps < 0
                or (self.speed_mps == 0 and not self.allow_stop_start)):
            raise ValueError("INVALID_FORWARD_REQUEST_NUMERIC")
        if self.allowed_end_directed_station_m < self.current_directed_station_m:
            raise ValueError("PLAN_CORRIDOR_SCOPE_UNKNOWN")


def _request_record(request: ForwardRequest) -> Dict[str, Any]:
    record = asdict(request)
    record.pop("remaining_energy_wh", None)
    record.pop("reserve_energy_wh", None)
    if not request.allow_stop_start:
        record.pop("allow_stop_start")
    if request.request_id is None:
        record.pop("request_id")
    if request.request_reason is None:
        record.pop("request_reason")
    if request.allowed_energy_candidate_node_ids is None:
        record.pop("allowed_energy_candidate_node_ids")
    else:
        record["allowed_energy_candidate_node_ids"] = tuple(sorted(
            str(value) for value in request.allowed_energy_candidate_node_ids
        ))
    return record


class ForwardServiceCatalog:
    """Immutable station-sorted interface index plus a full-scan reference Oracle."""

    def __init__(self, source: Mapping[str, Any]):
        rows = []
        node_paths = set()
        mainlines = {(m["direction_id"], m["layer_id"]): m for m in source["mainlines"]}
        for item in source["access_interfaces"]:
            identity = (item["direction_id"], item["source_layer_id"], item["service_node_id"])
            if identity in node_paths:
                raise ValueError(f"FIXED_PATH_NOT_UNIQUE:{identity}")
            node_paths.add(identity)
            key = (item["direction_id"], item["source_layer_id"])
            if key not in mainlines:
                raise ValueError("CATALOG_MAINLINE_MISSING")
            directed_station, projection_error, _, _ = project_station_xy(mainlines[key]["polyline_3d"], item["zhou_g_xyz"][:2])
            if projection_error > 1e-5:
                raise ValueError("CATALOG_GATE_PROJECTION_FAILED")
            row = {"corridor_id": mainlines[key]["mainline_id"], "direction_id": key[0], "source_layer_id": key[1],
                   "service_node_id": item["service_node_id"], "interface_id": item["interface_id"],
                   "gate_directed_station_m": float(directed_station), "source_chainage_m":float(item["source_chainage_m"]),
                   "shaft_axis_xy": list(item["shaft_axis_xy"]), "shaft_top_z_m": float(item["shaft_top_z_m"]),
                   "shaft_scope_end_z_m": float(item["shaft_scope_end_z_m"]),
                   "geometry_source_status": "G25_REGISTERED_ACCESS_INTERFACE"}
            for field in ("g_station_m", "zhou_g_xyz", "zhou_j_xyz", "zhou_allowed_cells", "zhou_mainline_tangent_xyz"):
                row[field] = copy.deepcopy(item[field])
            rows.append(row)
        self.rows = tuple(sorted(rows, key=lambda r: (r["direction_id"], r["source_layer_id"], r["gate_directed_station_m"], r["interface_id"])))
        self.catalog_hash = _hash(self.rows)
        self._index = {}
        for row in self.rows:
            key = (row["direction_id"], row["source_layer_id"])
            self._index.setdefault(key, []).append(row)

    def interval(self, direction: str, layer: str, lower_exclusive: float, upper_inclusive: float):
        rows = self._index.get((direction, layer), [])
        stations = [row["gate_directed_station_m"] for row in rows]
        lo = bisect.bisect_right(stations, lower_exclusive + STATION_EPS_M)
        hi = bisect.bisect_right(stations, upper_inclusive + STATION_EPS_M)
        return list(rows[lo:hi])

    def scan_oracle(self, direction: str, layer: str, lower_exclusive: float, upper_inclusive: float):
        return [row for row in self.rows if row["direction_id"] == direction and row["source_layer_id"] == layer
                and lower_exclusive + STATION_EPS_M < row["gate_directed_station_m"] <= upper_inclusive + STATION_EPS_M]


def _path_between(polyline: Sequence[Sequence[float]], start: float, end: float) -> List[List[float]]:
    cumulative = cumulative_lengths(polyline)
    start_point, start_index, _ = interpolate_station(polyline, start)
    end_point, end_index, _ = interpolate_station(polyline, end)
    points = [list(start_point)]
    for index in range(start_index + 1, end_index + 1):
        if cumulative[index] < end - 1e-9:
            points.append(list(polyline[index]))
    if math.dist(points[-1], end_point) > 1e-9:
        points.append(list(end_point))
    return points


def _candidate_plan(source: Mapping[str, Any], request: ForwardRequest, access: Mapping[str, Any], *,
                    allow_bounded_approach: bool = False) -> Dict[str, Any]:
    line = next(m for m in source["mainlines"] if m["direction_id"] == request.direction_id and m["layer_id"] == request.source_layer_id)
    suffix = hashlib.sha256(access["interface_id"].encode()).hexdigest()[:12]
    plan_id = f"{request.uav_id}:FORWARD:{suffix}"

    # Active V5 semantics: ECJA assigns a service node and its registered
    # fixed route only. C-MLPM owns E-anchor timing and the motion layer owns
    # E->J->P realization. ``g_station_m`` is retained only as compatibility
    # geometry for the fixed-route commit, not as a motion decision.
    if request.motion_model == ROUTE_ONLY_MOTION_MODEL:
        gate = float(access["g_station_m"])
        if not math.isfinite(gate):
            raise ValueError("ACCESS_GATE_STATION_INVALID")
        return {
            "uav_id": request.uav_id,
            "plan_id": plan_id,
            "plan_status": "FIXED" if request.committed else "CANDIDATE",
            "mode": "ROUTE_ONLY_SERVICE_NODE_ASSIGNMENT",
            "source_mainline_id": line["mainline_id"],
            "source_layer_id": request.source_layer_id,
            "source_direction_id": request.direction_id,
            "service_node_id": access["service_node_id"],
            "option_group_id": request.request_id or f"{request.uav_id}_FORWARD_ALL",
            "is_current_assignment": access["service_node_id"] == request.original_service_node_id,
            "committed": request.committed,
            "activity_start_s": float(request.snapshot_time_s),
            "activity_end_s": float(request.snapshot_time_s),
            "termination_reason": "CMLPM_OWNS_RESOURCE_TIMING",
            "trajectory_coverage_status": "ROUTE_ONLY_NO_MOTION_AUTHORITY",
            "route_id": f"route:{access['interface_id']}",
            "motion_parameter_provenance": "ECJA_ROUTE_ONLY_NO_MOTION_V1",
            "ecja_forward_contract": {
                "candidate_generation_version": ROUTE_ONLY_MOTION_MODEL,
                "route_plan_id": request.route_plan_id,
                "current_directed_station_m": request.current_directed_station_m,
                "allowed_end_directed_station_m": request.allowed_end_directed_station_m,
                "gate_directed_station_m": gate,
                "latest_switch_station_m": gate,
                "latest_switch_time_s": None,
                "eta_source_layer_shaft_gate_s": None,
                "deadline_evidence": "CMLPM_E_ANCHOR_DEFERRED",
                "deadline_contract_version": ROUTE_ONLY_MOTION_MODEL,
                "handoff_margin_s": 0.0,
                "research_margin_s": 0.0,
            },
        }
    gate, error, _, _ = project_station_xy(line["polyline_3d"], access["zhou_g_xyz"][:2])
    if error > 1e-5 or abs(gate - access["gate_directed_station_m"]) > 1e-4:
        raise ValueError("ACCESS_GATE_STATION_MISMATCH")
    if request.motion_model == FORMAL_MOTION_MODEL:
        formal = build_formal_motion_prediction(line, request, access,
                                                allow_bounded_approach=allow_bounded_approach)
        switch = formal["transfer_entry_station_m"]
        switch_time = formal["transfer_entry_time_s"]
        descent_end = formal["activity_end_s"]
        return {
            "uav_id": request.uav_id,
            "plan_id": plan_id,
            "plan_status": "FIXED" if request.committed else "CANDIDATE",
            "mode": "FORMAL_THREE_PHASE_ACCESS",
            "source_mainline_id": line["mainline_id"],
            "source_layer_id": request.source_layer_id,
            "source_direction_id": request.direction_id,
            "service_node_id": access["service_node_id"],
            "option_group_id": request.request_id or f"{request.uav_id}_FORWARD_ALL",
            "is_current_assignment": access["service_node_id"] == request.original_service_node_id,
            "committed": request.committed,
            "activity_start_s": request.snapshot_time_s,
            "activity_end_s": descent_end,
            "termination_reason": "ENGINEERING_BOUNDARY_REACHED",
            "trajectory_coverage_status": "COMPLETE_TO_ENGINEERING_BOUNDARY",
            "coverage_window": [request.snapshot_time_s, descent_end],
            "motion_prediction": formal["motion_prediction"],
            "route_id": f"route:{access['interface_id']}",
            "motion_parameter_provenance": formal["motion_parameter_provenance"],
            **({"candidate_prediction_evidence": {
                "role":"UNPUBLISHED_SRCM_CANDIDATE",
                "approach_kind":formal["approach_prediction_kind"],
                "physical_emptiness_proved":False,
            }} if allow_bounded_approach else {}),
            "formal_motion_contract": {
                "model": FORMAL_MOTION_MODEL,
                "curve": "ZHOU_2019_LOCAL_BSPLINE_TIME_ADJUSTMENT_V1",
                "vertical_speed_mps": 3.0,
                "vehicle_type": formal["vehicle_type"],
            },
            "ecja_forward_contract": {
                "candidate_generation_version": GENERATOR_VERSION,
                "route_plan_id": request.route_plan_id,
                "current_directed_station_m": request.current_directed_station_m,
                "allowed_end_directed_station_m": request.allowed_end_directed_station_m,
                "gate_directed_station_m": gate,
                "latest_switch_station_m": switch,
                "latest_switch_time_s": switch_time,
                "eta_source_layer_shaft_gate_s": formal["vertical_entry_time_s"],
                "deadline_evidence": "REGISTERED_G_WITH_ZHOU_PREDICTED_TRANSFER",
                "deadline_contract_version": SWITCH_CONTRACT_VERSION,
                "handoff_margin_s": 0.0,
                "research_margin_s": 0.0,
            },
        }
    raise ValueError("FORMAL_FIXED_PATH_REQUIRED")



def enumerate_request(source: Mapping[str, Any], catalog: ForwardServiceCatalog, request: ForwardRequest) -> Dict[str, Any]:
    request.validate()
    indexed = catalog.interval(request.direction_id, request.source_layer_id, request.current_directed_station_m, request.allowed_end_directed_station_m)
    scanned = catalog.scan_oracle(request.direction_id, request.source_layer_id, request.current_directed_station_m, request.allowed_end_directed_station_m)
    if [x["interface_id"] for x in indexed] != [x["interface_id"] for x in scanned]:
        raise ValueError("INDEX_FULL_SCAN_MISMATCH")
    all_layer = [row for row in catalog.rows if row["direction_id"] == request.direction_id and row["source_layer_id"] == request.source_layer_id]
    audits, plans = [], []
    energy_allow = (
        None if request.allowed_energy_candidate_node_ids is None
        else frozenset(str(value) for value in request.allowed_energy_candidate_node_ids)
    )
    for access in all_layer:
        gate = access["gate_directed_station_m"]
        reasons = []
        plan = None
        if gate <= request.current_directed_station_m + STATION_EPS_M:
            reasons.append("BEHIND_CURRENT_POSITION")
        elif gate > request.allowed_end_directed_station_m + STATION_EPS_M:
            reasons.append("OUTSIDE_PLAN_REMAINING_SEGMENT")
        elif request.task_compatible_node_ids and access["service_node_id"] not in request.task_compatible_node_ids:
            reasons.append("TASK_INCOMPATIBLE")
        elif energy_allow is not None and str(access["service_node_id"]) not in energy_allow:
            reasons.append("ENERGY_INFEASIBLE_CANDIDATE")
        else:
            try:
                plan = _candidate_plan(source, request, access)
                if request.committed and access["service_node_id"] == request.original_service_node_id:
                    plans.append(plan)
                elif not request.committed:
                    plans.append(plan)
            except ValueError as error:
                if str(error) not in {"MISSED_SWITCH_BOUNDARY", "FORMAL_APPROACH_DISTANCE_INSUFFICIENT",
                                      "ZHOU_TRANSFER_GENERATION_FAILED"}:
                    raise
                reasons.append(str(error))
        audits.append({"node_id":access["service_node_id"], "interface_id":access["interface_id"], "gate_directed_station_m":gate,
                       "status":("FIXED_COMMITTED" if request.committed and not reasons and access["service_node_id"] == request.original_service_node_id
                                 else "NOT_SELECTED_COMMITTED" if request.committed and not reasons else "ELIGIBLE" if not reasons else "EXCLUDED"), "reasons":reasons,
                       "latest_switch_station_m":plan["ecja_forward_contract"]["latest_switch_station_m"] if plan else None,
                       "latest_switch_time_s":plan["ecja_forward_contract"]["latest_switch_time_s"] if plan else None,
                       "route_sha256":(_hash(plan["trajectory"]) if plan and plan.get("trajectory") else motion_sha256(plan) if plan else None),
                       "eta_source_layer_shaft_gate_s":plan["ecja_forward_contract"]["eta_source_layer_shaft_gate_s"] if plan else None})
    eligible_nodes = sorted({plan["service_node_id"] for plan in plans})
    return {"request":_request_record(request), "catalog_hash":catalog.catalog_hash, "indexed_full_scan_equal":True,
            "registered_direction_layer_sites":len(all_layer), "forward_site_count":len(indexed),
            "eligible_service_node_count":len(eligible_nodes), "eligible_plan_count":len(plans),
            "uav_id": request.uav_id, "request_id": request.request_id or f"{request.uav_id}:FORWARD",
            "eligible_service_node_ids":eligible_nodes, "plans":plans, "per_site_audit":audits,
            "zero_candidate_reason":None if plans else (
                "NO_FORWARD_NODE" if not indexed else
                "NO_ENERGY_FEASIBLE_CANDIDATE" if energy_allow is not None else
                "NO_LEGAL_NON_ENERGY_CANDIDATE")}


def build_forward_scene(source: Mapping[str, Any], requests: Iterable[ForwardRequest], seed: int, scenario_id: str) -> Dict[str, Any]:
    catalog = ForwardServiceCatalog(source)
    audits, plans, state_overrides = [], [], {}
    for request in requests:
        outcome = enumerate_request(source, catalog, request)
        audits.append(outcome)
        plans.extend(outcome["plans"])
        state_overrides[request.uav_id] = {"in_flight":request.in_flight, "state_source":"P3R_FORWARD_REQUEST_DECLARATION",
            "request_id": request.request_id, "request_reason": request.request_reason}
    network = copy.deepcopy(source)
    network["profile_type"] = "G25_P3R_FORWARD_ALL_REACHABLE_DEV"
    scene = build_scenario_bundle(network, scenario_id, "OPTIONS", seed, plans=plans)
    scene["meta"]["snapshot_id"] = scenario_id + ":SNAPSHOT:0"
    scene["traffic_profile"].update({"candidate_generation_version":GENERATOR_VERSION, "catalog_version":CATALOG_VERSION,
                                     "catalog_hash":catalog.catalog_hash, "seed":seed, "no_top_k":True})
    scene["ecja_forward_request_audit"] = [{k:v for k,v in item.items() if k != "plans"} for item in audits]
    scene["ecja_request_state_overrides"] = state_overrides
    scene["meta"]["scenario_hash"] = ""
    scene["meta"]["scenario_hash"] = canonical_hash(scene)
    return scene

