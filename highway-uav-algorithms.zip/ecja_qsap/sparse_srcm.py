"""Sparse, auditable ECJA adapter for the frozen SRCM semantics.

The frozen SRCM remains the reference implementation.  This module consumes
its canonical crossing visits, indexes role segments by crossing and half-open
time window, and emits exact SRCM event identities plus a compact, expandable
coverage certificate for the full CC/CF universe.
"""

from __future__ import annotations

import copy
import hashlib
import json
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Mapping, MutableMapping, Optional, Sequence, Tuple

from srcm.crossing_registry import build_crossing_registry
from srcm.models import COMPLETE_COVERAGE, RESOURCE_REGISTRY_VERSION, SRCM_VERSION
from srcm.snapshot import resolve_snapshot_context
from srcm.uses import compute_crossing_uses
from srcm.validation import validate_srcm_input
from .v3_qq import OVERLAP_BASIS, event_union_records, union_digest


ADAPTER_VERSION = "ECJA_SPARSE_SRCM_ADAPTER_V1"
PROOF_VERSION = "ECJA_HALF_OPEN_VISIT_ZERO_PROOF_V1"


def _hash(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _stable_id(prefix: str, *values: str) -> str:
    digest = hashlib.sha256("|".join(values).encode("utf-8")).hexdigest()[:24]
    return prefix + ":" + digest


def _use_id(snapshot_id: str, plan_id: str, crossing_id: str, index: int) -> str:
    digest = hashlib.sha256("|".join((snapshot_id, plan_id, crossing_id, str(index))).encode("utf-8")).hexdigest()[:20]
    return "use:" + digest


def _pair_type(first: Mapping[str, Any], second: Mapping[str, Any]) -> Optional[str]:
    if first["uav_id"] == second["uav_id"]:
        return None
    statuses = {first["plan_status"], second["plan_status"]}
    if statuses == {"CANDIDATE"}:
        return "CANDIDATE_CANDIDATE"
    if statuses == {"CANDIDATE", "FIXED"}:
        return "CANDIDATE_FIXED"
    return None


def _required_pairs(plans: Sequence[Mapping[str, Any]]) -> Tuple[Dict[str, str], Dict[str, Tuple[str, str]]]:
    sorted_plans = sorted(plans, key=lambda item: item["plan_id"])
    types: Dict[str, str] = {}
    ids: Dict[str, Tuple[str, str]] = {}
    for index, first in enumerate(sorted_plans):
        for second in sorted_plans[index + 1 :]:
            kind = _pair_type(first, second)
            if kind is None:
                continue
            key = first["plan_id"] + "|" + second["plan_id"]
            types[key] = kind
            ids[key] = (first["plan_id"], second["plan_id"])
    return types, ids


def _competition_type(role_a: str, role_b: str, source_a: str, source_b: str, resource_layer: str, layer_order: Mapping[str, int]) -> Optional[str]:
    vertical_roles = {"VERTICAL_USER", "SOURCE_ENTRY"}
    if role_a in vertical_roles and role_b in vertical_roles:
        return "VV"
    if role_a == "VERTICAL_USER" and role_b == "MAINLINE_USER" and layer_order.get(source_a, -1) > layer_order.get(resource_layer, -1):
        return "VH"
    if role_b == "VERTICAL_USER" and role_a == "MAINLINE_USER" and layer_order.get(source_b, -1) > layer_order.get(resource_layer, -1):
        return "VH"
    return None


@dataclass
class SparseSrcmCache:
    """Versioned visit cache; immutable visit geometry is rematerialized per snapshot."""

    entries: MutableMapping[str, List[Dict[str, Any]]] = field(default_factory=dict)
    adapter_version: str = ADAPTER_VERSION

    def context_key(self, context_base_sha256: str, plan: Mapping[str, Any]) -> str:
        return _hash({"context_base_sha256": context_base_sha256, "plan": plan})


def _materialize_cached_uses(cached: Sequence[Mapping[str, Any]], scene: Mapping[str, Any], snapshot: Mapping[str, Any]) -> List[Dict[str, Any]]:
    result = copy.deepcopy(list(cached))
    for use in result:
        use["snapshot_id"] = snapshot["snapshot_id"]
        use["scenario_hash"] = scene["meta"].get("scenario_hash")
        use["use_id"] = _use_id(snapshot["snapshot_id"], use["plan_id"], use["crossing_id"], int(use["interval_index"]))
    return result


def _compute_uses(scene: Mapping[str, Any], snapshot: Mapping[str, Any], cache: SparseSrcmCache) -> Tuple[Dict[str, List[Dict[str, Any]]], Dict[str, int]]:
    uses_by_plan: Dict[str, List[Dict[str, Any]]] = {}
    hits = misses = 0
    resources = [
        {"crossing_id": item["crossing_id"], "geometry_hash": item.get("geometry_hash"), "geometry": item.get("geometry")}
        for item in build_crossing_registry(scene)
    ]
    context_base_sha256 = _hash(
        {
            "adapter_version": cache.adapter_version,
            "snapshot_id": snapshot["snapshot_id"],
            "scenario_hash": scene["meta"].get("scenario_hash"),
            "resources": resources,
            "t0_s": snapshot["t0_s"],
            "horizon_end_s": snapshot["horizon_end_s"],
            "guard_s": scene.get("time_profile", {}).get("optional_guard_s", 0.0),
        }
    )
    for plan in scene["plans"]:
        key = cache.context_key(context_base_sha256, plan)
        if key in cache.entries:
            hits += 1
            # The cache key binds snapshot id/hash, horizon, guard, resources and
            # the complete plan.  Exact-key hits are immutable and can therefore
            # be reused without copying or rewriting snapshot-scoped identities.
            uses = cache.entries[key]
        else:
            misses += 1
            uses = compute_crossing_uses(plan, scene, dict(snapshot))
            cache.entries[key] = uses
        uses_by_plan[plan["plan_id"]] = uses
    return uses_by_plan, {"hits": hits, "misses": misses, "entry_count": len(cache.entries)}


def _coalesce_same_use_atoms(atoms: Sequence[Mapping[str, Any]], tolerance: float) -> List[Dict[str, Any]]:
    """Merge adjacent same-role pieces of one physical resource use.

    Motion/path materialization may split one crossing visit at a geometric or
    phase boundary.  Those pieces retain the same ``use_id`` and can be
    contiguous in time.  They are one physical occupancy interval, so SRCM
    must not count them as two competition events.  Different uses, roles, or
    separated intervals remain distinct.
    """
    groups: Dict[Tuple[str, str, str, str], List[Dict[str, Any]]] = {}
    for atom in atoms:
        key = (
            str(atom["plan_id"]),
            str(atom["uav_id"]),
            str(atom["use_id"]),
            str(atom["role"]),
        )
        groups.setdefault(key, []).append(dict(atom))
    result: List[Dict[str, Any]] = []
    for pieces in groups.values():
        pieces.sort(key=lambda item: (float(item["enter_s"]), float(item["exit_s"])))
        current = pieces[0]
        for piece in pieces[1:]:
            if float(piece["enter_s"]) <= float(current["exit_s"]) + tolerance:
                current["exit_s"] = max(float(current["exit_s"]), float(piece["exit_s"]))
            else:
                result.append(current)
                current = piece
        result.append(current)
    return result


def _pair_digest(pair_keys: Iterable[str]) -> str:
    digest = hashlib.sha256()
    for key in sorted(pair_keys):
        digest.update(key.encode("utf-8"))
        digest.update(b"\n")
    return digest.hexdigest()


def evaluate_sparse_srcm(
    scene: Mapping[str, Any],
    snapshot: Optional[Mapping[str, Any]] = None,
    cache: Optional[SparseSrcmCache] = None,
) -> Dict[str, Any]:
    total_started = time.perf_counter()
    validation = validate_srcm_input(scene)
    if validation["status"] != "VALID":
        raise ValueError("INVALID_SRCM_INPUT: " + ",".join(sorted(item["code"] for item in validation["errors"])))
    effective_snapshot = resolve_snapshot_context(scene, snapshot)
    cache = cache or SparseSrcmCache()
    resources = build_crossing_registry(scene)
    resource_by_id = {item["crossing_id"]: item for item in resources}
    geometry_hash = _hash([(item["crossing_id"], item.get("geometry_hash"), item["geometry"]) for item in resources])
    layer_order = {item["layer_id"]: int(item["layer_order"]) for item in scene["layers"]}
    plan_by_id = {item["plan_id"]: item for item in scene["plans"]}
    pair_types, pair_ids = _required_pairs(scene["plans"])
    guard = float(scene.get("time_profile", {}).get("optional_guard_s", 0.0) or 0.0)
    tolerance = float(scene.get("time_profile", {}).get("numeric_tolerance_s", 1e-9))

    visit_started = time.perf_counter()
    uses_by_plan, cache_metrics = _compute_uses(scene, effective_snapshot, cache)
    visit_elapsed = time.perf_counter() - visit_started
    all_uses = sorted((item for values in uses_by_plan.values() for item in values), key=lambda item: item["use_id"])

    index_started = time.perf_counter()
    atoms_by_crossing: Dict[str, List[Dict[str, Any]]] = {}
    for uses in uses_by_plan.values():
        for use in uses:
            plan = plan_by_id[use["plan_id"]]
            for segment in use["role_segments"]:
                atoms_by_crossing.setdefault(use["crossing_id"], []).append(
                    {
                        "plan_id": use["plan_id"],
                        "uav_id": use["uav_id"],
                        "source_layer_id": plan.get("source_layer_id"),
                        "use_id": use["use_id"],
                        "role": segment["role"],
                        "enter_s": float(segment["enter_s"]),
                        "exit_s": float(segment["exit_s"]),
                    }
                )
    for crossing_id, atoms in atoms_by_crossing.items():
        atoms_by_crossing[crossing_id] = _coalesce_same_use_atoms(atoms, tolerance)
    index_elapsed = time.perf_counter() - index_started

    compare_started = time.perf_counter()
    event_by_key: Dict[Tuple[Any, ...], Dict[str, Any]] = {}
    for crossing_id, atoms in atoms_by_crossing.items():
        atoms.sort(key=lambda item: (item["enter_s"] - guard, item["exit_s"] + guard, item["plan_id"], item["role"]))
        active: List[Dict[str, Any]] = []
        resource = resource_by_id[crossing_id]
        for atom in atoms:
            lower = atom["enter_s"] - guard
            active = [other for other in active if other["exit_s"] + guard - lower > tolerance]
            for other in active:
                if atom["plan_id"] == other["plan_id"]:
                    continue
                first_id, second_id = sorted((atom["plan_id"], other["plan_id"]))
                pair_key = first_id + "|" + second_id
                if pair_key not in pair_types:
                    continue
                role_first, role_second = (atom, other) if atom["plan_id"] == first_id else (other, atom)
                kind = _competition_type(
                    role_first["role"], role_second["role"], role_first["source_layer_id"], role_second["source_layer_id"], resource["layer_id"], layer_order
                )
                if kind is None:
                    continue
                nominal_start = max(role_first["enter_s"], role_second["enter_s"])
                nominal_end = min(role_first["exit_s"], role_second["exit_s"])
                nominal = max(0.0, nominal_end - nominal_start)
                guarded_start = max(role_first["enter_s"] - guard, role_second["enter_s"] - guard)
                guarded_end = min(role_first["exit_s"] + guard, role_second["exit_s"] + guard)
                guarded = max(0.0, guarded_end - guarded_start)
                if nominal <= tolerance and guarded <= tolerance:
                    continue
                overlap_class = "NOMINAL_COMPETITION" if nominal > tolerance else "GUARD_ONLY_COMPETITION"
                overlap_start = nominal_start if nominal > tolerance else guarded_start
                overlap_end = nominal_end if nominal > tolerance else guarded_end
                event_key = (
                    effective_snapshot["snapshot_id"], pair_key, crossing_id, kind,
                    round(overlap_start, 12), round(overlap_end, 12), overlap_class,
                )
                if event_key in event_by_key:
                    continue
                plan_a, plan_b = plan_by_id[first_id], plan_by_id[second_id]
                event_by_key[event_key] = {
                    "event_id": _stable_id("event", *map(str, event_key)),
                    "snapshot_id": effective_snapshot["snapshot_id"],
                    "scenario_hash": scene["meta"].get("scenario_hash"),
                    "resource_registry_version": RESOURCE_REGISTRY_VERSION,
                    "plan_a_id": first_id,
                    "plan_b_id": second_id,
                    "uav_a_id": plan_a["uav_id"],
                    "uav_b_id": plan_b["uav_id"],
                    "crossing_id": crossing_id,
                    "competition_type": kind,
                    "role_a": role_first["role"],
                    "role_b": role_second["role"],
                    "overlap_start_s": overlap_start,
                    "overlap_end_s": overlap_end,
                    "guarded_overlap_start_s": guarded_start,
                    "guarded_overlap_end_s": guarded_end,
                    "nominal_overlap_s": nominal,
                    "guarded_overlap_s": guarded,
                    "overlap_class": overlap_class,
                    "use_a_id": role_first["use_id"],
                    "use_b_id": role_second["use_id"],
                    "coverage_status": "KNOWN",
                }
            active.append(atom)
    events = sorted(event_by_key.values(), key=lambda item: item["event_id"])
    v3_union_aggregates = event_union_records(events)
    event_pairs = {item["plan_a_id"] + "|" + item["plan_b_id"] for item in events}
    def coverage_complete(plan: Mapping[str, Any]) -> bool:
        status = plan.get("trajectory_coverage_status")
        return status in COMPLETE_COVERAGE or status == "ROUTE_ONLY_NO_MOTION_AUTHORITY"

    unknown_pairs = {
        key for key, (left, right) in pair_ids.items()
        if not coverage_complete(plan_by_id[left])
        or not coverage_complete(plan_by_id[right])
    }
    known_event_pairs = event_pairs - unknown_pairs
    zero_pairs = set(pair_types) - known_event_pairs - unknown_pairs
    compare_elapsed = time.perf_counter() - compare_started
    certified = len(pair_types) - len(unknown_pairs)
    cc_required = sum(value == "CANDIDATE_CANDIDATE" for value in pair_types.values())
    cf_required = sum(value == "CANDIDATE_FIXED" for value in pair_types.values())
    cc_unknown = sum(pair_types[key] == "CANDIDATE_CANDIDATE" for key in unknown_pairs)
    cf_unknown = sum(pair_types[key] == "CANDIDATE_FIXED" for key in unknown_pairs)
    pair_universe = {
        "plans": [
            {"plan_id": item["plan_id"], "uav_id": item["uav_id"], "plan_status": item["plan_status"]}
            for item in sorted(scene["plans"], key=lambda value: value["plan_id"])
        ],
        "pair_rule": "different UAV; CANDIDATE-CANDIDATE or CANDIDATE-FIXED only",
    }
    return {
        "adapter_version": ADAPTER_VERSION,
        "srcm_version": SRCM_VERSION,
        "snapshot_id": effective_snapshot["snapshot_id"],
        "scenario_hash": scene["meta"].get("scenario_hash"),
        "resource_registry_version": RESOURCE_REGISTRY_VERSION,
        "geometry_hash": geometry_hash,
        "resources": resources,
        "uses": all_uses,
        "events": events,
        # V3 audit view; ``events`` remains the untouched canonical SRCM
        # record and is still the source for coverage certificates.
        "v3_union_aggregates": list(v3_union_aggregates),
        "v3_union_aggregation_hash": union_digest(v3_union_aggregates),
        "v3_union_aggregation_basis": OVERLAP_BASIS,
        "pair_universe": pair_universe,
        "coverage_ledger": {
            "required_pairs": len(pair_types),
            "cc_required": cc_required,
            "cf_required": cf_required,
            "event_pair_keys": sorted(known_event_pairs),
            "event_pairs": len(known_event_pairs),
            "diagnostic_event_pairs_with_unknown_coverage": len(event_pairs & unknown_pairs),
            "proven_zero_pairs": len(zero_pairs),
            "unknown_pair_keys": sorted(unknown_pairs),
            "unknown_pairs": len(unknown_pairs),
            "cc_coverage_rate": (cc_required - cc_unknown) / cc_required if cc_required else 1.0,
            "cf_coverage_rate": (cf_required - cf_unknown) / cf_required if cf_required else 1.0,
            "coverage_rate": certified / len(pair_types) if pair_types else 1.0,
            "partition_count_check": len(known_event_pairs) + len(zero_pairs) + len(unknown_pairs) == len(pair_types),
        },
        "zero_interaction_certificate": {
            "proof_version": PROOF_VERSION,
            "proof_rule": "NO_COMPATIBLE_ROLE_SEGMENT_OVERLAP_ON_SHARED_CROSSING_HALF_OPEN_WINDOW",
            "snapshot_id": effective_snapshot["snapshot_id"],
            "snapshot_hash": scene["meta"].get("scenario_hash"),
            "srcm_version": SRCM_VERSION,
            "geometry_hash": geometry_hash,
            "time_semantics": "HALF_OPEN_WITH_FROZEN_GUARD_AND_ROLE_RULES",
            "pair_count": len(zero_pairs),
            "pair_set_sha256": _pair_digest(zero_pairs),
            "expansion": "rebuild pair universe from pair_universe, then subtract event_pair_keys and unknown_pair_keys",
            "visit_ids_sha256": _hash(sorted(item["use_id"] for item in all_uses)),
        },
        "cache_metrics": cache_metrics,
        "timing": {
            "visit_adaptation_s": visit_elapsed,
            "sparse_index_s": index_elapsed,
            "overlap_and_certificate_s": compare_elapsed,
            "total_s": time.perf_counter() - total_started,
        },
    }


def expand_pair_statuses(result: Mapping[str, Any]) -> Dict[str, str]:
    plans = result["pair_universe"]["plans"]
    pair_types, _ = _required_pairs(plans)
    event_pairs = set(result["coverage_ledger"]["event_pair_keys"])
    unknown_pairs = set(result["coverage_ledger"]["unknown_pair_keys"])
    statuses = {}
    for key in pair_types:
        if key in unknown_pairs:
            statuses[key] = "UNKNOWN"
        elif key in event_pairs:
            statuses[key] = "EVALUATED_WITH_EVENTS"
        else:
            statuses[key] = "PROVEN_NO_POSSIBLE_INTERACTION"
    if _pair_digest(key for key, value in statuses.items() if value == "PROVEN_NO_POSSIBLE_INTERACTION") != result["zero_interaction_certificate"]["pair_set_sha256"]:
        raise ValueError("ZERO_CERTIFICATE_DIGEST_MISMATCH")
    return statuses


def aggregate_competition_coefficients(
    events: Sequence[Mapping[str, Any]],
    theta: Optional[Mapping[str, float]] = None,
    t_ref_s: float = 1.0,
    duration_field: str = "nominal_overlap_s",
) -> Dict[str, float]:
    if t_ref_s <= 0:
        raise ValueError("INVALID_T_REF")
    theta = dict(theta or {"VV": 1.0, "VH": 1.0})
    coefficients: Dict[str, float] = {}
    seen = set()
    for event in events:
        if event["event_id"] in seen:
            raise ValueError("DUPLICATE_EVENT_ID")
        seen.add(event["event_id"])
        key = event["plan_a_id"] + "|" + event["plan_b_id"]
        coefficients[key] = coefficients.get(key, 0.0) + theta[event["competition_type"]] * float(event[duration_field]) / t_ref_s
    return coefficients


def compare_sparse_to_reference(reference: Mapping[str, Any], sparse: Mapping[str, Any]) -> Dict[str, Any]:
    reference_events = {item["event_id"]: item for item in reference["events"]}
    sparse_events = {item["event_id"]: item for item in sparse["events"]}
    reference_status = {}
    for item in reference["pair_evaluations"]:
        if item["evaluation_status"] == "UNKNOWN":
            reference_status[item["pair_key"]] = "UNKNOWN"
        elif item["event_ids"]:
            reference_status[item["pair_key"]] = "EVALUATED_WITH_EVENTS"
        else:
            reference_status[item["pair_key"]] = "PROVEN_NO_POSSIBLE_INTERACTION"
    sparse_status = expand_pair_statuses(sparse)
    event_identity_equal = set(reference_events) == set(sparse_events)
    event_payload_equal = reference_events == sparse_events
    pair_coverage_equal = reference_status == sparse_status
    reference_q = aggregate_competition_coefficients(reference["events"])
    sparse_q = aggregate_competition_coefficients(sparse["events"])
    q_equal = reference_q == sparse_q
    use_payload_equal = {item["use_id"]: item for item in reference["uses"]} == {item["use_id"]: item for item in sparse["uses"]}
    return {
        "event_identity_equal": event_identity_equal,
        "event_payload_equal": event_payload_equal,
        "pair_coverage_equal": pair_coverage_equal,
        "qsap_coefficient_equal": q_equal,
        "use_payload_equal": use_payload_equal,
        "reference_event_count": len(reference_events),
        "sparse_event_count": len(sparse_events),
        "reference_pair_count": len(reference_status),
        "sparse_pair_count": len(sparse_status),
        "all_equal": event_identity_equal and event_payload_equal and pair_coverage_equal and q_equal and use_payload_equal,
    }
