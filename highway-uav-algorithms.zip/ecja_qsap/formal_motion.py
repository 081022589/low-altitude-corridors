"""Formal three-phase motion prediction for ECJA candidates.

The G-to-J segment is generated from the entrance speed inside registered
free space. The published clock is an observation target, not a motion input.
"""

from __future__ import annotations

import math
from typing import Any, Mapping, Sequence

from configs.mission_config import DEFAULT_UAV_TYPE_SPECS
from g25_param_env.extractor import cumulative_lengths, interpolate_station, project_station_xy
from .zhou_transfer import generate_transfer


FORMAL_MOTION_MODEL = "FORMAL_THREE_PHASE_ZHOU_PATH_TIME_V2"
TYPE_BY_LAYER = {"L1": "inspection_uav", "L2": "cargo_small", "L3": "medical_fast"}


def predicted_g_speed(access: Mapping[str, Any], vehicle_type: str, observed_speed_mps: float) -> float:
    """Conservative speed target from available horizontal turn distance."""
    g, j = access["zhou_g_xyz"], access["zhou_j_xyz"]
    horizontal = math.dist(g[:2], j[:2])
    acceleration = float(DEFAULT_UAV_TYPE_SPECS[vehicle_type]["max_horizontal_acceleration_mps2"])
    return max(0.1, min(float(observed_speed_mps), 0.55*math.sqrt(2.*acceleration*horizontal)))


def _smoothstep(value: float) -> float:
    return 10.0 * value**3 - 15.0 * value**4 + 6.0 * value**5


def _integral_smoothstep(value: float) -> float:
    return 2.5 * value**4 - 3.0 * value**5 + value**6


def _stations(points: Sequence[Sequence[float]]) -> list[float]:
    result = [0.0]
    for first, second in zip(points, points[1:]):
        result.append(result[-1] + math.dist(first, second))
    return result


def _path_between(polyline: Sequence[Sequence[float]], start: float, end: float) -> list[list[float]]:
    cumulative = cumulative_lengths(polyline)
    start_point, start_index, _ = interpolate_station(polyline, start)
    end_point, end_index, _ = interpolate_station(polyline, end)
    points = [list(map(float, start_point))]
    for index in range(start_index + 1, end_index + 1):
        if cumulative[index] < end - 1e-9:
            points.append(list(map(float, polyline[index])))
    if math.dist(points[-1], end_point) > 1e-9:
        points.append(list(map(float, end_point)))
    return points


def _approach_time_table(distance_m: float, speed_mps: float, gate_speed_mps: float, acceleration_mps2: float, *, allow_stop_start: bool = False) -> tuple[list[float], list[float]]:
    if allow_stop_start and 0 <= speed_mps < gate_speed_mps:
        # Restart first, then cruise at gate speed. Never substitute cruise
        # speed for the actual stopped initial state (nor divide by zero).
        duration = 1.875*(gate_speed_mps-speed_mps)/acceleration_mps2
        length = .5*(speed_mps+gate_speed_mps)*duration
        if distance_m < length-1e-7:
            raise ValueError("FORMAL_APPROACH_DISTANCE_INSUFFICIENT")
        stations, times = [0.], [0.]
        for index in range(1,101):
            ratio = index/100.
            stations.append(speed_mps*duration*ratio+(gate_speed_mps-speed_mps)*duration*_integral_smoothstep(ratio))
            times.append(duration*ratio)
        if distance_m > length+1e-9:
            stations.append(distance_m)
            times.append(duration+(distance_m-length)/gate_speed_mps)
        return stations,times
    if min(distance_m, speed_mps, gate_speed_mps, acceleration_mps2) <= 0.0:
        raise ValueError("INVALID_FORMAL_APPROACH_STATE")
    delta = speed_mps - gate_speed_mps
    if abs(delta) <= 1e-12:
        return [0.0, distance_m], [0.0, distance_m / speed_mps]
    transition_s = 1.875 * abs(delta) / acceleration_mps2
    transition_m = 0.5 * (speed_mps + gate_speed_mps) * transition_s
    leading_m = distance_m - transition_m
    if leading_m < -1e-7:
        raise ValueError("FORMAL_APPROACH_DISTANCE_INSUFFICIENT")
    leading_m = max(0.0, leading_m)
    leading_s = leading_m / speed_mps
    stations = [0.0]
    elapsed = [0.0]
    if leading_m > 1e-9:
        stations.append(leading_m)
        elapsed.append(leading_s)
    for index in range(1, 101):
        ratio = index / 100.0
        local_t = ratio * transition_s
        local_d = speed_mps * local_t - delta * transition_s * _integral_smoothstep(ratio)
        station = leading_m + local_d
        if station > stations[-1] + 1e-10:
            stations.append(station)
            elapsed.append(leading_s + local_t)
    stations[-1] = distance_m
    return stations, elapsed


def _transfer_curve(access: Mapping[str, Any], vehicle_type: str, entry_speed_mps: float) -> tuple[list[list[float]], list[float], list[float]]:
    spec = DEFAULT_UAV_TYPE_SPECS[vehicle_type]
    result = generate_transfer(
        access, entry_speed_mps=entry_speed_mps,
        max_speed_mps=float(spec["max_speed"]),
        max_acceleration_mps2=float(spec["max_horizontal_acceleration_mps2"]),
        max_descent_speed_mps=float(spec["max_descent_speed"]),
        max_vertical_acceleration_mps2=float(spec["max_vertical_acceleration_mps2"]),
    )
    return result["path_xyz"], result["arc_stations_m"], result["elapsed_s"]


def formal_transfer_entry_station(line: Mapping[str, Any], access: Mapping[str, Any]) -> float:
    """Keep the separately registered G position on the directed mainline."""
    station, error, _, _ = project_station_xy(line["polyline_3d"], access["zhou_g_xyz"][:2])
    if error > 1e-4:
        raise ValueError("FORMAL_TRANSFER_ENTRY_NOT_ON_MAINLINE")
    if abs(station-float(access["g_station_m"])) > 1e-4:
        raise ValueError("FORMAL_TRANSFER_ENTRY_STATION_MISMATCH")
    return float(station)


def build_registered_descent_template(access: Mapping[str, Any], vehicle_type: str, *,
                                       reference_time_s: float, entry_speed_mps: float) -> dict[str, Any]:
    """Predicted G-to-J/vertical path-time data, with no approach model.

    The anchor is an arbitrary resource-geometry reference, not an arrival
    prediction or a published G time. Geometry and transfer-speed tables are
    the exact templates also consumed by ECJA's three-phase candidate builder.
    """
    path,arc,times=_transfer_curve(access,vehicle_type,entry_speed_mps)
    joint=path[-1]
    end=[joint[0],joint[1],float(access['shaft_scope_end_z_m'])]
    duration=math.dist(joint,end)/3.0
    return {
        'motion_prediction':{
            'model_version':'SRCM_PATH_TIME_V1','anchor_time_s':float(reference_time_s),
            'current_state':{'position_xyz':path[0],'speed_mps':entry_speed_mps},
            'phases':[
                {'phase_id':'ZHOU_TRANSFER','phase_type':'SOURCE_EXIT',
                 'path_xyz':path,'start_offset_s':0.,
                 'timing':{'model':'ARC_TIME_TABLE','arc_stations_m':arc,'elapsed_s':times}},
                {'phase_id':'VERTICAL_DESCENT_3MPS','phase_type':'V_DESCENT',
                 'path_xyz':[joint,end],'start_offset_s':times[-1],
                 'timing':{'model':'CONSTANT_SPEED','speed_mps':3.0}},
            ]},
        'activity_end_s':float(reference_time_s)+times[-1]+duration,
        'g_to_j_s':times[-1],
    }


def build_formal_motion_prediction(
    line: Mapping[str, Any], request: Any, access: Mapping[str, Any], *,
    allow_bounded_approach: bool = False,
) -> dict[str, Any]:
    """Build a path-time prediction and deadline metadata for one candidate."""

    vehicle_type = TYPE_BY_LAYER[str(request.source_layer_id)]
    gate_speed = predicted_g_speed(access, vehicle_type, float(request.speed_mps))
    transfer_path, transfer_arc, transfer_times = _transfer_curve(access, vehicle_type, gate_speed)
    transfer_entry = transfer_path[0]
    entry_station, entry_error, _, _ = project_station_xy(line["polyline_3d"], transfer_entry[:2])
    if entry_error > 1e-4:
        raise ValueError("FORMAL_TRANSFER_ENTRY_NOT_ON_MAINLINE")
    if request.current_directed_station_m + 1e-6 >= entry_station:
        raise ValueError("MISSED_SWITCH_BOUNDARY")
    approach_path = _path_between(line["polyline_3d"], request.current_directed_station_m, entry_station)
    approach_distance = _stations(approach_path)[-1]
    spec = DEFAULT_UAV_TYPE_SPECS[vehicle_type]
    speed=float(request.speed_mps)
    acceleration=float(spec["max_horizontal_acceleration_mps2"])
    approach_kind="SMOOTH_CANDIDATE"
    try:
        approach_arc, approach_times = _approach_time_table(
            approach_distance, speed, gate_speed, acceleration,
            allow_stop_start=bool(getattr(request,"allow_stop_start",False)),
        )
    except ValueError as error:
        if not allow_bounded_approach or str(error)!="FORMAL_APPROACH_DISTANCE_INSUFFICIENT":
            raise
        # A different candidate in the executor's piecewise constant bounded
        # acceleration set. Failure of either construction is not a joint
        # infeasibility proof. Keep the existing SRCM arc/time projection.
        duration=abs(speed-gate_speed)/acceleration
        length=.5*(speed+gate_speed)*duration
        if approach_distance < length-1e-7:
            raise ValueError("BOUNDED_APPROACH_CANDIDATE_NOT_CONSTRUCTED") from error
        sign=1. if gate_speed>speed else -1.
        leading=max(0.,approach_distance-length) if speed>=gate_speed else 0.
        leading_time=leading/speed if leading else 0.
        approach_arc,approach_times=[0.],[0.]
        if leading:
            approach_arc.append(leading); approach_times.append(leading_time)
        for index in range(1,101):
            t=duration*index/100.
            approach_arc.append(leading+speed*t+.5*sign*acceleration*t*t)
            approach_times.append(leading_time+t)
        if speed<gate_speed and approach_distance>length+1e-9:
            approach_arc.append(approach_distance)
            approach_times.append(duration+(approach_distance-length)/gate_speed)
        approach_arc[-1]=approach_distance
        approach_kind="BOUNDED_ACCELERATION_CANDIDATE"
    transfer_start_offset = approach_times[-1]
    vertical_start_offset = transfer_start_offset + transfer_times[-1]
    joint = transfer_path[-1]
    vertical_end = [joint[0], joint[1], float(access["shaft_scope_end_z_m"])]
    vertical_duration = math.dist(joint, vertical_end) / 3.0
    end_time = float(request.snapshot_time_s) + vertical_start_offset + vertical_duration
    return {
        "motion_prediction": {
            "model_version": "SRCM_PATH_TIME_V1",
            "anchor_time_s": float(request.snapshot_time_s),
            "current_state": {
                "position_xyz": approach_path[0],
                "speed_mps": float(request.speed_mps),
            },
            "phases": [
                {
                    "phase_id": "APPROACH",
                    "phase_type": "H_CRUISE",
                    "path_xyz": approach_path,
                    "timing": {
                        "model": "ARC_TIME_TABLE",
                        "arc_stations_m": approach_arc,
                        "elapsed_s": approach_times,
                    },
                },
                {
                    "phase_id": "ZHOU_TRANSFER",
                    "phase_type": "SOURCE_EXIT",
                    "path_xyz": transfer_path,
                    "start_offset_s": transfer_start_offset,
                    "timing": {
                        "model": "ARC_TIME_TABLE",
                        "arc_stations_m": transfer_arc,
                        "elapsed_s": transfer_times,
                    },
                },
                {
                    "phase_id": "VERTICAL_DESCENT_3MPS",
                    "phase_type": "V_DESCENT",
                    "path_xyz": [joint, vertical_end],
                    "start_offset_s": vertical_start_offset,
                    "timing": {"model": "CONSTANT_SPEED", "speed_mps": 3.0},
                },
            ],
        },
        "activity_end_s": end_time,
        "transfer_entry_station_m": float(entry_station),
        "transfer_entry_time_s": float(request.snapshot_time_s) + transfer_start_offset,
        "vertical_entry_time_s": float(request.snapshot_time_s) + vertical_start_offset,
        "motion_parameter_provenance": "ZHOU_2019_LOCAL_BSPLINE_TIME_ADJUSTMENT_V1",
        "vehicle_type": vehicle_type,
        "approach_prediction_kind": approach_kind,
    }
