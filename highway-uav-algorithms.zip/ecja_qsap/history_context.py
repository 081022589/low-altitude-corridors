"""History-aware ECJA input context and immutable commitment handling.

This module belongs to the ECJA algorithm boundary.  It reads the complete
runtime traffic snapshot supplied by the integration layer, partitions every
UAV into current requests, fixed historical/background plans, or excluded
states, and preserves unfinished passage commitments when building the next
ECJA scene.

It does not own the traffic store, motion integration, or C-MLPM scheduler.
Those components provide the state and consume ECJA's assignment result.
"""

from __future__ import annotations

import copy
import math
from typing import Any, Mapping

from configs.mission_config import DEFAULT_UAV_TYPE_SPECS
from ecja_qsap.p3r_forward import _path_between
from srcm.plan_motion import is_formally_frozen_v_plan, refresh_motion_prediction


OUTSIDE_ECJA_STATE_NAMES = frozenset({
    "NOT_YET_REQUESTED",
    "COMPLETED",
    "EXITED",
    "HORIZON_CENSORED",
})

# Post-service states are owned by the re-entry runtime, not by ECJA's
# committed-assignment domain.  Only an aircraft with an executable certified
# re-entry profile contributes an independent fixed background trajectory.
REENTRY_STATE_NAMES = frozenset({
    "SERVICING",
    "REENTRY_HOLD",
    "REENTRY_CLIMB",
    "REENTRY_LAND_TO_GROUND",
    "REENTRY_ASCENT_TO_50M",
    "REENTRY_STAGING_HOLD",
    "REENTRY_FINAL_APPROACH",
    "REENTRY_LOCAL_BRAKING",
    "REENTRY_LOCAL_HOLD",
})
REENTRY_FIXED_BACKGROUND_STATE_NAMES = frozenset({
    "REENTRY_CLIMB",
    "REENTRY_FINAL_APPROACH",
})

# Historical DISTANCE requests remain supported.  ENERGY_INSUFFICIENT is only
# valid for the versioned energy-trigger trace/runtime seam.
SUPPORTED_REQUEST_REASONS = frozenset({"DISTANCE", "ENERGY_INSUFFICIENT"})

_PASSAGE_COMMITMENT_KEYS = (
    "released_h_speed_controls",
    "motion_control_owner",
    "safety_following_hold",
    "thin_follow_hold",
    "thin_follow_braking",
    "thin_follow_speed_mps",
    "thin_follow_restart_ready",
    "passage_arrangement",
    "uav_control_feedback",
    "local_trajectory_reference",
    "local_trajectory_id",
    "local_certification_id",
    "runtime_reference_status",
    "timed_resource_targets",
    "speed_control_token",
    "motion_observed_events",
    "motion_vh_separation",
    "motion_certification",
    "mainline_target_speed_mps",
    "mainline_control_resource_id",
)
_PROMISE_KEYS = ("timed_resource_targets",)


def request_allows_stop_start(plan: Mapping[str, Any]) -> bool:
    """Read aircraft motion capability, never scheduler pending/managed labels.

    The current local execution model supports bounded braking and restart
    before any C-MLPM attempt. Its version is a declared motion contract; an
    earlier waiting decision or an already-materialized intent is unnecessary.
    """
    return bool(
        plan.get("motion_control_owner") == "MEASURED_KINEMATIC_EXECUTOR_V1"
        or plan.get("safety_following_hold")
        or plan.get("execution_mode") == "CMLPM_RETRY_HOLD"
        or plan.get("thin_follow_hold")
        or isinstance(plan.get("pending_hold"), Mapping)
        and plan["pending_hold"].get("stop_station_m") is not None
    )


def _state_name(state: Any) -> str:
    value = getattr(state, "state", state)
    return str(getattr(value, "value", value))


def _line(source: Mapping[str, Any], state: Any) -> Mapping[str, Any]:
    try:
        return next(
            item
            for item in source["mainlines"]
            if item["direction_id"] == state.direction
            and item["layer_id"] == state.layer
        )
    except StopIteration as error:
        raise ValueError(f"STATE_MAINLINE_NOT_REGISTERED:{state.uav_id}") from error


def build_mainline_fixed_plan(
    source: Mapping[str, Any], state: Any, now_s: float
) -> dict[str, Any] | None:
    """Build a fixed H/background plan from the observed runtime state."""

    line = _line(source, state)
    points = line["polyline_3d"]
    total = sum(math.dist(first, second) for first, second in zip(points, points[1:]))
    station = min(max(0.0, float(state.s_m)), total)
    if station >= total - 1e-6:
        return None
    path = _path_between(points, station, total)
    distance = sum(math.dist(first, second) for first, second in zip(path, path[1:]))
    timing: dict[str, Any] = {"model": "CONSTANT_SPEED", "speed_mps": float(state.speed_mps)}
    current_plan = state.current_motion_plan
    if request_allows_stop_start(current_plan):
        # A restart forecast keeps the observed zero/low speed at its origin.
        # This is SRCM input, not permission to replace an existing command.
        spec = DEFAULT_UAV_TYPE_SPECS[state.vehicle_type]
        acceleration = float(spec["max_horizontal_acceleration_mps2"])
        nominal = float(state.nominal_speed_mps or state.speed_mps)
        if nominal <= 0 or state.speed_mps < 0 or state.speed_mps > nominal + 1e-8:
            raise ValueError(f"INVALID_MAINLINE_RESTART_STATE:{state.uav_id}")
        ramp_distance = (nominal**2 - state.speed_mps**2) / (2.0 * acceleration)
        ramp = min(distance, ramp_distance)
        ramp_time = (
            (state.speed_mps**2 + 2.0 * acceleration * ramp) ** 0.5
            - state.speed_mps
        ) / acceleration
        stations, times = [0.0], [0.0]
        if ramp > 1e-9:
            for index in range(1, 101):
                elapsed = ramp_time * index / 100.0
                stations.append(
                    state.speed_mps * elapsed + 0.5 * acceleration * elapsed**2
                )
                times.append(elapsed)
        if distance > ramp + 1e-9:
            stations.append(distance)
            times.append(ramp_time + (distance - ramp) / nominal)
        timing = {"model": "ARC_TIME_TABLE", "arc_stations_m": stations, "elapsed_s": times}
        end_s = now_s + times[-1]
    else:
        if state.speed_mps <= 0:
            raise ValueError(f"UNAUTHORIZED_MAINLINE_ZERO_SPEED:{state.uav_id}")
        end_s = float(now_s) + distance / float(state.speed_mps)
    return {
        "uav_id": state.uav_id,
        "plan_id": f"{state.uav_id}:RUNTIME:H:{state.event_version}",
        "plan_status": "FIXED",
        "mode": "AUTHORITATIVE_MAINLINE_BACKGROUND",
        "source_mainline_id": line["mainline_id"],
        "source_layer_id": state.layer,
        "source_direction_id": state.direction,
        "service_node_id": state.assigned_node,
        "option_group_id": f"{state.uav_id}:RUNTIME_BACKGROUND",
        "is_current_assignment": False,
        "committed": state.commit_status != "UNCOMMITTED",
        "activity_start_s": float(now_s),
        "activity_end_s": end_s,
        "termination_reason": "MAINLINE_REGISTERED_END",
        "trajectory_coverage_status": "COMPLETE_TO_ENGINEERING_BOUNDARY",
        "coverage_window": [float(now_s), end_s],
        "route_id": f"runtime:{line['mainline_id']}",
        "motion_parameter_provenance": "AUTHORITATIVE_RUNTIME_STATE_V1",
        "motion_prediction": {
            "model_version": "SRCM_PATH_TIME_V1",
            "anchor_time_s": float(now_s),
            "current_state": {
                "position_xyz": path[0],
                "speed_mps": float(state.speed_mps),
            },
            "phases": [{
                "phase_id": f"{state.uav_id}:RUNTIME:H",
                "phase_type": "H_CRUISE",
                "path_xyz": path,
                "timing": timing,
            }],
        },
    }


def overlay_runtime_resource_state(
    plan: dict[str, Any], state: Any
) -> dict[str, Any]:
    """Carry observed resource history into the next ECJA scene."""

    for key in ("cmlpm_resource_passages", "motion_observed_events"):
        if key in state.current_motion_plan:
            plan[key] = copy.deepcopy(state.current_motion_plan[key])
    now=plan.get('runtime_state_time_s',plan.get('activity_start_s'))
    if now is not None:
        plan['cmlpm_resource_passages']=_measured_h_passages(state,float(now))
    return plan


def _measured_h_passages(state,now):
    """A read-time occupancy projection; original published records stay intact."""
    current=state.current_motion_plan
    rows=copy.deepcopy(current.get('cmlpm_resource_passages',()))
    if current.get('motion_control_owner')!='MEASURED_KINEMATIC_EXECUTOR_V1':return rows
    targets={str(t['resource_id']):t for t in current.get('timed_resource_targets',())}
    observed={(e['event_type'],str(e.get('resource_id'))):float(e['actual_time_s'])
              for e in current.get('motion_observed_events',())}
    spec=DEFAULT_UAV_TYPE_SPECS[state.vehicle_type]
    a=float(spec['max_horizontal_acceleration_mps2']);v=float(state.speed_mps)
    vmax=max(v,float(state.nominal_speed_mps or v))
    def eta(station):
        distance=max(0.,float(station)-float(state.s_m))
        ramp=(vmax*vmax-v*v)/(2*a)
        return ((v*v+2*a*distance)**.5-v)/a if distance<=ramp else (vmax-v)/a+(distance-ramp)/max(vmax,1e-6)
    for row in rows:
        rid=str(row.get('resource_id'));target=targets.get(rid)
        if target is None or str(row.get('role')).upper() not in {'M','MAINLINE_USER'}:continue
        entered=observed.get(('RESOURCE_ENTER',rid));exited=observed.get(('RESOURCE_EXIT',rid))
        row.update(published_enter_s=float(target['entry_time_s']),published_exit_s=float(target['exit_time_s']))
        if exited is not None:
            row.update(enter_s=entered if entered is not None else row['enter_s'],exit_s=exited,
                       status='RELEASED',source='OBSERVED_RESOURCE_EXIT')
        elif float(state.s_m)<float(target['exit_station_m']):
            if entered is None and float(state.s_m)>float(target['entry_station_m'])+1e-7:
                raise ValueError('MEASURED_H_RESOURCE_ENTER_NOT_OBSERVED:'+state.uav_id+':'+rid)
            row.update(enter_s=entered if entered is not None else now+eta(target['entry_station_m']),
                       exit_s=now+eta(target['exit_station_m']),
                       status='IN_PROGRESS' if entered is not None else 'CERTIFIED',source='MEASURED_RESOURCE_FORECAST')
        else:
            raise ValueError('ECJA_CERTIFIED_RESOURCE_EXIT_NOT_OBSERVED:'+state.uav_id+':'+rid)
    return rows


def _runtime_position_xyz(
    source: Mapping[str, Any], state: Any, plan: Mapping[str, Any]
) -> list[float] | None:
    recorded = plan.get("motion_position_xyz")
    if recorded is not None:
        point = list(map(float, recorded))
        if len(point) == 3 and all(math.isfinite(value) for value in point):
            return point
    if _state_name(state) in {"TRANSITION", "VERTICAL"}:
        return None
    line = _line(source, state)
    points = line["polyline_3d"]
    total = sum(math.dist(first, second) for first, second in zip(points, points[1:]))
    station = min(max(0.0, float(state.s_m)), total)
    path = _path_between(points, station, total)
    return list(map(float, path[0]))


def build_committed_fixed_plan(
    state: Any,
    *,
    source: Mapping[str, Any] | None = None,
    now_s: float | None = None,
) -> dict[str, Any]:
    """Re-expose an active assignment as immutable ECJA background."""

    if (source is not None and now_s is not None and not state.cmlpm_managed
            and _state_name(state) in {"MAINLINE", "ASSIGNED", "SCHEDULED"}
            and state.current_motion_plan.get("schedule_result") != "RELEASED"):
        # An assigned aircraft without a published descent is still physical H.
        # Local following may legitimately stop it; a nominal selected V path is
        # not a published future trajectory and must not be rebased at fake speed.
        background = build_mainline_fixed_plan(source,state,now_s)
        if background is not None:
            for key in _PASSAGE_COMMITMENT_KEYS:
                if key in state.current_motion_plan:
                    background[key] = copy.deepcopy(state.current_motion_plan[key])
            background.update(selected_service_route_id=state.assigned_route,
                              runtime_state_version=int(state.event_version),runtime_state_time_s=float(now_s))
            return overlay_runtime_resource_state(background,state)

    if not state.current_motion_plan:
        raise ValueError(f"COMMITTED_MOTION_PLAN_MISSING:{state.uav_id}")
    plan = copy.deepcopy(state.current_motion_plan)
    if plan.get("uav_id") != state.uav_id:
        raise ValueError(f"COMMITTED_PLAN_UAV_MISMATCH:{state.uav_id}")
    plan["plan_status"] = "FIXED"
    plan["committed"] = True
    plan["cmlpm_managed"] = bool(state.cmlpm_managed)
    plan["commit_status"] = state.commit_status
    plan["runtime_state_version"] = int(state.event_version)
    if now_s is not None:
        plan["runtime_state_time_s"] = float(now_s)

    frozen_identity = (
        plan.get("cmlpm_managed")
        and plan.get("commit_status") == "FROZEN"
        and plan.get("frozen") is True
        and plan.get("schedule_result") == "RELEASED"
    )
    if frozen_identity and not is_formally_frozen_v_plan(plan):
        raise ValueError(f"ECJA_FROZEN_V_PLAN_INCOMPLETE:{state.uav_id}")

    if (
        source is not None
        and now_s is not None
        and plan.get("motion_prediction")
        and not is_formally_frozen_v_plan(plan)
    ):
        position = _runtime_position_xyz(source, state, plan)
        if position is None:
            raise ValueError(f"ECJA_STALE_MOTION_PREDICTION:{state.uav_id}:POSITION_MISSING")
        plan = refresh_motion_prediction(
            plan,
            position_xyz=position,
            speed_mps=float(state.speed_mps),
            now_s=float(now_s),
        )
        plan["runtime_state_version"] = int(state.event_version)
        plan["runtime_state_time_s"] = float(now_s)
    return overlay_runtime_resource_state(plan,state) if now_s is not None else plan


def build_active_assignment_summary(snapshot: Any) -> dict[str, Any]:
    """Summarize unfinished historical assignments for QSAP cost context."""

    now = float(snapshot.sim_time_s)
    assignments: list[dict[str, Any]] = []
    resource_occupancies: list[dict[str, Any]] = []
    for state in sorted(snapshot.states.values(), key=lambda item: item.uav_id):
        if (
            _state_name(state) in OUTSIDE_ECJA_STATE_NAMES
            or _state_name(state) in REENTRY_STATE_NAMES
            or state.commit_status == "UNCOMMITTED"
        ):
            continue
        plan = state.current_motion_plan
        has_active_resources = any(
            str(row.get("status", "")).upper() != "RELEASED"
            for row in plan.get("cmlpm_resource_passages", ())
            if isinstance(row, Mapping)
        )
        if not state.assigned_node and not has_active_resources:
            continue
        node = str(state.assigned_node) if state.assigned_node else None
        occupancy = []
        for raw in _measured_h_passages(state,now):
            if not isinstance(raw, Mapping):
                continue
            if str(raw.get("status", "")).upper() == "RELEASED":
                continue
            row = copy.deepcopy(dict(raw))
            if float(row.get("exit_s", row.get("end_s", now))) <= now + 1e-9:
                continue
            row["uav_id"] = state.uav_id
            row["service_node_id"] = node
            occupancy.append(row)
            resource_occupancies.append(copy.deepcopy(row))
        release_candidates = [
            float(row["exit_s"])
            for row in occupancy
            if math.isfinite(float(row["exit_s"]))
        ]
        for key in ("ecja_effective_release_time_s", "j_time_s", "activity_end_s"):
            value = plan.get(key)
            if value is not None and math.isfinite(float(value)):
                release_candidates.append(float(value))
        assignments.append({
            "uav_id": state.uav_id,
            "service_node_id": node,
            "route_id": str(state.assigned_route or plan.get("route_id", "")),
            "state": str(getattr(state.state, "value", state.state)),
            "commit_status": state.commit_status,
            "cmlpm_managed": bool(state.cmlpm_managed),
            "release_time_s": max(release_candidates, default=now),
            "resource_occupancies": tuple(occupancy),
        })
    return {
        "schema_version": "ECJA_ACTIVE_ASSIGNMENT_SUMMARY_V1",
        "snapshot_version": int(snapshot.version),
        "snapshot_time_s": now,
        "active_assignments": tuple(assignments),
        "active_resource_occupancies": tuple(resource_occupancies),
    }


def _observed_resource_edges(plan: Mapping[str, Any]) -> dict[str, set[str]]:
    edges: dict[str, set[str]] = {}
    for row in plan.get("motion_observed_events", ()):
        if not isinstance(row, Mapping):
            raise ValueError("INVALID_OBSERVED_RESOURCE_EVENT")
        resource_id = row.get("resource_id")
        event_type = str(row.get("event_type", ""))
        if resource_id is not None and event_type in {"RESOURCE_ENTER", "RESOURCE_EXIT"}:
            edges.setdefault(str(resource_id), set()).add(event_type)
    return edges


def _observed_event_records(plan: Mapping[str, Any]) -> dict[str, Mapping[str, Any]]:
    """Index immutable observed events so the runtime can reject rewrites."""

    records: dict[str, Mapping[str, Any]] = {}
    for row in plan.get("motion_observed_events", ()):
        if not isinstance(row, Mapping) or not row.get("event_id"):
            raise ValueError("INVALID_OBSERVED_RESOURCE_EVENT")
        event_id = str(row["event_id"])
        if event_id in records and dict(records[event_id]) != dict(row):
            raise ValueError(f"OBSERVED_EVENT_ID_CONFLICT:{event_id}")
        records[event_id] = row
    return records


def passage_incompatibility(
    state: Any,
    candidate_plan: Mapping[str, Any],
    *,
    sim_time_s: float,
) -> str | None:
    """Return why a candidate would violate an unfinished passage promise."""

    prior = state.current_motion_plan
    has_commitment = any(key in prior for key in _PASSAGE_COMMITMENT_KEYS)
    if not has_commitment:
        return None
    contract = candidate_plan.get("ecja_forward_contract")
    if not isinstance(contract, Mapping) or "latest_switch_station_m" not in contract:
        return "CANDIDATE_FORK_STATION_MISSING"
    fork_station = float(contract["latest_switch_station_m"])
    if not math.isfinite(fork_station):
        return "CANDIDATE_FORK_STATION_INVALID"

    edges = _observed_resource_edges(prior)
    targets_by_resource: dict[str, Mapping[str, Any]] = {}
    required_station = float(state.s_m)
    for target in prior.get("timed_resource_targets", ()):
        if not isinstance(target, Mapping):
            return "INVALID_COMMITTED_RESOURCE_TARGET"
        resource_id = str(target.get("resource_id", ""))
        if not resource_id or "exit_station_m" not in target:
            return "COMMITTED_RESOURCE_TARGET_INCOMPLETE"
        targets_by_resource[resource_id] = target
        if "RESOURCE_EXIT" not in edges.get(resource_id, set()):
            required_station = max(required_station, float(target["exit_station_m"]))
    for resource_id, observed in edges.items():
        if "RESOURCE_ENTER" in observed and "RESOURCE_EXIT" not in observed:
            if resource_id not in targets_by_resource:
                return f"ACTIVE_RESOURCE_OCCUPANCY_TARGET_MISSING:{resource_id}"
            required_station = max(
                required_station,
                float(targets_by_resource[resource_id]["exit_station_m"]),
            )

    if fork_station + 1e-6 < required_station:
        return f"FORK_PRECEDES_COMMITTED_PASSAGE:{fork_station:.6f}<{required_station:.6f}"
    return None


def validate_passage_history(state: Any) -> None:
    """Malformed promises are systemic errors, never admission rejections."""

    prior = state.current_motion_plan
    targets = {}
    for row in prior.get("timed_resource_targets", ()):
        fields = ("entry_time_s", "exit_time_s", "entry_station_m", "exit_station_m")
        if not isinstance(row, Mapping) or not row.get("resource_id") or any(key not in row for key in fields):
            raise ValueError(f"ECJA_HISTORY_INCOMPLETE:{state.uav_id}:COMMITTED_RESOURCE_TARGET_INCOMPLETE")
        if (not all(math.isfinite(float(row[key])) for key in fields)
                or float(row["exit_time_s"]) <= float(row["entry_time_s"])
                or float(row["exit_station_m"]) < float(row["entry_station_m"])):
            raise ValueError(f"ECJA_HISTORY_INVALID:{state.uav_id}:RESOURCE_STATION")
        if row["resource_id"] in targets:
            raise ValueError(f"ECJA_HISTORY_INVALID:{state.uav_id}:DUPLICATE_RESOURCE_TARGET")
        targets[row["resource_id"]] = row
    for resource, edges in _observed_resource_edges(prior).items():
        if "RESOURCE_ENTER" in edges and "RESOURCE_EXIT" not in edges and resource not in targets:
            raise ValueError(f"ECJA_HISTORY_INCOMPLETE:{state.uav_id}:ACTIVE_RESOURCE_TARGET_MISSING:{resource}")


def request_background_plan(source: Mapping[str, Any], request: Any, history: Any = None) -> dict[str, Any] | None:
    """Keep a non-admitted request in the fixed airborne traffic universe."""

    from types import SimpleNamespace
    from .formal_motion import TYPE_BY_LAYER

    state = SimpleNamespace(
        uav_id=request.uav_id, direction=request.direction_id, layer=request.source_layer_id,
        s_m=request.current_directed_station_m, speed_mps=request.speed_mps,
        nominal_speed_mps=float(DEFAULT_UAV_TYPE_SPECS[TYPE_BY_LAYER[request.source_layer_id]]["cruise_speed"]),
        vehicle_type=TYPE_BY_LAYER[request.source_layer_id],
        current_motion_plan=history.current_motion_plan if history is not None else {},
        event_version=history.event_version if history is not None else 0,
        assigned_node=None, commit_status="UNCOMMITTED",
    )
    plan = build_mainline_fixed_plan(source, state, request.snapshot_time_s)
    if plan is None:
        return None
    plan = inherit_passage_commitment(state, plan)
    return overlay_runtime_resource_state(plan, state)


def inherit_passage_commitment(state: Any, candidate_plan: Mapping[str, Any]) -> dict[str, Any]:
    """Copy immutable passage promises and observed facts onto a new plan."""

    merged = copy.deepcopy(dict(candidate_plan))
    prior = state.current_motion_plan
    for key in _PASSAGE_COMMITMENT_KEYS:
        if key in prior:
            merged[key] = copy.deepcopy(prior[key])
    edges = _observed_resource_edges(prior)
    has_promise = any("RESOURCE_EXIT" not in edges.get(str(r["resource_id"]),set())
                      for r in prior.get("timed_resource_targets",()))
    if has_promise:
        merged["inherited_passage_commitment"] = True
        merged["inherited_passage_source_event_version"] = state.event_version
        merged["inherited_passage_plan"] = {
            key: copy.deepcopy(prior[key])
            for key in _PASSAGE_COMMITMENT_KEYS
            if key in prior
        }
    else:
        merged["inherited_passage_commitment"] = False
    return merged


def partition_ecja_state(
    snapshot: Any, source: Mapping[str, Any]
) -> tuple[tuple[Any, ...], tuple[dict[str, Any], ...], dict[str, Any], dict[str, Any]]:
    """Partition the complete traffic snapshot into ECJA input roles."""

    # Local imports avoid making the algorithm package import the runtime
    # package during module initialization.  The returned objects are the
    # runtime's public request/state records, not a second traffic ledger.
    from experiments.ecja_cmlpm_dt_flow_v1.simulation_state import FlightState
    from experiments.ecja_cmlpm_dt_flow_v1.srcm_ecja_adapter import AssignmentRequest

    requests = []
    fixed = []
    request_states: dict[str, Any] = {}
    active_request_ids: set[str] = set()
    excluded: list[str] = []
    for state in sorted(snapshot.states.values(), key=lambda item: item.uav_id):
        state_name = _state_name(state)
        if state_name in REENTRY_STATE_NAMES:
            if (
                state_name in REENTRY_FIXED_BACKGROUND_STATE_NAMES
                or (
                    state_name == "REENTRY_HOLD"
                    and state.current_motion_plan.get("reentry_profile")
                )
            ):
                from experiments.ecja_cmlpm_dt_flow_v1.reentry_background import build_reentry_fixed_plan
                fixed.append(build_reentry_fixed_plan(
                    source, state, float(snapshot.sim_time_s)
                ))
            else:
                excluded.append(state.uav_id)
            continue
        if state_name in OUTSIDE_ECJA_STATE_NAMES:
            excluded.append(state.uav_id)
            continue
        if state.request and state.commit_status == "UNCOMMITTED":
            if state_name != FlightState.PENDING_ASSIGNMENT.value:
                raise ValueError(f"REQUEST_STATE_NOT_PENDING:{state.uav_id}")
            if not state.request_id:
                raise ValueError(f"REQUEST_ID_MISSING:{state.uav_id}")
            if state.request_id in active_request_ids:
                raise ValueError(f"DUPLICATE_ACTIVE_REQUEST_ID:{state.request_id}")
            if state.request_reason not in SUPPORTED_REQUEST_REASONS:
                raise ValueError(f"REQUEST_REASON_INVALID:{state.uav_id}")
            if state.request_guard_valid is False:
                raise ValueError(f"REQUEST_OUTSIDE_GUARD:{state.uav_id}")
            if state.request_trigger_time_s is None:
                raise ValueError(f"REQUEST_TRIGGER_TIME_MISSING:{state.uav_id}")
            if not math.isfinite(float(state.request_trigger_time_s)):
                raise ValueError(f"REQUEST_TRIGGER_TIME_INVALID:{state.uav_id}")
            if float(state.request_trigger_time_s) > float(snapshot.sim_time_s) + 1e-9:
                raise ValueError(f"REQUEST_TRIGGER_IN_FUTURE:{state.uav_id}")
            active_request_ids.add(state.request_id)
            line = _line(source, state)
            total = sum(math.dist(first, second) for first, second in zip(line["polyline_3d"], line["polyline_3d"][1:]))
            requests.append(AssignmentRequest(
                state.uav_id,
                state.direction,
                state.layer,
                float(state.s_m),
                total,
                float(snapshot.sim_time_s),
                float(state.speed_mps),
                request_id=state.request_id,
                request_reason=state.request_reason,
                allowed_energy_candidate_node_ids=(
                    tuple(str(value) for value in state.current_motion_plan.get(
                        "energy_allowed_candidate_node_ids", ()
                    ))
                    if "energy_allowed_candidate_node_ids" in state.current_motion_plan
                    else None
                ),
                request_created_time_s=float(state.request_trigger_time_s),
                allow_stop_start=request_allows_stop_start(state.current_motion_plan),
            ))
            request_states[state.uav_id] = copy.deepcopy(state)
            continue
        if state.commit_status != "UNCOMMITTED" or state_name in {
            FlightState.ASSIGNED.value,
            FlightState.SCHEDULED.value,
            FlightState.TRANSITION.value,
            FlightState.VERTICAL.value,
        }:
            fixed.append(build_committed_fixed_plan(
                state, source=source, now_s=float(snapshot.sim_time_s)
            ))
        else:
            plan = build_mainline_fixed_plan(source, state, snapshot.sim_time_s)
            if plan is None:
                excluded.append(state.uav_id)
            else:
                fixed.append(overlay_runtime_resource_state(plan, state))
    contract = {
        "contract_version": "ECJA_AUTHORITATIVE_TRAFFIC_SNAPSHOT_V1",
        "snapshot_version": snapshot.version,
        "snapshot_time_s": snapshot.sim_time_s,
        "state_uav_ids": sorted(snapshot.states),
        "request_uav_ids": sorted(request_states),
        "fixed_uav_ids": sorted({plan["uav_id"] for plan in fixed}),
        "excluded_uav_ids": sorted(excluded),
    }
    return tuple(requests), tuple(fixed), contract, request_states


# Compatibility names for tests and the current runtime integration.  The
# implementation now lives in the ECJA algorithm package.
_mainline_fixed_plan = build_mainline_fixed_plan
_committed_fixed_plan = build_committed_fixed_plan
_overlay_runtime_resource_state = overlay_runtime_resource_state
_requests_and_background = partition_ecja_state
_runtime_position_xyz = _runtime_position_xyz
assignment_passage_incompatibility = passage_incompatibility
build_ecja_active_assignment_summary = build_active_assignment_summary


__all__ = [
    "SUPPORTED_REQUEST_REASONS",
    "OUTSIDE_ECJA_STATE_NAMES",
    "REENTRY_STATE_NAMES",
    "REENTRY_FIXED_BACKGROUND_STATE_NAMES",
    "build_mainline_fixed_plan",
    "build_committed_fixed_plan",
    "overlay_runtime_resource_state",
    "partition_ecja_state",
    "build_active_assignment_summary",
    "passage_incompatibility",
    "inherit_passage_commitment",
]
