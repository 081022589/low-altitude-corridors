"""Independent P3-R global-optimality proof audit for frozen P2 results.

The audit returns a *graded* proof class rather than a binary flag, because a
"globally optimal" label carries very different meaning at the two ends of the
component-size spectrum:

``TRIVIAL_NO_VARIABLE``
    No UAV has more than one legal candidate; there is nothing to search.
``TRIVIAL_LOWER_BOUND``
    The incumbent already equals the linear lower bound; separability makes it
    optimal without any neighbourhood work.
``COMPONENT_PROVEN``
    Every component with variable UAVs was searched completely in the final
    epoch, with no truncation and no cross-component load coupling.
``HEURISTIC``
    Anything else; ``provable_coverage`` then reports which share of the
    variable UAVs is still covered by a valid component certificate.
"""

from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, Mapping

from .cb_lns import proof_key_for_test
from .qsap import objective_model_hash


STATUS_BY_PROOF_CLASS = {
    "TRIVIAL_NO_VARIABLE": "GLOBAL_OPTIMAL_TRIVIAL_NO_VARIABLE",
    "TRIVIAL_LOWER_BOUND": "GLOBAL_OPTIMAL_TRIVIAL_LOWER_BOUND",
    "COMPONENT_PROVEN": "GLOBAL_OPTIMAL_COMPONENT_PROVEN",
    "HEURISTIC": "HEURISTIC_INCUMBENT",
    "K_FEASIBLE_COMPONENT_PROVEN": "K_FEASIBLE_COMPONENT_PROVEN",
    "K_FEASIBLE_HEURISTIC": "K_FEASIBLE_HEURISTIC",
}


def _hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def certify_global_optimality(model: Mapping[str, Any], result: Mapping[str, Any], eps: float = 1e-9) -> Dict[str, Any]:
    assignment = result.get("final_assignment", {})
    model_hash = objective_model_hash(model)
    terminal_signature = _hash({"assignment": assignment, "objective": result.get("final_objective"),
                                "objective_model_hash": model_hash})
    lower = sum(min(float(model["linear_costs"][c]) for c in model["candidate_ids_by_uav"][u]) for u in model["uavs"])
    final = float(result["final_objective"]["total"])
    nonnegative_q = all(float(value) >= -eps for value in model["quadratic_costs"].values())

    graph_components = [list(component) for component in result.get("graph", {}).get("components", [])]
    sizes = [len(component) for component in graph_components]
    variable_uavs = [uav for uav in model["uavs"] if len(model["candidate_ids_by_uav"][uav]) >= 2]
    variable_set = set(variable_uavs)
    component_stats = {
        "component_count": len(graph_components),
        "max_component_size": max(sizes) if sizes else 0,
        "variable_uav_count": len(variable_uavs),
        "variable_component_count": sum(1 for component in graph_components if variable_set.intersection(component)),
    }

    base = {
        "lower_bound": lower,
        "final_objective": final,
        "nonnegative_quadratic_verified": nonnegative_q,
        "terminal_assignment_signature": terminal_signature,
        "objective_model_hash": model_hash,
        "component_stats": component_stats,
        "component_certificates": [],
        "missing_components": [],
        "oracle_equality_is_not_proof": True,
    }

    if not variable_uavs:
        return {**base, "valid": True, "proof_class": "TRIVIAL_NO_VARIABLE",
                "source": "NO_VARIABLE_UAVS", "provable_coverage": 1.0}

    if nonnegative_q and final <= lower + eps:
        return {**base, "valid": True, "proof_class": "TRIVIAL_LOWER_BOUND",
                "source": "GLOBAL_LINEAR_LOWER_BOUND", "provable_coverage": 1.0}

    logs = result.get("diagnostics", {}).get("task_log", [])
    certificates = []
    missing = []
    for component_index, component in enumerate(graph_components):
        variables = tuple(sorted(u for u in component if len(model["candidate_ids_by_uav"][u]) >= 2))
        if not variables:
            continue
        relevant = [row for row in logs if tuple(sorted(row.get("group", []))) == variables]
        component_id = "C%03d" % component_index
        final_epoch = result.get("diagnostics", {}).get("component_epochs", {}).get(
            component_id, max((row.get("epoch", 0) for row in relevant), default=-1)
        )
        # An accepted move invalidates the proof context used by that task.  P2
        # records the incremented epoch on the same row, so accepted rows must
        # never certify the post-move incumbent; a later non-accepted complete
        # component search is required.
        expected_key = proof_key_for_test(model, assignment, variables)
        proofs = [row for row in relevant if row.get("epoch", 0) == final_epoch and not row.get("accepted")
                  and row.get("status") == "LOCAL_OPTIMAL_PROVEN" and row.get("delta_audit_pass")
                  and row.get("proof_key") == expected_key
                  and row.get("objective_model_hash") == model_hash]
        if not proofs:
            missing.append(list(variables))
        else:
            certificates.append({"component": list(variables), "epoch": final_epoch, "task_round": proofs[-1]["round"],
                                 "status": "COMPLETE_COMPONENT_PROVEN", "recomputed_proof_key": expected_key})

    proven_variable = sum(len(certificate["component"]) for certificate in certificates)
    provable_coverage = proven_variable / len(variable_uavs) if variable_uavs else 1.0
    valid = not missing and bool(certificates)
    cap = model.get("peak_load_cap_effective")
    if cap is not None:
        # Capacity couples components through shared descent units, so a
        # component-wise certificate is not a global one.  Report exactly what
        # was proven instead of claiming global optimality.
        proven_all = not missing and bool(certificates)
        return {**base,
                "valid": False,
                "proof_class": ("K_FEASIBLE_COMPONENT_PROVEN" if proven_all
                                else "K_FEASIBLE_HEURISTIC"),
                "certificate_scope": "CAP_FEASIBLE_COMPONENT_LOCAL",
                "peak_load_cap_effective": int(cap),
                "source": ("COMPONENT_SEARCH_WITHIN_CAP_FEASIBLE_DOMAIN" if proven_all
                           else "NO_CAP_FEASIBLE_CERTIFICATE"),
                "component_certificates": certificates,
                "missing_components": missing,
                "provable_coverage": 1.0 if proven_all else provable_coverage,
                "proven_variable_uav_count": proven_variable}
    return {**base,
            "valid": valid,
            "proof_class": "COMPONENT_PROVEN" if valid else "HEURISTIC",
            "source": "COMPLETE_FINAL_EPOCH_COMPONENT_SEARCH" if valid else "NO_VALID_GLOBAL_PROOF",
            "component_certificates": certificates,
            "missing_components": missing,
            "provable_coverage": 1.0 if valid else provable_coverage,
            "proven_variable_uav_count": proven_variable}


def enforce_proof_status(model: Mapping[str, Any], result: Mapping[str, Any], eps: float = 1e-9) -> Dict[str, Any]:
    updated = dict(result)
    proof = certify_global_optimality(model, result, eps)
    updated["global_optimality_proof"] = proof
    # The solver's own status is provisional; the certificate decides.
    updated["solver_status"] = STATUS_BY_PROOF_CLASS[proof["proof_class"]]
    if result.get("solver_status") == "GLOBAL_OPTIMAL_PROVEN" and not proof["valid"]:
        updated["termination_reason"] = "SEARCH_COMPLETED_WITHOUT_GLOBAL_PROOF"
        updated["global_status_downgraded"] = True
    else:
        updated["global_status_downgraded"] = False
    return updated
