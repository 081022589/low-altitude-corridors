"""P2 sparse conflict graphs and the frozen I1/G2/G3 heuristics."""

from __future__ import annotations

from typing import Any, Dict, Iterable, Mapping, Sequence, Set, Tuple


def pair_key(a: str, b: str) -> str:
    return "|".join(sorted((a, b)))


def q_value(model: Mapping[str, Any], a: str, b: str) -> float:
    return float(model["quadratic_costs"].get(pair_key(a, b), 0.0))


def minimum_linear_assignment(model: Mapping[str, Any]) -> Dict[str, str]:
    return {
        uav: min(candidates, key=lambda candidate: (float(model["linear_costs"][candidate]), candidate))
        for uav, candidates in sorted(model["candidate_ids_by_uav"].items())
    }


def build_graphs(model: Mapping[str, Any]) -> Dict[str, Any]:
    candidate_to_uav = dict(model.get("candidate_to_uav", {}))
    if not candidate_to_uav:
        candidate_to_uav = {candidate: uav for uav, values in model["candidate_ids_by_uav"].items() for candidate in values}
    candidate_adjacency = {candidate: {} for values in model["candidate_ids_by_uav"].values() for candidate in values}
    uav_adjacency: Dict[str, Set[str]] = {uav: set() for uav in model["uavs"]}
    uav_edge_weight: Dict[str, float] = {}
    for key, weight_value in model["quadratic_costs"].items():
        weight = float(weight_value)
        if weight <= 0:
            continue
        left, right = key.split("|", 1)
        left_uav, right_uav = candidate_to_uav[left], candidate_to_uav[right]
        if left_uav == right_uav:
            raise ValueError("SAME_UAV_GRAPH_EDGE")
        candidate_adjacency[left][right] = weight
        candidate_adjacency[right][left] = weight
        uav_adjacency[left_uav].add(right_uav)
        uav_adjacency[right_uav].add(left_uav)
        ukey = pair_key(left_uav, right_uav)
        uav_edge_weight[ukey] = max(uav_edge_weight.get(ukey, 0.0), weight)
    components = []
    unseen = set(uav_adjacency)
    while unseen:
        root = min(unseen)
        unseen.remove(root)
        stack, component = [root], []
        while stack:
            node = stack.pop()
            component.append(node)
            for neighbor in sorted(uav_adjacency[node], reverse=True):
                if neighbor in unseen:
                    unseen.remove(neighbor)
                    stack.append(neighbor)
        components.append(tuple(sorted(component)))
    return {
        "candidate_adjacency": candidate_adjacency,
        "uav_adjacency": {key: tuple(sorted(value)) for key, value in sorted(uav_adjacency.items())},
        "uav_edge_weight": uav_edge_weight,
        "components": tuple(components),
    }


def d_scores(model: Mapping[str, Any], assignment: Mapping[str, str], graph: Mapping[str, Any]) -> Dict[str, float]:
    lam = float(model["config"]["lambda_r"])
    output = {}
    for uav in model["uavs"]:
        current = assignment[uav]
        r_i = float(model["linear_costs"][current]) - min(float(model["linear_costs"][c]) for c in model["candidate_ids_by_uav"][uav])
        pressure = sum(q_value(model, current, assignment[other]) for other in graph["uav_adjacency"][uav])
        output[uav] = r_i + 0.5 * lam * pressure
    return output


def w_scores(model: Mapping[str, Any], graph: Mapping[str, Any]) -> Dict[str, float]:
    lam = float(model["config"]["lambda_r"])
    return {uav: lam * sum(graph["uav_edge_weight"][pair_key(uav, other)] for other in graph["uav_adjacency"][uav]) for uav in model["uavs"]}


def directed_h_index(model: Mapping[str, Any], assignment: Mapping[str, str], graph: Mapping[str, Any]) -> Dict[str, float]:
    lam = float(model["config"]["lambda_r"])
    result = {}
    for i, neighbors in graph["uav_adjacency"].items():
        for j in neighbors:
            current_j = assignment[j]
            best = 0.0
            for candidate_i in model["candidate_ids_by_uav"][i]:
                current_cost = q_value(model, candidate_i, current_j)
                minimum = min(q_value(model, candidate_i, candidate_j) for candidate_j in model["candidate_ids_by_uav"][j])
                best = max(best, max(0.0, current_cost - minimum))
            result[i + "->" + j] = lam * best
    return result


def h_score(group: Iterable[str], neighbor: str, directed: Mapping[str, float]) -> float:
    return sum(float(directed.get(uav + "->" + neighbor, 0.0)) for uav in group)


def connected_expansions(group: Sequence[str], graph: Mapping[str, Any]) -> Tuple[str, ...]:
    members = set(group)
    return tuple(sorted({neighbor for uav in group for neighbor in graph["uav_adjacency"][uav] if neighbor not in members}))
