"""Bounded local QSAP B&B implementing L1-L5 without the P1 Oracle."""

from __future__ import annotations

import math
import time
from dataclasses import dataclass
from typing import Any, Dict, Mapping, Optional, Sequence

from .conflict_graph import q_value
from .oracle import independent_q3_recompute


@dataclass(frozen=True)
class LocalBudget:
    """Deterministic work limit for one neighbourhood.

    Node expansions only.  There is no wall-clock stop: a time limit would make
    the returned incumbent depend on machine speed, so the same input would no
    longer reproduce the same output.
    """

    max_nodes: int
    eps: float = 1e-9


def _outside_load_counts(model: Mapping[str, Any], assignment: Mapping[str, str], group: Sequence[str]) -> Dict[str, int]:
    """Selected candidates per load key outside the neighbourhood."""

    members = set(group)
    mapping = model.get("candidate_to_load_key") or {}
    if not mapping:
        return {}
    counts: Dict[str, int] = {}
    for uav, candidate in assignment.items():
        if uav in members:
            continue
        key = mapping[candidate]
        counts[key] = counts.get(key, 0) + 1
    return counts


def local_external_costs(model: Mapping[str, Any], assignment: Mapping[str, str], group: Sequence[str]) -> Dict[str, float]:
    members = set(group)
    lam = float(model["config"]["lambda_r"])
    result = {}
    for uav in group:
        for candidate in model["candidate_ids_by_uav"][uav]:
            result[candidate] = (
                float(model["linear_costs"][candidate])
                + lam * sum(
                    q_value(model, candidate, assignment[other])
                    for other in model["uavs"] if other not in members
                )
            )
    return result


def local_objective(model: Mapping[str, Any], group: Sequence[str], local_assignment: Mapping[str, str], external: Mapping[str, float]) -> float:
    ordered = tuple(sorted(group))
    value = sum(float(external[local_assignment[uav]]) for uav in ordered)
    lam = float(model["config"]["lambda_r"])
    for index, left in enumerate(ordered):
        for right in ordered[index + 1:]:
            value += lam * q_value(model, local_assignment[left], local_assignment[right])
    return value


def solve_local_bnb(
    model: Mapping[str, Any], assignment: Mapping[str, str], group: Sequence[str], budget: LocalBudget,
    current_full_value: Optional[float] = None,
) -> Dict[str, Any]:
    """Solve one neighbourhood exactly within budget.

    ``current_full_value`` is the caller's already computed objective of
    ``assignment``.  Supplying it avoids recomputing the same O(M^2) value for
    the same (model, assignment) pair; omitting it keeps the legacy behaviour
    of recomputing internally.
    """
    started = time.perf_counter()
    group = tuple(sorted(group))
    if not group or budget.max_nodes <= 0:
        return {"status": "LOCAL_SKIPPED_BUDGET", "group": group, "nodes_expanded": 0, "elapsed_ms": 0.0, "improved": False}
    if any(len(model["candidate_ids_by_uav"][uav]) == 0 for uav in group):
        return {"status": "LOCAL_INVALID", "group": group, "reason": "EMPTY_CANDIDATE_SET", "nodes_expanded": 0, "elapsed_ms": 0.0, "improved": False}
    if any(float(value) < 0 or not math.isfinite(float(value)) for value in model["quadratic_costs"].values()):
        return {"status": "LOCAL_INVALID", "group": group, "reason": "L4_L5_NONNEGATIVITY_FAILED", "nodes_expanded": 0, "elapsed_ms": 0.0, "improved": False}
    cap = model.get("peak_load_cap_effective")
    cap = None if cap is None else int(cap)
    mapping = model.get("candidate_to_load_key") or {}
    outside_counts = _outside_load_counts(model, assignment, group) if cap is not None else {}
    if cap is not None:
        for uav in group:
            if not any(outside_counts.get(mapping.get(c), 0) < cap
                       for c in model["candidate_ids_by_uav"][uav]):
                return {"status": "LOCAL_INVALID", "group": group,
                        "reason": "PEAK_LOAD_CAP_EXHAUSTED", "nodes_expanded": 0,
                        "elapsed_ms": (time.perf_counter() - started) * 1000.0,
                        "improved": False}

    external = local_external_costs(model, assignment, group)
    current_local = {uav: assignment[uav] for uav in group}
    current_value = local_objective(model, group, current_local, external)
    l4 = sum(min(external[candidate] for candidate in model["candidate_ids_by_uav"][uav]) for uav in group)
    if l4 >= current_value - budget.eps:
        return {"status": "LOCAL_OPTIMAL_PROVEN", "proof": "L4_CERTIFIED_NO_IMPROVEMENT", "group": group,
                "current_local_value": current_value, "best_local_value": current_value, "l4": l4,
                "best_assignment": current_local, "nodes_expanded": 0, "elapsed_ms": (time.perf_counter() - started) * 1000.0,
                "improved": False, "complete": True}

    order = sorted(group, key=lambda uav: (len(model["candidate_ids_by_uav"][uav]), -sum(q_value(model, c, d) > 0 for c in model["candidate_ids_by_uav"][uav] for other in group if other != uav for d in model["candidate_ids_by_uav"][other]), uav))
    best_value, best_local = current_value, dict(current_local)
    nodes, pruned, budget_hit = 0, 0, False
    lam = float(model["config"]["lambda_r"])

    def expired() -> bool:
        return nodes >= budget.max_nodes

    def visit(depth: int, partial: Dict[str, str], partial_cost: float) -> None:
        nonlocal nodes, pruned, budget_hit, best_value, best_local
        if expired():
            budget_hit = True
            return
        nodes += 1
        remaining = order[depth:]
        lower = partial_cost
        for uav in remaining:
            lower += min(
                external[candidate] + lam * sum(q_value(model, candidate, selected) for selected in partial.values())
                for candidate in model["candidate_ids_by_uav"][uav]
            )
        if lower >= best_value - budget.eps:
            pruned += 1
            return
        if depth == len(order):
            if partial_cost < best_value - budget.eps:
                best_value, best_local = partial_cost, dict(partial)
            return
        uav = order[depth]

        def candidate_cost(candidate: str) -> float:
            return (
                external[candidate]
                + lam * sum(q_value(model, candidate, selected) for selected in partial.values())
            )

        allowed = model["candidate_ids_by_uav"][uav]
        if cap is not None:
            allowed = [
                candidate for candidate in allowed
                if outside_counts.get(mapping.get(candidate), 0)
                + sum(1 for selected in partial.values()
                      if mapping.get(selected) == mapping.get(candidate)) < cap
            ]
        candidates = sorted(allowed, key=lambda candidate: (candidate_cost(candidate), candidate))
        for candidate in candidates:
            increment = candidate_cost(candidate)
            partial[uav] = candidate
            visit(depth + 1, partial, partial_cost + increment)
            partial.pop(uav)
            if budget_hit:
                return

    visit(0, {}, 0.0)
    proposed = dict(assignment)
    proposed.update(best_local)
    old_full = (
        float(current_full_value)
        if current_full_value is not None
        else independent_q3_recompute(model, assignment)["total"]
    )
    new_full = independent_q3_recompute(model, proposed)["total"]
    local_delta, full_delta = best_value - current_value, new_full - old_full
    delta_valid = abs(local_delta - full_delta) <= max(budget.eps, 1e-9)
    # The independent objective audit of a proposed move is performed exactly
    # once by the caller when it accepts the move.  Repeating it here would
    # recompute the same value a second time without adding evidence.
    if not delta_valid:
        status = "LOCAL_INVALID"
    elif budget_hit:
        status = "LOCAL_IMPROVED_UNPROVEN" if new_full < old_full - budget.eps else "LOCAL_NO_IMPROVEMENT_UNPROVEN"
    else:
        status = "LOCAL_OPTIMAL_PROVEN"
    return {
        "status": status, "group": group, "current_local_value": current_value, "best_local_value": best_value,
        "l4": l4, "best_assignment": best_local, "proposed_assignment": proposed, "old_full_value": old_full,
        "new_full_value": new_full, "local_delta": local_delta, "full_delta": full_delta, "delta_audit_pass": delta_valid,
        "nodes_expanded": nodes, "nodes_pruned": pruned, "budget_hit": budget_hit,
        "elapsed_ms": (time.perf_counter() - started) * 1000.0, "improved": new_full < old_full - budget.eps,
        "complete": not budget_hit,
    }
