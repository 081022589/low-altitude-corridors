"""P3-R representation adapter matching frozen SRCM first-role dedup semantics."""

from __future__ import annotations

from typing import Any, Dict, Mapping

from .sparse_srcm import evaluate_sparse_srcm


def _kind(a, b, source_a, source_b, layer, order):
    vertical={"VERTICAL_USER","SOURCE_ENTRY"}
    if a in vertical and b in vertical: return "VV"
    if a=="VERTICAL_USER" and b=="MAINLINE_USER" and order.get(source_a,-1)>order.get(layer,-1): return "VH"
    if b=="VERTICAL_USER" and a=="MAINLINE_USER" and order.get(source_b,-1)>order.get(layer,-1): return "VH"
    return None


def evaluate_p3r_srcm(scene: Mapping[str, Any], snapshot=None, cache=None) -> Dict[str, Any]:
    """Keep sparse search/coverage, but reproduce frozen event role payload order.

    Event identity deliberately excludes role labels.  When two role-segment
    combinations collapse to one event key, the frozen reference keeps the
    first combination in use/role order whereas the sweep index encounters it
    in time order.  This adapter reconstructs only those two labels; event IDs,
    windows, uses, coverage and costs remain untouched.
    """
    # The evaluator owns this result; cached uses remain read-only. Only event
    # labels change, so copying their dictionaries is sufficient.
    result=dict(evaluate_sparse_srcm(scene,snapshot=snapshot,cache=cache))
    result["events"]=[dict(event) for event in result["events"]]
    uses={x["use_id"]:x for x in result["uses"]}; plans={x["plan_id"]:x for x in scene["plans"]}; resources={x["crossing_id"]:x for x in result["resources"]}
    order={x["layer_id"]:int(x["layer_order"]) for x in scene["layers"]}; guard=float(scene.get("time_profile",{}).get("optional_guard_s",0.0) or 0.0)
    grouped={}
    for event in result["events"]:
        pair=(event["use_a_id"],event["use_b_id"],event["crossing_id"])
        grouped.setdefault(pair,[]).append(event)
    for (use_a,use_b,crossing),events in grouped.items():
        ua,ub=uses[use_a],uses[use_b]
        pa,pb=plans[events[0]["plan_a_id"]],plans[events[0]["plan_b_id"]]
        resource=resources[crossing]
        wanted={(event["competition_type"],event["overlap_class"],round(event["overlap_start_s"],12),round(event["overlap_end_s"],12)) for event in events}
        first_roles={}
        # Preserve frozen nested-loop order and its first matching combination.
        # Each use pair is scanned once, independent of its number of events.
        for ra in ua["role_segments"]:
            for rb in ub["role_segments"]:
                kind=_kind(ra["role"],rb["role"],pa.get("source_layer_id"),pb.get("source_layer_id"),resource["layer_id"],order)
                if kind is None: continue
                ns,ne=max(ra["enter_s"],rb["enter_s"]),min(ra["exit_s"],rb["exit_s"]); nominal=max(0.0,ne-ns)
                gs,ge=max(ra["enter_s"]-guard,rb["enter_s"]-guard),min(ra["exit_s"]+guard,rb["exit_s"]+guard); guarded=max(0.0,ge-gs)
                cls="NOMINAL_COMPETITION" if nominal>1e-9 else "GUARD_ONLY_COMPETITION"; start=ns if nominal>1e-9 else gs; end=ne if nominal>1e-9 else ge
                key=(kind,cls,round(start,12),round(end,12))
                if key in wanted and key not in first_roles:
                    first_roles[key]=(ra["role"],rb["role"])
                    if len(first_roles)==len(wanted): break
            if len(first_roles)==len(wanted): break
        for event in events:
            key=(event["competition_type"],event["overlap_class"],round(event["overlap_start_s"],12),round(event["overlap_end_s"],12))
            if key not in first_roles:
                # Sparse SRCM may coalesce adjacent same-role pieces of one
                # physical use into a single event.  The merged interval no
                # longer matches one raw role-segment pair, but its role
                # payload remains canonical and must be retained.
                if _kind(
                    event["role_a"], event["role_b"],
                    pa.get("source_layer_id"), pb.get("source_layer_id"),
                    resource["layer_id"], order,
                ) != event["competition_type"]:
                    raise ValueError("P3R_EVENT_ROLE_CANONICALIZATION_FAILED")
                first_roles[key]=(event["role_a"],event["role_b"])
            event["role_a"],event["role_b"]=first_roles[key]
    result["p3r_role_payload_adapter"]="FROZEN_SRCM_FIRST_ROLE_DEDUP_ORDER_V1"
    return result

