"""Independent exhaustive Oracle and raw-Q3 auditor for P1."""

from __future__ import annotations

import itertools
import math
import time
from typing import Any, Dict, Mapping

from .load_balance import validate_capacity_assignment


def independent_q3_recompute(model: Mapping[str, Any], assignment: Mapping[str, str]) -> Dict[str, float]:
    uavs = tuple(sorted(model["candidate_ids_by_uav"]))
    if tuple(sorted(assignment)) != uavs:
        raise ValueError("AUDIT_UAV_SET_MISMATCH")
    selected = []
    for uav in uavs:
        candidate = assignment[uav]
        if candidate not in tuple(model["candidate_ids_by_uav"][uav]):
            raise ValueError("AUDIT_INVALID_CANDIDATE")
        selected.append(candidate)
    linear = 0.0
    for candidate in selected:
        linear += float(model["linear_costs"][candidate])
    raw_quadratic = 0.0
    for left_index in range(len(selected)):
        for right_index in range(left_index + 1, len(selected)):
            key = "|".join(sorted((selected[left_index], selected[right_index])))
            raw_quadratic += float(model["quadratic_costs"].get(key, 0.0))
    quadratic = float(model["config"]["lambda_r"]) * raw_quadratic
    return {"linear": linear, "quadratic": quadratic, "total": linear + quadratic}


def exhaustive_oracle(model: Mapping[str, Any], max_combinations: int = 1_000_000, tolerance: float = 1e-12) -> Dict[str, Any]:
    started = time.perf_counter()
    uavs = sorted(model["candidate_ids_by_uav"])
    candidate_lists = [tuple(model["candidate_ids_by_uav"][uav]) for uav in uavs]
    count = math.prod(len(values) for values in candidate_lists)
    if count == 0:
        raise ValueError("EMPTY_QSAP")
    if count > max_combinations:
        raise ValueError("ORACLE_COMBINATION_LIMIT")
    rows = []
    feasible_count = 0
    best_value = math.inf
    best_assignments = []
    for combination in itertools.product(*candidate_lists):
        assignment = dict(zip(uavs, combination))
        cap = model.get("peak_load_cap_effective")
        if cap is not None:
            try:
                validate_capacity_assignment(model, assignment, int(cap))
            except ValueError as error:
                if str(error) == "PEAK_LOAD_CAP_VIOLATED":
                    continue
                raise
        feasible_count += 1
        objective = independent_q3_recompute(model, assignment)
        rows.append({"assignment": assignment, "objective": objective})
        if objective["total"] < best_value - tolerance:
            best_value = objective["total"]
            best_assignments = [assignment]
        elif abs(objective["total"] - best_value) <= tolerance:
            best_assignments.append(assignment)
    if not feasible_count:
        raise ValueError("ORACLE_NO_CAPACITY_FEASIBLE_ASSIGNMENT")
    return {
        "oracle": "ORIGINAL_FLOAT_Q3_EXHAUSTIVE_ENUMERATION",
        "combination_count": count,
        "enumerated_count": count,
        "feasible_count": feasible_count,
        "complete": True,
        "best_value": best_value,
        "best_assignments": best_assignments,
        "rows": rows,
        "elapsed_ms": (time.perf_counter() - started) * 1000.0,
    }


def audit_objective(model: Mapping[str, Any], assignment: Mapping[str, str], reported: float, tolerance: float = 1e-9) -> Dict[str, Any]:
    recomputed = independent_q3_recompute(model, assignment)
    error = abs(float(reported) - recomputed["total"])
    return {"reported": float(reported), "recomputed": recomputed, "absolute_error": error,
            "tolerance": tolerance, "status": "PASS" if error <= tolerance else "FAIL"}


def make_t37_model() -> Dict[str, Any]:
    uavs = ["U1", "U2", "U3"]
    candidates = {uav: [uav + ":O", uav + ":X"] for uav in uavs}
    q = {}
    for i, left in enumerate(uavs):
        for right in uavs[i + 1:]:
            for a in candidates[left]:
                for b in candidates[right]:
                    q["|".join(sorted((a, b)))] = 0.0 if a.endswith(":X") and b.endswith(":X") else (10.0 if a.endswith(":O") and b.endswith(":O") else 15.0)
    return {
        "model_version": "ECJA_T37_T48_FROZEN_ARTIFICIAL_QSAP",
        "qualification": "EXACT_TEST_ONLY",
        "config": {"lambda_r": 1.0},
        "uavs": uavs,
        "candidate_ids_by_uav": candidates,
        "linear_costs": {candidate: (1.0 if candidate.endswith(":X") else 0.0) for values in candidates.values() for candidate in values},
        "quadratic_costs": q,
    }
