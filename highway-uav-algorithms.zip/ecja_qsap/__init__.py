"""ECJA algorithm package.

The public decision seam is :class:`ECJAInput` -> :func:`assign_ecja` ->
:class:`ECJAOutput`.  Solver internals and research diagnostics remain
implementation details or separate validation assets.
"""

from .algorithm import ECJAInput, ECJAOutput, ECJARequestHistory, assign_ecja
from .oracle import audit_objective, exhaustive_oracle, independent_q3_recompute
from .qsap import QsapConfig, build_qsap_model, evaluate_q3, potential_graph_stats

__all__ = [
    "ECJAInput",
    "ECJAOutput",
    "ECJARequestHistory",
    "assign_ecja",
    "QsapConfig",
    "audit_objective",
    "build_qsap_model",
    "evaluate_q3",
    "exhaustive_oracle",
    "independent_q3_recompute",
    "potential_graph_stats",
]

