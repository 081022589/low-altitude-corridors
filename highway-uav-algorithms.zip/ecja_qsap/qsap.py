"""P1 generalized QSAP construction and auditable objective semantics.

This module is an ECJA-only adapter.  It consumes the P0-R contract and the
read-only sparse SRCM result; it does not alter SRCM or produce execution-safe
decisions.

The objective is access cost plus SRCM competition only::

    total = sum(linear) + lambda_r * sum(q over selected CC pairs)

Same-node crowding is a **service level constraint**, not an objective term:
``n_k <= peak_load_cap`` on each descent unit ``(service_node_id,
source_layer_id)``.  Every quadratic edge in ``q`` remains an SRCM crossing
event, so the potential competition graph stays physically sparse and
decomposable.  See ``docs/TERMINOLOGY_DESCENT_UNIT_SERVICE_LEVEL_20261026.md``.
"""

from __future__ import annotations

import hashlib
import json
import math
from dataclasses import asdict, dataclass
from typing import Any, Dict, Mapping, Optional, Sequence, Tuple

from .load_balance import min_achievable_peak
from .sparse_srcm import expand_pair_statuses
from .sparse_srcm import ADAPTER_VERSION
from .v3_qq import (
    HEADWAY_MODE,
    OVERLAP_BASIS,
    V3_OBJECTIVE_VERSION,
    coefficient_from_union,
    event_union_records,
    role_class,
    union_digest,
)
from srcm.models import SRCM_VERSION
from srcm.plan_motion import phase_types


MODEL_VERSION = "ECJA_V3_CORE_THREE_TERM_2_0"


def objective_model_hash(model: Mapping[str, Any]) -> str:
    """Identify the complete objective and legal decision domains."""

    definition = {
        "semantics": "ECJA_V3_CORE_THREE_TERM_2_0",
        "model_version": model.get("model_version"),
        "config": dict(model["config"]),
        "domains": {u: sorted(cs) for u, cs in model["candidate_ids_by_uav"].items()},
        "linear_costs": model["linear_costs"],
        "quadratic_costs": model["quadratic_costs"],
        "v3_objective": {
            "version": model.get("v3_objective", {}).get("version", model.get("model_version")),
            "overlap_basis": model.get("v3_objective", {}).get("overlap_basis"),
            "headway_mode": model.get("v3_objective", {}).get("headway_mode"),
        },
        "candidate_to_load_key": model.get("candidate_to_load_key") or {},
        "peak_load_cap_effective": model.get("peak_load_cap_effective"),
    }
    return hashlib.sha256(json.dumps(definition, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def canonical_pair(a: str, b: str) -> str:
    return "|".join(sorted((str(a), str(b))))


@dataclass(frozen=True)
class QsapConfig:
    # Both profiles use the same solver, domains, feasibility and tie rules.
    objective_profile: str = "V3_CORE"
    alpha: float = 1.0
    gamma: float = 1.0
    delta: float = 1.0
    lambda_f: float = 1.0
    lambda_r: float = 1.0
    # Service level: maximum assignments in this batch per descent unit.
    # This is not simultaneous physical occupancy or ground capacity.
    peak_load_cap: int | None = None
    theta_vv: float = 1.0
    theta_vh: float = 1.0
    t_ref_s: float = 1.0
    flight_time_scale_s: float = 300.0
    duration_field: str = "guarded_overlap_s"
    overlap_basis: str = OVERLAP_BASIS
    headway_mode: str = HEADWAY_MODE
    unknown_policy: str = "BLOCK_UNKNOWN_SRCM_COVERAGE"
    config_status: str = "V3_CORE_THREE_TERM_FROZEN_WEIGHTS_SERVICE_LEVEL_ONLY"

    def validate(self) -> None:
        if self.objective_profile not in {"B0", "V3_CORE"}:
            raise ValueError("INVALID_OBJECTIVE_PROFILE")
        if self.peak_load_cap is not None and (
                isinstance(self.peak_load_cap, bool) or not isinstance(self.peak_load_cap, int)
                or self.peak_load_cap < 1):
            raise ValueError("INVALID_PEAK_LOAD_CAP")
        numeric = (self.alpha, self.gamma, self.delta, self.lambda_f,
                   self.lambda_r, self.theta_vv, self.theta_vh)
        if any(not math.isfinite(value) or value < 0 for value in numeric):
            raise ValueError("NEGATIVE_OR_INVALID_QSAP_WEIGHT")
        if not math.isfinite(self.t_ref_s) or self.t_ref_s <= 0:
            raise ValueError("INVALID_T_REF")
        if not math.isfinite(self.flight_time_scale_s) or self.flight_time_scale_s <= 0:
            raise ValueError("INVALID_FLIGHT_TIME_SCALE")
        if self.duration_field not in {"nominal_overlap_s", "guarded_overlap_s"}:
            raise ValueError("INVALID_OVERLAP_DURATION_FIELD")
        if self.overlap_basis not in {"PROTECTED_UNION", "NOMINAL_UNION_PLUS_RESIDUAL_HEADWAY"}:
            raise ValueError("INVALID_V3_OVERLAP_BASIS")
        if not self.headway_mode:
            raise ValueError("INVALID_V3_HEADWAY_MODE")
        if self.unknown_policy not in {"BLOCK_UNKNOWN_SRCM_COVERAGE", "ROBUST_UPPER_BOUND", "INTERVAL_AUDIT_ONLY"}:
            raise ValueError("INVALID_V3_UNKNOWN_POLICY")


def _event_weight(event: Mapping[str, Any], config: QsapConfig) -> float:
    kind = event["competition_type"]
    if kind not in {"VV", "VH"}:
        raise ValueError("INVALID_COMPETITION_TYPE")
    duration = float(event[config.duration_field])
    if not math.isfinite(duration) or duration < 0:
        raise ValueError("INVALID_EVENT_DURATION")
    theta = config.theta_vv if kind == "VV" else config.theta_vh
    return theta * duration / config.t_ref_s


def build_qsap_model(
    contract: Mapping[str, Any],
    sparse_srcm: Mapping[str, Any],
    plans: Sequence[Mapping[str, Any]],
    config: Optional[QsapConfig] = None,
    previous_node_by_uav: Optional[Mapping[str, str]] = None,
    active_assignment_summary: Optional[Mapping[str, Any]] = None,
) -> Dict[str, Any]:
    """Build Q1-Q4-ready sparse coefficients after all P1 hard gates."""
    config = config or QsapConfig()
    config.validate()
    if contract.get("qualification") != "PASS_ECJA_NON_ENERGY":
        raise ValueError("INPUT_CONTRACT_NOT_QUALIFIED")
    if sparse_srcm.get("srcm_version") != SRCM_VERSION or sparse_srcm.get("adapter_version") != ADAPTER_VERSION:
        raise ValueError("SRCM_VERSION_MISMATCH")
    if sparse_srcm.get("snapshot_id") != contract.get("snapshot_id") or sparse_srcm.get("scenario_hash") != contract.get("scenario_hash"):
        raise ValueError("SNAPSHOT_IDENTITY_MISMATCH")
    ledger = sparse_srcm["coverage_ledger"]
    statuses = expand_pair_statuses(sparse_srcm)
    if ledger.get("coverage_rate") != 1.0 or ledger.get("unknown_pairs") or any(v == "UNKNOWN" for v in statuses.values()):
        raise ValueError("INCOMPLETE_SRCM_COVERAGE")
    if not ledger.get("partition_count_check"):
        raise ValueError("INVALID_SRCM_COVERAGE_PARTITION")

    plan_by_id = {item["plan_id"]: item for item in plans}
    if len(plan_by_id) != len(plans):
        raise ValueError("DUPLICATE_PLAN_ID")
    allowed_plan_phases = {"H_CRUISE", "SOURCE_EXIT", "V_DESCENT", "OTHER_LEGAL_FLIGHT"}
    for plan in plans:
        if plan.get("plan_status") != "CANDIDATE":
            continue
        unsupported = sorted(set(phase_types(plan)) - allowed_plan_phases)
        if unsupported:
            raise ValueError("UNSUPPORTED_PLAN_PHASE:" + ",".join(map(str, unsupported)))
    fixed_ids = {item["plan_id"] for item in plans if item["plan_status"] == "FIXED"}
    fixed_contract_ids = {item["plan_id"] for item in contract.get("fixed_plans", [])}
    if fixed_ids != fixed_contract_ids:
        raise ValueError("FIXED_PLAN_SET_MISMATCH")

    candidates = list(contract["candidates"])
    candidate_by_id = {item["candidate_id"]: item for item in candidates}
    if len(candidate_by_id) != len(candidates):
        raise ValueError("DUPLICATE_CANDIDATE_ID")
    by_uav: Dict[str, list] = {}
    for item in candidates:
        by_uav.setdefault(item["uav_id"], []).append(item["candidate_id"])
    if not by_uav:
        raise ValueError("BLOCKED_NO_VALID_ASSIGNMENT")
    for values in by_uav.values():
        values.sort()

    # Keep all four physical ownership buckets for diagnostics. Only VV_CC
    # can become an active quadratic coefficient; VH_CC is never consumed by
    # graph construction, search scores, bounds, acceptance or tie breaking.
    event_seen = set()
    raw_events = list(sparse_srcm["events"])
    for event in raw_events:
        event_id = event.get("event_id")
        if event_id in event_seen:
            raise ValueError("DUPLICATE_EVENT_ID")
        event_seen.add(event_id)
    cached_unions = sparse_srcm.get("v3_union_aggregates")
    cached_basis = sparse_srcm.get("v3_union_aggregation_basis", OVERLAP_BASIS)
    event_unions = tuple(
        cached_unions
        if cached_unions is not None and cached_basis == config.overlap_basis
        else event_union_records(raw_events, overlap_basis=config.overlap_basis)
    )
    q_vv: Dict[str, float] = {}
    q_vh: Dict[str, float] = {}
    f_vv: Dict[str, float] = {candidate_id: 0.0 for candidate_id in candidate_by_id}
    f_vh: Dict[str, float] = {candidate_id: 0.0 for candidate_id in candidate_by_id}
    f: Dict[str, float] = {candidate_id: 0.0 for candidate_id in candidate_by_id}
    # Load balancing is keyed by the physical descent unit, i.e. the service
    # node plus the altitude layer.  Different layers of one facility use
    # different shafts and must not be charged against each other.
    candidate_to_load_key = {
        candidate_id: str(record["service_node_id"])
        + "|"
        + str(
            record.get("source_layer_id")
            if record.get("source_layer_id") is not None
            else plan_by_id.get(candidate_id, {}).get("source_layer_id")
        )
        for candidate_id, record in candidate_by_id.items()
    }
    # Resolve the service level before any cost is built.  The cap replaces the
    # convex penalty: once every unit is at or below K, spreading further only
    # adds flight time.  A cap below the geometric floor is relaxed to that
    # floor and reported, because no assignment could meet it.
    requested_cap = config.peak_load_cap
    effective_cap = None
    cap_status = None
    floor = None
    if requested_cap is not None:
        floor = min_achievable_peak({
            "uavs": sorted(by_uav),
            "candidate_ids_by_uav": by_uav,
            "candidate_to_load_key": candidate_to_load_key,
        })
        if floor is None:
            raise ValueError("BLOCKED_NO_VALID_ASSIGNMENT")
        effective_cap = max(int(requested_cap), int(floor))
        cap_status = "MET_TARGET" if effective_cap == requested_cap else "RELAXED_GEOMETRY"

    event_audit = []
    ownership_rows = []
    for union in event_unions:
        a, b = union["plan_a_id"], union["plan_b_id"]
        plan_a, plan_b = plan_by_id.get(a), plan_by_id.get(b)
        if plan_a is None or plan_b is None:
            raise ValueError("EVENT_ENDPOINT_OUTSIDE_FILTERED_MODEL")
        classification = role_class(plan_a, plan_b, union)
        kind = union["competition_type"]
        theta = config.theta_vv if kind == "VV" else config.theta_vh
        weight = coefficient_from_union(union, theta, config.t_ref_s)
        if classification.endswith("_CC"):
            if candidate_by_id.get(a, {}).get("uav_id") == candidate_by_id.get(b, {}).get("uav_id"):
                raise ValueError("ILLEGAL_SAME_UAV_CC_EVENT")
            key = canonical_pair(a, b)
            target = q_vv if classification == "VV_CC" else q_vh
            target[key] = target.get(key, 0.0) + weight
            owner = "quadratic_vv" if classification == "VV_CC" else "diagnostic_vh_cc"
        elif classification.endswith("_CF"):
            if a in candidate_by_id:
                candidate_id = a
            elif b in candidate_by_id:
                candidate_id = b
            else:
                raise ValueError("EVENT_ENDPOINT_OUTSIDE_FILTERED_MODEL")
            target = f_vv if classification == "VV_CF" else f_vh
            target[candidate_id] += weight
            f[candidate_id] += weight
            owner = "linear_vv_fixed" if classification == "VV_CF" else "linear_vh_fixed"
        elif classification.endswith("_BACKGROUND"):
            owner = "fixed_fixed_background"
        else:
            raise ValueError("INVALID_V3_COST_CLASSIFICATION")
        audit_row = {
            "pair_key": union["pair_key"],
            "crossing_id": union["crossing_id"],
            "competition_type": kind,
            "classification": classification,
            "weight": weight,
            "union_length_s": union["union_length_s"],
            "raw_event_count": union["raw_event_count"],
            "event_ids": list(union["event_ids"]),
            "role_pairs": [list(pair) for pair in union.get("role_pairs", ())],
            "headway_status": union.get("headway_status", config.headway_mode),
            "overlap_basis": union.get("overlap_basis", config.overlap_basis),
            "ownership": owner,
            "decision_active": config.objective_profile == "V3_CORE" and classification in {"VV_CC", "VV_CF", "VH_CF"},
        }
        event_audit.append(audit_row)
        ownership_rows.append(audit_row)
    q: Dict[str, float] = dict(sorted(q_vv.items())) if config.objective_profile == "V3_CORE" else {}
    if any(value < 0 or not math.isfinite(value) for values in (q, q_vv, q_vh, f_vv, f_vh) for value in values.values()):
        raise ValueError("INVALID_Q_COEFFICIENT")

    previous_node_by_uav = dict(previous_node_by_uav or {})
    costs: Dict[str, float] = {}
    access_costs: Dict[str, float] = {}
    components: Dict[str, Dict[str, float]] = {}
    for candidate_id, record in sorted(candidate_by_id.items()):
        plan = plan_by_id.get(candidate_id)
        if plan is None or plan.get("plan_status") != "CANDIDATE":
            raise ValueError("MISSING_CANDIDATE_PLAN")
        duration_s = float(plan["activity_end_s"]) - float(plan["activity_start_s"])
        if duration_s < 0:
            raise ValueError("NEGATIVE_FLIGHT_DURATION")
        node = record["service_node_id"]
        original = 0.0 if plan.get("is_current_assignment") else 1.0
        previous = previous_node_by_uav.get(record["uav_id"])
        switch = 0.0 if previous is None or previous == node else 1.0
        parts = {
            "flight": config.alpha * duration_s / config.flight_time_scale_s,
            "original_node_change": config.gamma * original,
            "previous_node_change": config.delta * switch,
            # Backward-compatible aggregate alias.  ``fixed_vv`` and
            # ``fixed_vh`` are the owned components used in the actual total;
            # the alias is intentionally not added a second time.
            "fixed_traffic": config.lambda_f * f[candidate_id],
            "fixed_vv": config.lambda_f * f_vv[candidate_id],
            "fixed_vh": config.lambda_f * f_vh[candidate_id],
        }
        components[candidate_id] = parts
        access_costs[candidate_id] = (
            parts["flight"]
            + parts["original_node_change"]
            + parts["previous_node_change"]
        )
        costs[candidate_id] = access_costs[candidate_id]
        if config.objective_profile == "V3_CORE":
            costs[candidate_id] += parts["fixed_vv"] + parts["fixed_vh"]

    q4_edges = [{"pair_key": key, "candidate_a": key.split("|", 1)[0], "candidate_b": key.split("|", 1)[1], "q": value}
                for key, value in sorted(q.items()) if value > 0]
    ownership_hash = union_digest(event_unions)
    candidate_domain_hash = hashlib.sha256(
        json.dumps({key: by_uav[key] for key in sorted(by_uav)}, sort_keys=True, separators=(",", ":")).encode()
    ).hexdigest()
    v3_bundle = {
        "objective_version": MODEL_VERSION,
        "objective_profile": config.objective_profile,
        "vh_cc_status": "DIAGNOSTIC_ONLY",
        "snapshot_id": contract["snapshot_id"],
        "scenario_hash": contract["scenario_hash"],
        "candidate_domain_hash": candidate_domain_hash,
        "unknown_policy": config.unknown_policy,
        "effective_K": effective_cap,
        "K_status": cap_status,
        "linear_access_cost": access_costs,
        "linear_vv_fixed_cost": f_vv,
        "linear_vh_fixed_cost": f_vh,
        "quadratic_vv_cost": q_vv,
        "quadratic_vh_cost": q_vh,
        "quadratic_total_cost": q,
        "diagnostic_w": {},
        "diagnostic_propagation_by_h": {},
        "cost_ownership_rows": ownership_rows,
    }
    return {
        "model_version": MODEL_VERSION,
        "objective_profile": config.objective_profile,
        "vh_cc_status": "DIAGNOSTIC_ONLY",
        "qualification": "PASS_ECJA_NON_ENERGY",
        "decision_dependency_scope": "NON_ENERGY_ONLY",
        "safe_status": "NOT_PRODUCED",
        "snapshot_id": contract["snapshot_id"],
        "scenario_hash": contract["scenario_hash"],
        "config": asdict(config),
        "uavs": sorted(by_uav),
        "candidate_ids_by_uav": {key: by_uav[key] for key in sorted(by_uav)},
        "candidate_to_uav": {key: candidate_by_id[key]["uav_id"] for key in sorted(candidate_by_id)},
        "candidate_to_node": {key: candidate_by_id[key]["service_node_id"] for key in sorted(candidate_by_id)},
        "candidate_to_load_key": {key: candidate_to_load_key[key] for key in sorted(candidate_to_load_key)},
        "service_level": {
            "key": "SERVICE_NODE_LAYER",
            "cap": effective_cap,
            "status": cap_status,
            "graph_edges": False,
        },
        "peak_load_cap": requested_cap,
        "peak_load_cap_effective": effective_cap,
        "peak_load_cap_status": cap_status,
        "min_achievable_peak": floor,
        "linear_costs": costs,
        "linear_cost_components": components,
        "linear_access_cost": access_costs,
        "fixed_competition": f,
        "linear_vv_fixed": f_vv,
        "linear_vh_fixed": f_vh,
        "linear_vv_fixed_cost": f_vv,
        "linear_vh_fixed_cost": f_vh,
        "active_assignment_summary": dict(active_assignment_summary or {}),
        "quadratic_costs": q,
        "quadratic_vv_costs": q_vv,
        "quadratic_vh_costs": q_vh,
        "quadratic_vv_cost": q_vv,
        "quadratic_vh_cost": q_vh,
        "quadratic_total_cost": q,
        "q4_nonzero_edges": q4_edges,
        "event_audit": event_audit,
        "union_records": list(event_unions),
        "srcm_union_aggregation_hash": ownership_hash,
        "candidate_domain_hash": candidate_domain_hash,
        "diagnostic_w": {},
        "diagnostic_propagation_by_h": {},
        "cost_ownership_rows": ownership_rows,
        "v3_objective_bundle": v3_bundle,
        "v3_objective": {
            "version": MODEL_VERSION,
            "coefficient_formula_version": V3_OBJECTIVE_VERSION,
            "overlap_basis": config.overlap_basis,
            "headway_mode": config.headway_mode,
            "unknown_policy": config.unknown_policy,
            "union_digest": ownership_hash,
            "headway_status": HEADWAY_MODE,
            "w_diagnostic": {},
            "propagation_diagnostic": {},
            "cost_ownership_rows": ownership_rows,
        },
        "coverage_audit": {
            "required_pairs": ledger["required_pairs"],
            "cc_required": ledger["cc_required"],
            "cf_required": ledger["cf_required"],
            "coverage_rate": ledger["coverage_rate"],
            "unknown_pairs": ledger["unknown_pairs"],
            "pair_status_count": len(statuses),
        },
    }


def validate_assignment(model: Mapping[str, Any], assignment: Mapping[str, str]) -> None:
    if set(assignment) != set(model["uavs"]):
        raise ValueError("Q1_UAV_SET_MISMATCH")
    for uav_id, candidate_id in assignment.items():
        if candidate_id not in model["candidate_ids_by_uav"][uav_id]:
            raise ValueError("Q1_INVALID_CANDIDATE")


def evaluate_q3(model: Mapping[str, Any], assignment: Mapping[str, str]) -> Dict[str, float]:
    validate_assignment(model, assignment)
    selected = set(assignment.values())
    linear = sum(float(model["linear_costs"][candidate]) for candidate in selected)
    quadratic_unscaled = sum(float(value) for key, value in model["quadratic_costs"].items()
                             if set(key.split("|", 1)).issubset(selected))
    quadratic = float(model["config"]["lambda_r"]) * quadratic_unscaled
    return {
        "linear": linear,
        "quadratic": quadratic,
        "total": linear + quadratic,
    }


def objective_components(model: Mapping[str, Any], assignment: Mapping[str, str]) -> Dict[str, Any]:
    """Owned costs and active objective, with VH_CC explicitly diagnostic.

    CF components stored in linear_cost_components are already weighted.
    Raw CF and CC dictionaries remain available for physical-cost auditing.
    """
    validate_assignment(model, assignment)
    selected = set(assignment.values())
    j0 = sum(model["linear_access_cost"][c] for c in selected)
    fixed_vv = sum(model["linear_cost_components"][c]["fixed_vv"] for c in selected)
    fixed_vh = sum(model["linear_cost_components"][c]["fixed_vh"] for c in selected)
    def selected_pairs(values):
        return float(model["config"]["lambda_r"])*sum(v for k,v in values.items()
            if set(k.split("|",1)).issubset(selected))
    active = model["objective_profile"] == "V3_CORE"
    return {"objective_profile":model["objective_profile"], "J0":j0,
            "VV_CF":fixed_vv if active else 0., "VH_CF":fixed_vh if active else 0.,
            "VV_CC":selected_pairs(model["quadratic_vv_costs"]) if active else 0.,
            "VH_CC_diagnostic":selected_pairs(model["quadratic_vh_costs"]),
            "active_total":evaluate_q3(model,assignment)["total"],
            "VH_CC_active":False}


def q4_product_is_valid(x_a: int, x_b: int, y: int) -> bool:
    return all(value in (0, 1) for value in (x_a, x_b, y)) and y >= x_a + x_b - 1 and y <= x_a and y <= x_b


def potential_graph_stats(model: Mapping[str, Any]) -> Dict[str, Any]:
    adjacency = {uav: set() for uav in model["uavs"]}
    for key, value in model["quadratic_costs"].items():
        if value <= 0:
            continue
        a, b = key.split("|", 1)
        ua, ub = model["candidate_to_uav"][a], model["candidate_to_uav"][b]
        adjacency[ua].add(ub)
        adjacency[ub].add(ua)
    components = []
    unseen = set(adjacency)
    while unseen:
        root = min(unseen)
        stack, component = [root], []
        unseen.remove(root)
        while stack:
            node = stack.pop()
            component.append(node)
            for neighbor in sorted(adjacency[node], reverse=True):
                if neighbor in unseen:
                    unseen.remove(neighbor)
                    stack.append(neighbor)
        components.append(sorted(component))
    variable = [uav for uav, candidates in model["candidate_ids_by_uav"].items() if len(candidates) >= 2]
    variable_set = set(variable)
    coupled_edges = sum(1 for a, ns in adjacency.items() for b in ns if a < b and a in variable_set and b in variable_set)
    return {
        "potential_uav_edge_count": sum(len(value) for value in adjacency.values()) // 2,
        "connected_components": components,
        "component_count": len(components),
        "variable_uav_count": len(variable),
        "variable_uav_ids": variable,
        "variable_candidate_coupling_edge_count": coupled_edges,
        "has_real_srcm_variable_candidate_quadratic_coupling": coupled_edges > 0,
    }
