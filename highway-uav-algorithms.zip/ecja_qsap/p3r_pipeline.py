"""P3 offline full-chain entry point with authoritative wall-clock receipt."""

from __future__ import annotations

import copy
import dataclasses
import hashlib
import json
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, Mapping, Optional

from .cb_lns import CBLNSConfig, solve_cb_lns
from .contracts import build_parameterized_request_states, build_research_input_contract
from .p3r_optimality import enforce_proof_status
from .conflict_graph import build_graphs, minimum_linear_assignment
from .oracle import audit_objective, independent_q3_recompute
from .load_balance import capacitated_initial_assignment
from .qsap import QsapConfig, build_qsap_model, potential_graph_stats
from .sparse_srcm import SparseSrcmCache, evaluate_sparse_srcm


PIPELINE_VERSION = "ECJA_QSAP_V3_2_1_P3_DEV"
# Research scope: per-round assignment invalidation (snapshot staleness,
# physical deadline expiry, wall-clock overrun) is recorded for
# observability but does not participate in decision validity.  Only contract
# qualification and independent objective audit can block a decision.
DECISION_VALIDITY_SCOPE = "TIMING_PREDICATES_RECORDED_NOT_ENFORCED"
# The algorithm carries no completion deadline.  Search stops on deterministic
# work limits, so the same snapshot reproduces the same incumbent regardless of
# machine speed.


@dataclass
class P3Config:
    cb_lns: CBLNSConfig = field(default_factory=CBLNSConfig)
    cache: Optional[SparseSrcmCache] = None
    request_id: str = "ECJA_P3_DEV_REQUEST"
    race_hook: Optional[Callable[[str], None]] = None
    serialization_failure: bool = False
    request_state_overrides: Optional[Mapping[str, Mapping[str, Any]]] = None
    scenario_clock: Optional[Callable[[], float]] = None
    # The runtime adapter may already have built the auditable QSAP model
    # from the exact fixed-traffic summary it is returning to callers.  When
    # supplied, the formal solver must consume that same model rather than
    # silently rebuilding a second model without the runtime projection.
    qsap_model: Optional[Mapping[str, Any]] = None
    peak_load_cap: Optional[int] = None


@dataclass(frozen=True)
class _PreparedBatch:
    """Call-local owned artifacts from algorithm.py; never a cross-call cache.

    The private fast path is bound to the exact scene and model objects. Public
    snapshot readers and configurable/race-hook calls retain full preparation.
    """
    scene: Mapping[str, Any]
    contract: Mapping[str, Any]
    sparse: Mapping[str, Any]
    model: Mapping[str, Any]


class MutableSnapshotSource:
    def __init__(self, scene: Mapping[str, Any]):
        self.scene = copy.deepcopy(scene)

    def read(self) -> Dict[str, Any]:
        return copy.deepcopy(self.scene)

    def identity(self):
        return (self.scene["meta"].get("snapshot_id"), self.scene["meta"].get("scenario_hash"))

    def mutate_version(self, suffix="RACE"):
        self.scene["meta"]["snapshot_id"] += ":" + suffix
        self.scene["meta"]["scenario_hash"] = hashlib.sha256(self.scene["meta"]["snapshot_id"].encode()).hexdigest()


def _identity(scene):
    return scene["meta"].get("snapshot_id"), scene["meta"].get("scenario_hash")


def _read(source):
    return source.read() if hasattr(source, "read") else copy.deepcopy(source)


def _source_identity(source):
    return source.identity() if hasattr(source, "identity") else _identity(source)


def _mark(timing, key, started):
    timing[key] = (time.perf_counter_ns() - started) / 1e6


def _failure(reason, request_id, snapshot=None, detail=None):
    return {"algorithm": PIPELINE_VERSION, "spec_version": "ECJA_QSAP_V3_2_1", "request_id": request_id,
            "snapshot_id": snapshot[0] if snapshot else None, "snapshot_hash": snapshot[1] if snapshot else None,
            "p0_contract_status": "BLOCKED", "assignment_status": "BLOCKED_NO_VALID_ASSIGNMENT",
            "result_validity": "BLOCKED", "solver_status": "NO_VALID_SOLUTION", "termination_reason": reason,
            "decision_dependency_scope": "NON_ENERGY_ONLY", "safe_status": "NOT_PRODUCED", "handoff_mode": "NON_ATOMIC_HANDOFF",
            "service_queues": {}, "unassigned": [], "diagnostics": {"detail": detail}}


def _queues(contract, model, sparse, assignment):
    records = {item["candidate_id"]: item for item in contract["candidates"]}
    uses = {}
    for use in sparse["uses"]:
        uses.setdefault(use["plan_id"], []).append(use["use_id"])
    queues = {}
    for uav, candidate_id in assignment.items():
        record = records[candidate_id]
        item = {"uav_id": uav, "assigned_node_id": record["service_node_id"], "source_layer": record["source_layer_id"],
                "candidate_id": candidate_id, "candidate_path_id": record["path"]["route_id"],
                "estimated_arrival_s": record["eta"]["estimated_arrival_s"], "eta_reference_point": record["eta"]["eta_reference_point"],
                "crossing_use_ids": sorted(uses.get(candidate_id, [])), "request_status": "ASSIGNED_CANDIDATE"}
        queues.setdefault(record["service_node_id"], []).append(item)
    for values in queues.values():
        values.sort(key=lambda item: (item["estimated_arrival_s"], item["uav_id"], item["candidate_id"]))
    return dict(sorted(queues.items()))


def _validate_dto(dto):
    required = {"algorithm", "spec_version", "result_validity", "solver_status", "termination_reason", "decision_dependency_scope", "safe_status", "service_queues", "unassigned"}
    if not required.issubset(dto):
        raise ValueError("DTO_REQUIRED_FIELD_MISSING")
    if dto["decision_dependency_scope"] != "NON_ENERGY_ONLY" or dto["safe_status"] != "NOT_PRODUCED":
        raise ValueError("DTO_QUALIFICATION_ESCALATION")


def ecja_assign(snapshot_source, config: Optional[P3Config] = None, *, _prepared: Optional[_PreparedBatch] = None):
    cfg = config or P3Config()
    outer_start = time.perf_counter_ns()
    timing, scene, dto, payload = {}, None, None, None
    initial_identity = None
    search_wall_ms = 0.0
    try:
        reuse = _prepared is not None
        if reuse and (snapshot_source is not _prepared.scene or cfg.qsap_model is not _prepared.model
                      or cfg.race_hook is not None or cfg.request_state_overrides is not None):
            raise ValueError("PREPARED_BATCH_CONTEXT_MISMATCH")
        stage = time.perf_counter_ns(); scene = _prepared.scene if reuse else _read(snapshot_source); _mark(timing, "snapshot_io_ms", stage)
        initial_identity = _identity(scene)
        if cfg.race_hook: cfg.race_hook("after_snapshot")
        stage = time.perf_counter_ns()
        if reuse:
            contract = _prepared.contract
            if (contract.get("snapshot_id"), contract.get("scenario_hash")) != initial_identity:
                raise ValueError("PREPARED_BATCH_SNAPSHOT_MISMATCH")
        else:
            states = build_parameterized_request_states(scene)
            states.update(copy.deepcopy(scene.get("ecja_request_state_overrides", {})))
            if cfg.request_state_overrides:
                for uav, values in cfg.request_state_overrides.items():
                    states.setdefault(uav, {}).update(dict(values))
            contract = build_research_input_contract(scene, request_state_overrides=states)
        _mark(timing, "contract_non_energy_eta_ms", stage)
        if not contract["requests"]:
            raise ValueError("NO_REQUESTS")
        if contract["qualification"] != "PASS_ECJA_NON_ENERGY":
            raise ValueError("INPUT_CONTRACT_BLOCKED")
        exceptions = [item for item in contract["requests"] if item["traffic_disposition"] != "OPTIMIZABLE"]
        if exceptions:
            raise ValueError("REQUEST_EXCEPTIONS_PRESENT")
        eligible = {item["candidate_id"] for item in contract["candidates"]}
        filtered = scene if reuse else copy.deepcopy(scene)
        if reuse:
            if {p["plan_id"] for p in scene["plans"] if p["plan_status"] == "CANDIDATE"} != eligible:
                raise ValueError("PREPARED_BATCH_CANDIDATE_SET_MISMATCH")
        else:
            filtered["plans"] = [plan for plan in scene["plans"] if plan["plan_status"] == "FIXED" or plan["plan_id"] in eligible]
        if cfg.race_hook: cfg.race_hook("during_optimization")
        stage = time.perf_counter_ns(); sparse = _prepared.sparse if reuse else evaluate_sparse_srcm(filtered, cache=cfg.cache); srcm_ms = (time.perf_counter_ns() - stage) / 1e6
        if (sparse.get("snapshot_id"), sparse.get("scenario_hash")) != initial_identity:
            raise ValueError("PREPARED_BATCH_SRCM_IDENTITY_MISMATCH")
        timing["srcm_visit_build_ms"] = 0.0 if reuse else sparse["timing"]["visit_adaptation_s"] * 1000
        timing["srcm_pairs_cert_ms"] = srcm_ms - timing["srcm_visit_build_ms"]
        stage = time.perf_counter_ns()
        if cfg.qsap_model is None:
            model = build_qsap_model(contract, sparse, filtered["plans"],
                                     QsapConfig(peak_load_cap=cfg.peak_load_cap))
            model_source = "FORMAL_PIPELINE_REBUILT"
        else:
            model = _prepared.model if reuse else copy.deepcopy(dict(cfg.qsap_model))
            if (
                model.get("snapshot_id") != contract.get("snapshot_id")
                or model.get("scenario_hash") != contract.get("scenario_hash")
            ):
                raise ValueError("QSAP_MODEL_SNAPSHOT_IDENTITY_MISMATCH")
            if set(model.get("uavs", ())) != {str(item["uav_id"]) for item in contract["candidates"]}:
                raise ValueError("QSAP_MODEL_REQUEST_SET_MISMATCH")
            model_source = "RUNTIME_ADAPTER_COMMON_MODEL"
        _mark(timing, "qsap_build_ms", stage)
        model_stats = potential_graph_stats(model)
        stage = time.perf_counter_ns(); build_graphs(model); _mark(timing, "graph_init_ms", stage)
        stage = time.perf_counter_ns()
        cap = model.get("peak_load_cap_effective")
        first_assignment = (capacitated_initial_assignment(model, int(cap)) if cap is not None
                            else minimum_linear_assignment(model))
        first_objective = independent_q3_recompute(model, first_assignment)
        _mark(timing, "initial_incumbent_ms", stage)
        first_incumbent_ms = (time.perf_counter_ns() - outer_start) / 1e6
        stage = time.perf_counter_ns()
        solver_cfg = cfg.cb_lns
        search_started = time.perf_counter_ns()
        solved = solve_cb_lns(model, solver_cfg)
        search_wall_ms = (time.perf_counter_ns()-search_started)/1e6
        solved = enforce_proof_status(model, solved, solver_cfg.eps)
        solve_ms = (time.perf_counter_ns() - stage) / 1e6
        first_improvement_upper_ms = (time.perf_counter_ns() - outer_start) / 1e6 if solved.get("changed_uavs") else None
        timing["bnb_ms"] = sum(row["elapsed_ms"] for row in solved["diagnostics"]["task_log"])
        timing["scheduler_frontier_ms"] = max(0.0, solve_ms - timing["bnb_ms"])
        timing["solver_only_ms"] = solve_ms
        stage = time.perf_counter_ns()
        audit = audit_objective(model, solved["final_assignment"], solved["final_objective"]["total"])
        _mark(timing, "independent_audit_ms", stage)
        if audit["status"] != "PASS": raise ValueError("INDEPENDENT_Q3_AUDIT_FAILED")
        if cfg.race_hook: cfg.race_hook("before_serialization")
        stage = time.perf_counter_ns(); queues = _queues(contract, model, sparse, solved["final_assignment"]); _mark(timing, "queue_export_ms", stage)
        dto = {"algorithm": PIPELINE_VERSION, "spec_version": "ECJA_QSAP_V3_2_1", "request_id": cfg.request_id,
               "snapshot_id": initial_identity[0], "snapshot_hash": initial_identity[1], "p0_contract_status": "PASS_ECJA_NON_ENERGY",
               "assignment_status": "FEASIBLE_UNCERTIFIED", "result_validity": "VALID_CANDIDATE_ONLY", "solver_status": solved["solver_status"],
               "termination_reason": solved["termination_reason"], "decision_dependency_scope": "NON_ENERGY_ONLY", "safe_status": "NOT_PRODUCED",
               "handoff_mode": "NON_ATOMIC_HANDOFF", "srcm_cc_coverage_rate": sparse["coverage_ledger"]["cc_coverage_rate"],
               "srcm_cf_coverage_rate": sparse["coverage_ledger"]["cf_coverage_rate"], "service_queues": queues, "unassigned": [],
               "global_optimality_proof": solved["global_optimality_proof"], "diagnostics": {"objective_initial": solved["initial_objective"], "objective_final": solved["final_objective"], "model_stats": model_stats,
               "proof_class": solved["global_optimality_proof"].get("proof_class"),
               "provable_coverage": solved["global_optimality_proof"].get("provable_coverage"),
               "component_stats": solved["global_optimality_proof"].get("component_stats"),
               "anytime_trace": {"time_to_first_valid_incumbent_ms":first_incumbent_ms,
                                  "time_to_first_accepted_improvement_ms":None,
                                  "time_to_first_accepted_improvement_upper_bound_ms":first_improvement_upper_ms,
                                  "points":[{"t_ms":first_incumbent_ms,"objective":first_objective["total"],"kind":"FIRST_VALID_INCUMBENT"},
                                            {"t_ms":(time.perf_counter_ns()-outer_start)/1e6,"objective":solved["final_objective"]["total"],"kind":"FINAL_INCUMBENT"}],
                                  "limitation":"frozen P2 solver exposes task outcomes but not an exact acceptance timestamp; upper bound is solver return"},
               "srcm": {"uses": len(sparse["uses"]), "events": len(sparse["events"]),
                        "event_type_counts":{"VV":sum(e["competition_type"]=="VV" for e in sparse["events"]),"VH":sum(e["competition_type"]=="VH" for e in sparse["events"])},
                        "coverage": sparse["coverage_ledger"], "cache": sparse["cache_metrics"], "timing": sparse["timing"]},
               "qsap":{"model_source": model_source,
                       "positive_q_candidate_edges":len(model["q4_nonzero_edges"]),
                       "fixed_cf_cost_total":sum(model["fixed_competition"].values()),
                       "linear_cost_total":sum(model["linear_costs"].values()),
                       "peak_load":int(solved["diagnostics"].get("service_level", {}).get("peak_load", 0)),
                       "service_level_cap":solved["diagnostics"].get("service_level", {}).get("cap_effective")},
               "scheduler": solved["diagnostics"], "independent_audit": audit, "pre_serialization_timing_ms": timing}}
        _validate_dto(dto)
        if cfg.serialization_failure: dto["bad"] = {1, 2}
        stage = time.perf_counter_ns(); payload = json.dumps(dto, ensure_ascii=False, sort_keys=True, allow_nan=False).encode("utf-8"); _mark(timing, "serialization_ms", stage)
        if cfg.race_hook: cfg.race_hook("after_serialization_before_handoff")
        stage = time.perf_counter_ns(); post_ok = _source_identity(snapshot_source) == initial_identity
        selected_plans = {plan["plan_id"]:plan for plan in filtered["plans"] if plan["plan_status"] == "CANDIDATE"}
        deadlines = [selected_plans[c]["ecja_forward_contract"] for c in solved["final_assignment"].values()
                     if c in selected_plans
                     and selected_plans[c].get("ecja_forward_contract", {}).get("latest_switch_time_s") is not None]
        deadline_resolved = len(deadlines) == len(solved["final_assignment"])
        scenario_now = float(cfg.scenario_clock()) if cfg.scenario_clock else float(scene["meta"].get("t0_s", 0.0)) + (time.perf_counter_ns()-outer_start)/1e9
        latest_allowed = min((d["latest_switch_time_s"]-d.get("handoff_margin_s",0.0)-d.get("research_margin_s",0.0) for d in deadlines), default=None)
        deadline_ok = not deadline_resolved or scenario_now <= latest_allowed + 1e-12
        _mark(timing, "post_serialization_check_ms", stage)
        # Timing predicates are recorded, not enforced.  The research scope
        # explicitly excludes per-round assignment invalidation from decision
        # validity: a decision is reported as a valid candidate for the
        # snapshot it was computed on.  Version races remain rejected by the
        # commit-time version comparison, which is the only place that owns
        # the traffic state.
        dto["snapshot_validated_after_serialization"] = bool(post_ok)
        if not deadline_resolved:
            dto["physical_deadline_status"] = "DEADLINE_UNRESOLVED_OFFLINE_RESEARCH_ONLY"
        elif deadline_ok:
            dto["physical_deadline_status"] = "RESOLVED_AND_VALID"
        else:
            dto["physical_deadline_status"] = "EXPIRED_RECORDED_ONLY"
        dto["decision_validity_scope"] = DECISION_VALIDITY_SCOPE
        dto["timing_validity"] = {
            "snapshot_ok": bool(post_ok),
            "deadline_ok": bool(deadline_ok),
            "deadline_resolved": bool(deadline_resolved),
            "scenario_output_time_s": scenario_now,
            "latest_allowed_s": latest_allowed,
            "enforcement": "RECORDED_NOT_ENFORCED",
        }
        dto["scenario_output_time_s"] = scenario_now
        dto["selected_latest_switch_time_s"] = {uav:selected_plans[c]["ecja_forward_contract"]["latest_switch_time_s"] for uav,c in solved["final_assignment"].items() if c in selected_plans and "ecja_forward_contract" in selected_plans[c]}
        stage = time.perf_counter_ns(); payload = json.dumps(dto, ensure_ascii=False, sort_keys=True, allow_nan=False).encode("utf-8"); timing["serialization_ms"] += (time.perf_counter_ns() - stage) / 1e6
    except StopIteration:
        pass
    except Exception as error:
        dto = _failure(str(error), cfg.request_id, initial_identity, type(error).__name__)
        stage = time.perf_counter_ns(); payload = json.dumps(dto, ensure_ascii=False, sort_keys=True).encode("utf-8"); timing["serialization_ms"] = timing.get("serialization_ms", 0.0) + (time.perf_counter_ns() - stage) / 1e6
        timing.setdefault("post_serialization_check_ms", 0.0)
    ready_ns = time.perf_counter_ns()
    total_ms = (ready_ns - outer_start) / 1e6
    timing["total_decision_wall_ms"] = total_ms
    # solver_only_ms is a convenience subtotal of scheduler_frontier + B&B and
    # must not be counted again in the phase-accounting reconciliation.
    measured = sum(value for key, value in timing.items() if key not in {"total_decision_wall_ms", "solver_only_ms"})
    timing["accounting_residual_ms"] = total_ms - measured
    receipt = {"request_id": cfg.request_id, "snapshot_hash": initial_identity[1] if initial_identity else None,
               "output_bytes_sha256": hashlib.sha256(payload).hexdigest(), "output_bytes": len(payload), "timing_ms": timing,
               "total_decision_wall_ms": total_ms,
               "search_wall_ms": search_wall_ms,
               "result_validity": dto["result_validity"], "handoff_mode": "NON_ATOMIC_HANDOFF"}
    return {"candidate_dto": dto, "candidate_bytes": payload, "timing_receipt": receipt}
