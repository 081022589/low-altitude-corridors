"""V3-QQ-BASE objective primitives.

This module is deliberately independent of the search implementation.  It
turns canonical SRCM events into partition-invariant physical-resource union
records and classifies candidate/fixed endpoints by their observed H/V role.
The returned coefficients are non-negative and can be consumed by the frozen
QSAP/CB-LNS/local-B&B stack.
"""

from __future__ import annotations

import hashlib
import json
import math
from collections import defaultdict
from typing import Any, Dict, Iterable, Mapping, Sequence, Tuple


V3_OBJECTIVE_VERSION = "ECJA_V3_QQ_BASE_1_1"
OVERLAP_BASIS = "NOMINAL_UNION_PLUS_RESIDUAL_HEADWAY"
PROTECTED_OVERLAP_BASIS = "PROTECTED_UNION"
HEADWAY_MODE = "UNAVAILABLE_UNTIL_ENTRY_TIMES"


def canonical_pair(left: str, right: str) -> str:
    return "|".join(sorted((str(left), str(right))))


def _stable_hash(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def interval_union(intervals: Iterable[Tuple[float, float]], tolerance: float = 1e-9) -> Tuple[Tuple[float, float], ...]:
    """Return a deterministic half-open interval union."""

    clean = []
    for start, end in intervals:
        start, end = float(start), float(end)
        if not math.isfinite(start) or not math.isfinite(end):
            raise ValueError("V3_INVALID_UNION_INTERVAL")
        if end - start > tolerance:
            clean.append((start, end))
    clean.sort()
    merged = []
    for start, end in clean:
        if not merged or start > merged[-1][1] + tolerance:
            merged.append([start, end])
        else:
            merged[-1][1] = max(merged[-1][1], end)
    return tuple((float(start), float(end)) for start, end in merged)


def union_measure(intervals: Iterable[Tuple[float, float]], tolerance: float = 1e-9) -> float:
    return sum(end - start for start, end in interval_union(intervals, tolerance))


def event_union_records(
    events: Sequence[Mapping[str, Any]],
    tolerance: float = 1e-9,
    overlap_basis: str = OVERLAP_BASIS,
) -> Tuple[Dict[str, Any], ...]:
    """Aggregate raw SRCM events by unordered plan pair/resource/type.

    The raw event list is untouched.  In nominal mode guard-only events remain
    visible as zero-measure audit records, while protected mode includes their
    guard-expanded interval.  A future implementation that has explicit entry
    times may populate a separate headway term; the current runtime records
    that component as unavailable and therefore sets it to zero.
    """

    if overlap_basis not in {OVERLAP_BASIS, PROTECTED_OVERLAP_BASIS}:
        raise ValueError("V3_INVALID_OVERLAP_BASIS")
    groups: Dict[Tuple[str, str, str, str], list] = defaultdict(list)
    for event in events:
        if overlap_basis == PROTECTED_OVERLAP_BASIS and (
            "guarded_overlap_start_s" not in event or "guarded_overlap_end_s" not in event
        ):
            raise ValueError("V3_PROTECTED_INTERVAL_FIELDS_MISSING")
        if overlap_basis == PROTECTED_OVERLAP_BASIS:
            guarded_start = float(event["guarded_overlap_start_s"])
            guarded_end = float(event["guarded_overlap_end_s"])
            if not math.isfinite(guarded_start) or not math.isfinite(guarded_end) or guarded_end <= guarded_start:
                raise ValueError("V3_INVALID_PROTECTED_INTERVAL")
        event_id = str(event.get("event_id", ""))
        left, right = sorted((str(event["plan_a_id"]), str(event["plan_b_id"])))
        key = (left, right, str(event["crossing_id"]), str(event["competition_type"]))
        groups[key].append(event)

    records = []
    for key in sorted(groups):
        left, right, crossing_id, kind = key
        rows = groups[key]
        if overlap_basis == PROTECTED_OVERLAP_BASIS:
            source_intervals = (
                (
                    float(row.get("guarded_overlap_start_s", row["overlap_start_s"])),
                    float(row.get("guarded_overlap_end_s", row["overlap_end_s"])),
                )
                for row in rows
            )
        else:
            # In the nominal mode guard-only events carry zero nominal measure.
            # Their entry-time residual G is retained as an explicit audit
            # status, but remains zero until authoritative entry timestamps are
            # available to the decision-time adapter.
            source_intervals = (
                (float(row["overlap_start_s"]), float(row["overlap_end_s"]))
                for row in rows
                if "nominal_overlap_s" not in row or float(row.get("nominal_overlap_s", 0.0)) > tolerance
            )
        intervals = interval_union(source_intervals, tolerance)
        union_length = sum(end - start for start, end in intervals)
        event_ids = sorted(str(row.get("event_id", "")) for row in rows)
        role_pairs = sorted({(str(row.get("role_a", "")), str(row.get("role_b", ""))) for row in rows})
        records.append({
            "pair_key": left + "|" + right,
            "plan_a_id": left,
            "plan_b_id": right,
            "crossing_id": crossing_id,
            "competition_type": kind,
            "union_intervals": intervals,
            "union_length_s": float(union_length),
            "raw_event_count": len(rows),
            "event_ids": event_ids,
            "role_pairs": role_pairs,
            "headway_component": 0.0,
            "headway_status": HEADWAY_MODE,
            "overlap_basis": overlap_basis,
        })
    return tuple(records)


def role_class(plan_a: Mapping[str, Any], plan_b: Mapping[str, Any], event: Mapping[str, Any]) -> str:
    """Classify the endpoint relation using the physical SRCM roles."""

    statuses = {str(plan_a.get("plan_status")), str(plan_b.get("plan_status"))}
    if str(event.get("competition_type")) == "VV":
        if statuses == {"CANDIDATE"}:
            return "VV_CC"
        if statuses == {"CANDIDATE", "FIXED"}:
            return "VV_CF"
        return "VV_BACKGROUND"
    if str(event.get("competition_type")) == "VH":
        if statuses == {"CANDIDATE"}:
            return "VH_CC"
        if statuses == {"CANDIDATE", "FIXED"}:
            return "VH_CF"
        return "VH_BACKGROUND"
    raise ValueError("V3_INVALID_COMPETITION_TYPE")


def _finite_nonnegative(value: float, code: str) -> float:
    value = float(value)
    if not math.isfinite(value) or value < 0:
        raise ValueError(code)
    return value


def union_digest(records: Sequence[Mapping[str, Any]]) -> str:
    payload = []
    for row in records:
        payload.append({
            "pair_key": row["pair_key"],
            "crossing_id": row["crossing_id"],
            "competition_type": row["competition_type"],
            "overlap_basis": row.get("overlap_basis", OVERLAP_BASIS),
            "union_intervals": [[float(a), float(b)] for a, b in row["union_intervals"]],
            "headway_component": float(row.get("headway_component", 0.0)),
        })
    return _stable_hash(payload)


def coefficient_from_union(record: Mapping[str, Any], theta: float, t_ref_s: float) -> float:
    theta = _finite_nonnegative(theta, "V3_INVALID_THETA")
    t_ref_s = float(t_ref_s)
    if not math.isfinite(t_ref_s) or t_ref_s <= 0:
        raise ValueError("V3_INVALID_T_REF")
    return theta * (
        float(record["union_length_s"]) / t_ref_s
        + float(record.get("headway_component", 0.0))
    )


__all__ = [
    "HEADWAY_MODE",
    "OVERLAP_BASIS",
    "PROTECTED_OVERLAP_BASIS",
    "V3_OBJECTIVE_VERSION",
    "canonical_pair",
    "coefficient_from_union",
    "event_union_records",
    "interval_union",
    "role_class",
    "union_digest",
    "union_measure",
]
