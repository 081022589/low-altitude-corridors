"""P2 component-fair progressive CB-LNS scheduler."""

from __future__ import annotations

import hashlib
import itertools
import json
import math
import time
from dataclasses import asdict, dataclass
from typing import Any, Dict, List, Mapping, Optional, Sequence, Tuple

from .conflict_graph import build_graphs, connected_expansions, d_scores, directed_h_index, h_score, minimum_linear_assignment, pair_key, w_scores
from .load_balance import capacitated_initial_assignment
from .local_bnb import LocalBudget, solve_local_bnb
from .oracle import audit_objective, independent_q3_recompute
from .qsap import objective_model_hash


ALGORITHM = "ECJA_QSAP_V3_2_1_CB_LNS"


def _hash(value: Any) -> str:
    return hashlib.sha256(json.dumps(value, sort_keys=True, separators=(",", ":"), allow_nan=False).encode()).hexdigest()


@dataclass(frozen=True)
class CBLNSConfig:
    b_uav: int = 8
    b_comb: int = 65536
    b_nodes: int = 200000
    b_expand: int = 8
    b_tasks_per_seed: int = 32
    b_tasks_per_round: int = 16
    b_total_tasks: int = 1000
    b_frontier_max: int = 4096
    b_generated_max: int = 10000
    b_scheduler_ops_per_turn: int = 256
    b_max_rounds: int = 1000
    # No wall-clock stop.  The search ends on deterministic work limits
    # (tasks, rounds, frontier, per-group nodes), so the same input yields the
    # same incumbent on any machine.
    eps: float = 1e-9
    config_status: str = "P2_DETERMINISTIC_WORK_LIMIT_DEFAULT"

    def validate(self) -> None:
        integers = (self.b_uav, self.b_comb, self.b_nodes, self.b_expand, self.b_tasks_per_seed,
                    self.b_tasks_per_round, self.b_total_tasks, self.b_frontier_max, self.b_generated_max,
                    self.b_scheduler_ops_per_turn, self.b_max_rounds)
        if any(value <= 0 for value in integers):
            raise ValueError("INVALID_CB_LNS_INTEGER_BUDGET")
        if self.eps < 0:
            raise ValueError("INVALID_CB_LNS_EPS")


def _combination_count(model: Mapping[str, Any], group: Sequence[str]) -> int:
    return math.prod(len(model["candidate_ids_by_uav"][uav]) for uav in group)


def _group_load_keys(model: Mapping[str, Any], group: Sequence[str]) -> set:
    """Descent units this group could use; only relevant under a service level.

    A capacity cap makes a group's feasible set depend on how many aircraft the
    rest of the batch put on each unit, so the proof context must include the
    outside counts.  Without a cap there is no such dependency.
    """

    mapping = model.get("candidate_to_load_key") or {}
    if not mapping or model.get("peak_load_cap_effective") is None:
        return set()
    return {mapping[c] for u in group for c in model["candidate_ids_by_uav"][u] if c in mapping}


def _proof_key(
    model: Mapping[str, Any], assignment: Mapping[str, str], group: Sequence[str],
    *, model_hash: Optional[str] = None,
) -> str:
    members = set(group)
    related_outside = sorted({
        other for uav in group for candidate in model["candidate_ids_by_uav"][uav]
        for other in model["uavs"] if other not in members
        if any(model["quadratic_costs"].get(pair_key(candidate, other_candidate), 0.0) > 0 for other_candidate in model["candidate_ids_by_uav"][other])
    })
    load_keys = _group_load_keys(model, group)
    outside_load_counts = {key: 0 for key in load_keys}
    mapping = model.get("candidate_to_load_key") or {}
    for uav, candidate in assignment.items():
        key = mapping.get(candidate)
        if uav not in members and key in outside_load_counts:
            outside_load_counts[key] += 1
    return _hash({"snapshot": model.get("scenario_hash"), "model": model_hash or objective_model_hash(model),
                  "group": sorted(group), "inside": {u: assignment[u] for u in sorted(group)},
                  "outside": {u: assignment[u] for u in related_outside},
                  "outside_load_counts": outside_load_counts, "version": "P2_PROOF_KEY_V2_FULL_OBJECTIVE_LOAD"})


def _all_connected_groups(component: Sequence[str], graph: Mapping[str, Any], model: Mapping[str, Any], assignment: Mapping[str, str], cfg: CBLNSConfig, diagnostics: Dict[str, Any]) -> List[Tuple[str, ...]]:
    variable = sorted(uav for uav in component if len(model["candidate_ids_by_uav"][uav]) >= 2)
    d, w, directed = d_scores(model, assignment, graph), w_scores(model, graph), directed_h_index(model, assignment, graph)
    seeds = sorted(variable, key=lambda uav: (-d[uav], -w[uav], uav))
    generated, groups = set(), []
    for seed in seeds:
        queue = [(seed,)]
        seed_tasks = 0
        while queue and seed_tasks < cfg.b_tasks_per_seed:
            group = queue.pop(0)
            if group in generated:
                diagnostics["dedup_hits"] += 1
                continue
            generated.add(group)
            if len(generated) > cfg.b_generated_max:
                diagnostics["generated_limit_hits"] += 1
                diagnostics["truncated_expansions"] += 1
                break
            k = _combination_count(model, group)
            if len(group) > cfg.b_uav or k > cfg.b_comb:
                diagnostics["pruned_group_budget_subtrees"] += 1
                continue
            if len(groups) >= cfg.b_frontier_max:
                diagnostics["frontier_limit_hits"] += 1
                diagnostics["truncated_expansions"] += 1
                break
            groups.append(group)
            diagnostics["group_seed_owner"].setdefault(",".join(group), seed)
            diagnostics["seed_generated_count"][seed] = diagnostics["seed_generated_count"].get(seed, 0) + 1
            seed_tasks += 1
            neighbors = list(connected_expansions(group, graph))
            neighbors.sort(key=lambda j: (-h_score(group, j, directed), -sum(graph["uav_edge_weight"].get(pair_key(i, j), 0.0) for i in group), j))
            for neighbor in neighbors[:cfg.b_expand]:
                expanded = tuple(sorted((*group, neighbor)))
                if len(expanded) > cfg.b_uav or _combination_count(model, expanded) > cfg.b_comb:
                    diagnostics["pruned_group_budget_subtrees"] += 1
                elif expanded not in generated and expanded not in queue:
                    queue.append(expanded)
            if len(neighbors) > cfg.b_expand:
                diagnostics["truncated_expansions"] += len(neighbors) - cfg.b_expand
                diagnostics["unvisited_eligible_expansions"] += len(neighbors) - cfg.b_expand
    diagnostics["generated_groups_count"] += len(generated)
    diagnostics["frontier_peak_global"] = max(diagnostics["frontier_peak_global"], len(groups))
    return sorted(set(groups), key=lambda group: (len(group), group))


def _load_counts(model: Mapping[str, Any], assignment: Mapping[str, str]) -> Dict[str, int]:
    mapping = model.get("candidate_to_load_key") or {}
    counts: Dict[str, int] = {}
    if not mapping:
        return counts
    for candidate in assignment.values():
        key = mapping[candidate]
        counts[key] = counts.get(key, 0) + 1
    return counts


def _invalidate_proofs_after_move(
    model, old_assignment, assignment, states, proof_cache, graph, cfg,
    diagnostics, model_hash, *, rebuild=True,
):
    """Invalidate only contexts affected by changed choices or load counts."""

    changed = {u for u in assignment if assignment[u] != old_assignment[u]}
    before, after = _load_counts(model, old_assignment), _load_counts(model, assignment)
    changed_load_keys = {
        key for key in before.keys() | after.keys() if before.get(key, 0) != after.get(key, 0)
    } if model.get("peak_load_cap_effective") is not None else set()
    for key, proof in list(proof_cache.items()):
        if key != _proof_key(model, assignment, proof["group"], model_hash=model_hash):
            del proof_cache[key]
            diagnostics["proof_cache_invalidations"] += 1
    for state in states:
        inside_changed = bool(changed.intersection(state["component"]))
        load_changed = state["load_keys"].intersection(changed_load_keys)
        if not inside_changed and not load_changed:
            continue
        old_epoch = state["epoch"]
        state["epoch"] += 1
        diagnostics["epoch_invalidations"].append({
            "component_id": state["id"], "old_epoch": old_epoch,
            "new_epoch": state["epoch"], "changed_uavs": sorted(changed),
            "changed_load_keys": sorted(load_changed),
            "reason": "COMPONENT_ASSIGNMENT_CHANGED" if inside_changed else "OUTSIDE_LOAD_CHANGED",
        })
        if rebuild:
            state["groups"] = _all_connected_groups(state["component"], graph, model, assignment, cfg, diagnostics)
        state["cursor"] = 0
        state["complete_groups"] = set()


def solve_cb_lns(model: Mapping[str, Any], config: Optional[CBLNSConfig] = None) -> Dict[str, Any]:
    cfg = config or CBLNSConfig()
    cfg.validate()
    started = time.perf_counter()
    cap = model.get("peak_load_cap_effective")
    cap = None if cap is None else int(cap)
    assignment = (capacitated_initial_assignment(model, cap) if cap is not None
                  else minimum_linear_assignment(model))
    initial = independent_q3_recompute(model, assignment)
    initial_assignment = dict(assignment)
    graph = build_graphs(model)
    model_hash = objective_model_hash(model)
    variable = [u for u in model["uavs"] if len(model["candidate_ids_by_uav"][u]) >= 2]
    lower_bound = sum(min(float(model["linear_costs"][c]) for c in model["candidate_ids_by_uav"][u]) for u in model["uavs"])
    diagnostics = {key: 0 for key in ("tasks_attempted", "fully_proven_tasks", "incomplete_tasks", "improving_tasks", "new_epoch_count", "dedup_hits", "proof_cache_hits", "truncated_expansions", "unvisited_eligible_expansions", "frontier_peak_global", "generated_groups_count", "generated_limit_hits", "frontier_limit_hits", "pruned_group_budget_subtrees", "round_quota_hits")}
    diagnostics.update({"component_turn_counts": {}, "component_rounds": {}, "seed_attempt_count": {}, "seed_generated_count": {}, "group_seed_owner": {}, "frontier_peak_by_component": {}, "task_log": [], "epoch_invalidations": [], "scheduler_ops": 0, "scheduler_ops_per_turn_peak": 0, "proof_cache_invalidations": 0, "objective_model_hash": model_hash, "component_epochs": {}})
    if not variable:
        return _result(model, cfg, started, initial_assignment, assignment, initial, initial, graph, diagnostics, "NO_VARIABLE_UAVS", "GLOBAL_OPTIMAL_PROVEN")
    if initial["total"] <= lower_bound + cfg.eps:
        return _result(model, cfg, started, initial_assignment, assignment, initial, initial, graph, diagnostics, "GLOBAL_LOWER_BOUND_REACHED", "GLOBAL_OPTIMAL_PROVEN")

    states = []
    for index, component in enumerate(graph["components"]):
        if not any(u in variable for u in component):
            continue
        cid = "C%03d" % index
        groups = _all_connected_groups(component, graph, model, assignment, cfg, diagnostics)
        states.append({"id": cid, "component": component, "epoch": 0, "groups": groups, "cursor": 0, "complete_groups": set(), "load_keys": _group_load_keys(model, [u for u in component if u in variable])})
        diagnostics["component_turn_counts"][cid] = 0
        diagnostics["component_rounds"][cid] = []
        diagnostics["frontier_peak_by_component"][cid] = len(groups)
    proof_cache = {}
    round_id, global_cursor = 0, 0
    termination, solver_status = "TASKS_EXHAUSTED_HEURISTIC", "HEURISTIC_INCUMBENT"
    all_component_exact = False
    while states and diagnostics["tasks_attempted"] < cfg.b_total_tasks and round_id < cfg.b_max_rounds:
        active = [state for state in states if state["cursor"] < len(state["groups"])]
        if not active:
            all_component_exact = all(len(state["complete_groups"]) == len(state["groups"]) for state in states)
            break
        round_id += 1
        tasks_this_round = 0
        served = set()
        checked = 0
        while checked < len(states) and tasks_this_round < cfg.b_tasks_per_round:
            state = states[global_cursor % len(states)]
            diagnostics["scheduler_ops"] += 1
            diagnostics["scheduler_ops_per_turn_peak"] = max(diagnostics["scheduler_ops_per_turn_peak"], 1)
            global_cursor = (global_cursor + 1) % len(states)
            checked += 1
            if state["id"] in served or state["cursor"] >= len(state["groups"]):
                continue
            served.add(state["id"])
            group = state["groups"][state["cursor"]]
            state["cursor"] += 1
            tasks_this_round += 1
            diagnostics["tasks_attempted"] += 1
            diagnostics["component_turn_counts"][state["id"]] += 1
            diagnostics["component_rounds"][state["id"]].append(round_id)
            seed = diagnostics["group_seed_owner"].get(",".join(group), group[0])
            diagnostics["seed_attempt_count"][seed] = diagnostics["seed_attempt_count"].get(seed, 0) + 1
            # Computed once and handed to the local search, which needs the
            # incumbent objective to evaluate its move.  Recomputing it inside
            # the solver duplicated the same O(M^2) evaluation per task.
            before = independent_q3_recompute(model, assignment)["total"]
            pkey = _proof_key(model, assignment, group, model_hash=model_hash)
            if pkey in proof_cache:
                outcome = dict(proof_cache[pkey], elapsed_ms=0.0, nodes_expanded=0)
                diagnostics["proof_cache_hits"] += 1
                cached = True
            else:
                outcome = solve_local_bnb(model, assignment, group,
                                          LocalBudget(cfg.b_nodes, cfg.eps), current_full_value=before)
                cached = False
                if outcome["status"] == "LOCAL_OPTIMAL_PROVEN" and not outcome.get("improved"):
                    # Reuse a local no-improvement proof, never a full proposal
                    # containing assignments and objective constants from an
                    # earlier outside state.
                    proof_cache[pkey] = {
                        "group": tuple(group), "status": outcome["status"],
                        "complete": True, "improved": False,
                        "delta_audit_pass": outcome.get("delta_audit_pass", True),
                    }
            if outcome.get("complete"):
                diagnostics["fully_proven_tasks"] += 1
                state["complete_groups"].add(group)
            else:
                diagnostics["incomplete_tasks"] += 1
            accepted = False
            if outcome.get("improved"):
                proposed = outcome["proposed_assignment"]
                # The single independent objective audit of an accepted move.
                audited = audit_objective(model, proposed, outcome["new_full_value"], cfg.eps)
                if audited["status"] == "PASS" and outcome["new_full_value"] < before - cfg.eps:
                    old_assignment = assignment
                    assignment = dict(proposed)
                    accepted = True
                    diagnostics["improving_tasks"] += 1
                    diagnostics["new_epoch_count"] += 1
                    _invalidate_proofs_after_move(
                        model, old_assignment, assignment, states, proof_cache,
                        graph, cfg, diagnostics, model_hash,
                    )
            after = outcome["new_full_value"] if accepted else before
            diagnostics["task_log"].append({"round": round_id, "component_id": state["id"], "epoch": state["epoch"], "group": list(group), "group_size": len(group), "combination_count": _combination_count(model, group), "status": outcome["status"], "cached": cached, "accepted": accepted, "objective_before": before, "objective_after": after, "nodes_expanded": outcome.get("nodes_expanded", 0), "elapsed_ms": outcome.get("elapsed_ms", 0.0), "delta_audit_pass": outcome.get("delta_audit_pass", True), "proof_key": pkey, "objective_model_hash": model_hash})
            if diagnostics["tasks_attempted"] >= cfg.b_total_tasks:
                break
        if tasks_this_round >= cfg.b_tasks_per_round:
            diagnostics["round_quota_hits"] += 1
    diagnostics["component_epochs"] = {state["id"]: state["epoch"] for state in states}
    final = independent_q3_recompute(model, assignment)
    if cap is not None:
        peak = max(_load_counts(model, assignment).values(), default=0)
        if peak > cap:
            raise ValueError(f"PEAK_LOAD_CAP_VIOLATED:{peak}>{cap}")
    if final["total"] <= lower_bound + cfg.eps:
        termination, solver_status = "GLOBAL_LOWER_BOUND_REACHED", "GLOBAL_OPTIMAL_PROVEN"
    elif (
        all_component_exact
        and not any(diagnostics[k] for k in ("truncated_expansions", "generated_limit_hits", "frontier_limit_hits"))
    ):
        termination, solver_status = "GLOBAL_OPTIMAL_PROVEN", "GLOBAL_OPTIMAL_PROVEN"
    elif diagnostics["tasks_attempted"] >= cfg.b_total_tasks or round_id >= cfg.b_max_rounds:
        termination = "WORK_LIMIT_STOPPED"
    return _result(model, cfg, started, initial_assignment, assignment, initial, final, graph, diagnostics, termination, solver_status)


def _result(model, cfg, started, initial_assignment, assignment, initial, final, graph, diagnostics, termination, solver_status):
    elapsed = (time.perf_counter() - started) * 1000.0
    diagnostics["scheduler_only_ms"] = elapsed
    diagnostics["local_nodes_expanded"] = sum(item["nodes_expanded"] for item in diagnostics["task_log"])
    diagnostics["b_tasks_per_round"] = cfg.b_tasks_per_round
    counts = _load_counts(model, assignment)
    diagnostics["service_level"] = {
        "key": "SERVICE_NODE_LAYER",
        "peak_load": max(counts.values()) if counts else 0,
        "cap_effective": model.get("peak_load_cap_effective"),
        "cap_status": model.get("peak_load_cap_status"),
        "selected_per_key": dict(sorted(counts.items())),
    }
    return {"algorithm": ALGORITHM, "decision_dependency_scope": "NON_ENERGY_ONLY", "safe_status": "NOT_PRODUCED",
            "snapshot_id": model.get("snapshot_id"), "scenario_hash": model.get("scenario_hash"), "config": asdict(cfg),
            "initial_assignment": initial_assignment, "final_assignment": assignment, "initial_objective": initial,
            "final_objective": final, "changed_uavs": sorted(u for u in assignment if assignment[u] != initial_assignment[u]),
            "termination_reason": termination, "solver_status": solver_status, "result_validity": "VALID_CANDIDATE_ONLY",
            "graph": {"components": [list(c) for c in graph["components"]], "uav_adjacency": graph["uav_adjacency"], "potential_edge_count": len(graph["uav_edge_weight"])},
            "diagnostics": diagnostics, "independent_audit": audit_objective(model, assignment, final["total"], cfg.eps),
            "elapsed_ms": elapsed}


def proof_key_for_test(model: Mapping[str, Any], assignment: Mapping[str, str], group: Sequence[str]) -> str:
    return _proof_key(model, assignment, group)
