"""Deterministic G-to-J transfer: one straight corridor run, then one curve.

G is registered ``v_max^2 / (2a)`` upstream of the point above J, so an aircraft
arriving at any speed up to its maximum can bleed that speed on the straight and
then follow a single cubic Bezier from the shaft entry down to J.  There is no
spline search and no fallback family: the path is built from the registered
geometry and only the clock is solved, as a forward-backward optimal profile.

No data from Zhou et al. (RA-L 2019) GPL code is copied here.
"""
from __future__ import annotations

import copy
import json
import math
from functools import lru_cache
from typing import Any, Mapping

import numpy as np


# A smooth turn at the acceleration bound sits exactly on the limit, so a
# small margin keeps the sampled profile strictly inside it.
TURN_SPEED_MARGIN = 0.90
# Samples kept across the shaft curve; the straight legs need only endpoints.
CURVE_SAMPLES = 16
_ACCESS_FIELDS = ("zhou_g_xyz", "zhou_j_xyz", "zhou_mainline_tangent_xyz", "zhou_allowed_cells")
_FAILED_KEYS: dict[str, str] = {}


def _cells(access: Mapping[str, Any]) -> tuple[tuple[np.ndarray, np.ndarray, np.ndarray], ...]:
    cells = access.get("zhou_allowed_cells")
    if not cells:
        raise ValueError("ZHOU_ALLOWED_SPACE_MISSING")
    return tuple(
        (np.asarray(row["center_xyz"], dtype=float),
         np.asarray(row["basis_columns"], dtype=float),
         np.asarray(row["half_lengths_m"], dtype=float))
        for row in cells
    )


def _outside_distances(points: np.ndarray, cells: tuple) -> np.ndarray:
    """Distance from each sample to the registered free space (0 when inside)."""
    best = np.full(len(points), np.inf)
    for center, basis, half in cells:
        excess = np.maximum(np.abs((points - center) @ basis) - half, 0.0)
        best = np.minimum(best, np.linalg.norm(excess, axis=1))
    return best


def generate_transfer(
    access: Mapping[str, Any], *, entry_speed_mps: float,
    max_speed_mps: float, max_acceleration_mps2: float,
    vertical_speed_mps: float = 3.0,
    max_descent_speed_mps: float = 3.0,
    max_vertical_acceleration_mps2: float = 2.0,
) -> dict[str, Any]:
    key = json.dumps({"access": {name: access[name] for name in _ACCESS_FIELDS},
                      "entry_speed_mps": float(entry_speed_mps),
                      "max_speed_mps": float(max_speed_mps),
                      "max_acceleration_mps2": float(max_acceleration_mps2),
                      "vertical_speed_mps": float(vertical_speed_mps),
                      "max_descent_speed_mps": float(max_descent_speed_mps),
                      "max_vertical_acceleration_mps2": float(max_vertical_acceleration_mps2)},
                     sort_keys=True, allow_nan=False)
    return copy.deepcopy(_cached_transfer(key))


@lru_cache(maxsize=256)
def _cached_transfer(key: str) -> dict[str, Any]:
    values = json.loads(key)
    failure = _FAILED_KEYS.get(key)
    if failure is not None:
        raise ValueError(failure)
    try:
        return _generate_transfer_impl(
            values["access"], entry_speed_mps=values["entry_speed_mps"],
            max_speed_mps=values["max_speed_mps"],
            max_acceleration_mps2=values["max_acceleration_mps2"],
            vertical_speed_mps=values["vertical_speed_mps"],
            max_descent_speed_mps=values["max_descent_speed_mps"],
            max_vertical_acceleration_mps2=values["max_vertical_acceleration_mps2"])
    except ValueError as error:
        # A deterministic failed input must not be re-solved on every call.
        _FAILED_KEYS[key] = str(error)
        if len(_FAILED_KEYS) > 256:
            _FAILED_KEYS.pop(next(iter(_FAILED_KEYS)))
        raise


def _bezier_point(p0, p1, p2, p3, t):
    u = 1. - t
    return (u ** 3) * p0 + 3. * (u ** 2) * t * p1 + 3. * u * (t ** 2) * p2 + (t ** 3) * p3


def _straight_then_curve(
    g: np.ndarray, j: np.ndarray, tangent: np.ndarray, cells: tuple, *,
    entry_speed_mps: float, vmax: float, amax: float,
    max_descent_speed_mps: float, max_vertical_acceleration_mps2: float,
    samples: int = 241,
) -> dict[str, Any] | None:
    """Straight run at mainline altitude, then one smooth curve into J.

    The straight part ends at the shaft west face; from there a cubic Bezier
    turns from horizontal to vertical and lands on J.  The clock is solved on
    the assembled path, so the shape is never bent just to satisfy timing.
    """
    shaft = [(center, half) for center, _, half in cells if half[2] >= 10.]
    if not shaft:
        return None
    # Travel-direction projection so the entry face follows the interface
    # direction; a fixed west face only holds for forward interfaces.
    flat = np.asarray((tangent[0], tangent[1], 0.), dtype=float)
    flat = flat / max(float(np.linalg.norm(flat)), 1e-12)
    faces = [float(np.dot(np.asarray((center[0] + sign * half[0], center[1]), dtype=float),
                          flat[:2]))
             for center, half in shaft for sign in (-1., 1.)]
    span = abs(float(np.dot(j[:2], flat[:2])) - min(faces))
    drop = float(g[2] - j[2])
    entry_xyz = np.asarray(j, dtype=float) - flat * span
    entry_xyz = np.asarray((entry_xyz[0], entry_xyz[1], g[2]), dtype=float)
    straight = float(np.linalg.norm(entry_xyz - g))
    if straight <= 1e-6 or span <= 1e-6 or drop <= 1e-6:
        return None
    if straight < float(entry_speed_mps) ** 2 / (2. * amax) * .25:
        return None

    best = None
    for share in (.6, .7, .8, .88, .94):
        p0 = entry_xyz.copy()
        # The straight leg follows the mainline tangent, which carries a small
        # lateral component; the curve must leave in the same direction or the
        # heading jumps at the seam and shows up as a spurious acceleration.
        p1 = p0 + flat * span
        p2 = j + np.asarray((0., 0., drop * share))
        p3 = j
        curve_steps = max(samples // 3, 24)
        params = np.linspace(0., 1., curve_steps)
        curve = np.asarray([_bezier_point(p0, p1, p2, p3, value) for value in params])
        d1 = np.asarray([3. * (1 - value) ** 2 * (p1 - p0)
                         + 6. * (1 - value) * value * (p2 - p1)
                         + 3. * value ** 2 * (p3 - p2) for value in params])
        d2 = np.asarray([6. * (1 - value) * (p2 - 2 * p1 + p0)
                         + 6. * value * (p3 - 2 * p2 + p1) for value in params])
        speed_raw = np.maximum(np.linalg.norm(d1, axis=1), 1e-12)
        curvature = np.linalg.norm(np.cross(d1, d2), axis=1) / speed_raw ** 3
        heading = d1 / speed_raw[:, None]

        straight_steps = max(int(round(samples * straight / (straight + .5 * math.pi * span))), 8)
        ratio = np.linspace(0., 1., straight_steps, endpoint=False)
        start = g + (p0 - g) * ratio[:, None]
        # Do not reuse the name ``flat``: it holds the 3-D travel direction and
        # a 2-D tiling here would corrupt the next iteration of this loop.
        flat_rows = np.tile(flat, (straight_steps, 1))
        points = np.vstack((start, curve))
        headings = np.vstack((flat_rows, heading))
        kap = np.concatenate((np.zeros(straight_steps), curvature))

        steps = np.maximum(np.linalg.norm(np.diff(points, axis=0), axis=1), 1e-9)
        arc = np.concatenate(([0.], np.cumsum(steps)))
        norms = np.maximum(np.linalg.norm(headings, axis=1), 1e-12)
        headings = headings / norms[:, None]
        step = np.maximum(np.diff(arc), 1e-9)
        steep = np.maximum(np.abs(headings[:, 2]), 1e-6)
        limit = np.minimum(vmax, max_descent_speed_mps / steep)
        limit = np.minimum(limit, np.sqrt(TURN_SPEED_MARGIN * amax / np.maximum(kap, 1e-12)))
        limit = np.minimum(limit, np.sqrt(TURN_SPEED_MARGIN * max_vertical_acceleration_mps2
                                          / np.maximum(kap, 1e-12)))
        centripetal = np.minimum(limit ** 2 * kap, amax ** 2)
        vertical_room = np.maximum(max_vertical_acceleration_mps2 - limit ** 2 * kap, 0.)
        tangential = np.minimum(amax, np.where(np.abs(headings[:, 2]) > 1e-6,
                                              vertical_room / steep, amax))
        tangential = np.minimum(tangential, np.sqrt(np.maximum(amax ** 2 - centripetal, 0.)))
        speed = limit.copy()
        speed[0] = min(speed[0], float(entry_speed_mps))
        speed[-1] = min(speed[-1], max_descent_speed_mps)
        for index in range(len(arc) - 1):
            budget = min(tangential[index], tangential[index + 1])
            speed[index + 1] = min(speed[index + 1],
                                   math.sqrt(speed[index] ** 2 + 2. * budget * step[index]))
        for index in range(len(arc) - 2, -1, -1):
            budget = min(tangential[index], tangential[index + 1])
            speed[index] = min(speed[index],
                               math.sqrt(speed[index + 1] ** 2 + 2. * budget * step[index]))
        if speed[0] < float(entry_speed_mps) - 1e-6 or speed[-1] < max_descent_speed_mps - 1e-6:
            continue
        speed[0] = float(entry_speed_mps)
        speed[-1] = float(max_descent_speed_mps)
        clock = np.zeros(len(arc))
        for index in range(len(arc) - 1):
            mean = max(.5 * (speed[index] + speed[index + 1]), 1e-6)
            duration_step=step[index]/mean
            # Bound the middle Bezier control of the Hermite vertical
            # derivative, so time interpolation cannot overshoot descent speed.
            dz=max(0.,float(points[index,2]-points[index+1,2]))
            vz0=max(0.,float(-headings[index,2]*speed[index]))
            vz1=max(0.,float(-headings[index+1,2]*speed[index+1]))
            duration_step=max(duration_step,3.*dz/max(max_descent_speed_mps+vz0+vz1,1e-9))
            clock[index + 1] = clock[index] + duration_step
        duration = float(clock[-1])
        if not math.isfinite(duration) or duration <= 0.:
            continue

        wanted = np.linspace(0., duration, samples)
        arc_at = np.interp(wanted, clock, arc)
        out_points = np.column_stack([np.interp(arc_at, arc, points[:, axis]) for axis in range(3)])
        out_speed = np.interp(arc_at, arc, speed)
        out_heading = np.column_stack([np.interp(arc_at, arc, headings[:, axis]) for axis in range(3)])
        norms = np.maximum(np.linalg.norm(out_heading, axis=1), 1e-12)
        velocity = (out_heading / norms[:, None]) * out_speed[:, None]
        outside = _outside_distances(out_points, cells)
        accel = np.gradient(velocity, wanted, axis=0)
        if (outside.max() > 1e-4
                or np.max(np.linalg.norm(velocity, axis=1)) > vmax + 1e-4
                or np.max(np.linalg.norm(accel, axis=1)) > amax + 1e-4
                or np.max(-velocity[:, 2]) > max_descent_speed_mps + 1e-4
                or np.max(np.abs(accel[:, 2])) > max_vertical_acceleration_mps2 + 1e-4
                or abs(float(np.linalg.norm(velocity[0])) - float(entry_speed_mps)) > 1e-4
                or abs(float(velocity[-1][2]) + float(max_descent_speed_mps)) > 1e-4):
            continue
        # The straight leg is a line, so two samples carry it exactly; only the
        # curve needs sampling.  Storing 241 uniform samples made every plan
        # ~36 KB and deep-copying that dominated the closed loop, so emit the
        # minimal set: straight ends, then CURVE_SAMPLES across the Bezier.
        emit_arc = np.unique(np.concatenate(
            ([0., straight], np.linspace(straight, arc[-1], CURVE_SAMPLES + 1))))
        emit_time = np.interp(emit_arc, arc, clock)
        emitted_points = np.column_stack([np.interp(emit_arc, arc, points[:, axis])
                                          for axis in range(3)])
        emitted_speed = np.interp(emit_arc, arc, speed)
        emitted_heading = np.column_stack([np.interp(emit_arc, arc, headings[:, axis])
                                           for axis in range(3)])
        emitted_norms = np.maximum(np.linalg.norm(emitted_heading, axis=1), 1e-12)
        emitted_velocity = (emitted_heading / emitted_norms[:, None]) * emitted_speed[:, None]
        table = [0.]
        for first_point, second_point in zip(emitted_points, emitted_points[1:]):
            table.append(table[-1] + float(np.linalg.norm(second_point - first_point)))
        candidate = {
            "method": "STRAIGHT_THEN_BEZIER_CURVE_V1",
            "generation_source": "STRAIGHT_THEN_CURVE",
            "path_xyz": [[float(value) for value in row] for row in emitted_points],
            "arc_stations_m": table,
            "elapsed_s": [float(value) for value in emit_time],
            "velocity_xyz": [[float(value) for value in row] for row in emitted_velocity],
            "duration_s": duration,
            "entry_speed_mps": float(entry_speed_mps),
            "max_sampled_outside_m": float(outside.max()),
            # Execution retains the validated motion knots. The small public
            # polyline remains a scheduling prediction, not an execution law.
            "execution_path_xyz": points.tolist(),
            "execution_elapsed_s": clock.tolist(),
            "execution_velocity_xyz": (headings*speed[:,None]).tolist(),
        }
        if best is None or candidate["duration_s"] < best["duration_s"]:
            best = candidate
    return best


def _generate_transfer_impl(
    access: Mapping[str, Any], *, entry_speed_mps: float,
    max_speed_mps: float, max_acceleration_mps2: float,
    vertical_speed_mps: float = 3.0,
    max_descent_speed_mps: float = 3.0,
    max_vertical_acceleration_mps2: float = 2.0,
) -> dict[str, Any]:
    """Straight corridor run, then one smooth curve from the shaft entry into J.

    Failure is explicit.  There is a single admissible shape family, so an input
    that cannot fit the registered space has no fallback to hide behind.
    """
    g = np.asarray(access["zhou_g_xyz"], dtype=float)
    j = np.asarray(access["zhou_j_xyz"], dtype=float)
    start_direction = np.asarray(access["zhou_mainline_tangent_xyz"], dtype=float)
    start_direction /= np.linalg.norm(start_direction)
    vmax, amax = float(max_speed_mps), float(max_acceleration_mps2)
    if (not all(math.isfinite(x) for x in (*g, *j, *start_direction, vmax, amax))
            or vmax <= 0. or amax <= 0.):
        raise ValueError("ZHOU_TRANSFER_INPUT_INVALID")
    if float(entry_speed_mps) > vmax + 1e-9:
        raise ValueError("ZHOU_TRANSFER_ENTRY_OVERSPEED")
    result = _straight_then_curve(
        g, j, start_direction, _cells(access), entry_speed_mps=float(entry_speed_mps),
        vmax=vmax, amax=amax,
        max_descent_speed_mps=float(max_descent_speed_mps),
        max_vertical_acceleration_mps2=float(max_vertical_acceleration_mps2))
    if result is None:
        raise ValueError("ZHOU_TRANSFER_GENERATION_FAILED")
    return result
