# Highway UAV corridor algorithms

This source bundle contains four components for shared-resource coordination in layered highway UAV corridors.

| Component | Entry point | Input |
| --- | --- | --- |
| SRCM | `srcm.detect_crossing_competitions` | A scene bundle and optional traffic snapshot |
| ECJA | `ecja_qsap.assign_ecja` | An `ECJAInput` with the current request batch, network geometry and relevant prior traffic |
| C-MLPM | `traffic_simulation.cmlpm.active.solve_cmlpm` | A validated `NodeSnapshot` |
| V5 motion executor | `experiments.ecja_cmlpm_dt_flow_v1.v5_thin_executor.execute_v5_thin_step` | Current traffic state and the execution context defined by the function signature |

Install the dependencies with `python -m pip install -r requirements.txt`. Run Python from the repository root so the source packages can be imported. The bundle was checked with Python 3.9.23, NumPy 2.0.2 and SciPy 1.13.1.

Pass `time_limit_s=5.0` when applying the paper's 5 s computational budget to C-MLPM. The solver returns a candidate schedule. The independent checker is available through `traffic_simulation.cmlpm.active.certify_cmlpm_result`.

The source tree retains its original import paths. The geometry, traffic-state, solver-validation and motion utilities in the tree support the four entry points. The entry points expect the project input contracts and caller-supplied network or traffic data.

The full closed-loop simulation and the project's registered G25 network assets are outside this bundle. The default registered-network helpers in the execution layer require those assets when called.
