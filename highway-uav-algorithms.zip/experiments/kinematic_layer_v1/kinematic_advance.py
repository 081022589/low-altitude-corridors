"""Parameterised kinematic advance layer -- reference implementation.

Design rule (the whole point of this module):

    Only input errors may abort. Every runtime state is recorded as a
    deviation and the simulation continues.

Architecture rule (2026-10-26 revision):

    Speed update, position integration and event detection share one
    piecewise trajectory. ``advance`` returns a ``Profile``; every query --
    end state, boundary crossing time, minimum gap -- is answered from that
    profile, never from a whole-step constant-acceleration assumption.

That second rule is what makes the events trustworthy. A step that stops
mid-step is a brake piece followed by a rest piece; treating it as a single
quadratic invents crossings that never happened.

Caps per 0.5 s step:

    nominal      aircraft type cruise speed            soft
    follow       piecewise stopping-budget speed cap  hard
    stop         stop boundary                         hard
    slot         deadline law for a published t_G      soft

``follow`` / ``stop`` protect separation; ``slot`` / ``nominal`` express
intent. A hard cap stricter than the slot means the aircraft is late -- that
is an observation, not an error.

For deadlines beyond the current step, the feedback proposal remains:

    v_raw = (d - v0*dt/2) / (T - dt/2)

Inside the final step, the speed proposal instead inverts the same piecewise
displacement used for execution at T. A speed which already meets the deadline
is retained; a physically unreachable deadline remains an observed deviation.

An open-loop profile cannot recover from a disturbance; once interrupted it
is dead, which is why the old executor had to abort on
``FROZEN_G_TIME_NOT_REALIZED``. The feedback law recomputes from the actual
state each step and absorbs the disturbance.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
import math
from typing import Callable, Iterable

GAP_TOL_M = 1e-6
SPEED_TOL_MPS = 1e-8
TIME_TOL_S = 1e-9

#: Slack allowed when *binding* a hard constraint. It must be strictly tighter
#: than any downstream audit tolerance. With both at 1e-6 the profile landed
#: exactly on the boundary (49.99999899999966 against a 50 - 1e-6 threshold) and
#: floating point decided whether the run survived.
_BINDING_TOL_M = 1e-9

INFO = "INFO"
WARN = "WARN"
VIOLATION = "VIOLATION"

#: A slot deviation smaller than this counts as realised.
SLOT_HIT_TOL_S = 0.05
#: A terminal-speed deviation smaller than this counts as realised.
TERMINAL_SPEED_TOL_MPS = 0.5


class InputError(ValueError):
    """The only exception class that may stop a run."""


@dataclass(frozen=True)
class Limits:
    v_min: float
    v_max: float
    a_max: float

    def __post_init__(self) -> None:
        if not all(math.isfinite(v) for v in (self.v_min, self.v_max, self.a_max)):
            raise InputError("LIMITS_NOT_FINITE")
        if self.v_min < 0.0 or self.v_max < self.v_min or self.a_max <= 0.0:
            raise InputError(f"LIMITS_INVALID:{self.v_min},{self.v_max},{self.a_max}")


@dataclass(frozen=True)
class Aircraft:
    uid: str
    s: float
    v: float
    nominal: float
    limits: Limits

    def __post_init__(self) -> None:
        if not all(math.isfinite(v) for v in (self.s, self.v, self.nominal)):
            raise InputError(f"AIRCRAFT_STATE_NOT_FINITE:{self.uid}")
        if self.v < -SPEED_TOL_MPS:
            raise InputError(f"AIRCRAFT_NEGATIVE_SPEED:{self.uid}:{self.v}")


@dataclass(frozen=True)
class Leader:
    """Actual, observed state of whatever is in front."""

    s: float
    v: float
    braking: float


@dataclass(frozen=True)
class Slot:
    """A published G crossing time. Intent, never a guarantee.

    ``v_g`` is the terminal speed required to join the fixed G->J transfer
    arc. ``None`` means "no terminal constraint"; a number switches on the
    braking envelope so the aircraft never arrives too fast to reach it.
    """

    t_g: float
    s_g: float
    v_g: float | None = None


@dataclass(frozen=True)
class Deviation:
    uid: str
    kind: str
    severity: str
    planned: float | None = None
    actual: float | None = None
    delta: float | None = None
    note: str = ""


@dataclass(frozen=True)
class ResourceEntryLimit:
    """Execution-only entry condition; never a replacement published target.

    Forecasts guide the approach. Until an actual EXIT confirms clearance,
    every accepted step must retain the ability to stop outside the resource.
    """

    resource_id: str
    station_m: float
    not_before_s: float
    exit_confirmed: bool
    blocking_uav_ids: tuple[str, ...] = ()

    def __post_init__(self) -> None:
        if not all(math.isfinite(v) for v in (self.station_m, self.not_before_s)):
            raise InputError("RESOURCE_ENTRY_LIMIT_NOT_FINITE")

    @property
    def stop_station_m(self) -> float:
        # Stay outside the event boundary, including its 1e-9 roundoff band.
        return self.station_m - GAP_TOL_M


@dataclass(frozen=True)
class ProfileEntryGuard:
    """A full-chain release check with a physical stopping fallback."""

    stop_station_m: float
    permits: Callable[[Profile, float], bool]

    def __call__(self, profile: Profile, speed: float) -> bool:
        return self.permits(profile, speed)


@dataclass(frozen=True)
class Piece:
    """One constant-acceleration segment of a step."""

    start_s: float
    end_s: float
    s0: float
    v0: float
    a: float

    @property
    def length_s(self) -> float:
        return self.end_s - self.start_s

    def state_at(self, tau: float) -> tuple[float, float]:
        local = min(max(tau, self.start_s), self.end_s) - self.start_s
        v = self.v0 + self.a * local
        if -SPEED_TOL_MPS <= v < 0.0:
            v = 0.0
        s = self.s0 + self.v0 * local + 0.5 * self.a * local * local
        return s, v

    def crossing(self, boundary_m: float) -> float | None:
        """Local time at which this piece passes ``boundary_m``, if it does."""
        delta = boundary_m - self.s0
        length = self.length_s
        if abs(self.a) < 1e-12:
            if abs(self.v0) < 1e-12:
                return None
            tau = delta / self.v0
            if -TIME_TOL_S <= tau <= length + TIME_TOL_S:
                return self.start_s + min(max(tau, 0.0), length)
            return None
        discriminant = self.v0 * self.v0 + 2.0 * self.a * delta
        if discriminant < 0.0:
            return None
        root = math.sqrt(discriminant)
        for tau in ((-self.v0 + root) / self.a, (-self.v0 - root) / self.a):
            if -TIME_TOL_S <= tau <= length + TIME_TOL_S:
                return self.start_s + min(max(tau, 0.0), length)
        return None


@dataclass(frozen=True)
class Profile:
    """The actual motion of one aircraft over one step."""

    pieces: tuple[Piece, ...]
    duration_s: float

    def state_at(self, tau: float) -> tuple[float, float]:
        for piece in self.pieces:
            if tau <= piece.end_s + 1e-12:
                return piece.state_at(tau)
        return self.pieces[-1].state_at(self.duration_s)

    @property
    def end(self) -> tuple[float, float]:
        return self.state_at(self.duration_s)

    def crossing(self, boundary_m: float) -> float | None:
        """First time within the step at which the aircraft passes the station."""
        for piece in self.pieces:
            tau = piece.crossing(boundary_m)
            if tau is not None:
                return tau
        return None

    def _piece_for_interval(self, left: float, right: float) -> Piece:
        """The piece that covers the interior of [left, right].

        Selecting by ``tau <= piece.end_s`` picks the *previous* piece when a
        knot sits exactly on a boundary, and the caller then extends that
        piece's acceleration across the following interval. With a braking
        piece that drags the aircraft backwards and invents a gap violation.
        """
        for piece in self.pieces:
            if piece.start_s <= left + TIME_TOL_S and piece.end_s >= right - TIME_TOL_S:
                return piece
        middle = 0.5 * (left + right)
        for piece in self.pieces:
            if piece.start_s - TIME_TOL_S <= middle <= piece.end_s + TIME_TOL_S:
                return piece
        return self.pieces[-1]

    def min_gap_with(self, front: "Profile") -> float:
        """Exact minimum of (front.s - self.s) over the overlapping step.

        Both profiles are piecewise quadratic, so the gap is quadratic on each
        interval between knots. Its minimum is at an endpoint or at the vertex
        where relative speed vanishes -- evaluated analytically, not sampled.
        """
        duration = min(self.duration_s, front.duration_s)
        knots = {0.0, duration}
        for profile in (self, front):
            for piece in profile.pieces:
                for edge in (piece.start_s, piece.end_s):
                    if 0.0 < edge < duration:
                        knots.add(edge)
        ordered = sorted(knots)
        minimum = math.inf
        for left, right in zip(ordered, ordered[1:]):
            rear = self._piece_for_interval(left, right)
            lead = front._piece_for_interval(left, right)
            rear_s, rear_v = rear.state_at(left)
            lead_s, lead_v = lead.state_at(left)
            gap0 = lead_s - rear_s
            relative_v = lead_v - rear_v
            relative_a = lead.a - rear.a
            minimum = min(minimum, gap0)
            span = right - left
            minimum = min(minimum, gap0 + relative_v * span + 0.5 * relative_a * span * span)
            if abs(relative_a) > 1e-12:
                tau = -relative_v / relative_a
                if 0.0 < tau < span:
                    minimum = min(minimum, gap0 + relative_v * tau + 0.5 * relative_a * tau * tau)
        return minimum


@dataclass(frozen=True)
class Tick:
    """One advance step plus everything worth recording about it."""

    aircraft: Aircraft
    profile: Profile
    caps: dict
    deviations: tuple[Deviation, ...]


def piecewise_following_speed(ac: Aircraft, leader: Leader, dt_s: float, min_gap_m: float) -> float:
    """Speed cap preserving the stopping budget of the executed profile.

    ``build_profile`` reaches the target at the acceleration limit, then
    cruises. Its exact displacement D for initial
    speed v, reachable target u, step h and acceleration magnitude b:

        D = u*h - (u-v)^2/(2*b)    (u >= v)
        D = u*h + (v-u)^2/(2*b)    (u <= v)

    Solve D + u^2/(2*b) <= gap + vL^2/(2*bL). The acceleration branch is
    linear in u; the braking branch is quadratic. ``advance`` also enforces
    reachable speeds and continuous separation against the actual leader
    profile. An already infeasible stopping budget requests maximum braking;
    it cannot be repaired by resetting position or speed.
    """
    b = ac.limits.a_max
    if leader.braking <= 0.0:
        raise InputError(f"LEADER_BRAKING_INVALID:{leader.braking}")
    gap = leader.s - ac.s - min_gap_m
    if gap < -GAP_TOL_M:
        return 0.0
    available = gap + max(0.0, leader.v) ** 2 / (2.0 * leader.braking)
    v = ac.v
    stopping_distance = v * v / (2.0 * b)
    if available < stopping_distance:
        return 0.0
    if available >= v * dt_s + stopping_distance:
        return max(0.0, (available + stopping_distance) / (dt_s + v / b))

    # u^2 + (b*h-v)*u + v^2/2-b*available <= 0.
    linear = b * dt_s - v
    constant = 0.5 * v * v - b * available
    root = math.sqrt(max(0.0, linear * linear - 4.0 * constant))
    if linear >= 0.0:
        # Avoid cancellation near a stationary leader / zero target speed.
        denominator = linear + root
        return max(0.0, -2.0 * constant / denominator) if denominator > 0.0 else 0.0
    return max(0.0, 0.5 * (root - linear))


def slot_speed(
    ac: Aircraft, slot: Slot, now_s: float, dt_s: float
) -> tuple[float | None, str]:
    """Deadline feedback law. Returns (speed cap, status).

    This is a soft speed proposal recomputed from the observed state. Actual
    displacement and hard following/stop constraints use the executed
    piecewise profile. Inside the final step, invert that same profile at the
    remaining deadline rather than extrapolating a whole-step trapezoid.
    When ``slot.v_g`` is given, a braking envelope
    ``v_g + a*T`` caps the result so
    the terminal speed stays reachable; the residual is reported once, at the
    crossing, as ``V_AT_G_DEVIATION``.
    """
    remaining_t = slot.t_g - now_s
    if remaining_t <= TIME_TOL_S:
        # The slot window has passed. Lateness is reported at the crossing,
        # not here: an expired slot is not an event, arriving late is.
        return None, "SLOT_EXPIRED"
    distance = slot.s_g - ac.s
    status = "SLOT_OK"
    if remaining_t <= dt_s:
        # Work in local distance to avoid subtracting two large propagated
        # stations at every root evaluation. build_profile applies finite
        # acceleration first, then cruises (or rests), just as execution does.
        local = replace(ac, s=0.0)
        slowest = build_profile(local, ac.limits.v_min, remaining_t)
        fastest = build_profile(local, ac.limits.v_max, remaining_t)
        if (ac.limits.v_min <= ac.v <= ac.limits.v_max and ac.v > 0.0
                and (distance == ac.v * remaining_t
                     or now_s + distance / ac.v == slot.t_g)):
            # Exact equality in distance or the event's absolute clock, not
            # an enlarged tolerance. Preserve a speed which hits the slot.
            # Check before local-distance bounds: absolute-clock subtraction
            # can round a coasting deadline a few ulps across either bound.
            raw = ac.v
        elif distance < slowest.end[0] or (
            ac.limits.v_min == 0.0
            and ac.v / ac.limits.a_max < remaining_t
            and distance <= slowest.end[0]
        ):
            # Already needing more than maximum braking: do not pretend that
            # stopping on the boundary early counts as first arrival later.
            raw, status = ac.limits.v_min, "SLOT_UNREACHABLE_EARLY"
        elif distance > fastest.end[0]:
            # Keep accelerating as hard as physically possible across the
            # actual tick, even if the deadline itself cannot be achieved.
            raw, status = ac.limits.v_max, "SLOT_UNREACHABLE_LATE"
        else:
            low, high = ac.limits.v_min, ac.limits.v_max
            for _ in range(64):
                middle = 0.5 * (low + high)
                if build_profile(local, middle, remaining_t).end[0] < distance:
                    low = middle
                else:
                    high = middle
            raw = 0.5 * (low + high)
    else:
        denominator = remaining_t - 0.5 * dt_s
        raw = (distance - 0.5 * ac.v * dt_s) / denominator
    if slot.v_g is not None:
        envelope = slot.v_g + ac.limits.a_max * remaining_t
        if raw > envelope + SPEED_TOL_MPS:
            raw = envelope
            status = "SLOT_TERMINAL_CAPPED"
    if raw > ac.limits.v_max + SPEED_TOL_MPS:
        return ac.limits.v_max, "SLOT_UNREACHABLE_LATE"
    if raw < ac.limits.v_min - SPEED_TOL_MPS:
        return ac.limits.v_min, "SLOT_UNREACHABLE_EARLY"
    return max(0.0, raw), status


def build_profile(ac: Aircraft, v_target: float, dt_s: float) -> Profile:
    """Piecewise motion: reach ``v_target`` at the acceleration limit, then hold.

    A target of zero reached before the step ends produces a brake piece plus a
    rest piece, which is what makes a mid-step stop physically exact.
    """
    b = ac.limits.a_max
    v0, s0 = ac.v, ac.s
    # A speed tolerance is for auditing, not for ignoring requested braking.
    # Holding even a nanometre-per-second residual instead of reaching zero
    # accumulates position drift over a long stopped queue. Integrate the
    # finite acceleration segment, however short; never snap the velocity.
    if v_target == v0:
        return Profile((Piece(0.0, dt_s, s0, v0, 0.0),), dt_s)
    acceleration = b if v_target > v0 else -b
    reach = abs(v_target - v0) / b
    if reach == 0.0:
        # Subnormal speeds can underflow the ramp duration to zero. Preserve
        # a finite-duration continuous ramp instead of emitting a zero piece.
        return Profile((Piece(0.0, dt_s, s0, v0, (v_target-v0)/dt_s),),dt_s)
    if reach >= dt_s:
        return Profile((Piece(0.0, dt_s, s0, v0, acceleration),), dt_s)
    first = Piece(0.0, reach, s0, v0, acceleration)
    s1, _ = first.state_at(reach)
    # The ramp analytically reaches the requested speed. Carry that value
    # forward so roundoff at a stop cannot create another braking segment.
    second = Piece(reach, dt_s, s1, v_target, 0.0)
    return Profile((first, second), dt_s)


def _can_stop(profile: Profile, ac: Aircraft, stop_station_m: float) -> bool:
    position, speed = profile.end
    # Strict, with only floating-point noise tolerated. The old 1e-6 slack here
    # matched the downstream ``UNSCHEDULED_V_STOP_BOUNDARY_UNREACHABLE`` check
    # to the digit, so a profile that parked at ``stop + 1e-6`` passed this test
    # and failed that one. A stop boundary is hard; do not spend tolerance on it.
    return position + speed * speed / (2.0 * ac.limits.a_max) <= stop_station_m + 1e-9


def stop_satisfied(profile: Profile, ac: Aircraft, stop_station_m: float | None) -> bool:
    """Public wrapper so later stages can audit a profile they did not build."""
    if stop_station_m is None:
        return True
    return _can_stop(profile, ac, stop_station_m)


def gap_satisfied(
    profile: Profile, leader_profile: Profile | None, min_gap_m: float
) -> bool:
    """Public wrapper for the continuous separation audit of an existing profile."""
    if leader_profile is None:
        return True
    return profile.min_gap_with(leader_profile) >= min_gap_m - _BINDING_TOL_M


def _choose_speed(
    ac: Aircraft,
    ceiling: float,
    dt_s: float,
    *,
    stop_station_m: float | None,
    leader_profile: Profile | None,
    min_gap_m: float,
    entry_limits: tuple[ResourceEntryLimit, ...] = (),
    now_s: float = 0.0,
    profile_guard=None,
) -> tuple[float, Profile, bool, bool]:
    """Largest speed in [0, ceiling] satisfying the hard constraints.

    Returns (speed, profile, stop_satisfied, gap_satisfied). Feasibility is
    monotone in speed, so a bisection is exact to tolerance and needs no
    solver. Speed 0 means "brake at the limit", which also covers restart:
    a stationary aircraft with room ahead simply gets a positive ceiling.
    """
    def ok(speed: float) -> tuple[bool, bool]:
        profile = build_profile(ac, speed, dt_s)
        stop_ok = True if stop_station_m is None else _can_stop(profile, ac, stop_station_m)
        if stop_station_m is not None and speed > 0.0:
            position, velocity = profile.end
            # Reserve a spatial rounding budget in control, not in the audit.
            # Maximum braking/holding remains available from a state on the line.
            stop_ok = stop_ok and position + velocity*velocity/(2*ac.limits.a_max) <= stop_station_m-GAP_TOL_M
        stop_ok = stop_ok and all(
            resource_entry_satisfied(profile, ac, limit, now_s) for limit in entry_limits
        )
        if profile_guard is not None:
            stop_ok = stop_ok and profile_guard(profile, speed)
        gap_ok = (
            True if leader_profile is None
            else profile.min_gap_with(leader_profile) >= min_gap_m - _BINDING_TOL_M
        )
        return stop_ok, gap_ok

    if profile_guard is not None:
        # Resource clocks depend non-monotonically on the speed at G. Do not
        # apply the scalar stopping-envelope bisection to this condition.
        candidates = {ceiling, min(ac.v, ceiling), 0.0}
        if isinstance(profile_guard, ProfileEntryGuard):
            stop = profile_guard.stop_station_m
            if stop_station_m is not None:
                stop = min(stop, stop_station_m)
            fallback, _, _, _ = _choose_speed(
                ac, ceiling, dt_s, stop_station_m=stop,
                leader_profile=leader_profile, min_gap_m=min_gap_m,
                entry_limits=entry_limits, now_s=now_s,
            )
            candidates.add(fallback)
        for speed in sorted(candidates, reverse=True):
            stop_ok, gap_ok = ok(speed)
            if stop_ok and gap_ok:
                return speed, build_profile(ac, speed, dt_s), True, True
        stop_ok, gap_ok = ok(0.0)
        return 0.0, build_profile(ac, 0.0, dt_s), stop_ok, gap_ok
    stop_ok, gap_ok = ok(0.0)
    if not (stop_ok and gap_ok):
        return 0.0, build_profile(ac, 0.0, dt_s), stop_ok, gap_ok
    stop_ok, gap_ok = ok(ceiling)
    if stop_ok and gap_ok:
        return ceiling, build_profile(ac, ceiling, dt_s), True, True
    low, high = 0.0, ceiling
    for _ in range(40):
        middle = 0.5 * (low + high)
        stop_ok, gap_ok = ok(middle)
        if stop_ok and gap_ok:
            low = middle
        else:
            high = middle
    if low * dt_s <= GAP_TOL_M:
        # The whole step would move less than the distance tolerance; hold
        # instead of creeping and accumulating drift.
        return 0.0, build_profile(ac, 0.0, dt_s), True, True
    return low, build_profile(ac, low, dt_s), True, True


def resource_entry_satisfied(
    profile: Profile, ac: Aircraft, limit: ResourceEntryLimit, now_s: float,
) -> bool:
    """Check both this continuous step and feasibility until the gate opens."""
    if not limit.exit_confirmed:
        return _can_stop(profile, ac, limit.stop_station_m)
    remaining = limit.not_before_s - now_s
    if remaining <= 0.0:
        return True
    crossing = profile.crossing(limit.station_m)
    if crossing is not None and crossing < remaining - TIME_TOL_S:
        return False
    if remaining <= profile.duration_s:
        return profile.state_at(remaining)[0] <= limit.station_m + _BINDING_TOL_M
    # Do not choose a step that makes the following step unable to wait.
    position, speed = profile.end
    slowest = build_profile(replace(ac, s=position, v=speed), 0.0,
                            remaining - profile.duration_s)
    return slowest.end[0] <= limit.station_m + _BINDING_TOL_M


def worst_case_min_gap(
    rear: Aircraft, leader: Leader, dt_s: float
) -> float:
    """Minimum gap if the leader brakes at its limit from this instant.

    This is a *feasibility* test, not a control law. When the result is below
    the required separation even though the rear aircraft brakes at its own
    limit, the initial state cannot maintain the gap and no rule can repair it.
    Use it at traffic generation and admission.
    """
    rear_profile = build_profile(rear, 0.0, dt_s)
    braking = leader.braking
    stop_time = leader.v / braking
    if stop_time >= dt_s:
        lead_pieces = (Piece(0.0, dt_s, leader.s, leader.v, -braking),)
    else:
        first = Piece(0.0, stop_time, leader.s, leader.v, -braking)
        s1, _ = first.state_at(stop_time)
        lead_pieces = (first, Piece(stop_time, dt_s, s1, 0.0, 0.0))
    return rear_profile.min_gap_with(Profile(lead_pieces, dt_s))


def advance(
    ac: Aircraft,
    *,
    dt_s: float,
    now_s: float,
    leader: Leader | None = None,
    leader_profile: Profile | None = None,
    stop_station_m: float | None = None,
    slot: Slot | None = None,
    min_gap_m: float = 50.0,
    entry_limits: tuple[ResourceEntryLimit, ...] = (),
    profile_guard=None,
    enforce_slot_timing: bool = True,
) -> Tick:
    """Advance one aircraft by one step. Never aborts on runtime state.

    ``leader`` is the observed state used by the piecewise following cap. ``leader_profile``
    is the leader's motion *this step*, used for the exact within-step gap
    audit; pass it when the leader has already been advanced in this step.
    """
    if not math.isfinite(dt_s) or dt_s <= 0.0:
        raise InputError(f"STEP_INVALID:{dt_s}")
    if not math.isfinite(now_s):
        raise InputError(f"NOW_INVALID:{now_s}")

    caps: dict[str, float] = {"nominal": min(ac.nominal, ac.limits.v_max)}
    notes: list[Deviation] = []

    if leader is not None:
        caps["follow"] = piecewise_following_speed(ac, leader, dt_s, min_gap_m)
    if slot is not None and enforce_slot_timing:
        v_slot, status = slot_speed(ac, slot, now_s, dt_s)
        if v_slot is not None:
            caps["slot"] = v_slot
            if status != "SLOT_OK":
                notes.append(
                    Deviation(ac.uid, status, WARN, planned=slot.t_g,
                              note=f"required_speed={v_slot:.3f}")
                )
            if "follow" in caps and caps["follow"] < caps["slot"] - SPEED_TOL_MPS:
                notes.append(
                    Deviation(
                        ac.uid, "FOLLOW_BLOCKS_SLOT", WARN,
                        planned=caps["slot"], actual=caps["follow"],
                        delta=caps["follow"] - caps["slot"],
                        note="hard separation cap stricter than deadline",
                    )
                )

    ceiling = min(caps.values())
    ceiling = min(ceiling, ac.v + ac.limits.a_max * dt_s, ac.limits.v_max)
    ceiling = max(0.0, ceiling)

    speed, profile, stop_ok, gap_ok = _choose_speed(
        ac, ceiling, dt_s,
        stop_station_m=stop_station_m,
        leader_profile=leader_profile,
        min_gap_m=min_gap_m,
        entry_limits=entry_limits, now_s=now_s,
        profile_guard=profile_guard,
    )
    caps["chosen"] = speed
    if profile_guard is not None:
        if not profile_guard(profile, speed):
            notes.append(Deviation(ac.uid,"V_RESOURCE_GUARD_UNREACHABLE",VIOLATION,
                                   note="no bounded candidate preserves the full descent-chain entry conditions"))
        elif speed < ceiling - SPEED_TOL_MPS:
            notes.append(Deviation(ac.uid,"V_RESOURCE_GUARD_BRAKING",INFO,
                                   planned=ceiling,actual=speed,note="full-chain resource condition overrides frozen G intent"))

    for limit in entry_limits:
        if not resource_entry_satisfied(profile, ac, limit, now_s):
            notes.append(Deviation(
                ac.uid, "RESOURCE_ENTRY_GUARD_UNREACHABLE", VIOLATION,
                planned=limit.not_before_s,
                note=f"resource={limit.resource_id}; blockers={limit.blocking_uav_ids}; "
                     "maximum bounded braking cannot preserve entry condition",
            ))

    if stop_station_m is not None:
        if not stop_ok:
            position, _ = profile.end
            notes.append(
                Deviation(
                    ac.uid, "STOP_BOUNDARY_OVERSHOOT", VIOLATION,
                    planned=stop_station_m, actual=position,
                    delta=position - stop_station_m,
                    note="braking distance exceeds remaining gap",
                )
            )
    if leader_profile is not None and not gap_ok:
        gap = profile.min_gap_with(leader_profile)
        notes.append(
            Deviation(
                ac.uid, "CONTINUOUS_GAP_VIOLATION", VIOLATION,
                planned=min_gap_m, actual=gap, delta=gap - min_gap_m,
                note="minimum gap over the whole step, not just its end",
            )
        )

    position, velocity = profile.end
    return Tick(
        aircraft=replace(ac, s=position, v=velocity),
        profile=profile,
        caps=caps,
        deviations=tuple(notes),
    )


def g_event(
    profile: Profile, slot: Slot, now_s: float
) -> tuple[float, float, Deviation | None, Deviation | None] | None:
    """One-shot G crossing report for this step, or None if G is not crossed.

    Returns (absolute_time, speed_at_crossing, time_deviation, speed_deviation).
    Call it once per step; the deviations are emitted only on the crossing step
    so they are not repeated every tick.
    """
    tau = profile.crossing(slot.s_g)
    if tau is None:
        return None
    _, speed = profile.state_at(tau)
    moment = now_s + tau
    time_note = None
    if abs(moment - slot.t_g) > SLOT_HIT_TOL_S:
        time_note = Deviation(
            "", "G_DEVIATION", INFO, planned=slot.t_g, actual=moment,
            delta=moment - slot.t_g,
        )
    speed_note = None
    if slot.v_g is not None and abs(speed - slot.v_g) > TERMINAL_SPEED_TOL_MPS:
        speed_note = Deviation(
            "", "V_AT_G_DEVIATION", WARN, planned=slot.v_g, actual=speed,
            delta=speed - slot.v_g,
            note="terminal speed not realised; G->J arc needs a within-step phase switch",
        )
    return moment, speed, time_note, speed_note


def audit_gap(
    front: Aircraft, rear: Aircraft, *, min_gap_m: float, now_s: float
) -> Deviation | None:
    """Post-step separation audit on end states. Records, never aborts."""
    gap = front.s - rear.s
    if gap >= min_gap_m - _BINDING_TOL_M:
        return None
    return Deviation(
        rear.uid, "SAFETY_GAP_VIOLATION", VIOLATION,
        planned=min_gap_m, actual=gap, delta=gap - min_gap_m,
        note=f"t={now_s:.3f} leader={front.uid}",
    )


def summarise(deviations: Iterable[Deviation]) -> dict[str, int]:
    counts: dict[str, int] = {}
    for item in deviations:
        key = f"{item.severity}:{item.kind}"
        counts[key] = counts.get(key, 0) + 1
    return counts


def has_violation(deviations: Iterable[Deviation]) -> bool:
    return any(item.severity == VIOLATION for item in deviations)
def terminal_slot_profile(ac: Aircraft, slot: Slot, now_s: float, dt_s: float) -> Profile:
    """Take a prefix of a bounded path to the reserved position, time and speed."""
    duration = slot.t_g - now_s
    target = slot.v_g
    lo, hi, acceleration = ac.limits.v_min, ac.limits.v_max, ac.limits.a_max
    distance = slot.s_g - ac.s
    if (target is None or not all(map(math.isfinite, (duration, target, distance)))
            or duration <= 0 or distance <= 0 or not lo <= target <= hi
            or abs(target-ac.v) > acceleration*duration + 1e-9):
        raise ValueError("G_TERMINAL_STATE_UNREACHABLE")

    # The lower and upper speed envelopes share both endpoint speeds.
    # Their convex combination spans every attainable travel distance.
    lower = ((lo, 0.), (ac.v, -acceleration), (target-acceleration*duration, acceleration))
    upper = ((hi, 0.), (ac.v, acceleration), (target+acceleration*duration, -acceleration))
    knots = {0., duration}
    for lines in (lower, upper):
        for i, (intercept, slope) in enumerate(lines):
            for other, other_slope in lines[i+1:]:
                if slope != other_slope:
                    t = (other-intercept)/(slope-other_slope)
                    if 0. < t < duration:
                        knots.add(t)

    def speeds(t):
        return (max(c+m*t for c,m in lower), min(c+m*t for c,m in upper))

    times = sorted(knots)
    minimum, maximum = (math.fsum((speeds(a)[i]+speeds(b)[i])*(b-a)/2
                                 for a,b in zip(times,times[1:])) for i in (0,1))
    if distance < minimum-1e-8 or distance > maximum+1e-8:
        raise ValueError("G_TERMINAL_STATE_UNREACHABLE")
    weight = min(1., max(0., (distance-minimum)/(maximum-minimum))) if maximum > minimum else 0.

    def speed(t):
        low, high = speeds(t)
        return low + weight*(high-low)

    position = ac.s
    pieces = []
    for a,b in zip(times,times[1:]):
        if a >= dt_s:
            break
        end = min(b,dt_s)
        v = ac.v if a == 0. else speed(a)
        # Use the slope of the active envelope lines, avoiding differencing
        # nearly identical velocities at neighboring floating-point knots.
        middle = (a+b)/2
        low_slope = max(lower,key=lambda line: line[0]+line[1]*middle)[1]
        high_slope = min(upper,key=lambda line: line[0]+line[1]*middle)[1]
        piece = Piece(a,end,position,v,low_slope+weight*(high_slope-low_slope))
        pieces.append(piece)
        position = piece.state_at(end)[0]
    if dt_s > duration:
        pieces.append(Piece(duration,dt_s,position,target,0.))
    return Profile(tuple(pieces),dt_s)
