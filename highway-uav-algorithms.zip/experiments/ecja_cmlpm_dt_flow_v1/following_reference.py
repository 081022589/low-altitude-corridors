"""Offline reuse of the production follow law for uncommitted H references."""
from dataclasses import replace
from experiments.kinematic_layer_v1.kinematic_advance import Piece,Profile,Leader,advance,stop_satisfied,build_profile


def following_reference(aircraft,duration,leader_profile=None,leader_braking=None,*,stop_station=None,min_gap=50.,leader_time_offset=0.):
    free=build_profile(aircraft,min(aircraft.nominal,aircraft.limits.v_max),duration)
    if leader_profile is None and stop_satisfied(free,aircraft,stop_station):
        return free
    current=aircraft
    pieces=[]
    clock=0.
    while clock<duration-1e-10:
        if current.v==0. and stop_station is not None and abs(current.s-stop_station)<=1e-6:
            pieces.append(Piece(clock,duration,current.s,0.,0.))
            break
        end=min(duration,clock+.5)
        leader=None
        front=None
        if leader_profile is not None and clock+leader_time_offset<leader_profile.duration_s-1e-9:
            end=min(end,leader_profile.duration_s-leader_time_offset)
            position,speed=leader_profile.state_at(clock+leader_time_offset)
            leader=Leader(position,speed,leader_braking)
            segment=[]
            for p in leader_profile.pieces:
                left,right=max(clock+leader_time_offset,p.start_s),min(end+leader_time_offset,p.end_s)
                if right>left:
                    s,v=p.state_at(left)
                    segment.append(Piece(left-clock-leader_time_offset,right-clock-leader_time_offset,s,v,p.a))
            front=Profile(tuple(segment),end-clock)
        tick=advance(current,dt_s=end-clock,now_s=clock,slot=None,leader=leader,
                     leader_profile=front,min_gap_m=min_gap,stop_station_m=stop_station,enforce_slot_timing=False)
        if stop_station is not None and not stop_satisfied(tick.profile,current,stop_station):
            raise ValueError("LTG_WAITING_STOP_UNREACHABLE")
        if front is not None and tick.profile.min_gap_with(front)<min_gap-1e-6:
            raise ValueError("FOLLOWING_REFERENCE_UNAVAILABLE")
        for p in tick.profile.pieces:
            start,finish=p.start_s+clock,p.end_s+clock
            # A positive local interval may collapse under floating-point
            # translation. It has no representable extent in this clock.
            if finish>start:
                pieces.append(Piece(start,finish,p.s0,p.v0,p.a))
        current=replace(current,s=tick.profile.end[0],v=tick.profile.end[1])
        clock=end
    return Profile(tuple(pieces),duration)

