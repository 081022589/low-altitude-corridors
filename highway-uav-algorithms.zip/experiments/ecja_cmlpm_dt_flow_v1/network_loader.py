from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Mapping
from ecja_qsap.formal_motion import formal_transfer_entry_station


REPO_ROOT = Path(__file__).resolve().parents[2]
FORMAL_DOMAIN_PATH = (
    REPO_ROOT
    / "docs/experiment_master_20261008/amd04_rectangular_shared_descent/AMD04_INTERFACE_ALLOWED_DOMAINS.json"
)
VERTICAL_CHANNEL_OUTER_RADIUS_M = 10.0
VERTICAL_CHANNEL_Z_MIN_M = 50.0
VERTICAL_CHANNEL_Z_MAX_M = 110.0


@dataclass(frozen=True)
class RegisteredG25:
    source_path: Path
    source_sha256: str
    contract_version: str
    structure_id: str
    geometry_hash: str
    nodes: tuple[Mapping[str, Any], ...]
    mainlines: tuple[Mapping[str, Any], ...]
    interfaces: tuple[Mapping[str, Any], ...]
    resources: tuple[Mapping[str, Any], ...]
    node_count_by_direction: Mapping[str, int]
    formal_geometry: Mapping[str, Mapping[str, Any]]

    @property
    def resource_by_id(self) -> dict[str, Mapping[str, Any]]:
        return {str(item["resource_id"]): item for item in self.resources}

    @property
    def interface_by_route(self) -> dict[str, Mapping[str, Any]]:
        return {str(item["route_id"]): item for item in self.interfaces}


def _vertical_channel_outer_envelope(j_xyz):
    """Runtime design metadata for the 10 m shared-resource envelope."""
    return {
        "type": "FINITE_CYLINDER",
        "axis_xy": [float(j_xyz[0]), float(j_xyz[1])],
        "radius_m": VERTICAL_CHANNEL_OUTER_RADIUS_M,
        "z_min_m": VERTICAL_CHANNEL_Z_MIN_M,
        "z_max_m": VERTICAL_CHANNEL_Z_MAX_M,
        "representation": "DESIGN_OUTER_ENVELOPE",
        "participates_in_resource_mapping": False,
    }


def formal_g_station(network: RegisteredG25, interface: Mapping[str, Any]) -> float:
    """The unique registered G entry; no legacy fork substitute."""
    return float(network.formal_geometry[str(interface["interface_id"])]["g_station_m"])


def formal_g_stations(network: RegisteredG25) -> dict[tuple[str, str], float]:
    return {(str(i["service_node_id"]), str(i["source_layer"])): formal_g_station(network, i)
            for i in network.interfaces}


def _fixed_path_geometry(mainlines, interfaces, source_sha256):
    domains = json.loads(FORMAL_DOMAIN_PATH.read_text(encoding="utf-8"))
    approved = {str(i["interface_id"]): i for i in domains.get("interfaces", ())
                if i.get("Omega_allowed", {}).get("approved") is True}
    anchors_path = REPO_ROOT / "network_contracts/g25_planar_realized_v1_3/zhou_transfer_anchors_v1.json"
    anchor_payload = json.loads(anchors_path.read_text(encoding="utf-8"))
    if anchor_payload.get("source_network_sha256") != source_sha256:
        raise ValueError("ZHOU_TRANSFER_ANCHOR_NETWORK_MISMATCH")
    anchors = {str(i["interface_id"]): i for i in anchor_payload["interfaces"]}
    if set(approved) != {str(i["interface_id"]) for i in interfaces} or set(anchors) != set(approved):
        raise ValueError("FORMAL_TRANSFER_FRAME_COVERAGE_INCOMPLETE")
    result, identities = {}, set()
    for interface in interfaces:
        identity = (str(interface["service_node_id"]), str(interface["direction"]), str(interface["source_layer"]))
        if identity in identities:
            raise ValueError(f"FIXED_PATH_NOT_UNIQUE:{identity}")
        identities.add(identity)
        line = next(m for m in mainlines if m["direction"] == identity[1] and m["paper_layer"] == identity[2])
        key = str(interface["interface_id"])
        domain, anchor = approved[key], anchors[key]
        frame = domain["frame"]
        g = float(anchor["g_station_m"])
        if not math.isfinite(g) or not 0. < g < float(line["path"]["length_m"]):
            raise ValueError(f"FORMAL_G_OUTSIDE_MAINLINE:{identity}")
        from build_airspace.corridor.network_contract_geometry import point_at_arc
        if math.dist(point_at_arc(line["path"], g), anchor["g_xyz"]) > 1e-5:
            raise ValueError(f"FORMAL_G_ANCHOR_OFF_MAINLINE:{key}")
        cells = {cell["cell_id"]: cell for family in ("Omega_H", "Omega_V")
                 for cell in domain[family]["cells"]}
        allowed = [cells[cell_id] for cell_id in domain["Omega_allowed"]["cell_ids"]]
        result[key] = {"formal_transfer_frame": frame, "g_station_m": g,
                       "zhou_g_xyz": anchor["g_xyz"], "zhou_j_xyz": anchor["j_xyz"],
                       "vertical_channel_outer_envelope": _vertical_channel_outer_envelope(anchor["j_xyz"]),
                       "zhou_allowed_cells": allowed,
                       "zhou_mainline_tangent_xyz": [frame["basis_columns"][axis][0] for axis in range(3)]}
    return result


@dataclass(frozen=True)
class DirectedNodeInterval:
    """Registered node geometry on one directed mainline.

    Stations are the registered directed-mainline ``q`` coordinates.  They
    increase in the operating direction for both forward and reverse flows.
    ``lower_q_m``/``upstream_node_id`` are retained as registry metadata for
    geometry and historical evidence. They are not the C-MLPM scheduling
    boundary; active scheduling starts at this node's ``G-3Dcommit``.
    """

    node_id: str
    direction: str
    layer: str
    mainline_id: str
    upstream_node_id: str | None
    lower_q_m: float
    upper_q_m: float
    lower_inclusive: bool = True
    upper_inclusive: bool = False

    def contains(self, q_m: float, *, tolerance: float = 1e-9) -> bool:
        value = float(q_m)
        return value >= self.lower_q_m - tolerance and value < self.upper_q_m


def directed_node_interval(
    network: RegisteredG25, node_id: str, direction: str, layer: str
) -> DirectedNodeInterval:
    """Resolve current-node G and registered upstream geometry metadata."""

    flows = [
        row for row in network.mainlines
        if str(row["direction"]) == direction and str(row["paper_layer"]) == layer
    ]
    if len(flows) != 1:
        raise ValueError(f"G25_MAINLINE_CARDINALITY:{direction}:{layer}:{len(flows)}")
    flow = flows[0]
    length_m = float(flow["path"]["length_m"])
    rows = [
        row for row in network.interfaces
        if str(row["direction"]) == direction and str(row["source_layer"]) == layer
    ]
    stations: list[tuple[float, str]] = []
    for row in rows:
        q_m = formal_g_station(network, row)
        if not 0.0 < q_m < length_m:
            raise ValueError(f"G25_NODE_STATION_OUTSIDE_FLOW:{row['service_node_id']}")
        stations.append((q_m, str(row["service_node_id"])))
    stations.sort()
    if any(right[0] <= left[0] for left, right in zip(stations, stations[1:])):
        raise ValueError(f"G25_NODE_STATIONS_NOT_STRICTLY_MONOTONE:{direction}:{layer}")
    matches = [index for index, (_, candidate) in enumerate(stations) if candidate == node_id]
    if len(matches) != 1:
        raise ValueError(f"G25_NODE_FLOW_CARDINALITY:{node_id}:{direction}:{layer}:{len(matches)}")
    index = matches[0]
    lower_q, upstream = (0.0, None) if index == 0 else stations[index - 1]
    upper_q = stations[index][0]
    return DirectedNodeInterval(
        node_id=node_id,
        direction=direction,
        layer=layer,
        mainline_id=str(flow["mainline_id"]),
        upstream_node_id=upstream,
        lower_q_m=float(lower_q),
        upper_q_m=float(upper_q),
    )


def load_registered_g25(path: str | Path) -> RegisteredG25:
    source = Path(path).resolve()
    raw = source.read_bytes()
    payload = json.loads(raw.decode("utf-8"))
    if payload.get("structure_id") != "G25-PLANAR-1.3":
        raise ValueError("UNEXPECTED_G25_STRUCTURE_ID")
    nodes = tuple(payload.get("service_nodes", ()))
    interfaces = tuple(payload.get("interfaces", ()))
    resources = tuple(payload.get("resources", ()))
    mainlines = tuple(payload.get("mainlines", ()))
    if (len(nodes), len(interfaces), len(resources), len(mainlines)) != (7, 21, 21, 6):
        raise ValueError("G25_REGISTERED_INVENTORY_MISMATCH")
    resource_ids = {str(item["resource_id"]) for item in resources}
    for interface in interfaces:
        if interface.get("status") != "ACCEPTED":
            raise ValueError(f"G25_INTERFACE_NOT_ACCEPTED:{interface.get('interface_id')}")
        chain = tuple(interface.get("route_template", {}).get("resource_chain", ()))
        if not chain or not set(chain) <= resource_ids:
            raise ValueError(f"G25_RESOURCE_CHAIN_UNREGISTERED:{interface.get('interface_id')}")
    by_direction = {
        direction: sum(direction in item.get("allowed_directions", ()) for item in nodes)
        for direction in ("forward", "reverse")
    }
    return RegisteredG25(
        source_path=source,
        source_sha256=hashlib.sha256(raw).hexdigest(),
        contract_version=str(payload["contract_version"]),
        structure_id=str(payload["structure_id"]),
        geometry_hash=str(payload["geometry_hash"]),
        nodes=nodes,
        mainlines=mainlines,
        interfaces=interfaces,
        resources=resources,
        node_count_by_direction=by_direction,
        formal_geometry=_fixed_path_geometry(mainlines, interfaces, hashlib.sha256(raw).hexdigest()),
    )


def to_ecja_g25_source(
    network: RegisteredG25, *, include_formal_motion: bool = True
) -> dict[str, Any]:
    """Project the accepted v1.3 registry into the read-only ECJA G25 seam."""

    if not include_formal_motion:
        raise ValueError("FORMAL_FIXED_PATH_REQUIRED")

    mainlines = []
    for item in network.mainlines:
        mainlines.append(
            {
                "mainline_id": item["mainline_id"],
                "parent_mainline_id": item["mainline_id"],
                "layer_id": item["paper_layer"],
                "direction_id": item["direction"],
                "side_id": item["direction"],
                "center_z_m": float(item["center_altitude_m"]),
                "width_m": float(item["width_m"]),
                "height_m": float(item["height_m"]),
                "polyline_3d": item["path"]["centerline_xyz"],
                "source_geometry_hash": item["path"]["path_id"],
            }
        )
    interfaces = []
    for item in network.interfaces:
        route = item["route_template"]
        layer = item["source_layer"]
        gate = item["origin_gate_xyz"]
        record = {
                "interface_id": item["interface_id"],
                "source_interface_id": item["interface_id"],
                "service_node_id": item["service_node_id"],
                "source_layer_id": layer,
                "direction_id": item["direction"],
                "source_chainage_m": formal_g_station(network, item),
                "interface_point_3d": list(gate),
                "shaft_axis_xy": [float(gate[0]), float(gate[1])],
                "shaft_top_z_m": float({"L1": 70.0, "L2": 90.0, "L3": 110.0}[layer]),
                "shaft_scope_end_z_m": 50.0,
                "resource_chain": list(route["resource_chain"]),
                "status": item["status"],
            }
        record.update(network.formal_geometry[str(item["interface_id"])])
        interfaces.append(record)
    return {
        "schema_version": "G25_CANONICAL_NETWORK_V3_0",
        "source_root": str(network.source_path.parent),
        "source_version": network.contract_version,
        "source_status": "REGISTERED_ACCEPTED",
        "formal_geometry_approval": False,
        "layers": [
            {"layer_id": "L1", "layer_order": 1, "center_z_m": 70.0, "width_m": 20.0, "height_m": 10.0},
            {"layer_id": "L2", "layer_order": 2, "center_z_m": 90.0, "width_m": 20.0, "height_m": 10.0},
            {"layer_id": "L3", "layer_order": 3, "center_z_m": 110.0, "width_m": 20.0, "height_m": 10.0},
        ],
        "mainlines": sorted(mainlines, key=lambda row: row["mainline_id"]),
        "access_interfaces": sorted(interfaces, key=lambda row: row["interface_id"]),
        "source_lineage": {
            "source_dataset_id": network.structure_id,
            "source_version": network.contract_version,
            "source_asset_paths": [str(network.source_path)],
            "source_asset_sha256": {str(network.source_path): network.source_sha256},
            "source_geometry_hash": network.geometry_hash,
            "geometry_gate_status": "C0_TRAFFIC_ARC_MODEL",
            "protected_changed": [],
            "protected_files": [str(network.source_path)],
            "offset_candidate_id": None,
        },
    }

