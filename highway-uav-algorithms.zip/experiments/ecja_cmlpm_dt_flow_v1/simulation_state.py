from __future__ import annotations
from .joint_motion_evidence import (
    measured, performance_span, copy_profile_sample, record_copy_profile,
)

from dataclasses import dataclass, field, replace
from enum import Enum
import copy
import hashlib
import json
import math
import sys
import threading
from time import perf_counter
from types import MappingProxyType
from typing import Any, Iterable, Mapping
from ecja_qsap.history_context import (
    _observed_event_records,
    assignment_passage_incompatibility,
    build_active_assignment_summary,
    inherit_passage_commitment,
)
from traffic_simulation.cmlpm.joint_single_node.schema import PendingTimingRequest
from .assignment_geometry import bind_assignment_geometry, assert_assignment_geometry_preserved


class FlightState(str, Enum):
    NOT_YET_REQUESTED = "NOT_YET_REQUESTED"
    MAINLINE = "MAINLINE"
    PENDING_ASSIGNMENT = "PENDING_ASSIGNMENT"
    ASSIGNED = "ASSIGNED"
    SCHEDULED = "SCHEDULED"
    TRANSITION = "TRANSITION"
    VERTICAL = "VERTICAL"
    # Post-service re-entry: active but off the mainline lane.
    SERVICING = "SERVICING"
    REENTRY_HOLD = "REENTRY_HOLD"
    REENTRY_CLIMB = "REENTRY_CLIMB"
    REENTRY_LAND_TO_GROUND = "REENTRY_LAND_TO_GROUND"
    REENTRY_ASCENT_TO_50M = "REENTRY_ASCENT_TO_50M"
    REENTRY_STAGING_HOLD = "REENTRY_STAGING_HOLD"
    REENTRY_FINAL_APPROACH = "REENTRY_FINAL_APPROACH"
    REENTRY_LOCAL_BRAKING = "REENTRY_LOCAL_BRAKING"
    REENTRY_LOCAL_HOLD = "REENTRY_LOCAL_HOLD"
    COMPLETED = "COMPLETED"
    EXITED = "EXITED"
    ENERGY_INFEASIBLE = "ENERGY_INFEASIBLE"
    UNASSIGNED = "UNASSIGNED"
    DEFERRED = "DEFERRED"
    MOTION_INFEASIBLE = "MOTION_INFEASIBLE"
    HORIZON_CENSORED = "HORIZON_CENSORED"


@dataclass(frozen=True)
class UAVState:
    uav_id: str
    vehicle_type: str
    lane_id: str
    direction: str
    layer: str
    entry_time_s: float
    s_m: float
    z_m: float
    speed_mps: float
    energy_remaining_wh: float = 200.0
    energy_reserve_wh: float = 10.0
    state: FlightState = FlightState.MAINLINE
    request_trigger_time_s: float | None = None
    request_id: str | None = None
    request_reason: str | None = None
    request_guard_valid: bool | None = None
    request_guard_distance_m: float | None = None
    request_distance_at_trigger_m: float | None = None
    candidate_nodes: tuple[str, ...] = ()
    assigned_node: str | None = None
    assigned_route: str | None = None
    commit_status: str = "UNCOMMITTED"
    assignment_outcome_reason: str | None = None
    frozen_event_ids: tuple[str, ...] = ()
    current_motion_plan: dict[str, Any] = field(default_factory=dict)
    event_version: int = 0
    request: bool = False
    direct_h_affected: bool = False
    follow_h_affected: bool = False
    nominal_speed_mps: float | None = None
    # Set only with a verified, atomically published C-MLPM result.
    # Physical execution continues; this request no longer accepts a new decision.
    cmlpm_managed: bool = False
    # Set only after the current C-MLPM round has an independently certified
    # passage time and executable speed command. Applies to both V requests
    # and H mainline traffic.
    cmlpm_plan_immutable: bool = False
    # Unpublished timing request, inherited verbatim by motion ticks. Cleared
    # only by a certified release, never by a new ECJA assignment.
    cmlpm_pending: PendingTimingRequest | None = None
    # Request facts survive rejected scheduling attempts; they are not a
    # WAITING result, a motion permission, or a frozen resource reservation.
    cmlpm_request_baseline: dict[str, Any] | None = None
    # Energy-trigger seam.  These fields are append-only runtime facts and do
    # not alter the registered ECJA/C-MLPM scheduling mathematics.
    energy_episode_id: int = 0
    energy_direct_finish_locked: bool = False
    energy_input_classification: str | None = None

    @classmethod
    def mainline(
        cls,
        uav_id: str,
        vehicle_type: str,
        lane_id: str,
        layer: str,
        s_m: float,
        speed_mps: float,
        *,
        direction: str = "forward",
        entry_time_s: float = 0.0,
        request: bool = False,
    ) -> "UAVState":
        return cls(
            uav_id=uav_id,
            vehicle_type=vehicle_type,
            lane_id=lane_id,
            direction=direction,
            layer=layer,
            entry_time_s=entry_time_s,
            s_m=s_m,
            z_m={"L1": 70.0, "L2": 90.0, "L3": 110.0}[layer],
            speed_mps=speed_mps,
            nominal_speed_mps=speed_mps,
            request=request,
        )

    def moved(self, *, s_m: float, speed_mps: float, **changes: Any) -> "UAVState":
        return replace(self, s_m=s_m, speed_mps=speed_mps, **changes)


@dataclass(frozen=True)
class TrafficEvent:
    event_id: str
    event_type: str
    uav_id: str
    sim_time_s: float
    node_id: str | None = None
    resource_id: str | None = None
    detail: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class TrafficSnapshot:
    """One immutable, versioned view of the observed traffic state."""

    version: int
    sim_time_s: float
    states: Mapping[str, UAVState]
    # Recent terminal event history still owns resource cooldown; these UAVs
    # are read-only dependencies, never reinserted into active traffic.
    resource_dependencies: Mapping[str, UAVState] = field(default_factory=dict)
    # ``None`` is retained for manually constructed analytical snapshots.  A
    # store-owned snapshot carries a private identity token so a caller cannot
    # accidentally pass a snapshot from another TrafficStateStore merely
    # because version/time happen to match.
    store_token: object | None = field(default=None, repr=False, compare=False)


build_ecja_active_assignment_summary = build_active_assignment_summary


@dataclass(frozen=True)
class AssignmentCommitReceipt:
    commit_id: str
    snapshot_version: int
    committed_version: int
    assignments: Mapping[str, tuple[str, str]]
    status: str
    admission_rejections: Mapping[str, str] = field(default_factory=dict)


@dataclass(frozen=True)
class SchedulingCommitReceipt:
    round_id: str
    snapshot_version: int
    committed_version: int
    uav_ids: tuple[str, ...]
    status: str
    waiting_uav_ids: tuple[str, ...] = ()


_MANAGED_SCHEDULE_FIELDS = (
    "schedule_result", "schedule_round_id", "plan_version", "freeze_record_id",
    "frozen", "g_time_s", "j_time_s", "resource_windows", "checker_evidence",
    "g_station_m", "g_to_j_s", "terminal_speed_mps", "descent_trajectory",
    "enforce_g_terminal_state",
    "local_trajectory_reference", "local_trajectory_id",
    "local_certification_id",
    "trajectory_profile_id", "trajectory_hash", "v4_frozen_trajectory",
    "trajectory_generation_source", "r_time_s", "e_time_s", "v5_frozen_trajectory",
)
_MANAGED_COMMAND_FIELDS = ("timed_resource_targets", "speed_control_token", "passage_arrangement", "cpff_execution")


_IMMUTABLE_PLAN_FIELDS = _MANAGED_COMMAND_FIELDS + (
    "resource_entry_station_m", "resource_exit_station_m", "resource_duration_s",
    "allowed_exit_time_ub_s",
    "trajectory_profile_id", "trajectory_hash", "v4_frozen_trajectory", "v5_frozen_trajectory",
)


def v5_retry_state(state, now_s, reason):
    """Retire an unentered V attempt with its original plan intact in history."""
    old = state.current_motion_plan
    payload = old.get("v5_frozen_trajectory") or {}
    entry = payload.get("boundary_times", {}).get("E")
    station = next((p["s_m"] for p in payload.get("points", ()) if p["time_s"] == entry), None)
    if (state.state != FlightState.SCHEDULED or not state.cmlpm_managed
            or not state.cmlpm_plan_immutable or payload.get("flow") != "V"
            or entry is None or entry <= now_s + 1e-9
            or station is None or state.s_m >= station - 1e-6):
        raise ValueError(f"V5_RETRY_AFTER_ENTRY_OR_NOT_SCHEDULED:{state.uav_id}")
    active = set()
    actual_exits = set()
    for event in old.get("motion_observed_events", ()):
        if event["event_type"] == "RESOURCE_ENTER":
            active.add(event["resource_id"])
        elif event["event_type"] == "RESOURCE_EXIT":
            active.discard(event["resource_id"])
            actual_exits.add(str(event["resource_id"]))
    protected_h = {str(t["resource_id"]) for t in old.get("timed_resource_targets", ())}
    token = old.get("speed_control_token") or {}
    protected_h.update(map(str, token.get("protected_resource_ids", ())))
    if active or protected_h - actual_exits:
        raise ValueError(f"V5_RETRY_WITH_ACTIVE_RESOURCE:{state.uav_id}")
    retired = {key: value for key, value in old.items() if key != "schedule_history"}
    plan = dict(old)
    for key in (*_MANAGED_COMMAND_FIELDS, "schedule_round_id", "plan_version", "freeze_record_id",
                "frozen", "g_time_s", "j_time_s", "e_time_s", "committed_e_time_s",
                "resource_windows", "v5_frozen_trajectory", "cmlpm_resource_passages",
                "resource_target_provenance", "ecja_effective_release_time_s",
                "checker_evidence", "cmlpm_release"):
        plan.pop(key, None)
    plan["schedule_history"] = tuple(old.get("schedule_history", ())) + (
        freeze_plan_payload({"status": "EXECUTION_REJECTED", "time_s": now_s,
                             "reason": reason, "plan": retired}),)
    if actual_exits:
        plan["cmlpm_resource_passages"] = tuple(
            passage for passage in old.get("cmlpm_resource_passages", ())
            if str(passage.get("resource_id")) in actual_exits)
    plan.update(e_station_m=float(station), execution_mode="CMLPM_RETRY_HOLD",
                retry_hold_reason="RUNTIME_AUDIT_REJECTED",
                schedule_result="RETRY_PENDING")
    return replace(state, state=FlightState.ASSIGNED, commit_status="COMMITTED",
                   cmlpm_managed=False, cmlpm_plan_immutable=False, current_motion_plan=plan,
                   event_version=state.event_version+1)


def assert_managed_schedule_preserved(current: UAVState, updated: UAVState) -> None:
    """Protect decisions/commands, while allowing observed physical state to evolve."""
    if not current.cmlpm_managed:
        return
    if _is_lifecycle_release(current, updated):
        return
    if not updated.cmlpm_managed:
        raise ValueError(f"CMLPM_MANAGED_LABEL_REMOVED:{current.uav_id}")
    if (updated.assigned_node, updated.assigned_route) != (current.assigned_node, current.assigned_route):
        raise ValueError(f"MANAGED_ASSIGNMENT_REWRITE:{current.uav_id}")
    fields = _MANAGED_SCHEDULE_FIELDS
    if current.current_motion_plan.get("schedule_result") == "RELEASED":
        fields += _MANAGED_COMMAND_FIELDS
    for key in fields:
        if current.current_motion_plan.get(key) != updated.current_motion_plan.get(key):
            raise ValueError(f"MANAGED_SCHEDULE_REWRITE:{current.uav_id}:{key}")


def assert_immutable_plan_preserved(current: UAVState, updated: UAVState, *, t_now: float | None = None) -> None:
    """Preserve a certified C-MLPM timing command while motion evolves."""
    if not current.cmlpm_plan_immutable:
        return
    if _is_lifecycle_release(current, updated):
        return
    if not updated.cmlpm_plan_immutable:
        from .speed_control_scope import assert_h_control_release
        records = updated.current_motion_plan.get("released_h_speed_controls", ())
        if records and assert_h_control_release(current, updated,
                t_now=float(t_now if t_now is not None else records[-1]["release_time_s"])):
            return
        raise ValueError(f"CMLPM_IMMUTABLE_LABEL_REMOVED:{current.uav_id}")
    for key in _IMMUTABLE_PLAN_FIELDS:
        if current.current_motion_plan.get(key) != updated.current_motion_plan.get(key):
            raise ValueError(f"CMLPM_IMMUTABLE_PLAN_REWRITE:{current.uav_id}:{key}")


def _is_lifecycle_release(current: UAVState, updated: UAVState) -> bool:
    """Whether an observed plan completion hands control to a new lifecycle.

    A resource/descent plan may be released only at an explicitly observed
    boundary.  This exception is intentionally narrow: it does not permit a
    scheduler update to clear an immutable plan while the UAV is still in the
    air.
    """
    if updated.state not in {
        FlightState.ASSIGNED, FlightState.SERVICING, FlightState.MAINLINE,
        FlightState.REENTRY_LAND_TO_GROUND,
    }:
        return False
    release = updated.current_motion_plan.get("cmlpm_release")
    if not isinstance(release, Mapping):
        return False
    if not any(
        isinstance(event, Mapping) and str(event.get("event_type")) in {
            "B_L1", "RESOURCE_EXIT"
        }
        for event in updated.current_motion_plan.get("motion_observed_events", ())
    ):
        return False
    return current.cmlpm_managed or current.cmlpm_plan_immutable


# Two plan artifacts are produced once, are never written in place, and account
# for ~94% of a planned state's payload:
#   descent_trajectory  ~110 KB  (401 segments of the fixed transfer curve)
#   motion_prediction    ~44 KB  (401-point polyline plus its time table)
# They are passed by reference at every ownership transfer instead of being
# deep-copied.  A new object replaces them when the plan is rebuilt, so an
# earlier snapshot keeps the object it observed: that is copy-on-write, not
# shared mutation.  ``tests/ecja/test_snapshot_shared_payload.py`` pins both
# halves of that contract.
SHARED_PLAN_FIELDS = (
    "descent_trajectory", "motion_prediction", "realized_descent_trajectory",
    "reentry_profile", "local_trajectory_reference",
    "v4_frozen_trajectory", "v5_frozen_trajectory", "schedule_history",
)


class FrozenPlanPayload(dict):
    """Read-only mapping used for shared plan artifacts.

    Sharing a mutable value across snapshots would let any consumer rewrite
    history in place, and the store could not notice.  Making the value
    read-only turns that silent corruption into an immediate ``TypeError``,
    so sharing becomes safe by construction rather than by convention.

    Copying stays available: an immutable value deep-copies to itself, which
    is also why the second copy site (``refresh_motion_prediction``) stops
    paying for these artifacts.
    """

    __slots__ = ()

    def _immutable(self, *args, **kwargs):
        raise TypeError("SHARED_PLAN_PAYLOAD_IS_IMMUTABLE")

    __setitem__ = _immutable
    __delitem__ = _immutable
    __ior__ = _immutable
    clear = _immutable
    pop = _immutable
    popitem = _immutable
    setdefault = _immutable
    update = _immutable

    def __deepcopy__(self, memo):
        return self

    def __copy__(self):
        return self

    def __reduce__(self):
        return (FrozenPlanPayload, (dict(self),))


class FrozenPlanSequence(list):
    """Read-only list that still compares equal to a plain list.

    ``tuple`` was the obvious choice and is wrong here: a registered geometry
    is compared with ``resources[rid] != geometry``, and ``[1, 2] != (1, 2)``.
    Keeping list identity means read-onlyness costs nothing at comparison
    sites.
    """

    __slots__ = ()

    def _immutable(self, *args, **kwargs):
        raise TypeError("SHARED_PLAN_PAYLOAD_IS_IMMUTABLE")

    __setitem__ = _immutable
    __delitem__ = _immutable
    __iadd__ = _immutable
    __imul__ = _immutable
    append = _immutable
    clear = _immutable
    extend = _immutable
    insert = _immutable
    pop = _immutable
    remove = _immutable
    reverse = _immutable
    sort = _immutable

    def __deepcopy__(self, memo):
        return self

    def __copy__(self):
        return self

    def __reduce__(self):
        return (FrozenPlanSequence, (list(self),))


def freeze_plan_payload(value: Any) -> Any:
    """Freeze one shared artifact, leaving an already-frozen value untouched."""

    if isinstance(value, (FrozenPlanPayload, FrozenPlanSequence)):
        return value
    if isinstance(value, Mapping):
        return FrozenPlanPayload(
            (key, freeze_plan_payload(item)) for key, item in value.items()
        )
    if isinstance(value, list):
        return FrozenPlanSequence(freeze_plan_payload(item) for item in value)
    if isinstance(value, tuple):
        return tuple(freeze_plan_payload(item) for item in value)
    return value


# Immutable scalars need no copy: deep-copying them returns an equal value and
# only pays the call overhead.  41 of the 58 plan keys are these.
_IMMUTABLE_SCALARS = (str, bytes, int, float, bool, type(None))


def _copy_plan_value(value: Any) -> Any:
    return value if isinstance(value, _IMMUTABLE_SCALARS) else copy.deepcopy(value)


def _copy_profile_size(value: Any) -> int:
    """Approximate sampled payload size without affecting normal execution."""
    if isinstance(value, Mapping):
        return sys.getsizeof(value) + sum(
            _copy_profile_size(key) + _copy_profile_size(item)
            for key, item in value.items()
        )
    if isinstance(value, (list, tuple, set, frozenset)):
        return sys.getsizeof(value) + sum(_copy_profile_size(item) for item in value)
    return sys.getsizeof(value)


def _copy_state(row: "UAVState") -> "UAVState":
    """Copy dynamic state, sharing explicitly frozen plan artifacts by reference.

    Everything else in ``current_motion_plan`` is still copied unless it is an
    immutable scalar, so a consumer that edits any other key cannot reach back
    into the store.
    """

    plan = row.current_motion_plan
    profile = copy_profile_sample()
    copied = {}
    for key, value in plan.items():
        started = perf_counter() if profile is not None else 0.0
        copied_value = (freeze_plan_payload(value) if key in SHARED_PLAN_FIELDS
                        else _copy_plan_value(value))
        if profile is not None:
            record_copy_profile(profile, f"plan.{key}", perf_counter() - started,
                                _copy_profile_size(value))
        copied[key] = copied_value
    if profile is not None:
        started = perf_counter()
        baseline = copy.deepcopy(row.cmlpm_request_baseline)
        record_copy_profile(profile, "cmlpm_request_baseline", perf_counter() - started,
                            _copy_profile_size(row.cmlpm_request_baseline))
    else:
        baseline = copy.deepcopy(row.cmlpm_request_baseline)
    return replace(row, current_motion_plan=copied,
                   cmlpm_request_baseline=baseline)


class TrafficStateStore:
    """Versioned in-memory adapter over the existing ``UAVState`` records.

    Traffic motion updates and ECJA assignment commits share the same version.
    A commit is compare-and-swap: either every selected request is written, or
    none is.  Replaying the same ``commit_id`` is idempotent.
    """

    def __init__(self, states: Iterable[UAVState] = (), *, sim_time_s: float = 0.0):
        rows = tuple(states)
        if len({row.uav_id for row in rows}) != len(rows):
            raise ValueError("DUPLICATE_UAV_STATE")
        # frozen=True protects attributes, not nested motion dictionaries.
        # Isolate those dictionaries at every ownership transfer.
        terminal = {FlightState.COMPLETED, FlightState.EXITED, FlightState.HORIZON_CENSORED}
        self._states = {row.uav_id: _copy_state(row) for row in rows if row.state not in terminal}
        self._completed_states = {row.uav_id: _copy_state(row) for row in rows if row.state in terminal}
        self._sim_time_s = float(sim_time_s)
        self._version = 0
        self._snapshot_token = object()
        self._commits: dict[str, tuple[tuple[tuple[str, str, str, str], ...], AssignmentCommitReceipt]] = {}
        self._unassigned_commits: dict[str, tuple[tuple[str, ...], AssignmentCommitReceipt]] = {}
        self._schedule_commits: dict[str, tuple[tuple[tuple[str, UAVState], ...], SchedulingCommitReceipt]] = {}
        self._reentry_retirements: list[dict[str, Any]] = []
        self._lock = threading.RLock()

    @measured("state.snapshot")
    def snapshot(self) -> TrafficSnapshot:
        """Copy only aircraft that can still change during a simulation step."""
        with self._lock:
            rows = {uav_id: _copy_state(row) for uav_id, row in self._states.items()}
            from .execution_precedence import resource_cooldown_dependencies
            dependencies=resource_cooldown_dependencies(self._completed_states,self._sim_time_s)
            return TrafficSnapshot(self._version,self._sim_time_s,MappingProxyType(rows),
                MappingProxyType({u:_copy_state(s) for u,s in dependencies.items()}),
                self._snapshot_token)

    def final_snapshot(self) -> TrafficSnapshot:
        """Include retained terminal records for reporting and historical audit."""
        with self._lock:
            rows = {uav_id: _copy_state(row) for uav_id, row in self._completed_states.items()}
            rows.update({uav_id: _copy_state(row) for uav_id, row in self._states.items()})
            return TrafficSnapshot(self._version, self._sim_time_s, MappingProxyType(rows),
                store_token=self._snapshot_token)

    def validate_snapshot(self, snapshot: TrafficSnapshot) -> TrafficSnapshot:
        """Validate and return a borrowed snapshot for the current store.

        This is deliberately stricter than checking ``version`` and
        ``sim_time_s``: two independent stores can legitimately have the same
        pair.  Manually constructed analytical snapshots have no token and are
        rejected by this runtime-only handoff API.
        """
        if not isinstance(snapshot, TrafficSnapshot):
            raise TypeError("INVALID_TRAFFIC_SNAPSHOT")
        with self._lock:
            if snapshot.store_token is not self._snapshot_token:
                raise ValueError("SNAPSHOT_STORE_MISMATCH")
            if snapshot.version != self._version or snapshot.sim_time_s != self._sim_time_s:
                raise ValueError("STALE_TRAFFIC_SNAPSHOT")
        return snapshot

    def retire_completed_for_reentry(
        self,
        *,
        expected_version: int,
        uav_id: str,
        sim_time_s: float,
        reset_state: UAVState,
        retirement_audit: Mapping[str, Any],
    ) -> UAVState:
        """Move one fulfilled completed descent back to an active SERVICING state.

        This is the only sanctioned path that clears ``cmlpm_managed`` /
        ``cmlpm_plan_immutable`` and the committed request identity.  It fails
        closed unless the descent plan is fulfilled, B_L1 was observed and every
        protected resource has an actual ``RESOURCE_EXIT``.  Existing motion,
        C-MLPM and ECJA paths are untouched.
        """

        with self._lock:
            if int(expected_version) != self._version:
                raise ValueError("STALE_TRAFFIC_SNAPSHOT")
            now = float(sim_time_s)
            if now < self._sim_time_s:
                raise ValueError("TRAFFIC_TIME_REWIND")
            key = str(uav_id)
            completed = self._completed_states.get(key)
            active = self._states.get(key)
            if completed is not None:
                if completed.state != FlightState.COMPLETED:
                    raise ValueError(f"REENTRY_RETIREMENT_NOT_COMPLETED:{key}")
                current = completed
                source = "completed"
            elif active is not None and active.state == FlightState.SERVICING:
                # B_L1 was written directly as SERVICING (re-entry mode); the
                # descent labels are still present and must be cleared by this
                # sanctioned path.
                current = active
                source = "active_servicing"
            else:
                raise ValueError(f"REENTRY_RETIREMENT_UNKNOWN_UAV:{key}")
            if reset_state.uav_id != key:
                raise ValueError("REENTRY_RETIREMENT_UAV_MISMATCH")
            if reset_state.state != FlightState.SERVICING:
                raise ValueError("REENTRY_RETIREMENT_RESET_NOT_SERVICING")
            if reset_state.cmlpm_managed or reset_state.cmlpm_plan_immutable:
                raise ValueError("REENTRY_RETIREMENT_LABELS_NOT_CLEARED")
            if (
                reset_state.commit_status != "UNCOMMITTED"
                or reset_state.assigned_node is not None
                or reset_state.request_id is not None
            ):
                raise ValueError("REENTRY_RETIREMENT_REQUEST_NOT_CLEARED")
            if "reentry_service_started_s" not in reset_state.current_motion_plan:
                raise ValueError("REENTRY_RETIREMENT_SERVICE_CLOCK_MISSING")

            plan = current.current_motion_plan
            observed = tuple(
                item for item in plan.get("motion_observed_events", ())
                if isinstance(item, dict)
            )
            if not any(str(item.get("event_type")) == "B_L1" for item in observed):
                raise ValueError(f"REENTRY_RETIREMENT_B_L1_MISSING:{key}")
            if any(float(item['actual_time_s']) > now+1e-9 for item in observed):
                raise ValueError(f"REENTRY_RETIREMENT_FUTURE_EVENT:{key}")
            arrangement = plan.get("passage_arrangement") or {}
            protected = [
                str(row[0]) for row in arrangement.get("resources", ())
                if row
            ]
            protected.extend(str(row[0]) for row in plan.get('resource_windows',()))
            protected.extend(str(row['resource_id']) for row in plan.get('timed_resource_targets',()))
            protected.extend(str(row['resource_id']) for row in observed
                             if row.get('event_type')=='RESOURCE_ENTER' and row.get('resource_id'))
            exited = {
                str(item.get("resource_id"))
                for item in observed
                if str(item.get("event_type")) == "RESOURCE_EXIT" and item.get("resource_id")
            }
            missing = [resource for resource in protected if resource not in exited]
            if missing:
                raise ValueError(
                    f"REENTRY_RETIREMENT_RESOURCE_NOT_RELEASED:{key}:{','.join(sorted(missing))}"
                )

            record = dict(retirement_audit)
            record['retired_motion_plan'] = freeze_plan_payload(_copy_plan_value(plan))
            record["uav_id"] = key
            record["retired_at_s"] = now
            record["retirement_source"] = source
            self._reentry_retirements.append(record)
            if source == "completed":
                self._completed_states.pop(key)
            self._states[key] = _copy_state(replace(reset_state,cmlpm_request_baseline=None))
            self._sim_time_s = now
            self._version += 1
            return reset_state

    def reentry_retirements(self) -> tuple[dict[str, Any], ...]:
        with self._lock:
            return tuple(dict(record) for record in self._reentry_retirements)

    @measured("state.read_metadata")
    def read_metadata(self) -> tuple[int, float, int]:
        """Read coherent scalar state without exposing any mutable payload."""
        with self._lock:
            return self._version, self._sim_time_s, len(self._states) + len(self._completed_states)

    def successful_completed_count(self) -> int:
        """Return the number of successful terminal records without deep-copying them.

        Completion-driven simulations must inspect terminal states that have
        already moved out of ``_states``.  This scalar accessor keeps the
        stop check cheap while preserving the store's ownership boundary.
        """
        with self._lock:
            return sum(
                state.state == FlightState.COMPLETED
                for state in self._completed_states.values()
            )

    def register_cmlpm_request_baselines(self, baselines, *, expected_version):
        """Record first eligibility independently of scheduling publication."""
        with self._lock:
            if expected_version != self._version:
                raise ValueError("STALE_TRAFFIC_SNAPSHOT")
            updates={}
            for uid,baseline in baselines.items():
                state=self._states.get(uid)
                if state is None:
                    raise ValueError("INVALID_CMLPM_REQUEST_BASELINE:"+uid)
                if (state.cmlpm_managed or state.commit_status!='COMMITTED' or state.state!=FlightState.ASSIGNED
                        or state.assigned_node!=baseline['node_id']
                        or baseline['request_id']!=(state.request_id or f"CMLPM:{state.assigned_node}:{uid}")
                        or not all(math.isfinite(float(baseline[k])) for k in
                                   ('nominal_service_time_s','first_eligible_time_s'))
                        or baseline['first_eligible_time_s']>self._sim_time_s):
                    raise ValueError("INVALID_CMLPM_REQUEST_BASELINE:"+uid)
                if state.cmlpm_pending is not None and any(baseline[k]!=getattr(state.cmlpm_pending,k)
                        for k in ('request_id','nominal_service_time_s','first_eligible_time_s')):
                    raise ValueError("CMLPM_REQUEST_BASELINE_PENDING_MISMATCH:"+uid)
                if state.cmlpm_request_baseline is not None:
                    if state.cmlpm_request_baseline!=baseline:
                        raise ValueError("CMLPM_REQUEST_BASELINE_REWRITE:"+uid)
                    continue
                updates[uid]=replace(state,cmlpm_request_baseline=copy.deepcopy(baseline))
            if updates:
                self._states.update(updates)
                self._version+=1
            return self._version

    @measured("state.replace_states")
    def replace_states(
        self, states: Iterable[UAVState], *, expected_version: int, sim_time_s: float,
        return_snapshot: bool = True, v5_audit_retries: Mapping[str, str] | None = None,
    ) -> TrafficSnapshot | None:
        rows = tuple(states)
        if len({row.uav_id for row in rows}) != len(rows):
            raise ValueError("DUPLICATE_UAV_STATE")
        with self._lock:
            with performance_span("state.replace_states.validate"):
                self._validate_replace_request(rows, expected_version=expected_version,
                    sim_time_s=sim_time_s)
                replacements = {row.uav_id: row for row in rows}
                for uid, reason in (v5_audit_retries or {}).items():
                    expected = v5_retry_state(self._states[uid], self._sim_time_s, reason)
                    updated = replacements[uid]
                    if (updated.state != expected.state or updated.cmlpm_managed
                            or updated.cmlpm_plan_immutable
                            or updated.commit_status != expected.commit_status
                            or updated.request_id != expected.request_id
                            or updated.current_motion_plan.get("schedule_history")
                            != expected.current_motion_plan["schedule_history"]
                            or updated.current_motion_plan.get("v5_frozen_trajectory") is not None):
                        raise ValueError(f"INVALID_V5_AUDIT_RETRY:{uid}")
                for uav_id, updated in replacements.items():
                    if updated.current_motion_plan.get("joint_motion_witness"):
                        raise ValueError(f"RETIRED_MOTION_CERTIFICATE_IN_NEW_RUN:{uav_id}")
                    current = self._states.get(uav_id)
                    if current is not None and uav_id not in (v5_audit_retries or {}) and (
                        updated.current_motion_plan.get("schedule_history")
                        != current.current_motion_plan.get("schedule_history")
                    ):
                        raise ValueError(f"V5_SCHEDULE_HISTORY_REWRITE:{uav_id}")
                    if updated.cmlpm_managed and (current is None or not current.cmlpm_managed):
                        raise ValueError(f"CMLPM_MANAGED_LABEL_NOT_PUBLISHED:{uav_id}")
                    if updated.cmlpm_plan_immutable and (current is None or not current.cmlpm_plan_immutable):
                        raise ValueError(f"CMLPM_IMMUTABLE_LABEL_NOT_PUBLISHED:{uav_id}")
                for uav_id, current in self._states.items():
                    updated = replacements.get(uav_id)
                    if current.state == FlightState.REENTRY_CLIMB and updated is not None:
                        if current.current_motion_plan.get('reentry_profile') != updated.current_motion_plan.get('reentry_profile'):
                            raise ValueError('REENTRY_PROFILE_REWRITE:'+uav_id)
                    if updated is not None:
                        if updated.cmlpm_request_baseline != current.cmlpm_request_baseline:
                            raise ValueError("CMLPM_REQUEST_BASELINE_REWRITE:"+uav_id)
                        # A fulfilled C-MLPM plan is intentionally replaced by
                        # the next lifecycle phase at B_L1/RESOURCE_EXIT.  At
                        # that boundary the old assigned-path geometry is no
                        # longer an active scheduling contract; the release
                        # marker is the authoritative handoff evidence.
                        if not _is_lifecycle_release(current, updated):
                            assert_assignment_geometry_preserved(current, updated)
                        from .speed_control_scope import assert_h_control_release
                        assert_h_control_release(current, updated, t_now=float(sim_time_s))
                    if current.cmlpm_pending is not None:
                        updated = replacements.get(uav_id)
                        if (updated is None or updated.cmlpm_pending != current.cmlpm_pending
                                or (updated.request_id,updated.assigned_node,updated.assigned_route) !=
                                   (current.request_id,current.assigned_node,current.assigned_route)
                                or any(updated.current_motion_plan.get(k) != current.current_motion_plan.get(k)
                                       for k in ("fifo_rank","fifo_queue_id"))):
                            raise ValueError(f"PENDING_REQUEST_HISTORY_REWRITE:{uav_id}")
                    if current.cmlpm_managed:
                        if uav_id not in replacements:
                            raise ValueError(f"CMLPM_MANAGED_STATE_DROPPED:{uav_id}")
                        if uav_id not in (v5_audit_retries or {}):
                            assert_managed_schedule_preserved(current, replacements[uav_id])
                    if current.cmlpm_plan_immutable:
                        if uav_id not in replacements:
                            raise ValueError(f"CMLPM_IMMUTABLE_STATE_DROPPED:{uav_id}")
                        if uav_id not in (v5_audit_retries or {}):
                            assert_immutable_plan_preserved(current, replacements[uav_id], t_now=float(sim_time_s))
            with performance_span("state.replace_states.history"):
                for uav_id, current in self._states.items():
                    prior_events = _observed_event_records(current.current_motion_plan)
                    if not prior_events:
                        continue
                    updated = replacements.get(uav_id)
                    if updated is None:
                        raise ValueError(f"OBSERVED_OCCUPANCY_HISTORY_DROPPED:{uav_id}")
                    next_events = _observed_event_records(updated.current_motion_plan)
                    for event_id, event in prior_events.items():
                        if event_id not in next_events:
                            raise ValueError(
                                f"OBSERVED_OCCUPANCY_HISTORY_DROPPED:{uav_id}:{event_id}"
                            )
                        if dict(next_events[event_id]) != dict(event):
                            raise ValueError(
                                f"OBSERVED_OCCUPANCY_HISTORY_REWRITTEN:{uav_id}:{event_id}"
                            )
            with performance_span("state.replace_states.copy"):
                terminal = {FlightState.COMPLETED, FlightState.EXITED, FlightState.HORIZON_CENSORED}
                next_active = {}
                newly_completed = {}
                for row in rows:
                    copied = _copy_state(row)
                    if row.state in terminal:
                        newly_completed[row.uav_id] = copied
                    else:
                        next_active[row.uav_id] = copied
            with performance_span("state.replace_states.install"):
                self._states = next_active
                self._completed_states.update(newly_completed)
                self._sim_time_s = float(sim_time_s)
                self._version += 1
            return self.snapshot() if return_snapshot else None

    def _validate_replace_request(self, rows, *, expected_version: int, sim_time_s: float) -> None:
        if expected_version != self._version:
            raise ValueError("STALE_TRAFFIC_SNAPSHOT")
        if float(sim_time_s) < self._sim_time_s:
            raise ValueError("TRAFFIC_TIME_REWIND")
        replacements = {row.uav_id: row for row in rows}
        if self._completed_states.keys() & replacements.keys():
            raise ValueError("COMPLETED_UAV_REENTERED_ACTIVE_STATE")
        if not self._states.keys() <= replacements.keys():
            raise ValueError("ACTIVE_UAV_STATE_DROPPED")

    @measured("state.commit_assignments")
    def commit_assignments(
        self,
        *,
        expected_version: int,
        commit_id: str,
        selections: Mapping[str, tuple[str, str, Mapping[str, Any]]],
        admission_rejections: Mapping[str, str] | None = None,
    ) -> AssignmentCommitReceipt:
        admission_rejections = dict(admission_rejections or {})
        if set(selections).intersection(admission_rejections):
            raise ValueError("ASSIGNMENT_ADMISSION_RESULT_OVERLAP")
        canonical = (tuple(sorted(
            (uav, node, route, str(plan.get("plan_id")),
             str((plan.get("ecja_forward_contract") or {}).get("latest_switch_station_m")))
            for uav, (node, route, plan) in selections.items()
        )), tuple(sorted(admission_rejections.items())))
        with self._lock:
            prior = self._commits.get(commit_id)
            if prior is not None:
                if prior[0] != canonical:
                    raise ValueError("COMMIT_ID_PAYLOAD_MISMATCH")
                return prior[1]
            if expected_version != self._version:
                raise ValueError("STALE_TRAFFIC_SNAPSHOT")
            updates: dict[str, UAVState] = {}
            for uav_id, (node_id, route_id, plan) in selections.items():
                state = self._states.get(uav_id)
                if state is None:
                    raise ValueError(f"UNKNOWN_COMMIT_UAV:{uav_id}")
                if state.commit_status != "UNCOMMITTED" or state.assigned_node is not None:
                    raise ValueError(f"ASSIGNMENT_ALREADY_COMMITTED:{uav_id}")
                if not state.request or state.state != FlightState.PENDING_ASSIGNMENT:
                    raise ValueError(f"UAV_NOT_PENDING_ASSIGNMENT:{uav_id}")
                incompatibility = assignment_passage_incompatibility(
                    state, plan, sim_time_s=self._sim_time_s
                )
                if incompatibility is not None:
                    raise ValueError(
                        f"ASSIGNMENT_INCOMPATIBLE_WITH_EXISTING_PASSAGE_COMMITMENT:"
                        f"{uav_id}:{incompatibility}"
                    )
                fixed_plan = bind_assignment_geometry(inherit_passage_commitment(state, plan),
                    node_id=str(node_id), route_id=str(route_id), vehicle_type=state.vehicle_type)
                # Assignment changes route metadata, never certified motion or
                # its finite execution authority. Keep integration fields here;
                # ECJA's frozen mathematical core remains unchanged.
                for key in ("safety_following_hold",):
                    if key in state.current_motion_plan:
                        fixed_plan[key]=copy.deepcopy(state.current_motion_plan[key])
                fixed_plan["plan_status"] = "FIXED"
                fixed_plan["committed"] = True
                updates[uav_id] = replace(
                    state,
                    assigned_node=str(node_id),
                    assigned_route=str(route_id),
                    current_motion_plan=fixed_plan,
                    commit_status="COMMITTED",
                    state=FlightState.ASSIGNED,
                    request=False,
                    event_version=state.event_version + 1,
                )
            for uav_id, reason in admission_rejections.items():
                state = self._states.get(uav_id)
                if (state is None or state.commit_status != "UNCOMMITTED"
                        or state.assigned_node is not None or not state.request
                        or state.state != FlightState.PENDING_ASSIGNMENT):
                    raise ValueError(f"UAV_NOT_PENDING_ASSIGNMENT:{uav_id}")
                if reason not in {
                    "NO_FORWARD_NODE", "NO_LEGAL_NON_ENERGY_CANDIDATE",
                    "NO_ENERGY_FEASIBLE_CANDIDATE",
                    "EXISTING_PASSAGE_COMMITMENT_INCOMPATIBLE",
                }:
                    raise ValueError(f"INVALID_ADMISSION_REJECTION:{uav_id}:{reason}")
                updates[uav_id] = replace(
                    state, state=FlightState.UNASSIGNED, request=False,
                    assignment_outcome_reason=reason, event_version=state.event_version + 1,
                )
            new_states = dict(self._states)
            from .speed_control_scope import assert_h_control_release
            for uid, updated in updates.items():
                assert_h_control_release(self._states[uid], updated, t_now=self._sim_time_s)
            new_states.update(updates)
            self._states = new_states
            self._version += 1
            receipt = AssignmentCommitReceipt(
                commit_id=commit_id,
                snapshot_version=expected_version,
                committed_version=self._version,
                assignments=MappingProxyType({
                    uav: (node, route) for uav, (node, route, _) in selections.items()
                }),
                status="COMMITTED_ATOMIC" if selections else "NO_ADMITTED_REQUESTS_ATOMIC",
                admission_rejections=MappingProxyType(admission_rejections),
            )
            self._commits[commit_id] = (canonical, receipt)
            return receipt

    def resolve_unassigned_requests(
        self,
        *,
        expected_version: int,
        commit_id: str,
        uav_ids: Iterable[str],
        status: str = "NO_VALID_ASSIGNMENT_ATOMIC",
        outcome_reason: str | None = None,
    ) -> AssignmentCommitReceipt:
        """Atomically close a batch for which ECJA has no valid assignment."""

        canonical = tuple(sorted(str(value) for value in uav_ids))
        if not canonical:
            raise ValueError("EMPTY_UNASSIGNED_BATCH")
        with self._lock:
            prior = self._unassigned_commits.get(commit_id)
            if prior is not None:
                if prior[0] != canonical:
                    raise ValueError("COMMIT_ID_PAYLOAD_MISMATCH")
                return prior[1]
            if expected_version != self._version:
                raise ValueError("STALE_TRAFFIC_SNAPSHOT")
            updates: dict[str, UAVState] = {}
            for uav_id in canonical:
                state = self._states.get(uav_id)
                if state is None:
                    raise ValueError(f"UNKNOWN_COMMIT_UAV:{uav_id}")
                if (
                    state.commit_status != "UNCOMMITTED"
                    or not state.request
                    or state.state != FlightState.PENDING_ASSIGNMENT
                ):
                    raise ValueError(f"UAV_NOT_PENDING_ASSIGNMENT:{uav_id}")
                updates[uav_id] = replace(
                    state,
                    state=FlightState.UNASSIGNED,
                    request=False,
                    assignment_outcome_reason=outcome_reason,
                    event_version=state.event_version + 1,
                )
            new_states = dict(self._states)
            new_states.update(updates)
            self._states = new_states
            self._version += 1
            receipt = AssignmentCommitReceipt(
                commit_id=commit_id,
                snapshot_version=expected_version,
                committed_version=self._version,
                assignments=MappingProxyType({}),
                status=str(status),
            )
            self._unassigned_commits[commit_id] = (canonical, receipt)
            return receipt

    @measured("state.publish_scheduling_round")
    def publish_scheduling_round(
        self,
        *,
        expected_version: int,
        round_id: str,
        updates: Mapping[str, UAVState],
        background_updates: Mapping[str, UAVState] | None = None,
        waiting_updates: Mapping[str, UAVState] | None = None,
        input_uav_ids: Iterable[str] | None = None,
        handoff_certificate=None,
    ) -> SchedulingCommitReceipt:
        """Atomically publish and freeze every result in one node round."""

        background_updates = background_updates or {}
        waiting_updates = waiting_updates or {}
        selected = set(updates) | set(waiting_updates)
        if set(updates) & set(waiting_updates) or selected & set(background_updates):
            raise ValueError("SCHEDULING_PARTITION_OVERLAP")
        if waiting_updates and input_uav_ids is None:
            raise ValueError("SCHEDULING_INPUT_PARTITION_MISSING")
        if input_uav_ids is not None:
            inputs = tuple(input_uav_ids)
            if len(inputs) != len(set(inputs)) or selected != set(inputs):
                raise ValueError("SCHEDULING_INPUT_PARTITION_INCOMPLETE")
        canonical = tuple(sorted(
            (uid, _copy_state(state))
            for uid, state in {**background_updates, **updates, **waiting_updates}.items()
        ))
        with self._lock:
            prior = self._schedule_commits.get(round_id)
            if prior is not None:
                if prior[0] != canonical:
                    raise ValueError("SCHEDULE_ROUND_ID_PAYLOAD_MISMATCH")
                return prior[1]
            if expected_version != self._version:
                raise ValueError("STALE_TRAFFIC_SNAPSHOT")
            if not selected and not background_updates:
                # A periodic C-MLPM observation may legitimately have no
                # state update.  Record the round without manufacturing a
                # plan, incrementing the traffic version, or deleting UAVs.
                receipt = SchedulingCommitReceipt(
                    round_id=str(round_id),
                    snapshot_version=int(expected_version),
                    committed_version=int(self._version),
                    uav_ids=(),
                    status="NO_UPDATE_ROUND",
                    waiting_uav_ids=(),
                )
                self._schedule_commits[round_id] = (canonical, receipt)
                return receipt
            published = {**background_updates, **updates, **waiting_updates}
            from .handoff_transaction import requires_handoff,verify_publication_certificate
            if handoff_certificate is not None or requires_handoff(self._states,published):
                verify_publication_certificate(expected_version,published,handoff_certificate)
            for uid,state in published.items():
                if state.current_motion_plan.get("joint_motion_witness"):
                    raise ValueError(f"RETIRED_MOTION_CERTIFICATE_IN_NEW_RUN:{uid}")
            for uid,updated in published.items():
                current = self._states.get(uid)
                if current is None:
                    raise ValueError(f"UNKNOWN_SCHEDULE_UAV:{uid}")
                if updated.cmlpm_request_baseline!=current.cmlpm_request_baseline:
                    raise ValueError("CMLPM_REQUEST_BASELINE_REWRITE:"+uid)
                assert_assignment_geometry_preserved(current, updated)
                from .speed_control_scope import assert_h_control_release
                assert_h_control_release(current, updated, t_now=self._sim_time_s)
                prior_events = _observed_event_records(current.current_motion_plan)
                next_events = _observed_event_records(updated.current_motion_plan)
                for event_id,event in prior_events.items():
                    if event_id not in next_events or dict(event) != dict(next_events[event_id]):
                        raise ValueError(f"OBSERVED_OCCUPANCY_HISTORY_REWRITTEN:{uid}:{event_id}")
            for uav_id, updated in background_updates.items():
                current = self._states.get(uav_id)
                if current is not None:
                    assert_managed_schedule_preserved(current, updated)
                    assert_immutable_plan_preserved(current, updated)
                    if (updated.cmlpm_pending,updated.cmlpm_managed,updated.commit_status,updated.request_id) != (
                            current.cmlpm_pending,current.cmlpm_managed,current.commit_status,current.request_id):
                        raise ValueError(f"BACKGROUND_REQUEST_STATUS_REWRITE:{uav_id}")
                    if current.cmlpm_pending is not None and any(
                            updated.current_motion_plan.get(k) != current.current_motion_plan.get(k)
                            for k in ("fifo_rank","fifo_queue_id")):
                        raise ValueError(f"PENDING_REQUEST_HISTORY_REWRITE:{uav_id}")
            next_states = dict(self._states)
            for uav_id, updated in {**updates, **waiting_updates, **background_updates}.items():
                current = self._states.get(uav_id)
                if current is not None and (updated.current_motion_plan.get("schedule_history")
                                            != current.current_motion_plan.get("schedule_history")):
                    raise ValueError(f"V5_SCHEDULE_HISTORY_REWRITE:{uav_id}")
            for uav_id, updated in updates.items():
                current = self._states.get(uav_id)
                if current is None:
                    raise ValueError(f"UNKNOWN_SCHEDULE_UAV:{uav_id}")
                if current.cmlpm_managed or current.commit_status != "COMMITTED" or current.state != FlightState.ASSIGNED:
                    raise ValueError(f"UAV_NOT_NEWLY_ASSIGNED:{uav_id}")
                if (updated.uav_id != uav_id or updated.commit_status != "FROZEN"
                        or not updated.cmlpm_managed
                        or (updated.current_motion_plan.get("schedule_result") == "RELEASED"
                            and not updated.cmlpm_plan_immutable)):
                    raise ValueError(f"INVALID_FROZEN_SCHEDULE_UPDATE:{uav_id}")
                if current.cmlpm_pending is not None and (updated.cmlpm_pending is not None or updated.request_id != current.request_id):
                    raise ValueError(f"PENDING_RELEASE_IDENTITY_INVALID:{uav_id}")
                if updated.assigned_node != current.assigned_node or updated.assigned_route != current.assigned_route:
                    raise ValueError(f"ASSIGNMENT_MUTATED_BY_SCHEDULER:{uav_id}")
                next_states[uav_id] = _copy_state(updated)
            for uav_id, updated in waiting_updates.items():
                current = self._states.get(uav_id)
                if current is None or current.cmlpm_managed or current.commit_status != "COMMITTED":
                    raise ValueError(f"INVALID_PENDING_REQUEST:{uav_id}")
                pending = updated.cmlpm_pending
                if (updated.uav_id != uav_id or updated.cmlpm_managed or updated.cmlpm_plan_immutable
                        or updated.commit_status != "COMMITTED" or updated.state != FlightState.ASSIGNED
                        or pending is None or pending.uav_id != uav_id
                        or updated.assigned_node != current.assigned_node
                        or updated.assigned_route != current.assigned_route
                        or updated.request_id != current.request_id
                        or updated.current_motion_plan.get("motion_certification") != "NOT_PERFORMED_EXECUTION_MEASURED"):
                    raise ValueError(f"INVALID_WAITING_UPDATE:{uav_id}")
                prior_pending = current.cmlpm_pending
                if prior_pending is not None and (
                    (pending.request_id, pending.nominal_service_time_s, pending.first_eligible_time_s)
                    != (prior_pending.request_id, prior_pending.nominal_service_time_s, prior_pending.first_eligible_time_s)
                    or pending.wait_rounds != prior_pending.wait_rounds + 1
                    or any(updated.current_motion_plan.get(k) != current.current_motion_plan.get(k)
                           for k in ("fifo_rank","fifo_queue_id"))
                ):
                    raise ValueError(f"PENDING_REQUEST_HISTORY_REWRITE:{uav_id}")
                if prior_pending is None and pending.wait_rounds != 1:
                    raise ValueError(f"INVALID_INITIAL_WAIT_AGE:{uav_id}")
                next_states[uav_id] = _copy_state(updated)
            for uav_id, updated in background_updates.items():
                if uav_id in updates:
                    raise ValueError(f"SCHEDULING_BACKGROUND_OVERLAP:{uav_id}")
                current = self._states.get(uav_id)
                if current is None:
                    raise ValueError(f"UNKNOWN_SCHEDULING_BACKGROUND_UAV:{uav_id}")
                if updated.assigned_node != current.assigned_node or updated.assigned_route != current.assigned_route:
                    raise ValueError(f"BACKGROUND_ASSIGNMENT_MUTATED:{uav_id}")
                next_states[uav_id] = _copy_state(updated)
            self._states = next_states
            self._version += 1
            receipt = SchedulingCommitReceipt(
                round_id=str(round_id),
                snapshot_version=int(expected_version),
                committed_version=self._version,
                uav_ids=tuple(sorted(updates)),
                status=("BACKGROUND_RESOURCE_PUBLISHED_ATOMIC" if not selected else
                        "WAITING_RETAINED_ATOMIC" if not updates else "PARTIAL_PUBLISHED_WITH_WAITING_ATOMIC"
                        if waiting_updates else "PUBLISHED_AND_FROZEN_ATOMIC"),
                waiting_uav_ids=tuple(sorted(waiting_updates)),
            )
            self._schedule_commits[round_id] = (canonical, receipt)
            return receipt

