from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable, Iterable, Mapping

from ecja_qsap.algorithm import (
    ECJAInput,
    ECJAOutput,
    ECJARequestHistory,
    build_ecja_scene,
)
from assignment_algorithms.api import assign_nodes
from assignment_algorithms.contracts import AssignmentAlgorithm
from ecja_qsap.p3r_forward import ForwardRequest, ROUTE_ONLY_MOTION_MODEL
from ecja_qsap.formal_motion import FORMAL_MOTION_MODEL

from .network_loader import RegisteredG25, to_ecja_g25_source


@dataclass(frozen=True)
class AssignmentRequest:
    uav_id: str
    direction: str
    layer: str
    current_station_m: float
    allowed_end_station_m: float
    snapshot_time_s: float
    speed_mps: float
    # Kept for compatibility with public traffic records; ECJA does not read
    # these fields when generating candidates or scoring assignments.
    remaining_energy_wh: float | None = None
    reserve_energy_wh: float | None = None
    request_id: str | None = None
    request_reason: str | None = None
    allowed_energy_candidate_node_ids: tuple[str, ...] | None = None
    allow_stop_start: bool = False
    request_created_time_s: float | None = None


AssignmentRun = ECJAOutput


def build_assignment_scene(
    network: RegisteredG25,
    requests: Iterable[AssignmentRequest],
    *,
    seed: int,
    fixed_plans: Iterable[Mapping[str, Any]] = (),
    motion_model: str = FORMAL_MOTION_MODEL,
    peak_load_cap: int | None = None,
    traffic_state_contract: Mapping[str, Any] | None = None,
    active_assignment_summary: Mapping[str, Any] | None = None,
    scenario_id: str | None = None,
) -> dict[str, Any]:
    requests = tuple(requests)
    source = to_ecja_g25_source(
        network, include_formal_motion=motion_model in {
            FORMAL_MOTION_MODEL, ROUTE_ONLY_MOTION_MODEL
        }
    )
    forward = tuple(
        ForwardRequest(
            uav_id=item.uav_id,
            direction_id=item.direction,
            source_layer_id=item.layer,
            current_directed_station_m=item.current_station_m,
            allowed_end_directed_station_m=item.allowed_end_station_m,
            snapshot_time_s=item.snapshot_time_s,
            speed_mps=item.speed_mps,
            in_flight=True,
            motion_model=motion_model,
            request_id=item.request_id,
            request_reason=item.request_reason,
            allowed_energy_candidate_node_ids=item.allowed_energy_candidate_node_ids,
            allow_stop_start=item.allow_stop_start,
        )
        for item in requests
    )
    return build_ecja_scene(
        ECJAInput(
            source=source,
            current_batch_requests=forward,
            historical_fixed_plans=tuple(fixed_plans),
            seed=seed,
            motion_model=motion_model,
            peak_load_cap=peak_load_cap,
            traffic_state_contract=traffic_state_contract,
            active_assignment_summary=active_assignment_summary,
            scenario_id=scenario_id,
        )
    )


def run_assignment(
    network: RegisteredG25,
    requests: Iterable[AssignmentRequest],
    *,
    policy: str,
    algorithm: AssignmentAlgorithm | None = None,
    seed: int,
    fixed_plans: Iterable[Mapping[str, Any]] = (),
    motion_model: str = FORMAL_MOTION_MODEL,
    peak_load_cap: int | None = None,
    traffic_state_contract: Mapping[str, Any] | None = None,
    active_assignment_summary: Mapping[str, Any] | None = None,
    scenario_id: str | None = None,
    request_history: Mapping[str, ECJARequestHistory] | None = None,
    candidate_compatibility: Callable[[Mapping[str, Any]], str | None] | None = None,
    _source: Mapping[str, Any] | None = None,
) -> AssignmentRun:
    requests = tuple(requests)
    if not requests:
        raise ValueError("NO_ASSIGNMENT_REQUESTS")
    source = _source if _source is not None else to_ecja_g25_source(
        network, include_formal_motion=motion_model in {
            FORMAL_MOTION_MODEL, ROUTE_ONLY_MOTION_MODEL
        }
    )
    forward_requests = tuple(
        ForwardRequest(
            uav_id=item.uav_id,
            direction_id=item.direction,
            source_layer_id=item.layer,
            current_directed_station_m=item.current_station_m,
            allowed_end_directed_station_m=item.allowed_end_station_m,
            snapshot_time_s=item.snapshot_time_s,
            speed_mps=item.speed_mps,
            in_flight=True,
            motion_model=motion_model,
            request_id=item.request_id,
            request_reason=item.request_reason,
            allowed_energy_candidate_node_ids=item.allowed_energy_candidate_node_ids,
            allow_stop_start=item.allow_stop_start,
        )
        for item in requests
    )
    return assign_nodes(
        ECJAInput(
            source=source,
            current_batch_requests=forward_requests,
            historical_fixed_plans=tuple(fixed_plans),
            seed=seed,
            policy=policy,
            motion_model=motion_model,
            peak_load_cap=peak_load_cap,
            traffic_state_contract=traffic_state_contract,
            active_assignment_summary=active_assignment_summary,
            request_history=request_history or {},
            scenario_id=scenario_id,
            request_created_times_s={r.uav_id: r.request_created_time_s for r in requests
                                     if r.request_created_time_s is not None},
        ),
        algorithm=algorithm,
        _compatibility_override=candidate_compatibility,
    )

