"""Classify mainline following versus cross-layer V/H conflicts.

The same physical resource identifier can be visited by a V leaving its
source layer and by a mainline aircraft on that layer.  A same-layer V/H pair
is still longitudinal traffic and is governed by following/FIFO; only a
different-layer pair is an orthogonal V/H resource conflict.
"""

from __future__ import annotations


def is_cross_layer_vh_pair(h, v) -> bool:
    """Return whether ``h`` and ``v`` require an exclusive VH contract."""

    return (
        str(getattr(h, "direction", "")) == str(getattr(v, "direction", ""))
        and str(getattr(h, "layer", "")) != str(getattr(v, "layer", ""))
    )


def is_cross_layer_vh_layers(*, h_layer, v_layer, h_direction=None, v_direction=None) -> bool:
    """Layer-only equivalent used by event audits without full UAV states."""

    if h_direction is not None and v_direction is not None:
        if str(h_direction) != str(v_direction):
            return False
    return str(h_layer) != str(v_layer)
