"""CPFF runtime anomaly response; proposed state only, no store writes.

Only a positive mainline gap below the registered minimum can be recorded
and recovered. Resource conflicts, capability violations and invalid data
remain blocking. Publication certification never uses this exception.
"""
from dataclasses import dataclass, replace
import math

from .following_time import physical_lane
from .numeric_motion import _continuous_piece_state, _covered_time_intervals, continuous_min_gap

GAP_CODES = frozenset({"CONTINUOUS_GAP_VIOLATION", "SAFETY_GAP_VIOLATION"})

# A rear aircraft counts as moving when its longitudinal speed exceeds this.
MOVING_SPEED_EPS_MPS = 1e-9
# Sub-intervals shorter than this are not treated as a moving episode.
MOVING_SPAN_EPS_S = 1e-9


@dataclass(frozen=True)
class AnomalyResponsePolicy:
    mode: str = "FAIL_CLOSED"

    @classmethod
    def from_config(cls, config):
        mode = config.get("motion", {}).get("cpff_anomaly_policy", "FAIL_CLOSED")
        if not isinstance(mode,str) or mode not in {"FAIL_CLOSED", "RECORD_AND_RECOVER"}:
            raise ValueError("CPFF_ANOMALY_POLICY_INVALID")
        return cls(mode)

    @property
    def enabled(self):
        return self.mode == "RECORD_AND_RECOVER"

    def permits_codes(self, codes):
        return self.enabled and bool(codes) and set(codes) <= GAP_CODES


def gap_statistics(front, rear, required):
    """Exact duration below the gap threshold on piecewise quadratics.

    The registered criterion is positional: any part of the tick with
    ``front - rear < required`` counts, regardless of motion.  That result is
    returned unchanged in ``violation_*`` so every historical number keeps its
    meaning.

    In addition the function reports how much of that time the **rear aircraft
    was actually moving** (``moving_*``).  A pair of parked aircraft holds a
    fixed spacing; no deceleration can restore the gap at standstill, so the
    positional duration and the moving duration answer different questions:

    * ``violation_duration_s``        - positional criterion (unchanged),
    * ``moving_violation_duration_s`` - time under threshold while the rear
      aircraft's speed is positive, i.e. genuine closure on the move,
    * ``stationary_violation_duration_s`` - the remainder, recorded as a
      stationary spacing deficit rather than a moving violation.
    """
    duration = min(front.duration_s, rear.duration_s)
    if not math.isfinite(required) or required <= 0 or duration <= 0:
        raise ValueError("CPFF_GAP_DOMAIN_INVALID")
    coverage = (_covered_time_intervals(front), _covered_time_intervals(rear))
    knots = sorted({0., duration} | {
        end for spans in coverage for _, end, _ in spans if 0 < end < duration})
    intervals = []
    moving = []
    indices = [0, 0]
    for left, right in zip(knots, knots[1:]):
        for index, spans in enumerate(coverage):
            while spans[indices[index]][1] <= left:
                indices[index] += 1
        fp, rp = (spans[index][2] for spans, index in zip(coverage, indices))
        fs, fv = _continuous_piece_state(fp, left)
        rs, rv = _continuous_piece_state(rp, left)
        a = .5*(fp.acceleration_mps2-rp.acceleration_mps2)
        b = fv-rv
        c = fs-rs-(required-1e-6)
        span = right-left
        roots = [0., span]
        if abs(a) < 1e-14:
            if abs(b) > 1e-14:
                root = -c/b
                if 0 < root < span:
                    roots.append(root)
        else:
            discriminant = b*b-4*a*c
            if discriminant >= 0:
                for root in ((-b-math.sqrt(discriminant))/(2*a), (-b+math.sqrt(discriminant))/(2*a)):
                    if 0 < root < span:
                        roots.append(root)
        cuts = sorted(set(roots))
        for lo, hi in zip(cuts, cuts[1:]):
            t = (lo+hi)/2
            if a*t*t+b*t+c < 0:
                intervals.append((left+lo, left+hi))
                # Restrict this below-threshold span to the part where the rear
                # aircraft is actually moving.  Rear speed is linear in time
                # within the knot segment: v(u) = rv + rear_accel*u.
                rear_accel = rp.acceleration_mps2
                if abs(rear_accel) <= 1e-14:
                    moving_span = (lo, hi) if rv > MOVING_SPEED_EPS_MPS else None
                else:
                    root = -rv/rear_accel
                    if rear_accel > 0.:
                        moving_span = (max(lo, root), hi)
                    else:
                        moving_span = (lo, min(hi, root))
                    if moving_span[1]-moving_span[0] <= MOVING_SPAN_EPS_S:
                        moving_span = None
                if moving_span is not None:
                    moving.append((left+moving_span[0], left+moving_span[1], left, a, b, c))

    def _gap_at(absolute_s, left, a, b, c):
        u = absolute_s-left
        return c+(required-1e-6)+b*u+a*u*u

    moving_minimum = None
    for lo, hi, left, a, b, c in moving:
        candidates = [_gap_at(lo, left, a, b, c), _gap_at(hi, left, a, b, c)]
        if abs(a) > 1e-14:
            vertex = -b/(2*a)
            if left+vertex > lo and left+vertex < hi:
                candidates.append(_gap_at(left+vertex, left, a, b, c))
        candidate = min(candidates)
        moving_minimum = candidate if moving_minimum is None else min(moving_minimum, candidate)

    violation_duration = math.fsum(hi-lo for lo, hi in intervals)
    moving_duration = math.fsum(hi-lo for lo, hi, *_ in moving)
    return dict(minimum_gap_m=continuous_min_gap(front, rear),
        end_gap_m=front.state_at(duration)[0]-rear.state_at(duration)[0],
        violation_duration_s=violation_duration,
        violation_intervals=tuple(intervals),
        first_violation_s=intervals[0][0] if intervals else None,
        last_violation_s=intervals[-1][1] if intervals else None,
        moving_violation_duration_s=moving_duration,
        moving_violation_intervals=tuple((lo, hi) for lo, hi, *_ in moving),
        moving_minimum_gap_m=moving_minimum,
        stationary_violation_duration_s=max(0., violation_duration-moving_duration),
        front_start_speed_mps=front.state_at(0.)[1],
        rear_start_speed_mps=rear.state_at(0.)[1])


def annotate_response(before, step, *, minimum_gap_m):
    """Track pair episodes on a candidate step. Audit/CAS owns acceptance."""
    lanes = {}
    for uid in step.mainline_profiles:
        state = before.states[uid]
        lanes.setdefault(physical_lane(state), []).append(state)
    pairs = {}
    for rows in lanes.values():
        rows.sort(key=lambda s: (-s.s_m, s.uav_id))
        for front, rear in zip(rows, rows[1:]):
            pairs[rear.uav_id] = (front.uav_id, gap_statistics(
                step.mainline_profiles[front.uav_id], step.mainline_profiles[rear.uav_id], minimum_gap_m))
    updated = []
    for state in step.states:
        if state.uav_id not in step.mainline_profiles:
            updated.append(state)
            continue
        plan = dict(state.current_motion_plan)
        episode = dict(before.states[state.uav_id].current_motion_plan.get("cpff_anomaly_state") or {})
        history = tuple(plan.get("cpff_anomaly_history", ()))
        events = []
        pair = pairs.get(state.uav_id)
        def event(kind, time_s, details):
            events.append(dict(event_type="CPFF_ANOMALY_RESPONSE", kind=kind,
                uav_id=state.uav_id, snapshot_version=before.version,
                step_start_s=step.t_from, step_end_s=step.t_to, time_s=time_s, **details))
        if episode.get("active") and (pair is None or pair[0] != episode["leader_id"]):
            episode.update(active=False, end_time_s=step.t_from, end_reason="DEPENDENCY_ENDED")
            history += (dict(episode),)
            event("GAP_DEPENDENCY_ENDED", step.t_from, dict(episode))
            episode = {}
        if pair is not None:
            leader, stats = pair
            if stats["violation_duration_s"] > 0:
                if not episode.get("active"):
                    episode = dict(active=True, leader_id=leader,
                        start_time_s=step.t_from+stats["first_violation_s"],
                        violation_duration_s=0., minimum_gap_m=stats["minimum_gap_m"])
                    event("GAP_RECOVERY_STARTED", episode["start_time_s"], dict(episode))
                episode.update(
                    violation_duration_s=episode["violation_duration_s"]+stats["violation_duration_s"],
                    minimum_gap_m=min(episode["minimum_gap_m"], stats["minimum_gap_m"]),
                    last_observed_s=step.t_to)
                event("GAP_RECOVERING", step.t_to, dict(episode,
                    action="BOUNDED_FOLLOWING_BRAKE", step_violation_duration_s=stats["violation_duration_s"]))
            if episode.get("active") and stats["end_gap_m"] >= minimum_gap_m-1e-6:
                end = step.t_from+stats["last_violation_s"] if stats["last_violation_s"] is not None else step.t_from
                episode.update(active=False, end_time_s=end, end_reason="GAP_RESTORED")
                history += (dict(episode),)
                event("GAP_RECOVERED", end, dict(episode))
        plan.update(cpff_anomaly_state=episode, cpff_anomaly_history=history,
                    cpff_anomaly_events=tuple(events))
        updated.append(replace(state, current_motion_plan=plan))
    return replace(step, states=tuple(updated))


def collect_response_events(step):
    parts = [part for _, part in step.substeps] if step.substeps else [step]
    return tuple(row for part in parts for state in part.states
                 for row in state.current_motion_plan.get("cpff_anomaly_events", ())
                 if row["step_start_s"] == part.t_from and row["step_end_s"] == part.t_to)


def recovery_motion_is_valid(before, step, required):
    """Accept observed gap violations only with non-crossing braking motion."""
    parts = step.substeps or ((before, step),)
    for source, part in parts:
        lanes = {}
        for uid in part.mainline_profiles:
            lanes.setdefault(physical_lane(source.states[uid]), []).append(source.states[uid])
        for rows in lanes.values():
            rows.sort(key=lambda s: (-s.s_m, s.uav_id))
            for front, rear in zip(rows, rows[1:]):
                fp, rp = part.mainline_profiles[front.uav_id], part.mainline_profiles[rear.uav_id]
                stats = gap_statistics(fp, rp, required)
                if not math.isfinite(stats["minimum_gap_m"]) or stats["minimum_gap_m"] <= 0:
                    return False
                for lo, hi in stats["violation_intervals"]:
                    if any(p.acceleration_mps2 > 1e-8 and p.start_s < hi and p.end_s > lo
                           for p in rp.pieces):
                        return False
    return True
