"""Measured ascent profiles using the shared descent geometry and generator.

Production uses registered_reentry_profile with serializable XYZ curves. The
explicit scalar helper supports isolated arithmetic tests. No production
transition length or access duration is assumed.
"""

from __future__ import annotations

from dataclasses import dataclass, fields
import math
from configs.runtime_parameters import vehicle_motion


MOTION_PROFILE_VERSION = "REENTRY_CLIMB_TRANSITION_V1"
TIME_TOLERANCE_S = 1e-9


class ReentryMotionInfeasible(ValueError):
    def __init__(self, code: str, detail: str = "") -> None:
        super().__init__(f"{code}:{detail}" if detail else code)
        self.code = code
        self.detail = detail


@dataclass(frozen=True)
class ReentryMotionLimits:
    climb_speed_mps: float
    max_climb_speed_mps: float
    acceleration_mps2: float
    max_acceleration_mps2: float
    max_speed_mps: float

    @classmethod
    def from_config(cls, config, vehicle_type):
        return cls(**vehicle_motion(config, vehicle_type))


@dataclass(frozen=True)
class ReentryMotionState:
    time_s: float
    station_m: float
    z_m: float
    speed_mps: float
    phase: str
    position_xyz: tuple | None = None


@dataclass(frozen=True)
class ReentryStageProfile:
    """A non-merging physical stage with its own relative time origin."""

    release_time_s: float
    end_time_s: float
    stage_kind: str
    trajectory: dict

    def state_at(self, time_s: float) -> ReentryMotionState:
        from .descent_trajectory import trajectory_state
        elapsed = min(max(float(time_s) - self.release_time_s, 0.0),
                      self.end_time_s - self.release_time_s)
        point, speed = trajectory_state(self.trajectory, elapsed)
        phase = 'HOLD' if float(time_s) < self.release_time_s - TIME_TOLERANCE_S else self.stage_kind
        return ReentryMotionState(float(time_s), float(point[0]), float(point[2]),
                                  0.0 if float(time_s) < self.release_time_s - TIME_TOLERANCE_S else float(speed),
                                  phase, tuple(point))

    @property
    def duration_s(self):
        return self.end_time_s - self.release_time_s

    def as_dict(self):
        return {
            'release_time_s': float(self.release_time_s),
            'end_time_s': float(self.end_time_s),
            'stage_kind': self.stage_kind,
            'trajectory': self.trajectory,
        }


def build_stage_profile(trajectory, *, release_time_s, stage_kind):
    """Validate and attach a relative-time origin to a physical stage."""
    segments = trajectory.get('segments') if isinstance(trajectory, dict) else None
    if not isinstance(segments, (list, tuple)) or not segments:
        raise ReentryMotionInfeasible('REENTRY_STAGE_PROFILE_EMPTY')
    previous = 0.0
    for index, segment in enumerate(segments):
        start = float(segment['start_s']); end = float(segment['end_s'])
        if end <= start or abs(start - previous) > TIME_TOLERANCE_S:
            raise ReentryMotionInfeasible('REENTRY_STAGE_PROFILE_TIME_INVALID', str(index))
        previous = end
    duration = float(trajectory.get('duration_s', previous))
    if duration <= 0.0 or abs(duration - previous) > TIME_TOLERANCE_S:
        raise ReentryMotionInfeasible('REENTRY_STAGE_PROFILE_DURATION_INVALID')
    if tuple(segments[0]['point0_xyz']) != tuple(trajectory['start_xyz']):
        raise ReentryMotionInfeasible('REENTRY_STAGE_PROFILE_START_MISMATCH')
    if tuple(segments[-1]['point1_xyz']) != tuple(trajectory['end_xyz']):
        raise ReentryMotionInfeasible('REENTRY_STAGE_PROFILE_END_MISMATCH')
    return ReentryStageProfile(float(release_time_s), float(release_time_s) + duration,
                               str(stage_kind), trajectory)


def transition_time_s(
    *,
    transition_length_m: float,
    merge_speed_mps: float,
    acceleration_mps2: float,
) -> float:
    """Time to cross the transition at bounded acceleration, then cruise."""

    length = float(transition_length_m)
    speed = float(merge_speed_mps)
    acceleration = float(acceleration_mps2)
    if not math.isfinite(length) or length <= 0.0:
        raise ReentryMotionInfeasible("REENTRY_TRANSITION_LENGTH_INVALID", f"{length}")
    if not math.isfinite(speed) or speed <= 0.0:
        raise ReentryMotionInfeasible("REENTRY_MERGE_SPEED_INVALID", f"{speed}")
    if not math.isfinite(acceleration) or acceleration <= 0.0:
        raise ReentryMotionInfeasible("REENTRY_ACCELERATION_INVALID", f"{acceleration}")
    acceleration_distance = speed * speed / (2.0 * acceleration)
    if acceleration_distance > length + TIME_TOLERANCE_S:
        raise ReentryMotionInfeasible(
            "REENTRY_TRANSITION_TOO_SHORT",
            f"need={acceleration_distance:.3f}:have={length:.3f}",
        )
    return speed / acceleration + (length - acceleration_distance) / speed


@dataclass(frozen=True)
class ReentryMotionProfile:
    release_time_s: float
    merge_time_s: float
    column_station_m: float
    merge_station_m: float
    base_altitude_m: float
    layer_altitude_m: float
    climb_speed_mps: float
    merge_speed_mps: float
    acceleration_mps2: float
    climb_duration_s: float
    acceleration_duration_s: float
    transition_duration_s: float
    access_duration_s: float
    model_version: str = MOTION_PROFILE_VERSION
    trajectory: dict | None = None

    def state_at(self, time_s: float) -> ReentryMotionState:
        elapsed = min(max(float(time_s) - self.release_time_s, 0.0), self.access_duration_s)
        if self.trajectory is not None:
            segments = self.trajectory.get('segments')
            if not isinstance(segments, (list, tuple)) or not segments:
                raise ReentryMotionInfeasible('REENTRY_PROFILE_EMPTY')
            from .reentry_trajectory import ascent_state
            point, station, speed = ascent_state(self.trajectory, elapsed)
            waiting=float(time_s) < self.release_time_s-TIME_TOLERANCE_S
            return ReentryMotionState(float(time_s), station, point[2], 0. if waiting else speed,
                'HOLD' if waiting else 'CLIMB' if elapsed <= self.climb_duration_s else 'TRANSITION', tuple(point))
        if elapsed <= self.climb_duration_s + TIME_TOLERANCE_S:
            return ReentryMotionState(
                time_s=float(time_s),
                station_m=self.column_station_m,
                z_m=self.base_altitude_m + self.climb_speed_mps * min(elapsed, self.climb_duration_s),
                speed_mps=0.0,
                phase="CLIMB",
            )
        tau = elapsed - self.climb_duration_s
        if tau <= self.acceleration_duration_s + TIME_TOLERANCE_S:
            tau = min(tau, self.acceleration_duration_s)
            station = self.column_station_m + 0.5 * self.acceleration_mps2 * tau * tau
            speed = self.acceleration_mps2 * tau
        else:
            accelerated = 0.5 * self.acceleration_mps2 * self.acceleration_duration_s ** 2
            station = self.column_station_m + accelerated + self.merge_speed_mps * (
                tau - self.acceleration_duration_s
            )
            speed = self.merge_speed_mps
        return ReentryMotionState(
            time_s=float(time_s),
            station_m=min(station, self.merge_station_m),
            z_m=self.layer_altitude_m,
            speed_mps=speed,
            phase="TRANSITION",
        )

    def as_dict(self) -> dict[str, float | str]:
        # The per-aircraft clock is small; the frozen template is shared.
        # dataclasses.asdict recursively duplicated every curve segment.
        return {field.name: getattr(self, field.name) for field in fields(self)}


def registered_reentry_profile(template, *, release_time_s, limits):
    """Attach a release clock to the fixed registered measured trajectory."""
    from .simulation_state import freeze_plan_payload
    trajectory = freeze_plan_payload(template)
    segments = trajectory.get('segments')
    if not isinstance(segments, (list, tuple)) or not segments:
        raise ReentryMotionInfeasible('REENTRY_PROFILE_EMPTY')
    previous_end = None
    climb_segment_ends = []
    for index, segment in enumerate(segments):
        if 'start_s' not in segment or 'end_s' not in segment:
            raise ReentryMotionInfeasible('REENTRY_PROFILE_SEGMENT_FIELDS', str(index))
        try:
            start = float(segment['start_s'])
            end = float(segment['end_s'])
        except (TypeError, ValueError) as error:
            raise ReentryMotionInfeasible('REENTRY_PROFILE_SEGMENT_INVALID', str(index)) from error
        if not math.isfinite(start) or not math.isfinite(end) or end <= start:
            raise ReentryMotionInfeasible('REENTRY_PROFILE_SEGMENT_INVALID', f'{start}:{end}')
        if index == 0 and abs(start) > TIME_TOLERANCE_S:
            raise ReentryMotionInfeasible('REENTRY_PROFILE_TIME_ORIGIN_INVALID', f'{start}')
        if previous_end is not None and abs(start - previous_end) > TIME_TOLERANCE_S:
            raise ReentryMotionInfeasible(
                'REENTRY_PROFILE_TIME_DISCONTINUITY', f'{previous_end}:{start}'
            )
        previous_end = end
        if segment.get('phase_type') == 'REENTRY_CLIMB':
            climb_segment_ends.append(end)
    try:
        climb = float(trajectory['j_offset_s'])
        duration = float(trajectory['duration_s'])
    except (KeyError, TypeError, ValueError) as error:
        raise ReentryMotionInfeasible('REENTRY_PROFILE_TIME_FIELDS') from error
    if not math.isfinite(climb):
        raise ReentryMotionInfeasible('REENTRY_PROFILE_CLIMB_OFFSET_INVALID', f'{climb}')
    if not climb_segment_ends:
        raise ReentryMotionInfeasible('REENTRY_PROFILE_CLIMB_SEGMENT_MISSING')
    if abs(climb - climb_segment_ends[-1]) > TIME_TOLERANCE_S:
        raise ReentryMotionInfeasible(
            'REENTRY_PROFILE_CLIMB_OFFSET_MISMATCH',
            f'{climb}:{climb_segment_ends[-1]}',
        )
    if not math.isfinite(duration) or duration <= 0.0:
        raise ReentryMotionInfeasible('REENTRY_PROFILE_DURATION_INVALID', f'{duration}')
    if previous_end is None or abs(duration - previous_end) > TIME_TOLERANCE_S:
        raise ReentryMotionInfeasible(
            'REENTRY_PROFILE_DURATION_MISMATCH', f'{duration}:{previous_end}'
        )
    if duration <= climb + TIME_TOLERANCE_S:
        raise ReentryMotionInfeasible(
            'REENTRY_PROFILE_DURATION_BEFORE_CLIMB', f'{duration}:{climb}'
        )
    return ReentryMotionProfile(
        release_time_s=release_time_s, merge_time_s=release_time_s+duration,
        column_station_m=trajectory['column_station_m'], merge_station_m=trajectory['merge_station_m'],
        base_altitude_m=trajectory['segments'][0]['point0_xyz'][2],
        layer_altitude_m=trajectory['segments'][-1]['point1_xyz'][2],
        climb_speed_mps=limits.climb_speed_mps, merge_speed_mps=trajectory['merge_speed_mps'],
        acceleration_mps2=limits.acceleration_mps2,climb_duration_s=climb,
        acceleration_duration_s=0.,transition_duration_s=duration-climb,access_duration_s=duration,
        model_version=trajectory['version'],trajectory=trajectory)


def build_local_reentry_profile(template, state, *, release_time_s, limits,
                                vertical_acceleration_mps2=2.0):
    """Build a fresh approach from a verified off-mainline waiting position.

    The local profile deliberately starts at the UAV's measured XYZ position;
    it never reuses the original staging point.  The vertical leg reaches the
    registered mainline altitude with zero endpoint speed, then a bounded
    horizontal acceleration reaches the registered merge point and speed.
    Shared ascent-column resource windows are absent because this state is
    created after the UAV has already cleared that column.
    """
    import math
    from .reentry_trajectory import _bounded_stop_go_segments
    from .descent_trajectory import _audit_hermite_motion

    plan = getattr(state, 'current_motion_plan', {}) or {}
    start = tuple(float(v) for v in plan.get('motion_position_xyz', ()))
    if len(start) != 3:
        raise ReentryMotionInfeasible('REENTRY_LOCAL_POSITION_MISSING', str(state.uav_id))
    end = tuple(float(v) for v in template['segments'][-1]['point1_xyz'])
    if start[0] >= end[0] - 1e-9:
        raise ReentryMotionInfeasible('REENTRY_LOCAL_POSITION_PAST_MERGE', str(state.uav_id))
    target_z = float(end[2])
    if start[2] > target_z + 1e-6:
        raise ReentryMotionInfeasible('REENTRY_LOCAL_ALTITUDE_ABOVE_MAINLINE', str(state.uav_id))

    segments = []
    cursor = 0.0
    if target_z - start[2] > 1e-9:
        vertical_end = (start[0], start[1], target_z)
        vertical, vertical_duration = _bounded_stop_go_segments(
            start_xyz=start, end_xyz=vertical_end,
            max_speed_mps=limits.climb_speed_mps,
            acceleration_mps2=float(vertical_acceleration_mps2),
            phase_type='REENTRY_LOCAL_VERTICAL',
        )
        segments.extend(vertical)
        cursor = vertical_duration

    horizontal_start = (start[0], start[1], target_z)
    horizontal_end = end
    dx = horizontal_end[0] - horizontal_start[0]
    dy = horizontal_end[1] - horizontal_start[1]
    distance = math.hypot(dx, dy)
    if distance <= 1e-9:
        raise ReentryMotionInfeasible('REENTRY_LOCAL_MERGE_DISTANCE_INVALID', str(state.uav_id))
    direction = (dx / distance, dy / distance, 0.0)
    acceleration = float(limits.acceleration_mps2)
    merge_speed = float(template['merge_speed_mps'])
    if acceleration <= 0.0 or merge_speed <= 0.0:
        raise ReentryMotionInfeasible('REENTRY_LOCAL_KINEMATICS_INVALID', str(state.uav_id))
    accel_time = merge_speed / acceleration
    accel_distance = 0.5 * acceleration * accel_time * accel_time
    if distance < accel_distance - 1e-6:
        raise ReentryMotionInfeasible('REENTRY_LOCAL_ACCELERATION_DISTANCE_INSUFFICIENT', str(state.uav_id))
    accel_end = tuple(horizontal_start[i] + direction[i] * accel_distance for i in range(3))
    segments.append({
        'phase_type': 'REENTRY_LOCAL_APPROACH',
        'point0_xyz': list(horizontal_start), 'point1_xyz': list(accel_end),
        'velocity0_xyz': [0.0, 0.0, 0.0],
        'velocity1_xyz': [direction[i] * merge_speed for i in range(3)],
        'start_s': cursor, 'end_s': cursor + accel_time,
    })
    cursor += accel_time
    cruise_distance = distance - accel_distance
    if cruise_distance > 1e-9:
        segments.append({
            'phase_type': 'REENTRY_LOCAL_APPROACH',
            'point0_xyz': list(accel_end), 'point1_xyz': list(horizontal_end),
            'velocity0_xyz': [direction[i] * merge_speed for i in range(3)],
            'velocity1_xyz': [direction[i] * merge_speed for i in range(3)],
            'start_s': cursor, 'end_s': cursor + cruise_distance / merge_speed,
        })
        cursor += cruise_distance / merge_speed
    duration = float(cursor)
    trajectory = {
        'version': 'REENTRY_LOCAL_REJOIN_V1',
        'segments': segments,
        'j_offset_s': float(cursor if target_z - start[2] > 1e-9 else 0.0),
        'generator_method': 'LOCAL_WAIT_POSITION_BOUNDED_APPROACH_V1',
        'geometry_source': template.get('geometry_source'),
        'source_network_sha256': template.get('source_network_sha256'),
        # Keep the registered ascent-column geometry for certificate matching;
        # the physical trajectory itself still starts at the measured position.
        'column_station_m': float(template['column_station_m']),
        'merge_station_m': float(template['merge_station_m']),
        'merge_speed_mps': merge_speed,
        'duration_s': duration,
        'mainline_path': template['mainline_path'],
        'resource_windows_offsets': {},
        'geometries': {},
        'start_xyz': list(start),
        'end_xyz': list(end),
    }
    trajectory['kinematic_audit'] = _audit_hermite_motion(segments)
    return ReentryMotionProfile(
        release_time_s=float(release_time_s),
        merge_time_s=float(release_time_s) + duration,
        column_station_m=float(template['column_station_m']),
        merge_station_m=float(template['merge_station_m']),
        base_altitude_m=float(start[2]), layer_altitude_m=target_z,
        climb_speed_mps=float(limits.climb_speed_mps), merge_speed_mps=merge_speed,
        acceleration_mps2=float(limits.acceleration_mps2),
        climb_duration_s=float(trajectory['j_offset_s']),
        acceleration_duration_s=accel_time,
        transition_duration_s=duration - float(trajectory['j_offset_s']),
        access_duration_s=duration,
        model_version=trajectory['version'], trajectory=trajectory,
    )


def build_reentry_motion_profile(
    *,
    release_time_s: float,
    merge_time_s: float,
    column_station_m: float,
    merge_station_m: float,
    layer_altitude_m: float,
    merge_speed_mps: float,
    limits: ReentryMotionLimits,
    base_altitude_m: float,
) -> ReentryMotionProfile:
    """Build the profile and verify the certificate window is realisable."""

    release = float(release_time_s)
    merge = float(merge_time_s)
    column = float(column_station_m)
    station = float(merge_station_m)
    base = float(base_altitude_m)
    altitude = float(layer_altitude_m)
    climb_speed = float(limits.climb_speed_mps)
    speed = float(merge_speed_mps)
    acceleration = float(limits.acceleration_mps2)

    if not math.isfinite(altitude) or altitude <= base + TIME_TOLERANCE_S:
        raise ReentryMotionInfeasible("REENTRY_LAYER_ALTITUDE_INVALID", f"{altitude}")
    if not math.isfinite(station) or station <= column + TIME_TOLERANCE_S:
        raise ReentryMotionInfeasible("REENTRY_MERGE_STATION_INVALID", f"{station}")
    if climb_speed <= 0.0 or climb_speed > float(limits.max_climb_speed_mps) + TIME_TOLERANCE_S:
        raise ReentryMotionInfeasible("REENTRY_CLIMB_SPEED_INVALID", f"{climb_speed}")
    if speed <= 0.0 or speed > float(limits.max_speed_mps) + TIME_TOLERANCE_S:
        raise ReentryMotionInfeasible("REENTRY_MERGE_SPEED_INVALID", f"{speed}")
    if acceleration <= 0.0 or acceleration > float(limits.max_acceleration_mps2) + TIME_TOLERANCE_S:
        raise ReentryMotionInfeasible("REENTRY_ACCELERATION_INVALID", f"{acceleration}")
    if merge <= release + TIME_TOLERANCE_S:
        raise ReentryMotionInfeasible("REENTRY_MERGE_BEFORE_RELEASE", f"{merge}<={release}")

    climb_duration = (altitude - base) / climb_speed
    acceleration_duration = speed / acceleration
    transition_duration = transition_time_s(
        transition_length_m=station - column,
        merge_speed_mps=speed,
        acceleration_mps2=acceleration,
    )
    access_duration = climb_duration + transition_duration
    window = merge - release
    if abs(window - access_duration) > 1e-6:
        raise ReentryMotionInfeasible(
            "REENTRY_CERTIFICATE_WINDOW_MISMATCH",
            f"window={window:.6f}:access={access_duration:.6f}",
        )
    return ReentryMotionProfile(
        release_time_s=release,
        merge_time_s=merge,
        column_station_m=column,
        merge_station_m=station,
        base_altitude_m=base,
        layer_altitude_m=altitude,
        climb_speed_mps=climb_speed,
        merge_speed_mps=speed,
        acceleration_mps2=acceleration,
        climb_duration_s=climb_duration,
        acceleration_duration_s=acceleration_duration,
        transition_duration_s=transition_duration,
        access_duration_s=access_duration,
    )
