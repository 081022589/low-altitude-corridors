"""Resource passage permissions and actual-exit release validation.

Current permissions bind resource identity, time and space, never a complete
aircraft motion process. ``passage_permission_status`` derives per-resource
completion from actual exit. Scoped tokens identify node-local permission;
their release is append-only and requires measured resource exits.

A speed profile is an execution command, not automatically an immutable
resource promise.  The token records where a node-local command owns the
mainline motion.  Resource commitments remain separate and are released only
by their observed events.
"""
from __future__ import annotations

import math
import copy
from dataclasses import replace
from typing import Any, Mapping

from .simulation_state import UAVState


TOKEN_VERSION = "MAINLINE_SPEED_SCOPE_V1"
POSITION_TOL_M = 1e-9
TIME_TOL_S = 1e-9
TOKEN_PURPOSES = frozenset({
    "LANE_GAP_SUPPORT", "RESOURCE_TIMING", "TARGET_NODE_EXECUTION",
})


def passage_permission_status(state: UAVState, resource_id: str, *, t_now: float) -> str:
    """Status of the published timing window, separate from entry authority."""
    arrangement = state.current_motion_plan.get("passage_arrangement",{})
    window = next((r for r in arrangement.get("resources",()) if str(r[0]) == str(resource_id)),None)
    if window is None:
        return "NOT_AUTHORIZED"
    observed = state.current_motion_plan.get("motion_observed_events",())
    if any(e.get("event_type") == "RESOURCE_EXIT" and str(e.get("resource_id")) == str(resource_id) for e in observed):
        return "COMPLETED"
    if float(t_now) < float(arrangement["issued_at_s"])-TIME_TOL_S:
        return "NOT_YET_VALID"
    if float(t_now) > float(window[2])+float(arrangement["time_tolerance_s"]):
        return "EXPIRED_UNFULFILLED"
    return "ACTIVE"


def resource_entry_authority(state, event, *, mainline, entry_limits=()):
    """Check the same entry contract in private continuation and actual motion.

    A frozen window is a timing baseline. Its expiry does not discard an
    unfulfilled commitment or bypass the current physical precedence gate.
    """
    plan = state.current_motion_plan
    rid = str(event.resource_id)
    now = event.actual_time_s
    if not mainline:
        if plan.get("schedule_result") != "RELEASED" or not any(
                str(row[0]) == rid for row in plan.get("resource_windows", ())):
            raise ValueError("DESCENT_ENTRY_WITHOUT_FROZEN_RESOURCE:" + event.event_id)
        return {"basis": "FROZEN_DESCENT", "plan_version": plan.get("plan_version")}

    for limit in entry_limits:
        if str(limit.resource_id) == rid and (
                not limit.exit_confirmed or now < limit.not_before_s - TIME_TOL_S):
            raise ValueError("MAINLINE_ENTRY_BEFORE_PHYSICAL_RELEASE:" + event.event_id)
    status = passage_permission_status(state, rid, t_now=now)
    if status in {"NOT_YET_VALID", "COMPLETED"}:
        raise ValueError("MAINLINE_ENTRY_OUTSIDE_PASSAGE_LIFECYCLE:" + event.event_id)
    target = next((t for t in plan.get("timed_resource_targets", ())
                   if str(t["resource_id"]) == rid), None)
    if status == "NOT_AUTHORIZED" and target is None:
        return {"basis": "REGISTERED_MAINLINE_FIFO", "timing_status": "NO_PUBLISHED_WINDOW"}
    provenance = plan.get("resource_target_provenance", {}).get(rid, {})
    return {"basis": "FROZEN_MAINLINE_CONTINUATION", "timing_status": status,
            "plan_version": provenance.get("version")}


def make_speed_control_token(
    state: UAVState,
    *,
    owner_node_id: str,
    round_id: str,
    purpose: str,
    lower_station_m: float,
    upper_station_m: float,
    valid_from_time_s: float,
    valid_until_time_s: float,
    protected_resource_ids: tuple[str, ...] = (),
) -> dict[str, Any]:
    """Create one auditable, half-open spatial speed-control authority."""

    return {
        "version": TOKEN_VERSION,
        "token_id": f"SPEED-SCOPE:{round_id}:{state.uav_id}",
        "owner_node_id": str(owner_node_id),
        "purpose": str(purpose),
        "lane_id": state.lane_id,
        "lower_station_m": float(lower_station_m),
        "upper_station_m": float(upper_station_m),
        "valid_from_time_s": float(valid_from_time_s),
        "valid_until_time_s": float(valid_until_time_s),
        "protected_resource_ids": tuple(sorted(set(protected_resource_ids))),
    }


def speed_control_token_is_active(state: UAVState, *, t_now: float) -> bool | None:
    """Return scoped-token authority, or ``None`` when no token is present."""

    token = state.current_motion_plan.get("speed_control_token")
    if token is None:
        return None
    if not isinstance(token, Mapping) or token.get("version") != TOKEN_VERSION:
        raise ValueError(f"INVALID_SPEED_CONTROL_TOKEN:{state.uav_id}")
    required = (
        "token_id", "owner_node_id", "purpose", "lane_id",
        "lower_station_m", "upper_station_m",
        "valid_from_time_s", "valid_until_time_s",
    )
    if any(key not in token for key in required):
        raise ValueError(f"INCOMPLETE_SPEED_CONTROL_TOKEN:{state.uav_id}")
    if str(token["lane_id"]) != state.lane_id:
        raise ValueError(f"SPEED_CONTROL_TOKEN_LANE_MISMATCH:{state.uav_id}")
    if str(token["purpose"]) not in TOKEN_PURPOSES:
        raise ValueError(f"SPEED_CONTROL_TOKEN_PURPOSE_INVALID:{state.uav_id}")
    lower = float(token["lower_station_m"])
    upper = float(token["upper_station_m"])
    start = float(token["valid_from_time_s"])
    end = float(token["valid_until_time_s"])
    if not all(math.isfinite(value) for value in (lower, upper, start, end)):
        raise ValueError(f"NONFINITE_SPEED_CONTROL_TOKEN:{state.uav_id}")
    if not lower < upper or not start < end:
        raise ValueError(f"EMPTY_SPEED_CONTROL_TOKEN_SCOPE:{state.uav_id}")
    return (
        lower - POSITION_TOL_M <= float(state.s_m) < upper - POSITION_TOL_M
        and start - TIME_TOL_S <= float(t_now) < end - TIME_TOL_S
    )


def is_scoped_h_resource_control(state: UAVState) -> bool:
    """A published H passage control, including H already assigned by ECJA.

    V releases and unpublished target-node holding commands have a different
    lifecycle.
    """
    plan = state.current_motion_plan
    token = plan.get("speed_control_token")
    return bool(not state.cmlpm_managed and state.commit_status != "FROZEN"
                and isinstance(token, Mapping) and token.get("version") == TOKEN_VERSION
                and token.get("purpose") == "RESOURCE_TIMING"
                and (plan.get("timed_resource_targets") or token.get("protected_resource_ids")))


def unfinished_resource_targets(state: UAVState) -> tuple[Mapping[str, Any], ...]:
    exited = {str(row["resource_id"]) for row in state.current_motion_plan.get("motion_observed_events", ())
              if isinstance(row, Mapping) and row.get("event_type") == "RESOURCE_EXIT" and row.get("resource_id")}
    targets = state.current_motion_plan.get("timed_resource_targets", ())
    if any(not isinstance(t, Mapping) or not t.get("resource_id") for t in targets):
        raise ValueError(f"INVALID_TIMED_RESOURCE_TARGET:{state.uav_id}")
    return tuple(t for t in targets if str(t["resource_id"]) not in exited)


def h_resource_control_required(state: UAVState, *, t_now: float) -> bool:
    """Keep a control until actual passage completion and scope expiration.

    Time expiration alone never fulfils an outstanding resource promise.
    Execution reports missing/expired evidence as a failure, not a release.
    """
    if not is_scoped_h_resource_control(state):
        return False
    active = speed_control_token_is_active(state, t_now=t_now)
    return bool(unfinished_resource_targets(state) or active)


def release_completed_h_control(state: UAVState, *, t_now: float) -> UAVState:
    """Archive a fulfilled H command, releasing only its execution authority."""
    if not is_scoped_h_resource_control(state):
        return state
    plan = state.current_motion_plan
    token = plan["speed_control_token"]
    active = speed_control_token_is_active(state, t_now=t_now)
    beyond = float(state.s_m) >= float(token["upper_station_m"])-POSITION_TOL_M
    expired = float(t_now) >= float(token["valid_until_time_s"])-TIME_TOL_S
    pending = unfinished_resource_targets(state)
    if pending:
        return state  # Expiry is an observed miss; only actual EXIT releases the permission.
    if active or not (beyond or expired):
        return state
    observed = {str(e["resource_id"]): e for e in plan.get("motion_observed_events", ())
                if e.get("event_type") == "RESOURCE_EXIT" and e.get("resource_id")}
    resource_ids = set(token.get("protected_resource_ids", ())) or {
        str(t["resource_id"]) for t in plan.get("timed_resource_targets", ())}
    if not resource_ids <= observed.keys():
        raise ValueError(f"H_CONTROL_RELEASE_EVIDENCE_MISSING:{state.uav_id}")
    exit_time = max(float(observed[r]["actual_time_s"]) for r in resource_ids)
    if exit_time > t_now+TIME_TOL_S:
        raise ValueError(f"H_CONTROL_RELEASE_IN_FUTURE:{state.uav_id}")
    record = {
        "release_id":f"{token['token_id']}:RELEASE", "release_time_s":float(t_now),
        "release_station_m":float(state.s_m), "resource_exit_time_s":exit_time,
        "reason":"OBSERVED_RESOURCE_EXIT_AND_CONTROL_SCOPE_END",
        "speed_control_token":copy.deepcopy(token),
        "timed_resource_targets":copy.deepcopy(plan.get("timed_resource_targets", ())),
    }
    if "passage_arrangement" in plan:
        record["passage_arrangement"] = copy.deepcopy(plan["passage_arrangement"])
    changed = dict(plan)
    changed["released_h_speed_controls"] = tuple(plan.get("released_h_speed_controls", ()))+(record,)
    changed.pop("speed_control_token", None)
    changed.pop("mainline_target_speed_mps", None)
    changed.pop("mainline_control_resource_id", None)
    changed["inherited_passage_commitment"] = False
    # Resource targets and observed events remain immutable historical facts.
    return replace(state, cmlpm_plan_immutable=False, current_motion_plan=changed,
                   event_version=state.event_version+1)


def assert_h_control_release(current: UAVState, updated: UAVState, *, t_now: float) -> bool:
    """Validate a single append-only release during a traffic-state CAS."""
    old = tuple(current.current_motion_plan.get("released_h_speed_controls", ()))
    new = tuple(updated.current_motion_plan.get("released_h_speed_controls", ()))
    if new[:len(old)] != old or len(new) < len(old):
        raise ValueError(f"H_CONTROL_RELEASE_HISTORY_REWRITTEN:{current.uav_id}")
    if len(new) == len(old):
        return False
    observed = updated.current_motion_plan.get("motion_observed_events", ())
    release = new[-1]
    release_at = float(release["release_time_s"])
    if release_at > t_now+TIME_TOL_S:
        raise ValueError(f"H_CONTROL_RELEASE_IN_FUTURE:{current.uav_id}")
    probe = replace(current, s_m=float(release["release_station_m"]), speed_mps=updated.speed_mps,
                    current_motion_plan={**current.current_motion_plan,"motion_observed_events":observed})
    expected = release_completed_h_control(probe, t_now=release_at)
    if (len(new) != len(old)+1 or expected is probe
            or tuple(expected.current_motion_plan.get("released_h_speed_controls", ())) != new
            or updated.cmlpm_plan_immutable or updated.cmlpm_managed != current.cmlpm_managed
            or updated.assigned_node != current.assigned_node or updated.assigned_route != current.assigned_route
            or updated.request_id != current.request_id or updated.commit_status != current.commit_status
            or any(updated.current_motion_plan.get(k) != expected.current_motion_plan.get(k)
                   for k in ("speed_control_token","timed_resource_targets"))):
        raise ValueError(f"INVALID_H_CONTROL_RELEASE:{current.uav_id}")
    return True


def speed_control_blocks_target_scheduling(
    state: UAVState, *, t_now: float,
) -> bool:
    """Unfulfilled passage promises and active H ownership precede target V."""

    plan = state.current_motion_plan
    exited_resources = {
        str(row.get("resource_id"))
        for row in plan.get("motion_observed_events", ())
        if isinstance(row, Mapping)
        and row.get("resource_id") is not None
        and str(row.get("event_type")) == "RESOURCE_EXIT"
    }
    for target in plan.get("timed_resource_targets", ()):
        if not isinstance(target, Mapping) or not target.get("resource_id"):
            raise ValueError(f"INVALID_TIMED_RESOURCE_TARGET:{state.uav_id}")
        if str(target["resource_id"]) not in exited_resources:
            return True
    if is_scoped_h_resource_control(state):
        return h_resource_control_required(state, t_now=t_now)
    if plan.get("speed_control_token") is not None:
        # The node's own speed command, released at the service node.
        return False
    # An inherited execution witness is not a passage promise. Outstanding
    # resource edges were checked above; H scope is handled by its token.
    return False

