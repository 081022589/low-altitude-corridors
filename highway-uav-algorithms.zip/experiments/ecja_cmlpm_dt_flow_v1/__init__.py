"""G25 traffic-state-driven ECJA and C-MLPM numerical experiment.

The two algorithms read common exogenous traffic state; C-MLPM does not
consume an ECJA result or handoff DTO.

New eligible V/H requests are scheduled by assignment and periodic triggers.
Published reservations remain immutable while actual motion continues.
"""

EXPERIMENT_ID = "G25_ECJA_CMLPM_DT_FLOW_V1"
RUNTIME_SCHEDULING_MODE = "EVENT_TRIGGERED_IMMUTABLE_PRIOR_RESERVATIONS"

