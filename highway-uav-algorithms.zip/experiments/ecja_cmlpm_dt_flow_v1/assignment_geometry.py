"""Geometry installed with a service-node assignment, independent of timing."""
from __future__ import annotations
import math
from typing import Any, Mapping
from .trigger_rules import commit_distance_m

VERSION = "ECJA_NODE_FIXED_PATH_GEOMETRY_V1"
GEOMETRY_FIELDS = ("g_station_m", "stop_station_m", "d_commit_m", "assignment_geometry_version")


def bind_assignment_geometry(plan: Mapping[str, Any], *, node_id: str, route_id: str,
                             vehicle_type: str) -> dict[str, Any]:
    contract = plan.get("ecja_forward_contract") or {}
    if "latest_switch_station_m" not in contract:
        raise ValueError("ASSIGNMENT_FORMAL_G_MISSING")
    g = float(contract["latest_switch_station_m"])
    if not math.isfinite(g):
        raise ValueError("ASSIGNMENT_FORMAL_G_INVALID")
    if plan.get("service_node_id") != node_id or plan.get("route_id") != route_id:
        raise ValueError("ASSIGNMENT_FIXED_PATH_IDENTITY_MISMATCH")
    for key, expected in (("g_station_m", g), ("stop_station_m", g-commit_distance_m(vehicle_type))):
        if key in plan and (not math.isfinite(float(plan[key])) or abs(float(plan[key])-expected)>1e-6):
            raise ValueError(f"ASSIGNMENT_FORMAL_G_CONFLICT:{key}")
    return {**plan, "g_station_m": g, "stop_station_m": g-commit_distance_m(vehicle_type),
            "d_commit_m": commit_distance_m(vehicle_type), "assignment_geometry_version": VERSION}


def assert_assignment_geometry_preserved(current, updated) -> None:
    if current.current_motion_plan.get("assignment_geometry_version") != VERSION:
        return
    if (updated.assigned_node,updated.assigned_route)!=(current.assigned_node,current.assigned_route):
        raise ValueError(f"ASSIGNED_PATH_GEOMETRY_IDENTITY_REWRITE:{current.uav_id}")
    for key in GEOMETRY_FIELDS:
        if current.current_motion_plan.get(key) != updated.current_motion_plan.get(key):
            raise ValueError(f"ASSIGNED_PATH_GEOMETRY_REWRITE:{current.uav_id}:{key}")
