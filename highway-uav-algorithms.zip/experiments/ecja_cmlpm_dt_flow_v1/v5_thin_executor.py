"""Realize and execute the v5 C-MLPM trajectory contract."""

from __future__ import annotations

from dataclasses import asdict, replace
import math
from typing import Any, Iterable, Mapping

from .existing_v_continuation import ExecutedEvent
from .numeric_motion import (
    MotionLimits, MotionPiece, TickProfile, bounded_profile, continuous_min_gap,
    reservation_profile_to_g,
)
from .following_time import OFF_MAINLINE, physical_lane
from .simulation_state import FlightState, TrafficSnapshot, UAVState


_TOL = 1e-9


def bind_mainline_motion(state, payload, *, now_s, limits):
    """Realize all mainline waypoints with one bounded longitudinal curve."""
    limits = replace(limits, min_speed_mps=0.0)
    clock = 0.0
    cursor = state
    pieces = []
    points = payload["points"]
    if payload["flow"] == "V":
        entry = float(payload["boundary_times"]["E"])
        waypoints = [p for p in points if abs(p["time_s"] - entry) <= _TOL]
    else:
        waypoints = [dict(p) for p in points[1:]]
        # Use the same speed at both ends of each resource crossing.
        for entering, exiting in zip(waypoints[::2], waypoints[1::2]):
            duration = exiting["time_s"] - entering["time_s"]
            if duration <= _TOL:
                raise ValueError("V5_RESOURCE_CROSSING_DURATION_INVALID")
            speed = (exiting["s_m"] - entering["s_m"]) / duration
            entering["speed_mps"] = exiting["speed_mps"] = speed
    for point in waypoints:
        end = float(point["time_s"]) - now_s
        if abs(end - clock) <= _TOL and abs(cursor.s_m - point["s_m"]) <= 1e-6:
            if abs(cursor.speed_mps - point["speed_mps"]) <= 1e-8:
                continue
        profile = reservation_profile_to_g(
            cursor, limits, duration_s=end-clock, g_station_m=point["s_m"],
            terminal_speed_mps=point["speed_mps"],
        )
        pieces.extend(asdict(replace(p, start_s=p.start_s+clock, end_s=p.end_s+clock))
                      for p in profile.pieces)
        position, speed = profile.state_at(profile.duration_s)
        cursor = replace(cursor, s_m=position, speed_mps=speed)
        clock = end
    if payload["flow"] == "V" and not waypoints:
        raise ValueError("V5_E_WAYPOINT_MISSING")
    return {**payload, "mainline_start_s": now_s, "mainline_pieces": tuple(pieces),
            "mainline_terminal_speed_mps": cursor.speed_mps}


def _mainline_tick(payload, *, t_from, dt_s):
    """Slice the frozen motion at the simulation and lane boundaries."""
    start = t_from - payload["mainline_start_s"]
    v_flow = payload["flow"] == "V"
    boundary = payload["boundary_times"]["E" if v_flow else "R"] - t_from
    duration = min(dt_s, boundary) if v_flow else dt_s
    if duration <= _TOL:
        return None
    pieces = []
    for row in payload["mainline_pieces"]:
        source = MotionPiece(**row)
        lo = max(0.0, source.start_s - start)
        hi = min(duration, source.end_s - start)
        if hi - lo > _TOL:
            position, speed = source.state_at(start + lo)
            pieces.append(MotionPiece(lo, hi, position, speed, source.acceleration_mps2))
    if not v_flow and boundary < duration - _TOL:
        last = payload["points"][-1]
        speed = payload["mainline_terminal_speed_mps"]
        lo = max(0.0, boundary)
        pieces.append(MotionPiece(lo, duration, last["s_m"] + speed*(lo-boundary), speed, 0.0))
    if not pieces:
        raise ValueError("V5_MAINLINE_PROFILE_MISSING")
    return TickProfile(tuple(pieces), duration)


def _schedule_entry_station(plan):
    return plan.get("e_station_m", plan.get("resource_entry_station_m"))
_TERMINAL = frozenset(
    {FlightState.COMPLETED, FlightState.EXITED, FlightState.HORIZON_CENSORED}
)
# Keep the V5 executor aligned with the canonical lifecycle partition.  The
# local hold state is newer than that shared set and is explicitly off-trunk.
_OFF_MAINLINE = frozenset((*OFF_MAINLINE, FlightState.REENTRY_LOCAL_HOLD))


def _payload(state: UAVState) -> Mapping[str, Any] | None:
    value = state.current_motion_plan.get("v5_frozen_trajectory")
    return value if isinstance(value, Mapping) else None


def has_v5_plan(state: UAVState) -> bool:
    """Return whether the state owns an active v5 immutable trajectory."""

    return _payload(state) is not None


def has_v5_state(snapshot: TrafficSnapshot) -> bool:
    # The retry marker is a scheduler/execution contract, not a request to
    # switch every caller to the V5 executor.  Formal V5 runtime calls pass
    # ``v5_thin_executor=True`` explicitly; keeping this probe payload-only
    # preserves isolated legacy/CPFF probes that intentionally exercise their
    # own executor with a retry-labelled state.
    return any(_payload(state) is not None for state in snapshot.states.values())


def v5_waiting_boundaries(network):
    """Return the scheduler's local read boundary and physical E by route."""
    from .crossing_resource_mapping import build_crossing_resource_maps
    from .network_loader import directed_node_interval
    return {
        (item.node_id, item.direction, item.layer): (
            directed_node_interval(network, item.node_id, item.direction, item.layer).upper_q_m,
            item.entry_station_m,
        ) for item in build_crossing_resource_maps(network).values()
    }


def _point_value(point: Mapping[str, Any], *names: str, default: float = 0.0) -> float:
    for name in names:
        if name in point and point[name] is not None:
            return float(point[name])
    return float(default)


def _point_sample(point: Mapping[str, Any]) -> dict[str, float]:
    return {
        "s_m": _point_value(point, "s_m"),
        "altitude_m": _point_value(point, "altitude_m"),
        "speed_mps": _point_value(point, "speed_mps", "longitudinal_speed_mps"),
        "longitudinal_speed_mps": _point_value(
            point, "longitudinal_speed_mps", "speed_mps"
        ),
        "vertical_speed_mps": _point_value(point, "vertical_speed_mps"),
    }


def build_v5_descent_payload(
    state: UAVState,
    plan: Mapping[str, Any],
    *,
    e_time_s: float,
    now_s: float | None = None,
) -> dict[str, Any]:
    """Materialize the published E→J→P template as an immutable sample list."""
    template = plan.get("descent_trajectory")
    if not isinstance(template, Mapping) or not template.get("segments"):
        raise ValueError(f"V5_DESCENT_TEMPLATE_MISSING:{state.uav_id}")
    e_station = float(plan.get("resource_entry_station_m", plan.get("e_station_m")))
    axis_station = e_station + float(template["v_e_mps"]) * float(template["j_offset_s"]) / 2
    rows: list[dict[str, float]] = []
    for segment in template["segments"]:
        phase = str(segment.get("phase_type", ""))
        start = float(segment["start_s"])
        end = float(segment["end_s"])
        p0 = segment["point0_xyz"]
        p1 = segment["point1_xyz"]
        v0 = segment.get("velocity0_xyz", (0.0, 0.0, 0.0))
        v1 = segment.get("velocity1_xyz", v0)
        for relative, point, velocity in ((start, p0, v0), (end, p1, v1)):
            if phase == "SOURCE_EXIT":
                station = (e_station + float(template["v_e_mps"]) * relative
                           - 0.5 * float(template["horizontal_acceleration_mps2"]) * relative**2)
                speed = max(0.0, math.hypot(float(velocity[0]), float(velocity[1])))
                vertical_speed = max(0.0, float(velocity[2]))
            else:
                station = axis_station
                speed = 0.0
                vertical_speed = max(0.0, float(velocity[2]))
            row = {
                "time_s": float(e_time_s) + relative,
                "s_m": float(station),
                "altitude_m": float(point[2]),
                "speed_mps": float(speed),
                "longitudinal_speed_mps": float(speed),
                "vertical_speed_mps": float(vertical_speed),
            }
            if rows and abs(rows[-1]["time_s"] - row["time_s"]) <= _TOL:
                rows[-1] = row
            else:
                rows.append(row)
    if not rows:
        raise ValueError(f"V5_DESCENT_POINTS_EMPTY:{state.uav_id}")
    if now_s is not None and float(e_time_s) > float(now_s) + _TOL:
        rows.insert(0, {
            "time_s": float(now_s), "s_m": float(state.s_m),
            "altitude_m": float(state.z_m), "speed_mps": float(state.speed_mps),
            "longitudinal_speed_mps": float(state.speed_mps),
            "vertical_speed_mps": 0.0,
        })
    return {
        "version": "V5_E_ANCHOR_SAMPLED_TRAJECTORY_V1",
        "flow": "V",
        "origin": "E",
        "points": tuple(rows),
        "vertical_profile": template["vertical_profile"],
        "resource_events": tuple(
            (rid, float(e_time_s) + offsets[0], float(e_time_s) + offsets[1])
            for rid, offsets in template["resource_windows_offsets"].items()
        ),
        "boundary_times": {
            "E": float(e_time_s),
            "J": float(e_time_s) + float(template["j_offset_s"]),
            "P": float(e_time_s) + float(template["e_to_p_s"]),
        },
    }


def build_v5_mainline_payload(
    state: UAVState,
    plan: Mapping[str, Any],
    *,
    now_s: float,
) -> dict[str, Any] | None:
    """Materialize a thin H trajectory from published resource targets."""
    targets = tuple(sorted(
        (item for item in plan.get("timed_resource_targets", ()) if isinstance(item, Mapping)),
        key=lambda item: float(item.get("entry_time_s", now_s)),
    ))
    if not targets:
        return None
    points: list[dict[str, float]] = [{
        "time_s": float(now_s), "s_m": float(state.s_m),
        "altitude_m": float(state.z_m), "speed_mps": float(state.speed_mps),
        "longitudinal_speed_mps": float(state.speed_mps), "vertical_speed_mps": 0.0,
    }]
    for target in targets:
        for time_key, station_key in (("entry_time_s", "entry_station_m"), ("exit_time_s", "exit_station_m")):
            moment = float(target[time_key])
            station = float(target[station_key])
            if moment < points[-1]["time_s"] - _TOL:
                continue
            duration = max(moment - points[-1]["time_s"], _TOL)
            speed = max(0.0, (station - points[-1]["s_m"]) / duration)
            points.append({
                "time_s": moment, "s_m": station, "altitude_m": float(state.z_m),
                "speed_mps": speed, "longitudinal_speed_mps": speed,
                "vertical_speed_mps": 0.0,
            })
    return {
        "version": "V5_E_ANCHOR_MAINLINE_TIMED_TRAJECTORY_V1",
        "flow": "H", "origin": "RESOURCE_TARGETS", "points": tuple(points),
        "boundary_times": {"R": float(points[-1]["time_s"])},
    }


def _sample(points: Iterable[Mapping[str, Any]], time_s: float) -> Mapping[str, float]:
    rows = tuple(points)
    if not rows:
        raise ValueError("V5_TRAJECTORY_POINTS_MISSING")
    if time_s <= float(rows[0]["time_s"]) + _TOL:
        return _point_sample(rows[0])
    if time_s >= float(rows[-1]["time_s"]) - _TOL:
        return _point_sample(rows[-1])
    left = rows[0]
    for right in rows[1:]:
        t0, t1 = float(left["time_s"]), float(right["time_s"])
        if time_s <= t1 + _TOL:
            ratio = (time_s - t0) / (t1 - t0)

            def value(name: str, fallback: str | None = None) -> float:
                left_value = _point_value(left, name, default=0.0)
                right_value = _point_value(right, name, default=0.0)
                if fallback is not None:
                    left_value = _point_value(left, name, fallback, default=left_value)
                    right_value = _point_value(right, name, fallback, default=right_value)
                return left_value + (right_value - left_value) * ratio

            return {
                "s_m": value("s_m"),
                "altitude_m": value("altitude_m"),
                "speed_mps": value("speed_mps", "longitudinal_speed_mps"),
                "longitudinal_speed_mps": value(
                    "longitudinal_speed_mps", "speed_mps"
                ),
                "vertical_speed_mps": value("vertical_speed_mps"),
            }
        left = right
    return _point_sample(rows[-1])


def _prior_events(state: UAVState, supplied: Iterable[ExecutedEvent]) -> tuple[ExecutedEvent, ...]:
    rows: dict[str, ExecutedEvent] = {}
    for event in supplied:
        rows[event.event_id] = event
    for raw in state.current_motion_plan.get("motion_observed_events", ()):
        if isinstance(raw, ExecutedEvent):
            rows[raw.event_id] = raw
        elif isinstance(raw, Mapping):
            event = ExecutedEvent(
                event_id=str(raw["event_id"]),
                event_type=str(raw["event_type"]),
                actual_time_s=float(raw["actual_time_s"]),
                sequence=int(raw.get("sequence", 0)),
                resource_id=raw.get("resource_id"),
                uav_id=str(raw.get("uav_id", state.uav_id)),
            )
            rows[event.event_id] = event
    return tuple(sorted(rows.values(), key=lambda row: (row.sequence, row.actual_time_s, row.event_id)))


def _seen(prior: Iterable[ExecutedEvent]) -> set[tuple[str, str | None]]:
    return {(row.event_type, row.resource_id) for row in prior}


def _event_rows(
    state: UAVState,
    *,
    t_from: float,
    t_to: float,
    prior: tuple[ExecutedEvent, ...],
) -> tuple[ExecutedEvent, ...]:
    payload = _payload(state)
    if payload is None:
        return ()
    plan = state.current_motion_plan
    boundaries = payload.get("boundary_times", {})
    candidates: list[tuple[float, str, str | None]] = []
    flow = str(payload.get("flow", plan.get("flow", ""))).upper()

    def add(moment: Any, kind: str, resource: str | None = None) -> None:
        if moment is None:
            return
        moment = float(moment)
        if t_from - _TOL <= moment <= t_to + _TOL:
            candidates.append((moment, kind, resource))

    # G/J are internal geometry of the trajectory implementation, not active
    # C-MLPM events.  Only published resource events and the physical service
    # boundary are emitted into the scheduling history.
    if flow == "V" and "P" in boundaries:
        add(boundaries["P"], "B_L1")

    targets = plan.get("timed_resource_targets", ())
    if flow == "V" and "vertical_profile" in payload:
        targets = tuple({"resource_id": rid, "entry_time_s": enter, "exit_time_s": exit_}
                        for rid, enter, exit_ in payload["resource_events"])
    for target in targets:
        if not isinstance(target, Mapping) or target.get("resource_id") is None:
            continue
        resource = str(target["resource_id"])
        add(target.get("entry_time_s"), "RESOURCE_ENTER", resource)
        add(target.get("exit_time_s"), "RESOURCE_EXIT", resource)

    seen = _seen(prior)
    if "mainline_pieces" in payload:
        seen = {(event.event_type, event.resource_id) for event in prior
                if f":V5:{flow}:" in event.event_id}
    rows: list[ExecutedEvent] = []
    sequence = 1 + max((row.sequence for row in prior), default=0)
    for moment, kind, resource in sorted(candidates, key=lambda item: (item[0], item[1], str(item[2]))):
        if (kind, resource) in seen:
            continue
        event_id = (f"{state.uav_id}:V5:{flow}:{kind}:{resource or '-'}"
                    if "mainline_pieces" in payload else
                    f"{state.uav_id}:V5:{kind}:{resource or '-'}")
        rows.append(ExecutedEvent(event_id, kind, moment, sequence, resource, state.uav_id))
        sequence += 1
        seen.add((kind, resource))
    return tuple(rows)


def _profile(state: UAVState, end: UAVState, dt_s: float) -> TickProfile:
    # The v5 point sampler is authoritative.  This profile is only the
    # measured mainline envelope consumed by the safety audit.
    acceleration = (float(end.speed_mps) - float(state.speed_mps)) / dt_s
    return TickProfile(
        (MotionPiece(0.0, dt_s, float(state.s_m), float(state.speed_mps), acceleration),),
        dt_s,
    )


def _retry_hold(
    state: UAVState,
    dt_s: float,
    motion_limits_by_type: Mapping[str, Any] | None,
) -> tuple[UAVState, TickProfile]:
    """Brake to a hover at the currently observed position envelope.

    This is deliberately not a station-targeted hold.  The next C-MLPM round
    either replaces the retry marker with a frozen trajectory or leaves the
    marker in place for another bounded braking/hover tick.
    """
    limits = (motion_limits_by_type or {}).get(
        state.vehicle_type, MotionLimits(0.0, max(1.0, state.speed_mps), 3.0))
    profile = bounded_profile(state, -limits.max_abs_acceleration_mps2,
                              replace(limits, min_speed_mps=0.0), dt_s)
    position, speed = profile.state_at(dt_s)
    return replace(state, s_m=position, speed_mps=speed), profile


def _release_h_plan(
    state: UAVState,
    payload: Mapping[str, Any],
    *,
    events: tuple[ExecutedEvent, ...],
) -> UAVState:
    plan = dict(state.current_motion_plan)
    plan["cmlpm_release"] = {
        "kind": "H_RESOURCE_PLAN_RELEASED",
        "plan_version": plan.get("plan_version"),
    }
    plan["motion_observed_events"] = tuple(asdict(event) for event in events)
    for key in (
        "v5_frozen_trajectory", "v4_frozen_trajectory", "execution_mode",
        "motion_control_owner", "freeze_record_id", "frozen", "plan_version",
        "g_time_s", "j_time_s", "g_to_j_s", "descent_trajectory",
        "descent_trajectory_realized", "enforce_g_terminal_state", "resource_windows",
        "timed_resource_targets", "passage_arrangement", "speed_control_token",
    ):
        plan.pop(key, None)
    next_state = (
        FlightState.ASSIGNED
        if state.assigned_node is not None
        and state.commit_status == "COMMITTED"
        and state.request_id is not None
        else FlightState.MAINLINE
    )
    return replace(
        state,
        state=next_state,
        current_motion_plan=plan,
        cmlpm_managed=False,
        cmlpm_plan_immutable=False,
        event_version=state.event_version + 1,
    )


def _release_v_plan(
    state: UAVState,
    payload: Mapping[str, Any],
    *,
    events: tuple[ExecutedEvent, ...],
    release_time_s: float,
) -> UAVState:
    """Convert a fulfilled descent into an active service episode.

    B_L1/P is a service handoff, never a task terminal state.  The active plan
    is reduced to lifecycle facts and observed events; all C-MLPM ownership,
    resource windows and trajectory artifacts are released before the service
    runtime takes over.
    """
    old_plan = state.current_motion_plan
    service_node = old_plan.get("service_node_id") or state.assigned_node
    if service_node is None:
        raise ValueError(f"V5_SERVICE_NODE_MISSING:{state.uav_id}")
    retained = {
        key: old_plan[key]
        for key in (
            "service_node_id", "route_id", "ecja_forward_contract",
            "g_station_m", "stop_station_m", "d_commit_m",
            "assignment_geometry_version",
            "schedule_history", "execution_history",
        )
        if key in old_plan
    }
    retained["service_node_id"] = str(service_node)
    # The descent assignment ends at the observed B_L1 handoff.  Keep the
    # identity needed by the re-entry runtime, but do not leave the lifecycle
    # plan looking like an active C-MLPM commitment.
    retained["uav_id"] = str(state.uav_id)
    retained["reentry_node_id"] = str(service_node)
    retained["lifecycle_owner"] = "REENTRY"
    retained["service_landing_time_s"] = float(release_time_s)
    retained["cmlpm_release"] = {
        "kind": "V_SERVICE_HANDOFF",
        "plan_version": old_plan.get("plan_version"),
        "resource_ids": tuple(
            str(event.resource_id) for event in events
            if event.event_type == "RESOURCE_EXIT" and event.resource_id is not None
        ),
    }
    retained["motion_observed_events"] = tuple(asdict(event) for event in events)
    released_resource_ids = {
        str(event.resource_id)
        for event in events
        if event.event_type == "RESOURCE_EXIT" and event.resource_id is not None
    }
    if old_plan.get("cmlpm_resource_passages"):
        # Preserve the immutable publication history for audit/replay, while
        # explicitly marking passages whose physical EXIT was observed.  This
        # is historical evidence, not an active resource commitment.
        retained["cmlpm_resource_passages"] = tuple(
            {
                **dict(row),
                **(
                    {
                        "status": "RELEASED",
                        "source": "OBSERVED_RESOURCE_EXIT",
                    }
                    if str(row.get("resource_id")) in released_resource_ids
                    else {}
                ),
            }
            for row in old_plan["cmlpm_resource_passages"]
            if isinstance(row, Mapping)
        )
        retained[
            "cmlpm_resource_passages_semantics"
        ] = "HISTORICAL_RELEASED_RESOURCE_HISTORY"
    return replace(
        state,
        state=FlightState.SERVICING,
        speed_mps=0.0,
        current_motion_plan=retained,
        commit_status="UNCOMMITTED",
        assigned_node=None,
        assigned_route=None,
        request_id=None,
        request=False,
        request_reason=None,
        request_trigger_time_s=None,
        request_guard_valid=None,
        request_guard_distance_m=None,
        request_distance_at_trigger_m=None,
        candidate_nodes=(),
        cmlpm_managed=False,
        cmlpm_plan_immutable=False,
        cmlpm_pending=None,
        event_version=state.event_version + 1,
    )


def execute_v5_thin_step(
    snapshot: TrafficSnapshot,
    *,
    dt_s: float,
    executed_by_uav: Mapping[str, Iterable[ExecutedEvent]] | None = None,
    min_mainline_gap_m: float | None = None,
    motion_limits_by_type: Mapping[str, Any] | None = None,
    v5_waiting_by_route: Mapping | None = None,
    **_: Any,
):
    """Execute one v5 tick without invoking the legacy motion machinery."""

    if not math.isfinite(dt_s) or dt_s <= 0.0:
        raise ValueError("INVALID_STEP")
    from .motion_executor import MotionStep

    t_from = float(snapshot.sim_time_s)
    t_to = t_from + float(dt_s)
    supplied = executed_by_uav or {}
    advanced: list[UAVState] = []
    events: list[ExecutedEvent] = []
    profiles: dict[str, TickProfile] = {}

    for state in sorted(snapshot.states.values(), key=lambda row: row.uav_id):
        if state.state in _TERMINAL:
            advanced.append(state)
            continue

        prior = _prior_events(state, supplied.get(state.uav_id, ()))
        plan = state.current_motion_plan
        payload = _payload(state)
        boundary = (v5_waiting_by_route or {}).get((state.assigned_node, state.direction, state.layer))
        waiting = (plan.get("execution_mode") == "CMLPM_RETRY_HOLD"
                   or plan.get("schedule_result") == "WAITING")
        if boundary and state.state == FlightState.ASSIGNED and state.commit_status == "COMMITTED":
            from .trigger_rules import latest_assignment_distance_m
            waiting = waiting or state.s_m >= boundary[0] - latest_assignment_distance_m(state.vehicle_type) - _TOL
        if payload is None and waiting:
            held, profile = _retry_hold(state, dt_s, motion_limits_by_type)
            entry_station = boundary[1] if boundary else _schedule_entry_station(plan)
            if entry_station is not None and held.s_m >= float(entry_station) - 1e-6:
                from .execution_precedence import HandoffRejected
                raise HandoffRejected(f"V5_RETRY_BRAKING_CROSSES_E:{state.uav_id}")
            retry_plan = dict(held.current_motion_plan)
            retry_plan["execution_mode"] = "CMLPM_RETRY_HOLD"
            retry_plan.setdefault("retry_hold_reason", "CMLPM_TRAJECTORY_PENDING")
            if entry_station is not None:
                retry_plan["e_station_m"] = float(entry_station)
            held = replace(held, current_motion_plan=retry_plan)
            advanced.append(held)
            profiles[state.uav_id] = profile
            continue

        if payload is None:
            if state.state in _OFF_MAINLINE:
                advanced.append(state)
                continue
            # Ordinary traffic remains a simple measured cruise in the v5
            # branch.  It is not a C-MLPM decision and has no repair channel.
            if state.current_motion_plan.get("thin_follow_hold"):
                # A following hold is a real local stop, not a permission to
                # restart immediately.  The following pass below removes the
                # marker only after the available gap can contain the next
                # acceleration tick; restarting here would create a transient
                # continuous-gap violation before that pass can react.
                restart_ready = bool(
                    state.current_motion_plan.get("thin_follow_restart_ready")
                )
                if restart_ready:
                    target_speed = float(
                        state.current_motion_plan.get(
                            "thin_follow_speed_mps",
                            state.nominal_speed_mps or state.speed_mps,
                        )
                    )
                    limit = float(
                        getattr(
                            (motion_limits_by_type or {}).get(state.vehicle_type),
                            "max_abs_acceleration_mps2",
                            3.0,
                        )
                    )
                    next_speed = min(target_speed, limit * dt_s)
                else:
                    next_speed = 0.0
            elif state.current_motion_plan.get("thin_follow_recovery"):
                target_speed = float(
                    state.current_motion_plan.get(
                        "thin_follow_speed_mps",
                        state.nominal_speed_mps or state.speed_mps,
                    )
                )
                limit = float(
                    getattr(
                        (motion_limits_by_type or {}).get(state.vehicle_type),
                        "max_abs_acceleration_mps2",
                        3.0,
                    )
                )
                next_speed = min(target_speed, state.speed_mps + limit * dt_s)
            elif state.current_motion_plan.get("thin_follow_braking"):
                # A previously braked follower may accelerate speculatively
                # within its bounded envelope.  The following continuous-gap
                # pass remains authoritative and replaces this profile with a
                # fresh brake/hold profile if the gap is still unsafe.
                target_speed = float(
                    state.current_motion_plan.get(
                        "thin_follow_speed_mps",
                        state.nominal_speed_mps or state.speed_mps,
                    )
                )
                limit = float(
                    getattr(
                        (motion_limits_by_type or {}).get(state.vehicle_type),
                        "max_abs_acceleration_mps2",
                        3.0,
                    )
                )
                next_speed = min(target_speed, state.speed_mps + limit * dt_s)
            else:
                resume_speed = float(
                    state.current_motion_plan.get(
                        "thin_follow_speed_mps",
                        state.speed_mps if state.speed_mps > 0.0 else (state.nominal_speed_mps or 0.0),
                    )
                )
                limit = float(
                    getattr(
                        (motion_limits_by_type or {}).get(state.vehicle_type),
                        "max_abs_acceleration_mps2",
                        3.0,
                    )
                )
                # Bounded approach to the resume setpoint, symmetric with the
                # braking and recovery branches above.  A stored target speed
                # that cannot be reached inside one tick must never be commanded
                # directly: ``_profile`` turns the pair (current, commanded) into
                # a single constant-acceleration piece, so an unclamped jump is
                # measured as an airframe violation and rejects the whole step
                # (MOTION_CAPABILITY_VIOLATION).  This also covers the stale-key
                # case where ``thin_follow_speed_mps`` survives without any of
                # the thin_follow_* markers.
                ceiling = state.speed_mps + limit * dt_s
                floor = max(0.0, state.speed_mps - limit * dt_s)
                next_speed = min(max(resume_speed, floor), ceiling)
            next_plan = dict(state.current_motion_plan)
            if (
                state.current_motion_plan.get("thin_follow_hold")
                and state.current_motion_plan.get("thin_follow_restart_ready")
                and next_speed > _TOL
            ):
                next_plan.pop("thin_follow_hold", None)
                next_plan.pop("thin_follow_restart_ready", None)
                next_plan.pop("safety_following_hold", None)
                next_plan.pop("thin_follow_braking", None)
                next_plan["thin_follow_recovery"] = True
            profile = _profile(state, replace(state, speed_mps=next_speed), dt_s)
            next_position, next_speed = profile.state_at(dt_s)
            end = replace(
                state,
                s_m=next_position,
                speed_mps=max(0.0, next_speed),
                current_motion_plan=next_plan,
            )
            advanced.append(end)
            profiles[state.uav_id] = profile
            continue

        flow = str(payload.get("flow", "")).upper()
        boundary_times = payload.get("boundary_times", {})
        profile = (_mainline_tick(payload, t_from=t_from, dt_s=dt_s)
                   if "mainline_pieces" in payload else None)
        sample = dict(_sample(payload.get("points", ()), t_to))
        if profile is not None:
            profiles[state.uav_id] = profile
            if flow == "H" or t_to <= float(boundary_times["E"]) + _TOL:
                sample["s_m"], sample["speed_mps"] = profile.state_at(profile.duration_s)
        if flow == "V" and "vertical_profile" in payload and t_to >= boundary_times["E"]:
            from .e_to_j_descent import _vertical_state
            elapsed = min(t_to, boundary_times["P"]) - boundary_times["E"]
            entry = _sample(payload["points"], boundary_times["E"])
            tau = min(elapsed, boundary_times["J"] - boundary_times["E"])
            speed = entry["speed_mps"]
            braking = speed / (boundary_times["J"] - boundary_times["E"])
            sample["s_m"] = entry["s_m"] + speed*tau - 0.5*braking*tau**2
            sample["speed_mps"] = max(0.0, speed - braking*tau)
            drop, _ = _vertical_state(payload["vertical_profile"], elapsed)
            sample["altitude_m"] = entry["altitude_m"] - drop
        row_events = _event_rows(state, t_from=t_from, t_to=t_to, prior=prior)
        events.extend(row_events)
        all_events = prior + row_events
        end = replace(
            state,
            s_m=sample["s_m"],
            z_m=sample["altitude_m"],
            speed_mps=max(0.0, sample["speed_mps"]),
            current_motion_plan={
                **state.current_motion_plan,
                "motion_observed_events": tuple(asdict(event) for event in all_events),
            },
            event_version=state.event_version + 1,
        )
        terminal = boundary_times.get("P" if flow == "V" else "R")
        if flow == "V":
            if terminal is not None and t_to >= float(terminal) - _TOL:
                end = _release_v_plan(
                    end, payload, events=all_events, release_time_s=t_to
                )
            elif "J" in boundary_times and t_to >= float(boundary_times["J"]) - _TOL:
                end = replace(end, state=FlightState.VERTICAL)
            elif "E" in boundary_times and t_to >= float(boundary_times["E"]) - _TOL:
                end = replace(end, state=FlightState.TRANSITION)
            else:
                end = replace(end, state=FlightState.SCHEDULED)
            if "mainline_pieces" not in payload and end.state not in {
                FlightState.SERVICING, FlightState.VERTICAL, FlightState.TRANSITION
            }:
                profiles[state.uav_id] = _profile(state, end, dt_s)
        else:
            if "mainline_pieces" not in payload:
                profiles[state.uav_id] = _profile(state, end, dt_s)
            if terminal is not None and t_to >= float(terminal) - _TOL:
                # The H trajectory ends at R.  Continue with ordinary
                # mainline cruise for any remainder of this tick, then make
                # the next C-MLPM round eligible to own the aircraft again.
                r_sample = _sample(payload.get("points", ()), float(terminal))
                remainder = max(0.0, t_to - float(terminal))
                if "mainline_pieces" not in payload:
                    end = replace(
                        end,
                        s_m=r_sample["s_m"] + r_sample["speed_mps"] * remainder,
                        z_m=r_sample["altitude_m"],
                        speed_mps=max(0.0, r_sample["speed_mps"]),
                    )
                end = _release_h_plan(end, payload, events=all_events)
                if "mainline_pieces" not in payload:
                    profiles[state.uav_id] = _profile(state, end, dt_s)
        advanced.append(end)

    # Audit and control use the same before-state lane order, even when the
    # leader leaves the lane partway through this tick.
    next_states = {state.uav_id: state for state in advanced}
    by_lane = {}
    for uid in profiles:
        state = snapshot.states[uid]
        by_lane.setdefault(physical_lane(state), []).append(state)
    required_gap = float(min_mainline_gap_m if min_mainline_gap_m is not None else 50.0)
    for lane in by_lane.values():
        ordered = sorted(lane, key=lambda state: (-state.s_m, state.uav_id))
        for leader, follower in zip(ordered, ordered[1:]):
            uid = follower.uav_id
            if _payload(follower) is not None:
                continue
            leader_profile, follower_profile = profiles[leader.uav_id], profiles[uid]
            leader_s, leader_speed = leader_profile.state_at(leader_profile.duration_s)
            rear_s, rear_speed = follower_profile.state_at(dt_s)
            limits = (motion_limits_by_type or {}).get(
                follower.vehicle_type, MotionLimits(0.0, max(1.0, follower.speed_mps), 3.0))
            brake = limits.max_abs_acceleration_mps2
            leader_limits = (motion_limits_by_type or {}).get(leader.vehicle_type, limits)
            braking_gap = max(0.0, rear_speed**2/(2*brake)
                              - leader_speed**2/(2*leader_limits.max_abs_acceleration_mps2))
            needs_braking = (continuous_min_gap(leader_profile, follower_profile) < required_gap - 1e-6
                             or (leader_profile.duration_s == dt_s
                                 and leader_s - rear_s < required_gap + braking_gap - 1e-6))
            if needs_braking:
                end = next_states[uid]
                held, profile = _retry_hold(follower, dt_s, motion_limits_by_type)
                plan = dict(end.current_motion_plan)
                plan.setdefault(
                    "thin_follow_speed_mps",
                    float(follower.nominal_speed_mps or follower.speed_mps),
                )
                plan.pop("thin_follow_recovery", None)
                if held.speed_mps <= _TOL:
                    plan.update(thin_follow_hold=True, safety_following_hold=True)
                    plan.pop('thin_follow_braking', None)
                    plan.pop('thin_follow_restart_ready', None)
                else:
                    plan['thin_follow_braking'] = True
                next_states[uid] = replace(end, s_m=held.s_m, speed_mps=held.speed_mps,
                                           current_motion_plan=plan)
                profiles[uid] = profile
            else:
                end = next_states[uid]
                plan = dict(end.current_motion_plan)
                target = plan.get("thin_follow_speed_mps")
                if plan.get("thin_follow_braking"):
                    plan.pop("thin_follow_braking", None)
                    plan["thin_follow_recovery"] = True
                if plan.get("thin_follow_hold"):
                    if leader_s - end.s_m > required_gap + 0.5*brake*dt_s**2:
                        plan["thin_follow_restart_ready"] = True
                    if end.speed_mps > _TOL:
                        plan.pop("thin_follow_hold", None)
                        plan.pop("thin_follow_restart_ready", None)
                        plan.pop("safety_following_hold", None)
                        plan["thin_follow_recovery"] = True
                if (
                    target is not None
                    and plan.get("thin_follow_recovery")
                    and end.speed_mps >= float(target) - _TOL
                ):
                    plan.pop("thin_follow_recovery", None)
                    plan.pop("thin_follow_speed_mps", None)
                next_states[uid] = replace(end, current_motion_plan=plan)
        if ordered:
            uid = ordered[0].uav_id
            end = next_states[uid]
            if end.current_motion_plan.get("thin_follow_hold"):
                next_states[uid] = replace(end, current_motion_plan={
                    **end.current_motion_plan, "thin_follow_restart_ready": True})

    return MotionStep(
        t_from=t_from,
        t_to=t_to,
        states=tuple(next_states.values()),
        events=tuple(sorted(events, key=lambda row: (row.actual_time_s, row.sequence, row.uav_id))),
        mainline_profiles=profiles,
    )
