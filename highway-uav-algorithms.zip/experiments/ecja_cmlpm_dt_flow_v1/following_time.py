"""Same-state physical dependencies and necessary departure/event relations.

These optimistic bounds exclude early events. They do not characterize holes
in a reachable set or certify any candidate trajectory. Aircraft acceptance is
mandatory even when every condition holds. No curve result is cached here.
"""
from __future__ import annotations

import hashlib
import math
from typing import Any, Iterable, Mapping

from .numeric_motion import MotionLimits
from .simulation_state import FlightState, UAVState

OFF_MAINLINE = {FlightState.COMPLETED, FlightState.EXITED,
                FlightState.HORIZON_CENSORED, FlightState.TRANSITION, FlightState.VERTICAL,
                 FlightState.SERVICING, FlightState.REENTRY_HOLD, FlightState.REENTRY_CLIMB,
                 FlightState.REENTRY_LAND_TO_GROUND, FlightState.REENTRY_ASCENT_TO_50M,
                 FlightState.REENTRY_STAGING_HOLD, FlightState.REENTRY_FINAL_APPROACH}


def physical_lane(state: UAVState) -> tuple[str, str, str]:
    # lane_id identifies the registered physical directed trunk; layer and
    # direction additionally guard malformed or reused labels.
    return state.lane_id, state.direction, state.layer


def motion_version(state: UAVState) -> str:
    return hashlib.sha256(repr((state.event_version, state.s_m, state.speed_mps,
                               state.current_motion_plan)).encode("utf-8")).hexdigest()


from dataclasses import asdict
from types import SimpleNamespace
from traffic_simulation.cmlpm.joint_single_node.following_contract import (
    FollowingAircraft, FollowingDomain, VERSION, derive_conditions, optimistic_clearance_s,
)
from traffic_simulation.cmlpm.joint_single_node.schema import MODEL_VERSION


def build_following_time_contract(payload: dict[str, Any], *,
                                  states: Iterable[UAVState],
                                  limits_by_type: Mapping[str, MotionLimits],
                                  published_e_times: Mapping[str, float],
                                  min_gap_m: float,
                                  include_uav_ids: Iterable[str] = (),
                                  suppress_published_ids: Iterable[str] = ()) -> None:
    """Build all-ahead dependencies and curve-independent V-departure bounds.

    Ordinary H, wait-only and other-node aircraft remain in the physical
    dependency evidence even without a schedulable event at this node. Such
    dependencies are resolved by joint aircraft acceptance, never deleted.
    """
    if not math.isfinite(min_gap_m) or min_gap_m < 50.:
        raise ValueError("INVALID_FOLLOWING_GAP")
    # A V request can be observed in TRANSITION/VERTICAL after a rejected or
    # expired plan.  It is still a physical aircraft in the current C-MLPM
    # request set and therefore must have an explicit following-domain row;
    # only those IDs are admitted back into the domain.  Other off-mainline
    # states retain the historical exclusion semantics.
    included = {str(value) for value in include_uav_ids}
    suppressed = {str(value) for value in suppress_published_ids}
    rows = tuple(s for s in states if s.state not in OFF_MAINLINE or s.uav_id in included)
    by_id = {s.uav_id: s for s in rows}
    if len(by_id) != len(rows):
        raise ValueError("DUPLICATE_FOLLOWING_UAV")
    metadata = payload["metadata"]
    version = int(metadata["state_version"])
    event_ids = {e["event_id"] for e in payload["events"]}
    motion_versions = {s.uav_id: motion_version(s) for s in rows}
    aircraft, dependencies = [], []
    for state in rows:
        limits = limits_by_type[state.vehicle_type]
        plan = state.current_motion_plan
        published = None if state.uav_id in suppressed else published_e_times.get(state.uav_id)
        if (published is None and state.uav_id not in suppressed
                and state.cmlpm_plan_immutable and state.commit_status == "FROZEN"
                and plan.get("schedule_result") == "RELEASED"):
            published = float(plan["e_time_s"])
        aircraft.append(FollowingAircraft(
            uav_id=state.uav_id, lane_id=state.lane_id, direction=state.direction, layer=state.layer,
            position_m=state.s_m, speed_mps=state.speed_mps, motion_version=motion_versions[state.uav_id],
            vmax_mps=min(limits.max_speed_mps, float(state.nominal_speed_mps or limits.max_speed_mps)),
            braking_mps2=limits.max_abs_acceleration_mps2,
            e_station_m=plan.get("resource_entry_station_m", plan.get("e_station_m")),
            e_entry_speed_mps=plan.get("e_entry_speed_mps"),
            published_e_time_s=published,
            resource_entry_station_m=plan.get("resource_entry_station_m")))
    valid_until = payload.get("t_clear")
    if valid_until is None:
        valid_until = max((event["time_ub"] for event in payload["events"]), default=payload["t_now"])
    domain = FollowingDomain(version, payload["t_now"], valid_until, min_gap_m, tuple(aircraft))
    for follower in rows:
        for leader in rows:
            if (physical_lane(leader) == physical_lane(follower)
                    and (-leader.s_m, leader.uav_id) < (-follower.s_m, follower.uav_id)):
                dependencies.append({"leader_id": leader.uav_id, "follower_id": follower.uav_id,
                    "lane_id": leader.lane_id, "direction": leader.direction, "layer": leader.layer,
                    "observed_gap_m": leader.s_m-follower.s_m, "state_version": version,
                    "leader_motion_version": motion_versions[leader.uav_id], "follower_motion_version": motion_versions[follower.uav_id],
                    "observed_at_s": payload["t_now"], "valid_until_s": valid_until})
    conditions = derive_conditions(domain,
        [SimpleNamespace(**e) for e in payload["events"]],
        [SimpleNamespace(**d) for d in payload["descents"]],
        [SimpleNamespace(**u) for u in payload.get("resource_uses", ())])
    payload.update(model_version=MODEL_VERSION, following_domain=asdict(domain),
                   following_time_conditions=[asdict(c) for c in conditions])
    metadata.update(physical_following_dependencies=dependencies,
                    following_time_certification="NECESSARY_ONLY; ACTUAL_EXECUTION_AUDITED")
