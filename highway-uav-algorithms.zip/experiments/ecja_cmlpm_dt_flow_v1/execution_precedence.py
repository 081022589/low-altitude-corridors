"""Shared execution facts and certified H/V precedence, not scheduling costs.

Frozen targets are proposal evidence. Only committed observed edges release
occupancy; a forecast is never a release. Both guards consume this result.
"""
from __future__ import annotations
from dataclasses import dataclass,asdict
from functools import lru_cache
import hashlib,json,math
from traffic_simulation.cmlpm.joint_single_node.conflict_builder import SHARED_RESOURCE_ENTRY_HEADWAY_S
from .existing_v_continuation import current_v_resource_windows
from .resource_conflict_classification import is_cross_layer_vh_pair


class HandoffRejected(RuntimeError):pass


def _planned_entry_station(plan):
    """Return the active E-anchor station used by the execution guard.

    E is the only C-MLPM timing anchor.  A geometric upstream hold point may
    still be carried by the execution layer, but it is deliberately not read
    here as a scheduler event or timing field.
    """
    for key in ("resource_entry_station_m", "e_station_m"):
        if plan.get(key) is not None:
            return float(plan[key])
    return None


def _planned_entry_times(plan):
    """Return (E, end-of-transfer) for an E-anchor publication."""
    entry = plan.get("e_time_s")
    if entry is None:
        # Historical non-E plans can still reach this shared helper from
        # regression fixtures.  They are not part of the active E-anchor
        # publication contract.
        entry = plan.get("g_time_s")
    if entry is None:
        return None, None
    transfer = float(plan.get("e_to_j_s", 0.0) or 0.0)
    if transfer <= 0.0 and plan.get("j_time_s") is not None:
        transfer = float(plan["j_time_s"]) - float(entry)
    return float(entry), float(entry) + max(0.0, transfer)


@lru_cache(None)
def registered_environment():
    from pathlib import Path
    from .config import load_config
    from .network_loader import load_registered_g25
    from .cmlpm_runtime_pipeline import motion_limits_from_config
    from .crossing_resource_mapping import mainline_crossing_stations
    root=Path(__file__).resolve().parents[2]
    cfg=load_config(root/"experiments/ecja_cmlpm_dt_flow_v1/configs/baseline.yaml")
    net=load_registered_g25(root/"network_contracts/g25_planar_realized_v1_3/network.json")
    return mainline_crossing_stations(net),motion_limits_from_config(cfg),cfg["resource_safety"]


def digest(x):
    return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(",",":"),default=str).encode()).hexdigest()


@lru_cache(None)
def registered_mainline_gap():
    from pathlib import Path
    from .config import load_config
    return float(load_config(Path(__file__).resolve().parents[2]/"experiments/ecja_cmlpm_dt_flow_v1/configs/baseline.yaml")["motion"]["min_gap_m"])


def resource_cooldown_dependencies(completed,now):
    _,_,safety=registered_environment()
    tail=max(SHARED_RESOURCE_ENTRY_HEADWAY_S,float(safety["vh_v_to_h_margin_s"]),float(safety["vh_h_to_v_margin_s"]))
    return {u:s for u,s in completed.items() if any(
        e["event_type"]=="RESOURCE_EXIT" and e["actual_time_s"]+tail>now-1e-9
        for e in s.current_motion_plan.get("motion_observed_events",()))}


@dataclass(frozen=True)
class ExecutionPrecedence:
    resource_id:str
    h_uid:str
    v_uid:str
    order:str
    reason:str
    h_entry_station_m:float
    h_exit_station_m:float
    h_actual_entry_s:float|None
    h_actual_exit_s:float|None
    v_actual_entry_s:float|None
    v_actual_exit_s:float|None
    v_actual_entry_anchor_s:float|None
    v_predicted_entry_s:float
    v_predicted_exit_s:float
    h_stopping_room_m:float
    h_stopping_distance_m:float
    plan_pair_sha256:str

    @property
    def key(self):return self.resource_id+"|"+self.h_uid+"|"+self.v_uid


def event_edges(events,now):
    enters={};exits={}
    for e in events:
        if e.actual_time_s>now+1e-9:raise HandoffRejected("HANDOFF_FUTURE_ACTUAL_EVENT")
        if e.event_type=="RESOURCE_ENTER":enters[str(e.resource_id)]=e.actual_time_s
        if e.event_type=="RESOURCE_EXIT":exits[str(e.resource_id)]=e.actual_time_s
    if set(exits)-set(enters):raise HandoffRejected("HANDOFF_EXIT_WITHOUT_ENTER")
    if any(exits[r]<enters[r]-1e-9 for r in exits):raise HandoffRejected("HANDOFF_RESOURCE_HISTORY_REVERSED")
    return enters,exits


def resource_execution_facts(state,now):
    """Occupancy summary from event edges only, separate from SRCM plan cover.

    On a candidate state this is candidate evidence; only the successful store
    CAS makes it authoritative, exactly like the state's actual-G field.
    """
    from .existing_v_continuation import ExecutedEvent
    plan=state.current_motion_plan
    events=tuple(ExecutedEvent(**e) for e in plan.get("motion_observed_events",()))
    enters,exits=event_edges(events,now)
    planned={str(r):(a,b) for r,a,b in plan.get("resource_windows",())}
    for t in plan.get("timed_resource_targets",()):
        planned.setdefault(str(t["resource_id"]),(t["entry_time_s"],t["exit_time_s"]))
    return {rid:{"resource_id":rid,"observed_at_s":now,
        "actual_entry_s":enters.get(rid),"actual_exit_s":exits.get(rid),
        "actual_state":"ACTUAL_RELEASED" if rid in exits else "ACTUAL_ACTIVE" if rid in enters else "NOT_ENTERED",
        "planned_entry_s":planned.get(rid,(None,None))[0],"planned_exit_s":planned.get(rid,(None,None))[1],
        "release_basis":"OBSERVED_EXIT" if rid in exits else None}
        for rid in sorted(set(planned)|set(enters)|set(exits))}


def build_execution_precedence(snapshot,*,prior,mainline_crossings=None,motion_limits_by_type=None,resource_safety=None,min_mainline_gap_m=None):
    if mainline_crossings is None or motion_limits_by_type is None or resource_safety is None:
        crossings,limits,safety=registered_environment()
        if mainline_crossings is None:mainline_crossings=crossings
        if motion_limits_by_type is None:motion_limits_by_type=limits
        if resource_safety is None:resource_safety=safety
    h_after_v=float(resource_safety["vh_v_to_h_margin_s"])
    v_after_h=float(resource_safety["vh_h_to_v_margin_s"])
    gap=registered_mainline_gap() if min_mainline_gap_m is None else float(min_mainline_gap_m)
    from .following_time import physical_lane
    canonical,_,_=registered_environment()
    registry={str(r) for table in (canonical,mainline_crossings) for group in table.values() for r,_,_ in group}
    now=snapshot.sim_time_s;states=snapshot.states
    edges={u:event_edges(prior.get(u,()),now) for u in states};vertical={};result=[]
    if any((set(en)|set(ex))-registry for en,ex in edges.values()):raise HandoffRejected("HANDOFF_UNKNOWN_RESOURCE_HISTORY")
    for v in states.values():
        p=v.current_motion_plan;windows=p.get("resource_windows",())
        if not windows or p.get("motion_control_owner")!="MEASURED_KINEMATIC_EXECUTOR_V1":continue
        if any(str(r) not in registry for r,_,_ in windows):raise HandoffRejected("HANDOFF_UNKNOWN_RESOURCE")
        e_actual = p.get("e_actual_time_s")
        if v.state.value in {"TRANSITION","VERTICAL","COMPLETED"} and e_actual is None:
            raise HandoffRejected("HANDOFF_ACTUAL_E_HISTORY_MISSING")
        e_time, transfer_end = _planned_entry_times(p)
        if e_time is None or transfer_end is None:
            raise HandoffRejected("HANDOFF_E_ANCHOR_PLAN_MISSING")
        forecast,_=current_v_resource_windows(v,t_now=now,resource_windows=windows,
            e_time_s=e_time,e_to_j_s=transfer_end-e_time,executed=prior.get(v.uav_id,()))
        ve,vx=edges[v.uav_id]
        if v.state.value=="COMPLETED" and any(str(r) not in vx for r,_,_ in windows):
            raise HandoffRejected("HANDOFF_COMPLETED_V_EXIT_HISTORY_MISSING")
        for rid,a,b in windows:
            rid=str(rid)
            if rid in vx and now>=max(vx[rid]+h_after_v,ve[rid]+SHARED_RESOURCE_ENTRY_HEADWAY_S)-1e-9:continue
            vertical.setdefault(rid,[]).append((v,forecast[rid],e_actual,ve.get(rid),vx.get(rid)))
    for h in states.values():
        hp=h.current_motion_plan;he,hx=edges[h.uav_id];he_actual=hp.get("e_actual_time_s")
        targets={str(t["resource_id"]):t for t in hp.get("timed_resource_targets",())}
        if set(targets)-registry:raise HandoffRejected("HANDOFF_UNKNOWN_RESOURCE")
        for rid,entry,exit_ in mainline_crossings.get((h.direction,h.layer),()):
            rid=str(rid)
            # Only actual straight-path H edges, or a future physical crossing.
            h_enter=he.get(rid);h_exit=hx.get(rid)
            if h_enter is not None and he_actual is not None and h_enter>=he_actual-1e-9:continue
            if h_enter is None:
                if h.state.value in {"TRANSITION","VERTICAL","SERVICING","REENTRY_HOLD","REENTRY_CLIMB",
                                     "REENTRY_LAND_TO_GROUND","REENTRY_ASCENT_TO_50M",
                                     "REENTRY_STAGING_HOLD","REENTRY_FINAL_APPROACH",
                                     "COMPLETED","EXITED","HORIZON_CENSORED"}:continue
                if exit_<h.s_m-1e-9:continue
                planned_entry = _planned_entry_station(hp)
                if hp.get("schedule_result")=="RELEASED" and planned_entry is not None and entry>=planned_entry-1e-9:continue
            bound=motion_limits_by_type.get(h.vehicle_type)
            if bound is None:raise HandoffRejected("HANDOFF_MOTION_LIMITS_MISSING")
            room=float(entry)-1e-6-float(h.s_m);brake=h.speed_mps*h.speed_mps/(2*bound.max_abs_acceleration_mps2)
            for v,forecast,vg,ve,vx in vertical.get(rid,()):
                if h.uav_id==v.uav_id:continue
                # Same-layer V/H is longitudinal following/FIFO.  It must
                # never enter the orthogonal handoff state machine merely
                # because both paths mention the same physical resource id.
                if not is_cross_layer_vh_pair(h, v):
                    continue
                if h_exit is not None and now>=max(h_exit+v_after_h,h_enter+SHARED_RESOURCE_ENTRY_HEADWAY_S)-1e-9:continue
                pair_hash=digest([rid,h.uav_id,v.uav_id,targets.get(rid),v.current_motion_plan.get("resource_windows"),v.current_motion_plan.get("e_time_s")])
                key=rid+"|"+h.uav_id+"|"+v.uav_id
                old=hp.get("execution_precedence",{}).get(key)
                if h_enter is not None and (ve is None or h_enter<=ve):order,reason="H_FIRST","ACTUAL_H_PRECEDENCE"
                elif ve is not None and (h_enter is None or ve<h_enter):order,reason="V_FIRST","ACTUAL_V_PRECEDENCE"
                elif vg is not None or ve is not None:order,reason="V_FIRST","ACTUAL_IRREVERSIBLE_V"
                elif old and old["plan_pair_sha256"]==pair_hash:order,reason=old["order"],"RETAIN_CERTIFIED_HANDOFF"
                elif h_exit is not None:order,reason="H_FIRST","ACTUAL_H_EXIT_HEADWAY"
                elif (physical_lane(h)==physical_lane(v) and h.s_m>v.s_m and
                      _planned_entry_station(v.current_motion_plan) is not None and
                      float(entry)-1e-6-float(_planned_entry_station(v.current_motion_plan))<gap+1e-9):
                    # Stopping this physical predecessor would deny V the
                    # clearance needed to reach G. It must clear first; the
                    # proposed handoff is still subject to joint certification.
                    order,reason="H_FIRST","QUEUE_PREDECESSOR_BLOCKS_G"
                elif room+1e-9<brake:order,reason="H_FIRST","H_STOP_UNREACHABLE_V_UNLAUNCHED"
                else:
                    target=targets.get(rid)
                    # An expired, unobserved H target is not evidence that H
                    # can pass first. In particular H may be queued behind V.
                    # Actual edges and an unavoidable physical H crossing are
                    # handled above; changed proposals still need joint proof.
                    if target is not None and float(target["entry_time_s"])>=now-1e-9 and max(float(target["exit_time_s"])+v_after_h,
                            float(target["entry_time_s"])+SHARED_RESOURCE_ENTRY_HEADWAY_S)<=forecast[0]:
                        order,reason="H_FIRST","CURRENT_FORECAST_H_BEFORE_V"
                    else:order,reason="V_FIRST","REACHABLE_INHERITED_ORDER_PROPOSAL"
                if order=="H_FIRST" and vg is None and ve is None and h_exit is None:
                    vb=motion_limits_by_type[v.vehicle_type]
                    entry_station = _planned_entry_station(v.current_motion_plan)
                    if entry_station is None:
                        raise HandoffRejected("HANDOFF_V_ENTRY_STATION_MISSING")
                    vr=entry_station-1e-6-v.s_m
                    vd=v.speed_mps*v.speed_mps/(2*vb.max_abs_acceleration_mps2)
                    if vr+1e-9<vd:
                        from .local_trajectory_certification import certified_approach_covers
                        if not certified_approach_covers(snapshot,h,v,mainline_crossings=mainline_crossings,
                                resource_safety=resource_safety,min_mainline_gap_m=gap):
                            error=HandoffRejected("HANDOFF_V_WAIT_UNREACHABLE")
                            error.feedback={"status":"COMMITMENT_UNFULFILLABLE", "channel":"VH",
                                "snapshot_version":snapshot.version,"time_s":now,
                                "h_uav_id":h.uav_id,"v_uav_id":v.uav_id,"resource_id":rid,
                                "remaining_to_g_m":vr,"braking_distance_m":vd,
                                "stopping_margin_m":vr-vd,
                                "reason":"STOP_UNREACHABLE_AND_CONTINUATION_NOT_CERTIFIED"}
                            error.diagnostics=error.feedback
                            raise error
                if order=="V_FIRST" and vx is None and h_enter is None and h_exit is None and room+1e-9<brake:
                    raise HandoffRejected("HANDOFF_H_STOP_UNREACHABLE_IRREVERSIBLE_V")
                result.append(ExecutionPrecedence(rid,h.uav_id,v.uav_id,order,reason,float(entry),float(exit_),
                    h_enter,h_exit,ve,vx,vg,float(forecast[0]),float(forecast[1]),room,brake,pair_hash))
    return tuple(result)


def attach_precedence(states,relations,version):
    from dataclasses import replace
    by_uid={}
    for relation in relations:
        row={**asdict(relation),"certified_input_version":version}
        for uid in (relation.h_uid,relation.v_uid):by_uid.setdefault(uid,{})[relation.key]=row
    return tuple(replace(s,current_motion_plan={**s.current_motion_plan,
        "execution_precedence":by_uid.get(s.uav_id,{})})
        if s.uav_id in by_uid or s.current_motion_plan.get("execution_precedence") else s for s in states)
