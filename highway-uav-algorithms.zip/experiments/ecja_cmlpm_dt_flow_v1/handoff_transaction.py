"""Prepublication certification and atomic measured-motion commit.

Private candidate audits are never authoritative occupancy. The store CAS
must succeed before the public audit/actual-event consumers are advanced.
"""
from dataclasses import dataclass,replace
from collections import Counter
import json,hashlib
from .joint_motion_evidence import measured,rehearsal_context,performance_span,performance_metrics
from .execution_precedence import HandoffRejected,digest
from traffic_simulation.cmlpm.joint_single_node.conflict_builder import SHARED_RESOURCE_ENTRY_HEADWAY_S


def state_digest(states):
    return digest({uid:vars(s) for uid,s in sorted(states.items())})


@dataclass(frozen=True)
class HandoffCertificate:
    input_version:int
    proposed_sha256:str
    passed:bool
    relations:tuple
    motion_summary:dict


class MotionAuditRejected(HandoffRejected):
    def __init__(self, violations, counts):
        super().__init__("HANDOFF_JOINT_MOTION_INFEASIBLE:" + json.dumps(dict(counts), sort_keys=True))
        self.violations = tuple(violations)


def seed_actual_audit(snapshot,config):
    from .measured_motion_audit import MeasuredMotionAudit
    from .existing_v_continuation import ExecutedEvent
    audit=MeasuredMotionAudit(config,None);audit._pending=[]
    events=[]
    for state in {**getattr(snapshot,"resource_dependencies",{}),**snapshot.states}.values():
        g=state.current_motion_plan.get("g_actual_time_s")
        for row in state.current_motion_plan.get("motion_observed_events",()):
            if row.get("resource_id") and row["event_type"] in {"RESOURCE_ENTER","RESOURCE_EXIT"}:
                if row["actual_time_s"]>snapshot.sim_time_s+1e-9:raise HandoffRejected("HANDOFF_FUTURE_ACTUAL_EVENT")
                events.append((ExecutedEvent(**row),"V" if any(
                    marker in str(row.get('event_id','')) for marker in (':REENTRY:', ':V5:V:'))
                    or g is not None and row["actual_time_s"]>=g-1e-9 else "H", state))
    seen=set()
    for event,role,state in sorted(events,key=lambda item:(item[0].actual_time_s,item[0].sequence,item[0].uav_id)):
        if event.event_id in seen:continue
        seen.add(event.event_id);audit._resource_event(event,role,state)
    audit._pending=[]
    return audit


@measured("motion.independent_audit")
def trial_motion_audit(audit,before,step,limits,*,allow_gap_recovery=False):
    trial=audit.fork()
    previous=Counter(trial.safety)
    trial.observe(before,step,limits)
    new=Counter(trial.safety)-previous
    if new:
        from .cpff_anomaly_response import AnomalyResponsePolicy,recovery_motion_is_valid
        policy=AnomalyResponsePolicy.from_config(audit.config)
        recoverable=(allow_gap_recovery and policy.permits_codes(new)
            and recovery_motion_is_valid(before,step,float(audit.config['motion']['min_gap_m'])))
        if not recoverable:
            raise MotionAuditRejected(
                (row for row in trial._pending if row.get("severity") == "VIOLATION"), new)
    return trial


def _handoff_obligations_complete(final, obligations):
    """Reuse exit facts only within this one immutable private step.

    Keep every relation and the original short-circuit/validation order.
    No completion fact survives a step or substitutes for observed EXIT.
    """
    exits = {}
    v_complete = {}
    def exited(state):
        if state.uav_id not in exits:
            exits[state.uav_id] = {
                str(e.get("resource_id"))
                for e in state.current_motion_plan.get("motion_observed_events", ())
                if e["event_type"] == "RESOURCE_EXIT"
            }
        return exits[state.uav_id]
    for row in obligations:
        h = final.states[row["h_uid"]]
        v = final.states[row["v_uid"]]
        hx, vx = exited(h), exited(v)
        if row["order"] == "H_FIRST" and row["resource_id"] not in hx:
            return False
        if v.uav_id not in v_complete:
            v_complete[v.uav_id] = not any(
                str(r) not in vx for r, _, _ in v.current_motion_plan.get("resource_windows", ())
            )
        if not v_complete[v.uav_id]:
            return False
    return True


def continuation_obligations(states,relations):
    """Explicit resource EXIT duties equivalent to the original terminal rule.

    Full V chains are retained: removing downstream duties needs a separate
    independence proof. Duplicate obligations retain every source relation.
    V_FIRST deliberately preserves the existing terminal semantics for H.
    """
    duties={}
    for row in relations:
        source=(row['resource_id'],row['h_uid'],row['v_uid'],row['order'])
        needed=[(row['v_uid'],str(r),'V_CHAIN_EXIT',None)
                for r,_,_ in states[row['v_uid']].current_motion_plan.get('resource_windows',())]
        if row['order']=='H_FIRST':
            needed.append((row['h_uid'],str(row['resource_id']),'H_PRECEDENCE_EXIT',row.get('h_exit_station_m')))
        for uid,rid,kind,station in needed:
            key=(uid,rid,kind)
            duty=duties.setdefault(key,dict(uav_id=uid,resource_id=rid,event_type='RESOURCE_EXIT',
                kind=kind,exit_station_m=station,source_relations=[]))
            if source not in duty['source_relations']:
                duty['source_relations'].append(source)
    return [duties[key] for key in sorted(duties)]


def pending_continuation_obligations(states,duties):
    exits={}
    pending=[]
    for duty in duties:
        uid=duty['uav_id']
        if uid not in exits:
            exits[uid]={str(e.get('resource_id')) for e in states[uid].current_motion_plan.get('motion_observed_events',())
                        if e['event_type']=='RESOURCE_EXIT'}
        if duty['resource_id'] not in exits[uid]:pending.append(duty)
    return pending


def continuation_completion_lower_bound(states,pending,now,limits):
    """Optimistic geometric bound; no target/forecast times are physical bounds.

    Only H mainline EXIT distance/max speed is used. Unknown motion classes
    receive no positive bound. Parallel duties combine by max, never by sum.
    """
    bound=now;witness=None
    for duty in pending:
        state=states[duty['uav_id']]
        if (duty['kind']!='H_PRECEDENCE_EXIT' or duty['exit_station_m'] is None
                or state.state.value not in {'MAINLINE','ASSIGNED','SCHEDULED','DEFERRED','MOTION_INFEASIBLE'}):
            continue
        speed=limits[state.vehicle_type].max_speed_mps
        if speed<=0:continue
        earliest=now+max(0.,float(duty['exit_station_m'])-state.s_m)/speed
        if earliest>bound:
            bound=earliest;witness=dict(uav_id=state.uav_id,resource_id=duty['resource_id'],
                bound_basis='MAINLINE_DISTANCE_OVER_MAX_SPEED',earliest_completion_s=earliest)
    return bound,witness


@rehearsal_context
@measured("handoff.continuation")
def prove_handoff_continuation(snapshot,states,relations,*,config,network,limits):
    """Finite private continuation proof, not actual events or new traffic.

    New H/V relations must progress through actual-edge gates in the private
    state. A work-horizon failure is UNKNOWN/rejected, not physical infeasibility.
    """
    from .simulation_state import TrafficStateStore, TrafficSnapshot
    from .motion_executor import execute_frozen_motion,resource_z_bounds
    from .crossing_resource_mapping import mainline_crossing_stations
    obligations=[]
    for row in relations:
        old=snapshot.states[row["h_uid"]].current_motion_plan.get("execution_precedence",{}).get(
            row["resource_id"]+"|"+row["h_uid"]+"|"+row["v_uid"])
        target_new=(row["h_uid"] in states and snapshot.states[row["h_uid"]].current_motion_plan.get("timed_resource_targets")
                    !=states[row["h_uid"]].current_motion_plan.get("timed_resource_targets"))
        v_new=(row["v_uid"] in states and snapshot.states[row["v_uid"]].current_motion_plan.get("resource_windows")
                    !=states[row["v_uid"]].current_motion_plan.get("resource_windows"))
        recovery=(not old and row["reason"] in {"H_STOP_UNREACHABLE_V_UNLAUNCHED","CURRENT_FORECAST_H_BEFORE_V","QUEUE_PREDECESSOR_BLOCKS_G"})
        if target_new or v_new or recovery:obligations.append(row)
    performance_metrics(obligation_relations=len(obligations))
    if not obligations:return {"prediction_only":True,"required":False,"reason":"NO_CHANGED_HV_HANDOFF"}
    initial={**getattr(snapshot,"resource_dependencies",{}),**snapshot.states,**states}
    store=TrafficStateStore(initial.values(),sim_time_s=snapshot.sim_time_s)
    store._version=snapshot.version
    audit=seed_actual_audit(store.final_snapshot(),config)
    dt=float(config["simulation"]["dt_s"]);start=snapshot.sim_time_s
    kwargs=dict(dt_s=dt,vertical_speed_mps=config["motion"]["vertical_speed_mps"],completion_z_m=50.,
        motion_limits_by_type=limits,resource_z=resource_z_bounds(network),mainline_crossings=mainline_crossing_stations(network),
        min_mainline_gap_m=config["motion"]["min_gap_m"],resource_safety=config["resource_safety"])
    from .conditional_feasibility_feedback import CPFFPolicy
    kwargs["cpff_policy"] = CPFFPolicy.from_config(config)
    events=[];steps=0
    # Keep the latest step records, including terminal participants, for this
    # private proof only. Completion does not require copying the entire store.
    continuation_states=dict(initial)
    duties=continuation_obligations(initial,obligations)
    performance_metrics(resource_obligations=len(duties),obligation_scope='LEGACY_FULL_V_CHAIN')
    while store.read_metadata()[1]<start+120.-1e-9:
        pending=pending_continuation_obligations(continuation_states,duties)
        lower,witness=continuation_completion_lower_bound(continuation_states,pending,store.read_metadata()[1],limits)
        if lower>start+120.+1e-9:
            performance_metrics(private_steps=steps,termination='UNKNOWN_LOWER_BOUND',
                pending_obligations=pending,lower_bound_witness=witness)
            error=HandoffRejected('HANDOFF_CONTINUATION_UNKNOWN_HORIZON_NO_PUBLICATION')
            error.diagnostics=dict(reason='STRICT_LOWER_BOUND_EXCEEDS_HORIZON',
                skipped_private_steps=max(0,int(round((start+120.-store.read_metadata()[1])/dt))),
                checked_until_s=store.read_metadata()[1],private_steps=steps,
                pending_obligations=pending,lower_bound_witness=witness,
                unexecuted_safety_checks=True,prediction_only=True)
            raise error
        with performance_span('continuation.step',private_step=steps,private_time_s=store.read_metadata()[1]):
            before=store.snapshot()
            try:
                step=execute_frozen_motion(before,**kwargs)
                commit_motion_step(store,before,step,audit,limits,return_snapshot=False,allow_gap_recovery=False)
            except (ValueError,RuntimeError) as error:
                raise HandoffRejected("HANDOFF_CONTINUATION_NOT_CERTIFIED:"+str(error)) from error
            events.extend({"event_type":e.event_type,"uav_id":e.uav_id,"resource_id":e.resource_id,"predicted_time_s":e.actual_time_s} for e in step.events)
            steps+=1
            continuation_states.update((state.uav_id,state) for state in step.states)
            if not pending_continuation_obligations(continuation_states,duties):
                performance_metrics(private_steps=steps,termination="PASS")
                return {"prediction_only":True,"required":True,"passed":True,"steps":steps,
                    "predicted_end_s":step.t_to,"predicted_event_chain":events,"motion_audit":audit.summary(),
                    "obligation_scope":"LEGACY_FULL_V_CHAIN","resource_obligations":duties}
    pending=pending_continuation_obligations(continuation_states,duties)
    performance_metrics(private_steps=steps,termination='UNKNOWN_HORIZON',pending_obligations=pending)
    error=HandoffRejected('HANDOFF_CONTINUATION_UNKNOWN_HORIZON_NO_PUBLICATION')
    error.diagnostics=dict(reason='HORIZON_EXHAUSTED',private_steps=steps,
        checked_until_s=store.read_metadata()[1],pending_obligations=pending,
        prediction_only=True,unexecuted_safety_checks=False)
    raise error


@measured("handoff.certify_publication")
def certify_publication(snapshot,updates,background_updates,waiting_updates,*,config,network,
                        cpff_enabled=False, execution_feedback=None,
                        e_anchor_execution=False):
    from .conditional_feasibility_feedback import CPFFPolicy
    from .simulation_state import TrafficSnapshot
    from .motion_executor import execute_frozen_motion,resource_z_bounds
    from .cmlpm_runtime_pipeline import motion_limits_from_config
    from .crossing_resource_mapping import mainline_crossing_stations
    limits=motion_limits_from_config(config)
    if e_anchor_execution:
        from .v5_thin_executor import bind_mainline_motion

        def bind(rows):
            bound = {}
            for uid, state in rows.items():
                plan = state.current_motion_plan
                payload = plan.get("v5_frozen_trajectory")
                if payload is not None and "mainline_pieces" not in payload:
                    try:
                        payload = bind_mainline_motion(
                            snapshot.states[uid], payload,
                            now_s=snapshot.sim_time_s, limits=limits[state.vehicle_type])
                    except ValueError as cause:
                        error = HandoffRejected(f"V5_MAINLINE_REALIZATION_REJECTED:{uid}:{cause}")
                        error.uav_id = uid
                        raise error from cause
                    state = replace(state, current_motion_plan={**plan, "v5_frozen_trajectory": payload})
                    if payload["flow"] == "V":
                        planned = {rid: (enter, exit_) for rid, enter, exit_ in plan["resource_windows"]}
                        realized = {rid: (enter, exit_) for rid, enter, exit_ in payload["resource_events"]}
                        if not planned.keys() <= realized.keys() or any(
                            abs(a-b) > 1e-6 for rid in planned
                            for a, b in zip(planned[rid], realized[rid])
                        ):
                            raise HandoffRejected(f"V5_DESCENT_RESOURCE_TIMING_MISMATCH:{uid}")
                bound[uid] = state
            return bound

        updates, background_updates = bind(updates), bind(background_updates)
    proposed={**background_updates,**updates,**waiting_updates}
    merged={**snapshot.states,**proposed}
    candidate=TrafficSnapshot(snapshot.version,snapshot.sim_time_s,merged,getattr(snapshot,"resource_dependencies",{}))
    # A new H resource grant starts a new nominal approach only after the old
    # resource obligations have actually finished. Unowned queue forecasts
    # must not override the newly selected resource entry/exit conditions.
    background_updates=dict(background_updates)
    for uid,state in background_updates.items():
        old=snapshot.states[uid].current_motion_plan
        plan=state.current_motion_plan
        exits={str(e.get("resource_id")) for e in old.get("motion_observed_events",())
               if e["event_type"]=="RESOURCE_EXIT"}
        old_targets=old.get("timed_resource_targets",())
        if (plan.get("timed_resource_targets")!=old_targets
                and plan.get("timed_resource_targets")
                and all(str(t["resource_id"]) in exits for t in old_targets)):
            fresh=dict(plan)
            for key in ("local_trajectory_reference","local_trajectory_id","local_certification_id"):
                fresh.pop(key,None)
            fresh.pop('cpff_execution',None)
            background_updates[uid]=replace(state,current_motion_plan=fresh)
    proposed={**background_updates,**updates,**waiting_updates}
    if cpff_enabled:
        from .conditional_feasibility_feedback import bind_release_conditions
        bound=bind_release_conditions(snapshot,proposed,limits=limits,config=config)
        updates={u:bound[u] for u in updates}
        background_updates={u:bound[u] for u in background_updates}
        waiting_updates={u:bound[u] for u in waiting_updates}
        proposed=bound
    merged={**snapshot.states,**proposed}
    candidate=TrafficSnapshot(snapshot.version,snapshot.sim_time_s,merged,getattr(snapshot,"resource_dependencies",{}))
    decision_ids=set(updates)|set(waiting_updates)|{
        uid for uid,state in background_updates.items()
        if state.current_motion_plan.get('timed_resource_targets')!=
           snapshot.states[uid].current_motion_plan.get('timed_resource_targets')}
    # E-anchor V5 already contains the immutable sampled E->J->P trajectory
    # produced from C-MLPM's E time and resource windows.  The historical LTG/
    # JEC bundle is a second trajectory authority (and still carries the old
    # G/J waiting-stop assumptions), so it must not gate this publication.
    # Keep the legacy bundle path for non-E-anchor callers only.
    bundle = None
    if not e_anchor_execution:
        from .local_trajectory_certification import generate_and_certify
        bundle=generate_and_certify(candidate,limits,config,
            next((s.current_motion_plan.get("schedule_round_id") for s in updates.values()),"H_ONLY"),
            execution_feedback=execution_feedback,decision_ids=decision_ids)
        if bundle["certification_status"]!="PASS":
            error=HandoffRejected("LTG_JEC_UNAVAILABLE:"+bundle["reason"])
            error.diagnostics=bundle.get("diagnostics",{})
            raise error
    # Attach references only to the states participating in this publication.
    # Existing frozen states remain read-only dependencies.
    def attach(rows):
        return {uid:replace(state,current_motion_plan={
            **state.current_motion_plan,
            "local_trajectory_reference":bundle["trajectories"][uid],
            "local_trajectory_id":bundle["trajectory_id"],
            "local_certification_id":bundle["certification_id"],
            "runtime_reference_status":"VALID",
        }) if uid in decision_ids and uid in bundle["trajectories"] and uid not in bundle.get("inherited_references",{})
            else state for uid,state in rows.items()}
    if not e_anchor_execution:
        updates=attach(updates)
        background_updates=attach(background_updates)
        waiting_updates=attach(waiting_updates)
    proposed={**background_updates,**updates,**waiting_updates}
    merged={**snapshot.states,**proposed}
    candidate=TrafficSnapshot(snapshot.version,snapshot.sim_time_s,merged,getattr(snapshot,"resource_dependencies",{}))
    resource_z = resource_z_bounds(network)
    crossings = mainline_crossing_stations(network)
    v5_kwargs = {}
    if e_anchor_execution:
        from .v5_thin_executor import v5_waiting_boundaries
        v5_kwargs["v5_waiting_by_route"] = v5_waiting_boundaries(network)
    def advance(state, dt_s):
        try:
            return execute_frozen_motion(state,dt_s=dt_s,
                vertical_speed_mps=config["motion"]["vertical_speed_mps"],completion_z_m=50.,
                motion_limits_by_type=limits,resource_z=resource_z,mainline_crossings=crossings,
                min_mainline_gap_m=config["motion"]["min_gap_m"],resource_safety=config["resource_safety"],
                cpff_policy=CPFFPolicy.from_config(config) if cpff_enabled else CPFFPolicy(False, False),
                e_anchor_execution=e_anchor_execution,
                v5_thin_executor=e_anchor_execution, **v5_kwargs)
        except HandoffRejected:
            raise
        except (ValueError,RuntimeError) as error:
            raise HandoffRejected("HANDOFF_JOINT_MOTION_INFEASIBLE:"+str(error)) from error
    dt_s = float(config["simulation"]["dt_s"])
    step=advance(candidate, dt_s)
    audit=seed_actual_audit(snapshot,config);trial=trial_motion_audit(audit,candidate,step,limits)
    if e_anchor_execution:
        boundaries = [
            payload["boundary_times"]["P" if payload["flow"] == "V" else "R"]
            for uid in decision_ids
            if (payload := proposed[uid].current_motion_plan.get("v5_frozen_trajectory"))
        ]
        horizon = max(boundaries, default=step.t_to)
        preview = step
        while preview.t_to < horizon - 1e-9:
            current = TrafficSnapshot(
                snapshot.version, preview.t_to, {row.uav_id: row for row in preview.states},
                candidate.resource_dependencies)
            preview = advance(current, min(dt_s, horizon - current.sim_time_s))
            trial = trial_motion_audit(trial, current, preview, limits)
    records={s.uav_id:s.current_motion_plan.get("execution_precedence",{}) for s in step.states}
    # Only the certified relation is materialized; simulated positions/events
    # are candidate evidence and must never enter a scheduling publication.
    changes={}
    for uid,relations in records.items():
        if not relations or relations==merged[uid].current_motion_plan.get("execution_precedence",{}):continue
        changes[uid]=replace(merged[uid],current_motion_plan={**merged[uid].current_motion_plan,"execution_precedence":relations})
    updated=dict(updates);background=dict(background_updates);waiting=dict(waiting_updates)
    for uid,state in changes.items():
        if uid in updated:updated[uid]=state
        elif uid in waiting:waiting[uid]=state
        else:background[uid]=state
    # Precedence observation can add a dependency to the publication after the
    # initial partitions were assembled. Bind its reference in the final set.
    if not e_anchor_execution:
        updated=attach(updated)
        background=attach(background)
        waiting=attach(waiting)
    proposed={**background,**updated,**waiting}
    relations=tuple(row for uid in sorted(records) for row in records[uid].values() if row["h_uid"]==uid)
    continuation=(
        {"prediction_only": True, "required": True,
         "audited_through_s": max(step.t_to, horizon),
         "reason": "E_ANCHOR_CONTINUOUS_APPROACH_AUDIT"}
        if e_anchor_execution else
        prove_handoff_continuation(snapshot,proposed,relations,config=config,network=network,limits=limits)
    )
    from .following_time import physical_lane
    lanes={}
    for s in snapshot.states.values():
        if s.uav_id in step.mainline_profiles:lanes.setdefault(physical_lane(s),[]).append(s)
    adjacency=[]
    for group in lanes.values():
        ordered=sorted(group,key=lambda s:(-s.s_m,s.uav_id))
        adjacency.extend({"front":a.uav_id,"rear":b.uav_id,"input_gap_m":a.s_m-b.s_m} for a,b in zip(ordered,ordered[1:]))
    summary={**trial.summary(),"local_trajectory_bundle":bundle,
             "publication_uav_ids":sorted(proposed),
             "continuation":continuation,"local_following_adjacency":adjacency,
             "profile_uav_ids":sorted(step.mainline_profiles),
             "input_actual_resource_occupancy":{rid:[dict(use) for use in uses if use["exit_s"] is None
                 or use["exit_s"]+max(SHARED_RESOURCE_ENTRY_HEADWAY_S,float(config["resource_safety"]["vh_v_to_h_margin_s"]),
                    float(config["resource_safety"]["vh_h_to_v_margin_s"]))>snapshot.sim_time_s-1e-9]
                 for rid,uses in audit.uses.items()}}
    certificate=HandoffCertificate(snapshot.version,state_digest(proposed),True,relations,summary)
    return updated,background,waiting,certificate


def verify_publication_certificate(snapshot_version,proposed,certificate):
    if certificate is None:raise HandoffRejected("HANDOFF_CERTIFICATE_MISSING")
    if not certificate.passed:raise HandoffRejected("HANDOFF_CERTIFICATE_REJECTED")
    if certificate.input_version!=snapshot_version:raise HandoffRejected("HANDOFF_CERTIFICATE_STALE")
    if state_digest(proposed)!=certificate.proposed_sha256:raise HandoffRejected("HANDOFF_CANDIDATE_CHANGED_AFTER_CERTIFICATION")
    bundle=certificate.motion_summary.get("local_trajectory_bundle")
    if bundle is not None:
        from .local_trajectory_certification import verify_bundle
        verify_bundle(bundle,proposed,snapshot_version)
    elif any(state.current_motion_plan.get("local_trajectory_id") for state in proposed.values()):
        raise HandoffRejected("LTG_PUBLICATION_PROOF_MISSING")


def requires_handoff(existing,proposed):
    merged={**existing,**proposed};vertical={}
    for s in merged.values():
        if s.state.value in {"COMPLETED","EXITED","HORIZON_CENSORED"}:continue
        for rid,_,_ in s.current_motion_plan.get("resource_windows",()):vertical.setdefault(str(rid),set()).add(s.uav_id)
    for s in proposed.values():
        for t in s.current_motion_plan.get("timed_resource_targets",()):
            for v_uid in vertical.get(str(t["resource_id"]),set())-{s.uav_id}:
                v = merged.get(v_uid)
                if v is None:
                    return True
                from .resource_conflict_classification import is_cross_layer_vh_pair
                if is_cross_layer_vh_pair(s, v):
                    return True
    return False


@measured("motion.atomic_commit")
def commit_motion_step(store,before,step,audit,limits,*,return_snapshot=True,allow_gap_recovery=True,
                       v5_audit_retries=None):
    trial=trial_motion_audit(audit,before,step,limits,allow_gap_recovery=allow_gap_recovery)
    # This CAS also verifies unchanged assignments, frozen plans and immutable
    # observed prefixes. A rejected CAS leaves both audit and actual facts old.
    kwargs = {"v5_audit_retries": v5_audit_retries} if v5_audit_retries else {}
    store.replace_states(step.states,expected_version=before.version,sim_time_s=step.t_to,
                         return_snapshot=False, **kwargs)
    path=audit.path;pending=list(trial._pending)
    audit.__dict__.update(trial.__dict__);audit.path=path
    if path is not None and pending:
        with path.open("a",encoding="utf8") as stream:
            for row in pending:stream.write(json.dumps(row,ensure_ascii=False)+"\n")
    return store.snapshot() if return_snapshot else None
