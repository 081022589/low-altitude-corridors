"""Sole measured mainline and G-to-J executor for closed-loop experiments.

The mainline reaches G continuously. At G, the measured speed generates the
transfer trajectory; J and resource events are measured from that trajectory.

What changes relative to ``_advance_mainline``:

* no joint verification, no witness certificate, no LP -- the speed is the
  minimum of the piecewise following cap, the stop boundary and the deadline law;
* a late G is recorded instead of raising ``FROZEN_G_TIME_NOT_REALIZED``, and
  the G event is emitted either way;
* the physical trajectory is one piecewise ``Profile``, so positions, speeds
  and the G crossing all come from the same curve.

Types are the production ones (``UAVState`` / ``ExecutedEvent`` / ``MotionStep``),
so this is a drop-in body, not a parallel system.
"""

from __future__ import annotations

import math
from dataclasses import asdict, replace
from typing import Any, Mapping

from .existing_v_continuation import ExecutedEvent, current_v_resource_windows
from .motion_executor import (
    MotionExecutionBlocked,
    MotionStep,
    _advance_descent,
    _advance_transfer,
    _is_pending_wait,
    _mainline_crossing_events,
    _sequence_index,
    _TERMINAL,
    _TIME_TOL,
)
from .numeric_motion import MotionLimits, MotionPiece, TickProfile, stop_start_limits
from .descent_trajectory import realize_descent_at_g, trajectory_resource_windows
from .simulation_state import FlightState, TrafficSnapshot, UAVState
from .trigger_rules import commit_distance_m

from experiments.kinematic_layer_v1.kinematic_advance import (
    Aircraft,
    Limits,
    Leader,
    Piece,
    Profile,
    ProfileEntryGuard,
    Slot,
    ResourceEntryLimit,
    Deviation,
    build_profile,
    stop_satisfied,
    resource_entry_satisfied,
    terminal_slot_profile,
    advance,
)


def _to_limits(limits: MotionLimits) -> Limits:
    return Limits(
        v_min=float(limits.min_speed_mps),
        v_max=float(limits.max_speed_mps),
        a_max=float(limits.max_abs_acceleration_mps2),
    )


def _to_aircraft(state: UAVState, limits: Limits) -> Aircraft:
    nominal = state.nominal_speed_mps
    return Aircraft(
        uid=state.uav_id,
        s=float(state.s_m),
        v=float(state.speed_mps),
        nominal=float(nominal if nominal is not None else limits.v_max),
        limits=limits,
    )


def _to_tick_profile(profile: Profile) -> TickProfile:
    """Adapter so consumers of ``mainline_profiles`` keep working."""
    pieces = tuple(
        MotionPiece(piece.start_s, piece.end_s, piece.s0, piece.v0, piece.a)
        for piece in profile.pieces
    )
    return TickProfile(pieces, profile.duration_s)


def _frozen_slot(state: UAVState) -> Slot | None:
    plan = state.current_motion_plan
    if plan.get("execution_mode")=="CMLPM_RETRY_HOLD":
        return None
    g_time = plan.get("g_time_s")
    g_station = plan.get("g_station_m")
    if g_time is None or g_station is None:
        observed = {(e["event_type"],str(e.get("resource_id")))
                    for e in plan.get("motion_observed_events",())}
        targets=[]
        for target in plan.get("timed_resource_targets",()):
            rid=str(target["resource_id"])
            for event,time_key,station_key in (("RESOURCE_ENTER","entry_time_s","entry_station_m"),
                                               ("RESOURCE_EXIT","exit_time_s","exit_station_m")):
                if (event,rid) not in observed and float(target[station_key]) >= state.s_m-1e-8:
                    targets.append((float(target[station_key]),float(target[time_key])))
        if not targets:
            return None
        station,moment=min(targets)
        return Slot(t_g=moment,s_g=station,v_g=None)
    return Slot(
        t_g=float(g_time),
        s_g=float(g_station),
        v_g=float(plan["terminal_speed_mps"]) if plan.get("enforce_g_terminal_state") else None,
    )


def _is_v_frozen_plan(plan: Mapping[str, Any]) -> bool:
    """Identify V plans without treating an H resource schedule as V.

    V5 H publications intentionally omit top-level G timing/geometry fields.
    Their immutable trajectory payload still carries the flow discriminator;
    legacy V plans are recognized from their resource-window/G fields.
    """
    if plan.get("schedule_result") != "RELEASED":
        return False
    payload = plan.get("v5_frozen_trajectory") or plan.get("v4_frozen_trajectory") or {}
    flow = str(plan.get("flow") or payload.get("flow") or "").upper()
    if flow:
        return flow == "V"
    return bool(plan.get("resource_windows")) and plan.get("g_station_m") is not None


def _scheduled_stop_station(state: UAVState, slot: Slot | None) -> float | None:
    """A permitted aircraft runs to G; an unpermitted one holds at D_commit.

    The registered stopping line applies while the aircraft awaits release.
    """
    plan = state.current_motion_plan
    if plan.get("execution_mode")=="CMLPM_RETRY_HOLD":
        return float(state.s_m)
    pending = plan.get("pending_hold") or {}
    # E-anchor production plans do not authorize a G stop.  ``g_station_m``
    # may still exist as a derived compatibility field, but the physical
    # release boundary is the shared-resource entrance E.
    anchor_station = (plan.get("resource_entry_station_m")
                      if plan.get("descent_template_origin") == "E"
                      else plan.get("g_station_m"))
    released = plan.get("schedule_result") == "RELEASED"

    if not released and state.commit_status == "COMMITTED" and anchor_station is not None:
        return float(anchor_station) - commit_distance_m(state.vehicle_type)
    if slot is not None:
        return None
    if released:
        # Released traffic is governed by the measured leader/resource
        # constraints, not by the frozen G deadline.  There is no artificial
        # stop at the current position when the deadline hint is omitted.
        return None
    if pending.get("reason") == "FROZEN_V_RESOURCE_GUARD":
        return None
    if pending.get("stop_station_m") is not None:
        return float(pending["stop_station_m"])
    if anchor_station is not None:
        return float(anchor_station) - commit_distance_m(state.vehicle_type)
    if _is_pending_wait(state):
        # Assigned but not yet permitted: hold where it is. Without this the
        # aircraft cruises on and closes the gap to whatever is ahead, which is
        # what the old admission certification used to prevent via
        # ``pending_hold``.
        return float(state.s_m)
    return None


def _stop_station(
    state: UAVState, slot: Slot | None,
    entry_limits: tuple[ResourceEntryLimit, ...] = (),
    *, now_s: float | None = None,
) -> float | None:
    """Resource safety applies even when a published slot already exists."""
    stops = [
        limit.stop_station_m
        for limit in entry_limits
        if not limit.exit_confirmed
        or now_s is None
        or float(limit.not_before_s) > float(now_s) + _TIME_TOL
    ]
    scheduled = _scheduled_stop_station(state, slot)
    if scheduled is not None:
        stops.append(scheduled)
    return min(stops) if stops else None


def build_h_resource_entry_limits(
    snapshot: TrafficSnapshot, *,
    executed_by_uav: Mapping[str, tuple[ExecutedEvent, ...]],
    vh_v_to_h_margin_s: float,
    mainline_crossings=None, precedence=None, motion_limits_by_type=None,
) -> dict[str, tuple[ResourceEntryLimit, ...]]:
    """Consume the same execution relation as the V full-chain guard."""
    from .execution_precedence import build_execution_precedence
    if precedence is None:
        precedence=build_execution_precedence(snapshot,prior=executed_by_uav,
            mainline_crossings=mainline_crossings,motion_limits_by_type=motion_limits_by_type)
    result={}
    from traffic_simulation.cmlpm.joint_single_node.conflict_builder import SHARED_RESOURCE_ENTRY_HEADWAY_S
    for relation in precedence:
        if relation.order!="V_FIRST" or relation.h_actual_entry_s is not None:continue
        confirmed=relation.v_actual_exit_s is not None
        exit_=relation.v_actual_exit_s if confirmed else relation.v_predicted_exit_s
        enter=relation.v_actual_entry_s if relation.v_actual_entry_s is not None else relation.v_predicted_entry_s
        not_before=max(exit_+vh_v_to_h_margin_s,enter+SHARED_RESOURCE_ENTRY_HEADWAY_S)
        if confirmed and not_before<=snapshot.sim_time_s+1e-9:continue
        result.setdefault(relation.h_uid,[]).append(ResourceEntryLimit(relation.resource_id,
            relation.h_entry_station_m,not_before,confirmed,(relation.v_uid,)))
    return {uid:tuple(sorted(rows,key=lambda r:(r.station_m,r.resource_id))) for uid,rows in result.items()}


def build_v_resource_entry_limits(
    snapshot: TrafficSnapshot, *,
    executed_by_uav: Mapping[str, tuple[ExecutedEvent, ...]],
    vv_min_entry_headway_s: float,
) -> dict[str, tuple[ResourceEntryLimit, ...]]:
    """Build the minimal V-V resource gate used by traffic-mode execution.

    The full-chain forecast guard is intentionally not used in the synthetic
    traffic experiments.  A shared descent resource still needs one physical
    invariant: a V may not reach its first resource until the preceding V has
    actually cleared it (or its registered exit time plus the V-V headway has
    elapsed).  This gate is a single spatial stop at G, not a trajectory
    certificate and not a deadline controller.
    """
    by_resource: dict[str, list[tuple[UAVState, float, float]]] = {}
    for state in snapshot.states.values():
        windows = state.current_motion_plan.get("resource_windows", ())
        if not windows or state.state in _TERMINAL:
            continue
        for resource_id, enter, exit_ in windows:
            by_resource.setdefault(str(resource_id), []).append(
                (state, float(enter), float(exit_))
            )

    result: dict[str, list[ResourceEntryLimit]] = {}
    headway = float(vv_min_entry_headway_s)
    for resource_id, rows in by_resource.items():
        rows.sort(key=lambda row: (row[1], row[0].uav_id))
        for index, (previous, _previous_enter, previous_exit) in enumerate(rows[:-1]):
            previous_events = executed_by_uav.get(previous.uav_id, ())
            previous_enter_actual = next(
                (event.actual_time_s for event in previous_events
                 if event.resource_id == resource_id and event.event_type == "RESOURCE_ENTER"),
                None,
            )
            previous_exit_actual = next(
                (event.actual_time_s for event in previous_events
                 if event.resource_id == resource_id and event.event_type == "RESOURCE_EXIT"),
                None,
            )
            # Only the immediate predecessor matters for this resource; later
            # predecessors inherit the same ordering.
            current, _current_enter, _current_exit = rows[index + 1]
            if current.state in _TERMINAL or current.state in {
                FlightState.TRANSITION,
                FlightState.VERTICAL,
                FlightState.SERVICING,
                FlightState.REENTRY_HOLD,
                FlightState.REENTRY_CLIMB,
            }:
                continue
            current_plan = current.current_motion_plan
            station = (current_plan.get("resource_entry_station_m")
                       if current_plan.get("descent_template_origin") == "E"
                       else current_plan.get("g_station_m"))
            if station is None or current_plan.get("schedule_result") != "RELEASED":
                continue
            current_events = executed_by_uav.get(current.uav_id, ())
            if any(event.resource_id == resource_id and event.event_type == "RESOURCE_ENTER"
                   for event in current_events):
                continue
            if previous_exit_actual is not None:
                not_before = max(
                    previous_exit_actual + headway,
                    (previous_enter_actual + headway
                     if previous_enter_actual is not None else float("-inf")),
                )
                confirmed = True
            else:
                # Until the actual exit is observed, preserve stopping
                # capability at G. The planned exit is only a diagnostic
                # lower bound; it never authorizes crossing by itself.
                not_before = previous_exit + headway
                confirmed = False
            result.setdefault(current.uav_id, []).append(
                ResourceEntryLimit(
                    resource_id,
                    float(station),
                    float(not_before),
                    confirmed,
                    (previous.uav_id,),
                )
            )
    return {
        uid: tuple(sorted(rows, key=lambda row: (row.station_m, row.resource_id)))
        for uid, rows in result.items()
    }


def _physical_h_crossings(state,crossings):
    """Physical straight crossings before any committed descent G."""
    if state.state in _TERMINAL or state.state in {FlightState.TRANSITION,FlightState.VERTICAL}:
        return ()
    plan=state.current_motion_plan
    anchor = (plan.get("resource_entry_station_m")
              if plan.get("descent_template_origin") == "E"
              else plan.get("g_station_m"))
    g=(float(anchor) if _is_v_frozen_plan(plan) and anchor is not None else math.inf)
    return tuple((str(r),float(a),float(b)) for r,a,b in crossings.get((state.direction,state.layer),())
                 if float(a)<g-_TIME_TOL and float(b)>=state.s_m-_TIME_TOL)


def _profile_interval(profile: Profile, start: float, end: float) -> Profile:
    """Return a profile interval with its clock reset to zero."""
    if end <= start + _TIME_TOL:
        position, speed = profile.state_at(start)
        return Profile((Piece(0.0, 0.0, position, speed, 0.0),), 0.0)
    pieces = []
    for piece in profile.pieces:
        left = max(start, piece.start_s)
        right = min(end, piece.end_s)
        if right <= left:
            continue
        position, speed = piece.state_at(left)
        pieces.append(Piece(left - start, right - start, position, speed, piece.a))
    return Profile(tuple(pieces), end - start)


def _v_chain_guard(state, current, now, states, prior, safety, limits, vertical_speed, completion_z,
                   mainline_crossings=None,motion_limits_by_type=None,step_duration=.5,execution_precedence=None,
                   feedback_channels=None):
    """A local G-release predicate, rebuilt on every observed motion step.

    Before losing the ability to stop at G, a bounded continuation must clear
    every resource in the chain using its actual candidate G speed. Already
    realised predecessors have deterministic remaining paths; an unlaunched
    predecessor or an uncleared preceding H keeps the gate closed.
    """
    plan=state.current_motion_plan
    if plan.get('schedule_result')!='RELEASED':return None
    station=float(plan['g_station_m']);vv=float(safety.get('vv_min_entry_headway_s',2.5))
    vh=float(safety.get('vh_h_to_v_margin_s',.5))
    own={str(r):(float(a),float(b)) for r,a,b in plan.get('resource_windows',())}
    if execution_precedence is None:
        from .execution_precedence import build_execution_precedence
        by_uid={s.uav_id:s for s in states};history=dict(prior)
        by_uid[state.uav_id]=replace(state,s_m=current.s,speed_mps=current.v)
        for s in states:
            known={e.event_id for e in history.get(s.uav_id,())}
            history[s.uav_id]=tuple(history.get(s.uav_id,()))+tuple(ExecutedEvent(**e)
                for e in s.current_motion_plan.get("motion_observed_events",()) if e["event_id"] not in known)
        execution_precedence=build_execution_precedence(TrafficSnapshot(0,now,by_uid),prior=history,
            mainline_crossings=mainline_crossings,motion_limits_by_type=motion_limits_by_type,resource_safety=safety)
    required={r:[] for r in own};unknown=False
    for other in states:
        if feedback_channels is not None and not feedback_channels.vv:
            break
        if other.uav_id==state.uav_id:continue
        op=other.current_motion_plan;events=prior.get(other.uav_id,())
        enters={str(e.resource_id):e.actual_time_s for e in events if e.event_type=='RESOURCE_ENTER'}
        exits={str(e.resource_id):e.actual_time_s for e in events if e.event_type=='RESOURCE_EXIT'}
        if op.get('resource_windows'):
            original={str(r):(a,b) for r,a,b in op['resource_windows']}
            forecast=op.get('realized_resource_windows')
            for r,(a,b) in original.items():
                if r not in own:continue
                if a>=own[r][0]-_TIME_TOL and forecast is None and r not in enters:continue
                if r in enters:required[r].append(enters[r]+vv)
                elif forecast is not None:required[r].append(float(forecast[r][0])+vv)
                else:unknown=True
    from traffic_simulation.cmlpm.joint_single_node.conflict_builder import SHARED_RESOURCE_ENTRY_HEADWAY_S
    for relation in execution_precedence:
        if feedback_channels is not None and not feedback_channels.vh:
            break
        if relation.v_uid!=state.uav_id or relation.order!="H_FIRST":continue
        if relation.resource_id not in required:continue
        if relation.h_actual_exit_s is None:
            unknown=True
        else:
            required[relation.resource_id].append(max(relation.h_actual_exit_s+vh,
                relation.h_actual_entry_s+SHARED_RESOURCE_ENTRY_HEADWAY_S))
    cache={}
    if (feedback_channels is not None and not unknown
            and not any(bound > now+_TIME_TOL for bounds in required.values() for bound in bounds)):
        return None
    def permitted(profile,command):
        # A forecast is not a release for a later motion step: a new frozen H
        # can appear before that step. Keep the braking fallback until this
        # very profile crosses G and its measured G speed clears the chain.
        stop_line=station-1e-6
        if stop_satisfied(profile,current,stop_line):
            position,speed=profile.end
            if command==0. or position+speed*speed/(2*current.limits.a_max)<=stop_line-1e-6:
                return True
        crosses_now=profile.crossing(station)
        can_stop_now=current.s+current.v*current.v/(2*current.limits.a_max)<=stop_line+1e-9
        if crosses_now is None and can_stop_now:return False
        if unknown:return False
        # An imported historical snapshot may already lack stopping distance
        # (the original 770 s case). Preserve bounded recovery and report any
        # failure; never move it backwards or pretend it can stop.
        horizon=current.v/current.limits.a_max+max(0.,station-current.s)/max(command,.1)+2.
        continuation=(profile if crosses_now is not None else
                      build_profile(current,command,max(profile.duration_s,horizon)))
        tau=continuation.crossing(station)
        if tau is None:return False
        speed=continuation.state_at(tau)[1]
        if speed not in cache:
            if plan.get("descent_template_origin") == "E":
                # E-origin (B design): the E->J->P template is frozen and
                # independent of the candidate crossing speed.
                origin_time = float(plan["e_time_s"])
                cache[speed] = {
                    str(resource): (float(enter) - origin_time, float(exit_) - origin_time)
                    for resource, enter, exit_ in plan.get("resource_windows", ())
                }
            elif plan.get("v4_frozen_trajectory") is not None:
                g_time = float(plan["g_time_s"])
                cache[speed] = {
                    str(resource): (float(enter) - g_time, float(exit_) - g_time)
                    for resource, enter, exit_ in plan.get("resource_windows", ())
                }
            else:
                try:
                    trajectory=realize_descent_at_g(plan,entry_speed_mps=speed,vertical_speed_mps=vertical_speed,
                        completion_z_m=completion_z,max_speed_mps=limits.max_speed_mps,
                        max_acceleration_mps2=limits.max_abs_acceleration_mps2,vehicle_type=state.vehicle_type)
                    cache[speed]=trajectory_resource_windows(trajectory)
                except ValueError:cache[speed]=None
        windows=cache[speed]
        return windows is not None and all(now+tau+windows[r][0]>=max(bounds)-_TIME_TOL
            for r,bounds in required.items() if bounds)
    return ProfileEntryGuard(station-1e-6,permitted)


def _mainline_pass(
    states: list[UAVState],
    *,
    t_from: float,
    dt_s: float,
    motion_limits_by_type: Mapping[str, MotionLimits],
    min_gap_m: float,
    entry_limits_by_uav: Mapping[str, tuple[ResourceEntryLimit, ...]] | None = None,
    all_states=(), prior=None, resource_safety=None, vertical_speed_mps=3., completion_z_m=50.,mainline_crossings=None,execution_precedence=(),
    enforce_schedule_timing: bool = True,
    cpff_policy=None,
    anomaly_policy=None,
    e_anchor_execution: bool = False,
) -> tuple[dict[str, tuple[Profile, Aircraft, tuple, tuple[str, str]]], list]:
    """Advance the mainline front to back, each using its leader's profile."""
    limits_by_uid = {}
    for state in states:
        limits = motion_limits_by_type.get(state.vehicle_type)
        if limits is None:
            raise MotionExecutionBlocked("MAINLINE_MOTION_LIMITS_MISSING", state.vehicle_type)
        effective = stop_start_limits(state, limits)
        # Following, waiting and target execution may brake to zero and restart.
        effective = replace(effective,min_speed_mps=0.)
        limits_by_uid[state.uav_id] = _to_limits(effective)

    # Group by the registered physical lane first, then order by station
    # inside the lane. A global station sort mixes lanes whose station origins
    # are unrelated, so the "previous" aircraft is not the real leader.
    from .following_time import physical_lane

    results: dict[str, tuple[Profile, Aircraft, tuple, tuple[str, str]]] = {}
    edges: list[tuple[str, str]] = []
    ahead_in_lane: dict[tuple[str, str, str], list[tuple[UAVState, Profile]]] = {}

    for state in sorted(states, key=lambda item: (-item.s_m, item.uav_id)):
        lane = physical_lane(state)
        predecessors = ahead_in_lane.setdefault(lane, [])
        limits = limits_by_uid[state.uav_id]
        aircraft = _to_aircraft(state, limits)
        # Keep the published slot object for release/stopping semantics.  The
        # traffic experiment can disable only its deadline law while retaining
        # all hard leader/resource constraints.
        slot = _frozen_slot(state)
        entry_limits = (entry_limits_by_uav or {}).get(state.uav_id, ())
        if entry_limits:
            first = entry_limits[0]
            if slot is None or (slot.v_g is None and first.station_m <= slot.s_g):
                # A transient execution intent, not a new published slot.
                slot = Slot(first.not_before_s, first.station_m)
        stop = _stop_station(state, slot, entry_limits, now_s=t_from)
        e_origin = (state.current_motion_plan.get("descent_template_origin") == "E"
                    and state.current_motion_plan.get("schedule_result") == "RELEASED")
        g_station = ((state.current_motion_plan.get("resource_entry_station_m")
                      if e_origin else state.current_motion_plan.get("g_station_m"))
                     if state.current_motion_plan.get("schedule_result")=="RELEASED" else None)
        pieces: list[Piece] = []
        all_notes = []
        elapsed = 0.0
        current = aircraft
        # A positive caller-supplied substep must have a nonempty profile,
        # including a residual interval below the ordinary time tolerance.
        while elapsed < dt_s - _TIME_TOL or not pieces:
            # A predecessor stops being a mainline leader at its own G. The
            # next aircraft farther ahead takes over for the rest of this step.
            ahead = next(
                ((other, motion) for other, motion in reversed(predecessors)
                 if motion.duration_s > elapsed + _TIME_TOL),
                None,
            )
            segment_end = min(dt_s, ahead[1].duration_s) if ahead else dt_s
            segment_dt = segment_end - elapsed
            leader = None
            leader_profile = None
            if ahead is not None:
                position, speed = ahead[1].state_at(elapsed)
                leader = Leader(position, speed, limits_by_uid[ahead[0].uav_id].a_max)
                leader_profile = _profile_interval(ahead[1], elapsed, segment_end)

            reference = state.current_motion_plan.get("local_trajectory_reference")
            if state.current_motion_plan.get("runtime_reference_status")=="DEVIATED":
                reference = None
            if reference and t_from+elapsed >= reference["start_time_s"]+reference["duration_s"]-1e-8:
                reference = None
            feedback_guard = None
            is_v = _is_v_frozen_plan(state.current_motion_plan)
            if is_v:
                channel_guard = None
                hard_guard = None
                if not e_anchor_execution:
                    channel_guard = _v_chain_guard(
                        state, current, t_from+elapsed, all_states, prior or {}, resource_safety or {},
                        motion_limits_by_type[state.vehicle_type], vertical_speed_mps, completion_z_m,
                        mainline_crossings, motion_limits_by_type, segment_dt, execution_precedence,
                        feedback_channels=cpff_policy,
                    )
                    hard_guard = _v_chain_guard(
                        state, current, t_from+elapsed, all_states, prior or {}, resource_safety or {},
                        motion_limits_by_type[state.vehicle_type], vertical_speed_mps, completion_z_m,
                        mainline_crossings, motion_limits_by_type, segment_dt, execution_precedence,
                    )
                def feedback_guard(profile, command):
                    if channel_guard is not None and not channel_guard(profile, command):
                        return False
                    # Preserve a reachable stop after every candidate step,
                    # including when an ablation disables CPFF anticipation.
                    return hard_guard is None or hard_guard(profile, command)
                guards = tuple(guard for guard in (channel_guard, hard_guard) if guard is not None)
                if guards:
                    # Preserve the stopping envelope for candidate generation;
                    # every candidate still passes both original predicates.
                    feedback_guard = ProfileEntryGuard(
                        min(guard.stop_station_m for guard in guards), feedback_guard,
                    )
                else:
                    feedback_guard = None
            # References are immutable scheduling evidence. A reactive intent
            # may depart from them without clearing or rewriting that evidence.
            record_recovery = bool(anomaly_policy and anomaly_policy.enabled) and not e_anchor_execution
            reactive = state.current_motion_plan.get("runtime_reference_status") == "DEVIATED"
            reference_failure = None
            if state.current_motion_plan.get("execution_mode")=="CMLPM_RETRY_HOLD":
                chunk = build_profile(current,0.,segment_dt)
                gap_failed = leader_profile is not None and chunk.min_gap_with(leader_profile)<min_gap_m-1e-6
                if not stop_satisfied(chunk,current,stop) or (gap_failed and not record_recovery):
                    raise MotionExecutionBlocked("CMLPM_RETRY_HOLD_BRAKING_UNAVAILABLE",state.uav_id)
                notes = ((Deviation(state.uav_id,"CONTINUOUS_GAP_VIOLATION","VIOLATION",
                          note="bounded braking while recovering a measured gap"),) if gap_failed else ())
            elif not reactive and (reference or (slot is not None and slot.v_g is not None)):
                now = t_from + elapsed
                try:
                    if reference:
                        from .local_trajectory_certification import reference_interval
                        chunk = reference_interval(reference,replace(state,s_m=current.s,speed_mps=current.v),
                                                   now,segment_dt)
                    else:
                        chunk = terminal_slot_profile(current, slot, now, segment_dt)
                except ValueError as error:
                    reference_failure = str(error)
                    chunk = None
                if chunk is not None and ((leader_profile is not None and chunk.min_gap_with(leader_profile) < min_gap_m-1e-6)
                        or not stop_satisfied(chunk, current, stop)
                        or any(not resource_entry_satisfied(chunk, current, limit, now)
                               for limit in entry_limits)):
                    reference_failure = "G_TERMINAL_STATE_SAFETY_BLOCKED"
                leader_leaves = bool(ahead is not None
                    and _is_v_frozen_plan(ahead[0].current_motion_plan)
                    and ahead[0].current_motion_plan.get('g_station_m') is not None
                    and ahead[1].crossing(float(ahead[0].current_motion_plan['g_station_m'])) is not None)
                if chunk is not None and leader_profile is not None and not leader_leaves:
                    # A reference can have enough gap throughout this tick yet
                    # leave its follower unable to respond to the leader's
                    # bounded braking on the next tick. Use the same stopping
                    # budget as the reactive following controller, before the
                    # measured separation is exhausted.
                    front_s,front_v=leader_profile.end
                    rear_s,rear_v=chunk.end
                    reserve=max(0.,rear_v*rear_v/(2*limits.a_max)
                                -front_v*front_v/(2*leader.braking))
                    if front_s-rear_s < min_gap_m+reserve-1e-6:
                        reference_failure="FOLLOWING_STOPPING_RESERVE_REQUIRED"
                if (not e_anchor_execution and chunk is not None and feedback_guard is not None
                        and not feedback_guard(chunk, chunk.end[1])):
                    reference_failure = "CPFF_STOPPING_RESERVE_REQUIRED"
                if reference_failure is None and slot is not None and slot.v_g is not None and chunk.crossing(slot.s_g) is not None:
                    guard = _v_chain_guard(
                        state, current, now, all_states, prior or {}, resource_safety or {},
                        motion_limits_by_type[state.vehicle_type], vertical_speed_mps, completion_z_m,
                        mainline_crossings, motion_limits_by_type, segment_dt, execution_precedence,
                    )
                    if guard is not None and not guard(chunk, slot.v_g):
                        raise MotionExecutionBlocked("G_TERMINAL_STATE_RESOURCE_BLOCKED", state.uav_id)
                notes = ()
            elif reactive:
                notes = ()
            else:
                tick = advance(
                    current, dt_s=segment_dt, now_s=t_from + elapsed, slot=slot,
                    leader=leader, leader_profile=leader_profile,
                    stop_station_m=stop, min_gap_m=min_gap_m,
                    entry_limits=entry_limits,
                    # All execution paths preserve a reachable resource stop.
                    profile_guard=feedback_guard,
                    # V resource windows remain the lightweight serialization
                    # token for the shared descent column.  Ordinary mainline
                    # traffic does not receive a G deadline in traffic mode.
                    enforce_slot_timing=(
                        enforce_schedule_timing
                        or bool(state.current_motion_plan.get("resource_windows"))
                    ),
                )
                chunk, notes = tick.profile, tick.deviations

            if (not e_anchor_execution) and (reactive or reference_failure is not None):
                # Keep the published G target as a soft execution reference;
                # do not demand its old terminal speed after a disturbance.
                intent = replace(slot, v_g=None) if slot is not None else None
                tick = advance(current, dt_s=segment_dt, now_s=t_from+elapsed,
                    slot=intent, leader=leader, leader_profile=leader_profile,
                    stop_station_m=stop, min_gap_m=min_gap_m, entry_limits=entry_limits,
                    profile_guard=feedback_guard, enforce_slot_timing=enforce_schedule_timing)
                chunk = tick.profile
                notes = tick.deviations + (Deviation(state.uav_id, "CPFF_LOCAL_REPAIR", "INFO",
                    note=reference_failure or "CONTINUE_REACTIVE_APPROACH"),)
                reactive = True
            violations = {n.kind for n in notes if n.severity == "VIOLATION"}
            # The physical continuous audit uses the registered metre
            # tolerance. Do not promote the controller's tighter diagnostic
            # threshold into a different safety definition.
            if leader_profile is not None and chunk.min_gap_with(leader_profile)>=min_gap_m-1e-6:
                notes=tuple(n for n in notes if n.kind not in {'CONTINUOUS_GAP_VIOLATION','SAFETY_GAP_VIOLATION'})
                violations={n.kind for n in notes if n.severity=='VIOLATION'}
            gap_recoverable = anomaly_policy is not None and anomaly_policy.permits_codes(violations)
            if violations and not gap_recoverable:
                error = MotionExecutionBlocked("CPFF_LOCAL_REPAIR_UNAVAILABLE", state.uav_id)
                error.feedback = {"status":"COMMITMENT_UNFULFILLABLE", "uav_id":state.uav_id,
                    "time_s":t_from+elapsed, "channels":cpff_policy.as_dict() if cpff_policy else {},
                    "reasons":[n.kind for n in notes if n.severity == "VIOLATION"]}
                raise error

            crossing = chunk.crossing(float(g_station)) if g_station is not None else None
            flown = _profile_interval(chunk, 0.0, crossing) if crossing is not None else chunk
            for piece in flown.pieces:
                start,finish=piece.start_s+elapsed,piece.end_s+elapsed
                if finish>start:
                    pieces.append(Piece(start,finish,piece.s0,piece.v0,piece.a))
            all_notes.extend(notes)
            if ahead is not None:
                binding = any(
                    note.kind in {"FOLLOW_BLOCKS_SLOT", "CONTINUOUS_GAP_VIOLATION", "SLOT_BLOCKED_BY_SEPARATION"}
                    for note in notes
                )
                if binding or (slot is None and current.v > flown.end[1] + 1e-9):
                    edges.append((ahead[0].uav_id, state.uav_id))
            elapsed += flown.duration_s
            if crossing is not None:
                break
            current = replace(current, s=flown.end[0], v=flown.end[1])

        profile = Profile(tuple(pieces), elapsed)
        results[state.uav_id] = (profile, aircraft, tuple(all_notes), None)
        predecessors.append((state, profile))
    return results, edges


def execute_frozen_motion_v1(
    snapshot: TrafficSnapshot,
    *,
    dt_s: float,
    forks: Mapping[tuple[str, str], float] | None = None,
    resource_z: Mapping[str, tuple[float, float]] | None = None,
    vertical_speed_mps: float,
    completion_z_m: float,
    executed_by_uav: Mapping[str, tuple[ExecutedEvent, ...]] | None = None,
    mainline_crossings=None,
    min_mainline_gap_m: float | None = None,
    motion_limits_by_type: Mapping[str, MotionLimits] | None = None,
    motion_dependency_states: Mapping[str, UAVState] | None = None,
    resource_safety: Mapping[str, float] | None = None,
    enforce_schedule_timing: bool = True,
    cpff_policy=None,
    anomaly_policy=None,
    e_anchor_execution: bool = False,
) -> MotionStep:
    """Advance one period. Signature and return type match the old executor."""
    if not math.isfinite(dt_s) or dt_s <= 0.0:
        raise MotionExecutionBlocked("INVALID_STEP", str(dt_s))
    if motion_limits_by_type is None:
        raise MotionExecutionBlocked("MAINLINE_MOTION_LIMITS_REQUIRED")
    gap = float(min_mainline_gap_m if min_mainline_gap_m is not None else 50.0)

    t_from = float(snapshot.sim_time_s)
    t_to = t_from + float(dt_s)
    dependencies={**getattr(snapshot,"resource_dependencies",{}),**(motion_dependency_states or {})}
    factual_states={**dependencies,**snapshot.states}
    fact_snapshot=TrafficSnapshot(snapshot.version,snapshot.sim_time_s,factual_states)
    prior = {uid: tuple(rows) for uid, rows in (executed_by_uav or {}).items()}
    for state in factual_states.values():
        known = {event.event_id for event in prior.get(state.uav_id, ())}
        stored = tuple(
            ExecutedEvent(**row)
            for row in state.current_motion_plan.get("motion_observed_events", ())
        )
        prior[state.uav_id] = tuple(
            sorted(
                prior.get(state.uav_id, ()) + tuple(e for e in stored if e.event_id not in known),
                key=lambda e: e.sequence,
            )
        )
        if any(e.actual_time_s > t_from + _TIME_TOL for e in prior[state.uav_id]):
            raise MotionExecutionBlocked("RESOURCE_GUARD_FUTURE_EVENT", state.uav_id)

    mainline = [
        state for state in snapshot.states.values()
        if state.state not in _TERMINAL
        and state.state not in {
            FlightState.TRANSITION, FlightState.VERTICAL,
            FlightState.SERVICING, FlightState.REENTRY_HOLD, FlightState.REENTRY_CLIMB,
        }
    ]
    from .execution_precedence import build_execution_precedence,attach_precedence
    precedence=build_execution_precedence(fact_snapshot,prior=prior,mainline_crossings=mainline_crossings,
        motion_limits_by_type=motion_limits_by_type,resource_safety=resource_safety,min_mainline_gap_m=gap)
    entry_limits_by_uav = build_h_resource_entry_limits(
        snapshot, executed_by_uav=prior,
        vh_v_to_h_margin_s=float((resource_safety or {}).get("vh_v_to_h_margin_s", .5)),
        precedence=precedence,motion_limits_by_type=motion_limits_by_type,
        mainline_crossings=mainline_crossings,
    )
    profiles, edges = _mainline_pass(
        mainline, t_from=t_from, dt_s=dt_s,
        motion_limits_by_type=motion_limits_by_type, min_gap_m=gap,
        entry_limits_by_uav=entry_limits_by_uav,
        all_states=tuple(factual_states.values()),prior=prior,resource_safety=resource_safety,execution_precedence=precedence,
        vertical_speed_mps=vertical_speed_mps,completion_z_m=completion_z_m,
        mainline_crossings=mainline_crossings,
        enforce_schedule_timing=enforce_schedule_timing,
        cpff_policy=cpff_policy,
        anomaly_policy=anomaly_policy,
        e_anchor_execution=e_anchor_execution,
    )

    advanced: list[UAVState] = []
    events: list[ExecutedEvent] = []
    mainline_event_ids: set[str] = set()
    mainline_profiles: dict[str, TickProfile] = {}

    for state in sorted(snapshot.states.values(), key=lambda item: item.uav_id):
        if state.state in _TERMINAL:
            advanced.append(state)
            continue

        if state.state == FlightState.TRANSITION:
            rows, new_state = _advance_transfer(
                state, t_from=t_from, t_to=t_to, resource_z=resource_z,
                vertical_speed_mps=vertical_speed_mps, completion_z_m=completion_z_m,
                prior=prior.get(state.uav_id, ()),
            )
            events.extend(rows)
            advanced.append(new_state)
            continue

        if state.state == FlightState.VERTICAL:
            rows, new_state = _advance_descent(
                state, t_from=t_from, t_to=t_to, resource_z=resource_z,
                vertical_speed_mps=vertical_speed_mps, completion_z_m=completion_z_m,
                prior=prior.get(state.uav_id, ()),
            )
            events.extend(rows)
            advanced.append(new_state)
            continue

        if state.uav_id not in profiles:
            advanced.append(state)
            continue

        profile, aircraft, notes, _ = profiles[state.uav_id]
        mainline_profiles[state.uav_id] = _to_tick_profile(profile)
        position, speed = profile.end
        new_state = replace(state, s_m=position, speed_mps=speed)
        if state.state == FlightState.MAINLINE and state.current_motion_plan.get('reentry_profile'):
            from build_airspace.corridor.network_contract_geometry import point_at_arc
            path=state.current_motion_plan['reentry_profile']['trajectory']['mainline_path']
            # The environment retires aircraft at the finite mainline outlet.
            # A tick can cross it before t_to; its bounded station profile is
            # unchanged, while XYZ is defined only up to the observation exit.
            point=point_at_arc(path,min(position,float(path['length_m'])))
            new_state=replace(new_state,z_m=float(point[2]),current_motion_plan={
                **new_state.current_motion_plan,'motion_position_xyz':tuple(point)})
        plan=dict(new_state.current_motion_plan)
        repaired = any(n.kind == "CPFF_LOCAL_REPAIR" for n in notes)
        if repaired:
            plan["runtime_reference_status"] = "DEVIATED"
        plan["cpff_runtime_feedback"] = {
            "status":"LOCALLY_REPAIRED" if repaired else "EXECUTABLE",
            "snapshot_version":snapshot.version,"time_s":t_from,
            "channels":cpff_policy.as_dict() if cpff_policy else {},
            "reasons":[n.note for n in notes if n.kind == "CPFF_LOCAL_REPAIR"],
        }
        # This executor advances ordinary unassigned mainline traffic too.
        # Its bounded stop/restart capability must survive a queue hold even
        # when that aircraft has never received a scheduling publication.
        plan['motion_control_owner']='MEASURED_KINEMATIC_EXECUTOR_V1'
        if (plan.get('pending_hold') or {}).get('reason')=='V_RESOURCE_GUARD':plan.pop('pending_hold',None)
        if any(n.kind=='V_RESOURCE_GUARD_BRAKING' for n in notes):
            anchor = (plan.get('resource_entry_station_m')
                      if plan.get('descent_template_origin') == 'E'
                      else plan.get('g_station_m'))
            plan['pending_hold']={'reason':'V_RESOURCE_GUARD','stop_station_m':float(anchor)-1e-6,
                                  'phase':'PENDING_HOVER' if speed<1e-8 else 'PENDING_BRAKING'}
        new_state=replace(new_state,current_motion_plan=plan)

        # A zero-speed aircraft on the mainline must carry an explicit hold
        # record, otherwise ECJA refuses it as UNAUTHORIZED_MAINLINE_ZERO_SPEED.
        # Two distinct causes are recorded:
        # a stop boundary writes ``pending_hold``; being braked by the leader
        # writes ``safety_following_hold``. ``request_allows_stop_start`` reads
        # either one, and nothing else.
        entry_limits = entry_limits_by_uav.get(state.uav_id, ())
        plan = dict(new_state.current_motion_plan)
        if entry_limits:
            plan["resource_entry_protection"] = {
                "state_version": snapshot.version, "time_s": t_from,
                "limits": tuple(asdict(limit) for limit in entry_limits),
            }
        else:
            plan.pop("resource_entry_protection", None)
        if ((plan.get("pending_hold") or {}).get("reason") == "ACTUAL_RESOURCE_ENTRY_GUARD"
                and plan.get('execution_mode')!='CMLPM_RETRY_HOLD'):
            plan.pop("pending_hold", None)
        new_state = replace(new_state, current_motion_plan=plan)
        stop_used = _stop_station(new_state, _frozen_slot(state), entry_limits, now_s=t_to)
        if stop_used is not None:
            pending = dict(new_state.current_motion_plan.get("pending_hold") or {})
            pending.update(
                {
                    "stop_station_m": float(stop_used),
                    "phase": "PENDING_HOVER" if speed < 1e-8 else "PENDING_BRAKING",
                }
            )
            if any(not limit.exit_confirmed and abs(limit.stop_station_m-stop_used) < 1e-9
                   for limit in entry_limits):
                pending["reason"] = "ACTUAL_RESOURCE_ENTRY_GUARD"
            new_state = replace(
                new_state,
                current_motion_plan={
                    **new_state.current_motion_plan,
                    "pending_hold": pending,
                },
            )
        elif speed < float(state.speed_mps) - 1e-8:
            new_state = replace(
                new_state,
                current_motion_plan={
                    **new_state.current_motion_plan,
                    "safety_following_hold": True,
                },
            )

        # H stays on the mainline; V uses this same measured mainline prefix
        # before its descent handoff.  The handoff station is G for the legacy
        # G-origin template and E for the E-origin (B design) template.
        g_station = (new_state.current_motion_plan.get("g_station_m")
                     if new_state.current_motion_plan.get("schedule_result")=="RELEASED" else None)
        e_origin = (new_state.current_motion_plan.get("descent_template_origin") == "E"
                    and new_state.current_motion_plan.get("schedule_result") == "RELEASED")
        origin_station = (float(new_state.current_motion_plan["resource_entry_station_m"])
                          if e_origin else g_station)
        crossing_rows = _mainline_crossing_events(
            state,
            mainline_profiles[state.uav_id],
            t_from=t_from,
            t_to=t_to,
            prior=prior.get(state.uav_id, ()),
            mainline_crossings=mainline_crossings or {},
            stop_at_station_m=float(origin_station) if origin_station is not None else None,
        )
        events.extend(crossing_rows)
        mainline_event_ids.update(e.event_id for e in crossing_rows)
        if notes:
            new_state = replace(
                new_state,
                current_motion_plan={
                    **new_state.current_motion_plan,
                    "motion_deviations": tuple(
                        {
                            "kind": note.kind,
                            "severity": note.severity,
                            "planned": note.planned,
                            "actual": note.actual,
                            "delta": note.delta,
                            "note": note.note,
                        }
                        for note in notes
                    ),
                },
            )
        elif new_state.current_motion_plan.get("motion_deviations"):
            new_state = replace(new_state,current_motion_plan={
                **new_state.current_motion_plan,"motion_deviations":(),
            })

        g_station = (new_state.current_motion_plan.get("g_station_m")
                     if new_state.current_motion_plan.get("schedule_result")=="RELEASED" else None)
        e_origin = (new_state.current_motion_plan.get("descent_template_origin") == "E"
                    and new_state.current_motion_plan.get("schedule_result") == "RELEASED")
        origin_station = (float(new_state.current_motion_plan["resource_entry_station_m"])
                          if e_origin else g_station)
        tau = profile.crossing(float(origin_station)) if origin_station is not None else None
        if tau is None:
            advanced.append(new_state)
            continue

        actual_origin = t_from + tau
        _, actual_origin_speed = profile.state_at(tau)
        plan = new_state.current_motion_plan
        reactive_g = plan.get("runtime_reference_status") == "DEVIATED"
        if e_origin:
            cap = float(plan.get("e_entry_speed_cap_mps", plan.get("terminal_speed_mps", 0.0)))
            target = float(plan.get("e_entry_speed_mps", plan.get("terminal_speed_mps", 0.0)))
            if not reactive_g and (
                abs(actual_origin - float(plan["e_time_s"])) > 1e-6
                or abs(actual_origin_speed - target) > 1e-6
            ):
                raise MotionExecutionBlocked("E_TERMINAL_STATE_MISMATCH", state.uav_id)
            if actual_origin_speed > cap + 1e-6:
                raise MotionExecutionBlocked("E_ENTRY_SPEED_ABOVE_CAP", state.uav_id)
        elif plan.get("enforce_g_terminal_state") and not reactive_g and (
            abs(actual_origin - float(plan["g_time_s"])) > 1e-6
            or abs(actual_origin_speed - float(plan["terminal_speed_mps"])) > 1e-6
        ):
            raise MotionExecutionBlocked("G_TERMINAL_STATE_MISMATCH", state.uav_id)
        if tau > _TIME_TOL:
            mainline_profiles[state.uav_id] = TickProfile(mainline_profiles[state.uav_id].pieces, tau)
        else:
            mainline_profiles.pop(state.uav_id, None)
        rows: list[ExecutedEvent] = [
            ExecutedEvent(
                event_id=f"{state.uav_id}:E" if e_origin else f"{state.uav_id}:G",
                event_type="E" if e_origin else "G",
                actual_time_s=actual_origin,
                sequence=_sequence_index(prior.get(state.uav_id, ())) + len(crossing_rows),
                resource_id=None,
                uav_id=state.uav_id,
            )
        ]
        plan = dict(new_state.current_motion_plan)
        # The shared descent-path machinery is origin-agnostic: it reads
        # ``g_actual_time_s`` as the template origin.  For the E-origin
        # template that origin is the observed E crossing.
        plan["g_actual_time_s"] = actual_origin
        plan["descent_origin_kind"] = "E" if e_origin else "G"
        if e_origin:
            plan["e_actual_time_s"] = actual_origin
            plan["e_delay_s"] = actual_origin - float(plan["e_time_s"])
        else:
            plan["g_delay_s"] = actual_origin - float(plan["g_time_s"])
        if reactive_g:
            plan["g_terminal_deviation"] = dict(
                target_time_s=plan.get("e_time_s", plan.get("g_time_s")),
                actual_time_s=actual_origin,
                target_speed_mps=plan.get("e_entry_speed_mps", plan.get("terminal_speed_mps")),
                actual_speed_mps=actual_origin_speed)
        if "descent_trajectory" not in plan:
            raise MotionExecutionBlocked("DESCENT_TEMPLATE_MISSING", state.uav_id)
        if e_origin or plan.get("v4_frozen_trajectory") is not None:
            # E-origin (B design) and v4 publish the descent template before
            # execution; it must never be regenerated at the observed crossing.
            realized = plan["descent_trajectory"]
        else:
            if "zhou_transfer_access" not in plan:
                raise MotionExecutionBlocked("G_TRANSFER_ROUTE_MISSING", state.uav_id)
            limits = motion_limits_by_type[state.vehicle_type]
            try:
                realized = realize_descent_at_g(
                    plan, entry_speed_mps=(float(plan["terminal_speed_mps"])
                                           if plan.get("enforce_g_terminal_state") and not reactive_g else actual_origin_speed),
                    vertical_speed_mps=vertical_speed_mps,
                    completion_z_m=completion_z_m,
                    max_speed_mps=limits.max_speed_mps,
                    max_acceleration_mps2=limits.max_abs_acceleration_mps2,
                    vehicle_type=state.vehicle_type,
                )
            except ValueError as error:
                blocked = MotionExecutionBlocked(
                    str(error),
                    f"{state.uav_id}:G_time_s={actual_origin:.9f}:entry_speed_mps={actual_origin_speed:.9f}",
                )
                blocked.uav_id = state.uav_id
                blocked.actual_g_time_s = actual_origin
                blocked.entry_speed_mps = actual_origin_speed
                raise blocked from error
        plan["realized_descent_trajectory"] = realized
        plan["descent_trajectory_realized"] = True
        plan["g_actual_speed_mps"] = actual_origin_speed
        plan["j_realized_time_s"] = actual_origin + realized["j_offset_s"]
        plan["realized_resource_windows"] = {
            resource: (actual_origin+enter, actual_origin+exit_)
            for resource, (enter, exit_) in trajectory_resource_windows(realized).items()
        }
        planned_windows = {str(resource):(float(enter),float(exit_))
                           for resource,enter,exit_ in plan.get("resource_windows",())}
        plan["resource_delay_s"] = {
            resource:{"enter_s":enter-planned_windows[resource][0],
                      "exit_s":exit_-planned_windows[resource][1]}
            for resource,(enter,exit_) in plan["realized_resource_windows"].items()
            if resource in planned_windows
        }
        plan["j_delay_s"] = plan["j_realized_time_s"] - float(plan["j_time_s"])
        new_state = replace(new_state, s_m=float(origin_station), speed_mps=actual_origin_speed,
                            state=FlightState.TRANSITION, current_motion_plan=plan)
        if tau < float(dt_s) - _TIME_TOL:
            more, new_state = _advance_transfer(
                new_state, t_from=actual_origin, t_to=t_to, resource_z=resource_z,
                vertical_speed_mps=vertical_speed_mps, completion_z_m=completion_z_m,
                prior=prior.get(state.uav_id, ()) + tuple(crossing_rows) + tuple(rows),
            )
            rows.extend(more)
        events.extend(rows)
        advanced.append(new_state)

    from .speed_control_scope import resource_entry_authority
    observed: dict[str, list[ExecutedEvent]] = {}
    authorities: dict[str, dict] = {}
    for event in events:
        if event.event_type == "RESOURCE_ENTER":
            basis = resource_entry_authority(snapshot.states[event.uav_id], event,
                mainline=event.event_id in mainline_event_ids,
                entry_limits=entry_limits_by_uav.get(event.uav_id, ()))
            authorities.setdefault(event.uav_id, {})[event.event_id] = basis
        observed.setdefault(event.uav_id, []).append(event)
    advanced = [
        replace(
            state,
            current_motion_plan={
                **state.current_motion_plan,
                **({"resource_entry_authorities": {
                    **state.current_motion_plan.get("resource_entry_authorities", {}),
                    **authorities[state.uav_id],
                }} if state.uav_id in authorities else {}),
                "motion_observed_events": tuple(
                    asdict(e)
                    for e in prior.get(state.uav_id, ()) + tuple(observed.get(state.uav_id, ()))
                ),
            },
        )
        if state.uav_id in observed else state
        for state in advanced
    ]

    from .speed_control_scope import release_completed_h_control
    advanced=[release_completed_h_control(s,t_now=t_to) for s in advanced]
    from .execution_precedence import resource_execution_facts
    advanced=[replace(s,current_motion_plan={**s.current_motion_plan,
        "execution_resource_facts":resource_execution_facts(s,t_to)}) for s in advanced]
    from .upstream_congestion import propagate_upstream_congestion
    advanced = list(propagate_upstream_congestion(
        snapshot.states.values(), advanced,
        observed_at_s=t_to,
    ))
    step = MotionStep(
        t_from=t_from,
        t_to=t_to,
        states=attach_precedence(advanced,precedence,snapshot.version),
        events=tuple(events),
        following_response_edges=tuple(edges),
        mainline_profiles=mainline_profiles,
    )
    if anomaly_policy is not None and anomaly_policy.enabled:
        from .cpff_anomaly_response import annotate_response
        step = annotate_response(snapshot, step, minimum_gap_m=gap)
    return step


