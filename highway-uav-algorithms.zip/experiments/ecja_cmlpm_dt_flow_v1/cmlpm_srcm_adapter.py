"""Runtime SRCM call for the real C-MLPM node-input path.

This module owns the flowchart branch ``E -> F -> I``: from one immutable,
versioned traffic read it exposes predicted descent paths and nominal H plans, performs
a real ``evaluate_p3r_srcm`` call over the registered G25 crossing geometry,
    and converts the resulting crossing visits into the C-MLPM ``ResourceUse``
    rows plus explicitly labelled VV/VH diagnostic evidence. An active V is
    represented from its registered E resource-entry interface; no upstream
    G/J event is predicted or exposed to C-MLPM.
    Reachable windows and published E times have separate downstream owners.

The C-MLPM representation follows the frozen resource model: one crossing at
layer ``L`` is one schedulable resource, represented by the registered column
segment that starts at the layer-L altitude.  A V's ordered crossing visits
    become the chain uses anchored at the resource-entry event ``E``; an H's crossing
visit at its own layer becomes the single mainline use anchored at its
resource-entry event.  The offsets are the actual visit windows measured
against the plan's shaft-entry time, so the MILP schedules on physically
measured occupancy rather than on synthetic durations.

Nothing in this module invents resource uses or safety parameters.  Committed
vertical traffic whose remaining events cannot be rebuilt from the current
state (TRANSITION/VERTICAL/frozen) is carried as as-committed fixed evidence
only; its C-MLPM reservation inheritance remains the P2 frozen-ledger work.
"""

from __future__ import annotations

from dataclasses import dataclass
import copy
import math
from types import MappingProxyType
from typing import Any, Iterable, Mapping

from ecja_qsap.p3r_forward import ForwardServiceCatalog
from ecja_qsap.p3r_srcm import evaluate_p3r_srcm
from g25_param_env.scenario import build_scenario_bundle
from srcm.plan_motion import iter_plan_motion_segments
from srcm.crossing_registry import build_crossing_registry
from .e_to_j_descent import build_e_to_j_template, to_motion_prediction
from configs.mission_config import DEFAULT_UAV_TYPE_SPECS

from .crossing_resource_mapping import (
    CROSSING_MAP_VERSION,
    CROSSING_SHAFT_RADIUS_M,
    build_crossing_resource_maps,
    crossing_map_for_node_layer,
    verify_registered_geometry,
)
from .cmlpm_runtime_input import NodeTrafficRead, RuntimeInputBlocked
from ecja_qsap.history_context import build_mainline_fixed_plan
from .network_loader import RegisteredG25, to_ecja_g25_source
from .numeric_motion import MotionLimits, stop_start_limits
from .reachable_window import bounded_reachability_window
from .simulation_state import FlightState, UAVState


SRCM_ADAPTER_VERSION = "CMLPM_RUNTIME_SRCM_ADAPTER_V5_E_ANCHOR"
SRCM_SCENE_GUARD_S = 0.5
_LAYER_INDEX = {"L1": 1, "L2": 2, "L3": 3}


@dataclass(frozen=True)
class RuntimePolicies:
    """Declared research parameters for the runtime input generation."""

    guard_s: float = 0.5
    vh_margin_s: float = 0.5
    vh_version: str = "DT_FLOW_VH_BASELINE_0P5_NUMERICAL_ASSUMPTION_V1"
    vv_entry_headway_s: float = 2.5
    vv_version: str = "CMLPM_SHARED_RESOURCE_HEADWAY_2P5_V1"
    h_allowed_exit_delay_s: float = 12.0
    h_delay_version: str = "DT_FLOW_H_ALLOWED_EXIT_DELAY_12S_RESEARCH_ASSUMPTION_V1"
    vertical_speed_mps: float = 3.0
    # E is the scheduling anchor.  ``e_entry_speed_cap_mps`` is an *upper
    # bound* on the horizontal speed when entering the shaft; the actual
    # speed realised at E is an output of the registered descent template and
    # is published separately as ``e_entry_speed_mps`` in the plan fields.
    e_entry_speed_cap_mps: float = 7.0
    # E-anchor is the only active template.  G is an upstream safety-hold
    # point owned by the executor and is not a C-MLPM variable.
    descent_template: str = "E_TO_J"

    @classmethod
    def from_config(cls, config: Mapping[str, Any]) -> "RuntimePolicies":
        safety = config.get("resource_safety", {})
        if not isinstance(safety, Mapping):
            raise RuntimeInputBlocked("INVALID_RUNTIME_POLICIES", "resource_safety")
        motion = config.get("motion", {})
        e_cap = float(motion.get("e_entry_speed_cap_mps", 7.0))
        return cls(
            guard_s=float(SRCM_SCENE_GUARD_S),
            vh_margin_s=float(safety["vh_v_to_h_margin_s"]),
            vh_version=str(safety.get("vh_margin_status", "UNKNOWN")),
            vv_entry_headway_s=float(safety["vv_min_entry_headway_s"]),
            h_allowed_exit_delay_s=float(safety["h_allowed_exit_delay_s"]),
            h_delay_version=str(safety.get("h_allowed_exit_delay_status", "UNKNOWN")),
            vertical_speed_mps=float(motion.get("vertical_speed_mps", 3.0)),
            e_entry_speed_cap_mps=e_cap,
            descent_template=str(motion.get("descent_template", "E_TO_J")),
        )


def _resource_band(network: RegisteredG25, resource_id: str) -> tuple[float, float]:
    """Return (high_z, low_z) of a registered resource segment."""

    for row in network.resources:
        if str(row["resource_id"]) == str(resource_id):
            z0 = float(row["start_xyz"][2])
            z1 = float(row["end_xyz"][2])
            return (max(z0, z1), min(z0, z1))
    raise RuntimeInputBlocked("SRCM_V_RESOURCE_BAND_MISSING", str(resource_id))


def _template_speed_at(predicted: Mapping[str, Any], time_s: float) -> float:
    """Horizontal speed of the registered transfer at a G-relative time.

    ``predicted`` is the realised G->J template.  The shaft-entry time is an
    offset in that template, so interpolating the stored velocity table gives
    the actual E speed without re-deriving the curve.
    """

    times = predicted.get("transfer_elapsed_s") or predicted.get("elapsed_s")
    velocities = predicted.get("transfer_velocity_xyz") or predicted.get("velocity_xyz")
    if not times or not velocities:
        raise RuntimeInputBlocked("SRCM_V_TEMPLATE_SPEED_MISSING", "")
    stamps = [float(value) for value in times]
    if time_s <= stamps[0] + 1e-9:
        return math.dist((0.0, 0.0, 0.0), velocities[0])
    for index in range(1, len(stamps)):
        if time_s <= stamps[index] + 1e-9:
            span = max(stamps[index] - stamps[index - 1], 1e-12)
            ratio = (float(time_s) - stamps[index - 1]) / span
            vector = [
                float(velocities[index - 1][axis])
                + (float(velocities[index][axis]) - float(velocities[index - 1][axis])) * ratio
                for axis in range(3)
            ]
            return math.dist((0.0, 0.0, 0.0), vector)
    return math.dist((0.0, 0.0, 0.0), velocities[-1])


@dataclass(frozen=True)
class NodeSrcmEvidence:
    node_id: str
    direction: str
    state_version: int
    t_now: float
    srcm_snapshot_id: str
    scenario_hash: str
    geometry_hash: str
    guard_s: float
    resource_uses: tuple[dict[str, Any], ...]
    vv_events: tuple[dict[str, Any], ...]
    vh_events: tuple[dict[str, Any], ...]
    h_resource_ids: tuple[str, ...]
    vh_resources: tuple[str, ...]
    plan_fields: Mapping[str, Mapping[str, Any]]
    coverage: Mapping[str, Any]
    provenance: Mapping[str, Any]


def _mainline_from_source(
    source: Mapping[str, Any], direction: str, layer: str
) -> Mapping[str, Any]:
    matches = [
        item for item in source["mainlines"]
        if str(item["direction_id"]) == direction and str(item["layer_id"]) == layer
    ]
    if len(matches) != 1:
        raise RuntimeInputBlocked(
            "SRCM_MAINLINE_CARDINALITY", f"{direction}:{layer}:{len(matches)}"
        )
    return matches[0]


def _rebuild_active_v_plan(
    source: Mapping[str, Any],
    state: UAVState,
    node_id: str,
    t_now: float,
    catalog: ForwardServiceCatalog,
    *,
    descent_template: str = "E_TO_J",
    v_e_mps: float = 7.0,
    vertical_speed_mps: float = 3.0,
    allow_missed_e_boundary: bool = False,
) -> dict[str, Any]:
    """Expose registered descent resource geometry, never predict approach.

    Current position/speed remain observed metadata and safety inputs. In the
    active E-anchor mode the SRCM path starts at E at a labelled reference
    time; ECJA assignment and this input builder do not impose a G stop.
    """

    line = _mainline_from_source(source, state.direction, state.layer)
    access_rows = [
        row for row in catalog.rows
        if str(row["service_node_id"]) == node_id
        and str(row["source_layer_id"]) == state.layer
        and str(row["direction_id"]) == state.direction
    ]
    if len(access_rows) != 1:
        raise RuntimeInputBlocked(
            "SRCM_CATALOG_ACCESS_CARDINALITY", f"{node_id}:{state.layer}:{len(access_rows)}"
        )
    access = access_rows[0]
    if descent_template != "E_TO_J":
        raise RuntimeInputBlocked("E_ANCHOR_ONLY_TEMPLATE", str(descent_template))
    if not all(math.isfinite(float(v)) for v in (state.s_m,state.speed_mps,t_now)) or state.speed_mps<0.:
        raise RuntimeInputBlocked('INVALID_V_OBSERVED_STATE',state.uav_id)
    anchor_station = float(access["zhou_j_xyz"][0]) - CROSSING_SHAFT_RADIUS_M
    if state.s_m+1e-6>=anchor_station and not allow_missed_e_boundary:
        raise RuntimeInputBlocked('SRCM_ACTIVE_V_PLAN_REBUILD_FAILED',
                                  f'{state.uav_id}:MISSED_E_BOUNDARY')
    if descent_template == "E_TO_J":
        # The E-origin template does not depend on the registered G->J curve,
        # so no Zhou transfer is generated (the 10 m synthetic shaft cannot
        # satisfy it at cruise speed).
        from configs.mission_config import DEFAULT_UAV_TYPE_SPECS as _TYPE_SPECS
        spec = _TYPE_SPECS[state.vehicle_type]
        axis_station = float(access["zhou_j_xyz"][0])
        e_template = build_e_to_j_template(
            e_station_m=axis_station - CROSSING_SHAFT_RADIUS_M,
            # E is on the registered source mainline.  The measured z may be
            # a stale low-altitude value left by the retired G/J executor
            # after a failed publication; it is not the E-anchor altitude.
            e_altitude_m=float(access["zhou_g_xyz"][2]),
            axis_station_m=axis_station,
            completion_z_m=50.0,
            v_e_mps=float(v_e_mps),
            descent_speed_mps=float(vertical_speed_mps),
            horizontal_acceleration_mps2=float(spec["max_horizontal_acceleration_mps2"]),
            vertical_acceleration_mps2=float(spec["max_vertical_acceleration_mps2"]),
            resource_bands={},
            e_xyz=(
                float(access["zhou_j_xyz"][0]) - CROSSING_SHAFT_RADIUS_M * float(access["zhou_mainline_tangent_xyz"][0]),
                float(access["zhou_j_xyz"][1]) - CROSSING_SHAFT_RADIUS_M * float(access["zhou_mainline_tangent_xyz"][1]),
            ),
            axis_xyz=(float(access["zhou_j_xyz"][0]), float(access["zhou_j_xyz"][1])),
        )
        template = {
            'activity_end_s': float(t_now) + float(e_template["e_to_p_s"]),
            'motion_prediction': to_motion_prediction(
                e_template, reference_time_s=float(t_now)),
            'e_to_j_s': float(e_template["j_offset_s"]),
        }
    return {
        'uav_id':state.uav_id,'plan_id':f'{state.uav_id}:CMLPM_FIXED_DESCENT:{access["interface_id"]}',
        'plan_status':'CANDIDATE','committed':False,'mode':'REGISTERED_DESCENT_RESOURCE_TEMPLATE',
        'source_mainline_id':line['mainline_id'],'source_layer_id':state.layer,
        'source_direction_id':state.direction,'service_node_id':node_id,
        'option_group_id':state.request_id or f'{state.uav_id}:RESOURCE_TEMPLATE',
        'is_current_assignment':True,'route_id':f'route:{access["interface_id"]}',
        'activity_start_s':float(t_now),'activity_end_s':template['activity_end_s'],
        'termination_reason':'ENGINEERING_BOUNDARY_REACHED',
        'trajectory_coverage_status':'FIXED_DESCENT_ONLY',
        'coverage_window':[float(t_now),template['activity_end_s']],
        'motion_prediction':template['motion_prediction'],
        'resource_entry_station_m': anchor_station,
        'e_station_m': anchor_station,
        'e_to_j_s': float(template['e_to_j_s']),
        'template_reference':{'anchor_event':'E','reference_time_s':float(t_now),
                              'is_arrival_prediction':False,'is_published_time':False},
        'observed_state':{'s_m':float(state.s_m),'speed_mps':float(state.speed_mps),'time_s':float(t_now)},
        'motion_parameter_provenance':'E_ANCHOR_FIXED_TEMPLATE_V1',
    }


def _is_active_v(state: UAVState) -> bool:
    """A V that is still optimizable in this scheduling event.

    ``SCHEDULED`` before the spatial commit boundary remains an adjustable
    descent; only TRANSITION/VERTICAL (already past E) and explicitly frozen
    plans are inherited through the frozen reservation contract.
    """

    return (
        state.state not in {
            FlightState.TRANSITION, FlightState.VERTICAL,
            FlightState.SERVICING, FlightState.REENTRY_HOLD, FlightState.REENTRY_CLIMB,
            FlightState.REENTRY_LAND_TO_GROUND, FlightState.REENTRY_ASCENT_TO_50M,
            FlightState.REENTRY_STAGING_HOLD, FlightState.REENTRY_FINAL_APPROACH,
        }
        and state.commit_status != "FROZEN"
    )


def _phase_end_time(plan: Mapping[str, Any], phase_type: str) -> float:
    """Absolute end time of one motion phase.

    Uses the frozen SRCM segment iterator so the path-time prediction is
    resolved to absolute seconds exactly as ``compute_crossing_uses`` does.
    """

    segments = [
        item for item in iter_plan_motion_segments(plan)
        if item["phase_type"] == phase_type
    ]
    if not segments:
        raise RuntimeInputBlocked("SRCM_PHASE_MISSING", f"{plan.get('plan_id')}:{phase_type}")
    return max(float(item["end_s"]) for item in segments)


def _visits_by_uav(uses: Iterable[Mapping[str, Any]]) -> dict[str, list[Mapping[str, Any]]]:
    grouped: dict[str, list[Mapping[str, Any]]] = {}
    for use in uses:
        grouped.setdefault(str(use["uav_id"]), []).append(use)
    for rows in grouped.values():
        rows.sort(key=lambda item: (float(item["enter_s"]), float(item["exit_s"])))
    return grouped


def _node_chain_visits(
    visits: Iterable[Mapping[str, Any]], expected_crossing_ids: Iterable[str]
) -> tuple[Mapping[str, Any], ...]:
    """Keep only the assigned node's ordered crossing chain."""

    expected = set(str(value) for value in expected_crossing_ids)
    return tuple(item for item in visits if str(item["crossing_id"]) in expected)


def run_node_srcm(
    network: RegisteredG25,
    read: NodeTrafficRead,
    *,
    policies: RuntimePolicies,
    seed: int = 0,
    motion_limits_by_type: Mapping[str, MotionLimits] | None = None,
    continued_uav_ids: Iterable[str] = (),
    replan_existing_v_ids: Iterable[str] = (),
    evaluation_clear_time_s: float | None = None,
    use_bounded_h_crossing: bool = False,
    static_context=None,
) -> NodeSrcmEvidence:
    """Perform one real SRCM evaluation for the node traffic read.

    Every plan in the scene is rebuilt from, or anchored to, the same traffic
    state version carried by ``read``.  The returned evidence binds that
    version, the SRCM snapshot id, the scenario hash and the geometry hash, so
    downstream consumers can prove the single-version requirement.
    """

    t_now = float(read.t_now)
    if static_context is not None:
        static_context.require_network(network)
        network = static_context.network
        maps, source, catalog = static_context.crossings, static_context.source, static_context.catalog
    else:
        verify_registered_geometry(network)
        maps = build_crossing_resource_maps(network)
        source = to_ecja_g25_source(network, include_formal_motion=True)
        catalog = ForwardServiceCatalog(source)

    plans: list[dict[str, Any]] = []
    active_v_ids: list[str] = []
    committed_plan_ids: list[str] = []
    continued = {str(value) for value in continued_uav_ids}
    replanned = {str(value) for value in replan_existing_v_ids}
    for state in sorted(read.traffic_states, key=lambda item: item.uav_id):
        if state.uav_id in continued:
            # Already committed and inherited through frozen reservations; the
            # SRCM competition evidence for new traffic must not re-create it.
            continue
        frozen_nonrelease = (
            state.commit_status == "FROZEN"
            and state.state in {FlightState.DEFERRED, FlightState.MOTION_INFEASIBLE}
        )
        if state.assigned_node == read.node_id and not frozen_nonrelease:
            if _is_active_v(state) or state.uav_id in replanned:
                plans.append(
                    _rebuild_active_v_plan(
                        source, state, read.node_id, t_now, catalog,
                        descent_template=policies.descent_template,
                        v_e_mps=min(float(policies.e_entry_speed_cap_mps), 12.0),
                        vertical_speed_mps=float(policies.vertical_speed_mps),
                        allow_missed_e_boundary=state.uav_id in replanned)
                )
                active_v_ids.append(state.uav_id)
            else:
                if not state.current_motion_plan:
                    raise RuntimeInputBlocked(
                        "SRCM_COMMITTED_PLAN_MISSING", state.uav_id
                    )
                plan = copy.deepcopy(dict(state.current_motion_plan))
                if str(plan.get("uav_id")) != state.uav_id:
                    raise RuntimeInputBlocked("SRCM_COMMITTED_PLAN_UAV_MISMATCH", state.uav_id)
                plan["plan_status"] = "FIXED"
                plan["committed"] = True
                plans.append(plan)
                committed_plan_ids.append(str(plan["plan_id"]))
        else:
            plan = build_mainline_fixed_plan(source, state, t_now)
            if plan is None:
                raise RuntimeInputBlocked("SRCM_BACKGROUND_PLAN_MISSING", state.uav_id)
            plans.append(plan)

    scenario_id = f"CMLPM_SRCM:NODE:{read.node_id}:V{read.state_version}:T{t_now:.6f}"
    scene = (static_context.scene(scenario_id, seed, plans) if static_context else
             build_scenario_bundle(source, scenario_id, "OPTIONS", seed, plans=plans))
    scene["meta"]["snapshot_id"] = scenario_id + ":SNAPSHOT:0"
    scene["meta"]["t0_s"] = t_now
    # Replanned active E-anchor states can carry an expired historical
    # activity end. SRCM still needs a strictly positive local horizon for
    # the new round; derive it from finite current plans and keep one second
    # of look-ahead even when every old target has expired.
    end_times = [
        float(plan["activity_end_s"])
        for plan in scene["plans"]
        if math.isfinite(float(plan.get("activity_end_s", t_now)))
    ]
    latest_end = max(end_times, default=t_now)
    scene["meta"]["horizon_s"] = max(1.0, latest_end - t_now + 1.0)
    scene["time_profile"]["optional_guard_s"] = float(policies.guard_s)
    scene["meta"]["scenario_hash"] = ""
    from g25_param_env.scenario import canonical_hash

    scene["meta"]["scenario_hash"] = canonical_hash(scene)

    result = evaluate_p3r_srcm(scene)
    visits = _visits_by_uav(result["uses"])
    plan_by_uav = {str(plan["uav_id"]): plan for plan in scene["plans"]}
    geometry_by_crossing = {row["crossing_id"]: row["geometry"]
                            for row in build_crossing_registry(scene)}

    resource_uses: list[dict[str, Any]] = []
    plan_fields: dict[str, dict[str, Any]] = {}
    h_resource_ids: list[str] = []
    vh_resources: set[str] = set()

    for state in sorted(read.traffic_states, key=lambda item: item.uav_id):
        uav_id = state.uav_id
        crossing = crossing_map_for_node_layer(
            maps, read.node_id, read.direction, state.layer
        )
        frozen_nonrelease = (
            state.commit_status == "FROZEN"
            and state.state in {FlightState.DEFERRED, FlightState.MOTION_INFEASIBLE}
        )
        if state.assigned_node == read.node_id and not frozen_nonrelease:
            if uav_id not in active_v_ids:
                continue
            plan = plan_by_uav[uav_id]
            all_uav_visits = visits.get(uav_id, ())
            expected = [
                crossing_map_for_node_layer(maps, read.node_id, read.direction, layer).crossing_id
                for layer in _expected_visit_layers(state.layer)
            ]
            # A registered ECJA route may physically cross shafts belonging to
            # upstream service nodes before reaching its assigned node.  A
            # single-node C-MLPM input owns only the assigned node's resource
            # chain; those earlier crossings remain SRCM background evidence
            # and must not be mistaken for extra resources of this node.
            uav_visits = _node_chain_visits(all_uav_visits, expected)
            if not uav_visits:
                if uav_id not in replanned:
                    raise RuntimeInputBlocked("SRCM_V_CROSSING_VISITS_MISSING", uav_id)
                # A rejected/expired plan may have no SRCM visit left for the
                # current node: the aircraft can be sitting at the node's E
                # boundary while the old route-only history ends upstream.
                # Replanning owns a fresh E-anchor realization, so use the
                # registered resource chain as geometry and do not fabricate
                # old crossing times here.
                uav_visits = tuple(
                    {"crossing_id": crossing_id, "enter_s": t_now, "exit_s": t_now}
                    for crossing_id in expected
                )
            if uav_id in replanned:
                # A failed active plan can be observed after one or more
                # registered shaft slices have already been crossed.  Replan
                # only the measured suffix; continuation semantics already
                # removed the old prefix from the immutable ledger.
                expected = [str(item["crossing_id"]) for item in uav_visits]
            visit_layers = [str(item["crossing_id"]) for item in uav_visits]
            if visit_layers != expected:
                raise RuntimeInputBlocked(
                    "SRCM_V_VISIT_ORDER_MISMATCH",
                    f"{uav_id}:{visit_layers}!={expected}",
                )
            geometries={maps[c].segment_resource_id:geometry_by_crossing[c] for c in expected}
            limits=(motion_limits_by_type or {}).get(state.vehicle_type)
            if limits is None:
                import json
                from pathlib import Path
                cfg=json.loads((Path(__file__).parent/'configs/baseline.yaml').read_text(encoding='utf-8'))['motion']
                limits=MotionLimits(0.,float(cfg['nominal_and_normal_max_speed_mps'][state.vehicle_type]),
                                    float(cfg['max_abs_acceleration_mps2'][state.vehicle_type]))
            e_cap = min(float(policies.e_entry_speed_cap_mps), float(limits.max_speed_mps))
            # E-anchor template: the trajectory starts at E, and all resource
            # offsets are measured from that single scheduling event.
            axis_station = float(crossing.entry_station_m) + CROSSING_SHAFT_RADIUS_M
            access = next(
                row for row in catalog.rows
                if str(row["service_node_id"]) == read.node_id
                and str(row["source_layer_id"]) == state.layer
                and str(row["direction_id"]) == state.direction
            )
            bands = {
                str(maps[c].segment_resource_id): _resource_band(
                    network, str(maps[c].segment_resource_id))
                for c in expected
            }
            predicted = build_e_to_j_template(
                e_station_m=float(crossing.entry_station_m),
                # The E-anchor starts on the registered source layer.  Do not
                # feed a stale TRANSITION/VERTICAL z into the descent model:
                # that can place the aircraft below a resource band and make
                # the altitude-time inversion take sqrt(negative).
                e_altitude_m=float(access["zhou_g_xyz"][2]),
                axis_station_m=axis_station,
                completion_z_m=50.0,
                v_e_mps=e_cap,
                descent_speed_mps=float(policies.vertical_speed_mps),
                horizontal_acceleration_mps2=float(limits.max_abs_acceleration_mps2),
                vertical_acceleration_mps2=float(
                    DEFAULT_UAV_TYPE_SPECS[state.vehicle_type]["max_vertical_acceleration_mps2"]),
                resource_bands=bands,
                require_first_resource_at_e=uav_id not in replanned,
                e_xyz=(
                    float(access["zhou_j_xyz"][0]) - CROSSING_SHAFT_RADIUS_M * float(access["zhou_mainline_tangent_xyz"][0]),
                    float(access["zhou_j_xyz"][1]) - CROSSING_SHAFT_RADIUS_M * float(access["zhou_mainline_tangent_xyz"][1]),
                ),
                axis_xyz=(float(access["zhou_j_xyz"][0]), float(access["zhou_j_xyz"][1])),
            )
            physical_windows = dict(predicted["resource_windows_offsets"])
            e_offset = 0.0
            e_speed = float(predicted["v_e_mps"])
            e_to_j = float(predicted["j_offset_s"])
            if e_to_j <= 0.0:
                raise RuntimeInputBlocked("SRCM_V_NONPOSITIVE_E_TO_J", f"{uav_id}:{e_to_j}")
            for route_order, visit in enumerate(uav_visits):
                visit_crossing = crossing_map_for_node_layer(
                    maps, read.node_id, read.direction, _visit_layer(visit, maps)
                )
                resource_uses.append({
                    "use_id": f"{uav_id}:{visit_crossing.segment_resource_id}:V",
                    "uav_id": uav_id,
                    "resource_id": visit_crossing.segment_resource_id,
                    "role": "V",
                    "anchor_event_id": f"{uav_id}:E",
                    "start_offset": physical_windows[visit_crossing.segment_resource_id][0] - e_offset,
                    "end_offset": physical_windows[visit_crossing.segment_resource_id][1] - e_offset,
                    "activation": "completion",
                    "route_order": route_order,
                    "source_layer": state.layer,
                })
            plan_fields[uav_id] = {
                "resource_entry_station_m": float(crossing.entry_station_m),
                "e_station_m": float(crossing.entry_station_m),
                "e_entry_speed_mps": e_speed,
                "e_entry_speed_cap_mps": e_cap,
                "e_to_j_s": e_to_j,
                "e_to_p_s": predicted.get("e_to_p_s"),
                "descent_template_origin": "E",
                'resource_geometry_basis':'REGISTERED_E_ENTRY_FIXED_TEMPLATE',
                "descent_trajectory": predicted,
            }
        else:
            uav_visits = visits.get(uav_id, ())
            layer_visits = [
                item for item in uav_visits
                if str(item["crossing_id"]) == crossing.crossing_id
            ]
            if len(layer_visits) != 1:
                raise RuntimeInputBlocked(
                    "SRCM_H_CROSSING_VISIT_CARDINALITY",
                    f"{uav_id}:{len(layer_visits)}",
                )
            visit = layer_visits[0]
            duration = float(visit["exit_s"]) - float(visit["enter_s"])
            exited_resources = {
                str(row.get("resource_id"))
                for row in state.current_motion_plan.get("motion_observed_events", ())
                if isinstance(row, Mapping)
                and row.get("event_type") == "RESOURCE_EXIT"
                and row.get("resource_id") is not None
            }
            existing_target = next((item for item in state.current_motion_plan.get("timed_resource_targets",())
                                    if item["resource_id"] == crossing.segment_resource_id
                                    and str(item["resource_id"]) not in exited_resources),None)
            if existing_target is not None:
                # This duration is backed by a previously certified physical
                # speed curve, not a new constant-current-speed forecast.
                duration = float(existing_target["exit_time_s"])-float(existing_target["entry_time_s"])
            if duration <= 0.0:
                raise RuntimeInputBlocked("SRCM_H_VISIT_DURATION_NONPOSITIVE", uav_id)
            if motion_limits_by_type is not None:
                h_limits = motion_limits_by_type.get(state.vehicle_type)
                if h_limits is None:
                    raise RuntimeInputBlocked("SRCM_H_MOTION_LIMITS_MISSING", uav_id)
            else:
                import json
                from pathlib import Path
                cfg=json.loads((Path(__file__).parent/'configs/baseline.yaml').read_text(encoding='utf-8'))['motion']
                h_limits=MotionLimits(0.,float(cfg['nominal_and_normal_max_speed_mps'][state.vehicle_type]),
                                      float(cfg['max_abs_acceleration_mps2'][state.vehicle_type]))
            # The 10 m registered crossing slice is the scheduling resource.
            # If the SRCM visit table is shorter than the minimum traversal
            # time allowed by the current geometry/speed contract, extend the
            # H occupancy conservatively before handing it to C-MLPM.
            crossing_speed = None
            if existing_target is None and use_bounded_h_crossing:
                distance = max(0.0, crossing.entry_station_m - state.s_m)
                crossing_speed = min(
                    h_limits.max_speed_mps,
                    math.sqrt(state.speed_mps**2 + 2*h_limits.max_abs_acceleration_mps2*distance),
                )
                if crossing_speed <= 0.0:
                    raise RuntimeInputBlocked("SRCM_H_CROSSING_SPEED_UNREACHABLE", uav_id)
                duration = (crossing.exit_station_m - crossing.entry_station_m) / crossing_speed
            elif existing_target is None:
                duration = max(duration, (crossing.exit_station_m - crossing.entry_station_m) / h_limits.max_speed_mps)
            resource_uses.append({
                "use_id": f"{uav_id}:{crossing.segment_resource_id}:M",
                "uav_id": uav_id,
                "resource_id": crossing.segment_resource_id,
                "role": "M",
                "anchor_event_id": f"{uav_id}:E",
                "start_offset": 0.0,
                "end_offset": duration,
                "activation": "always",
                "route_order": 0,
                "source_layer": state.layer,
            })
            h_resource_ids.append(crossing.segment_resource_id)
            nominal_speed = float(state.nominal_speed_mps or state.speed_mps)
            nominal_entry = t_now + (crossing.entry_station_m - float(state.s_m)) / nominal_speed
            nominal_exit = nominal_entry + duration
            allowed_exit_ub = nominal_exit + float(policies.h_allowed_exit_delay_s)
            if crossing_speed is not None:
                window = bounded_reachability_window(
                    t_now=t_now, length_m=distance, v_now=float(state.speed_mps),
                    v_min=0.0, v_max=h_limits.max_speed_mps,
                    a_max=h_limits.max_abs_acceleration_mps2, b_max=h_limits.max_abs_acceleration_mps2,
                    v_terminal=crossing_speed, allow_stop_start=True,
                    latest_time_s=allowed_exit_ub-duration,
                )
                if not window.feasible:
                    raise RuntimeInputBlocked("H_ALLOWED_EXIT_WINDOW_UNREACHABLE", uav_id)
                allowed_exit_ub = min(allowed_exit_ub, window.t_ub+duration)
            elif motion_limits_by_type is not None and not use_bounded_h_crossing:
                limits = motion_limits_by_type.get(state.vehicle_type)
                if limits is None:
                    raise RuntimeInputBlocked("SRCM_H_MOTION_LIMITS_MISSING", uav_id)
                restarting = stop_start_limits(state, limits).min_speed_mps == 0.
                if restarting and evaluation_clear_time_s is None:
                    raise RuntimeInputBlocked("H_RESTART_HORIZON_MISSING",uav_id)
                # A measured H can be inside a bounded braking segment and
                # therefore temporarily below the nominal cruise floor.  The
                # observed speed is still a valid state; use it as this
                # round's lower envelope instead of rejecting the entire
                # C-MLPM input before scheduling.
                observed_speed = max(1e-6, float(state.speed_mps))
                effective_v_min = min(float(limits.min_speed_mps), observed_speed)
                window = bounded_reachability_window(
                    t_now=t_now,
                    length_m=crossing.entry_station_m - float(state.s_m),
                    v_now=float(state.speed_mps),
                    v_min=effective_v_min,
                    v_max=limits.max_speed_mps,
                    a_max=limits.max_abs_acceleration_mps2,
                    b_max=limits.max_abs_acceleration_mps2,
                    v_terminal=None,
                    source_state_id=f"{uav_id}:h-entry",
                    allow_stop_start=restarting,
                    latest_time_s=evaluation_clear_time_s,
                )
                reachable_exit_lb = window.t_lb + duration
                reachable_exit_ub = window.t_ub + duration
                allowed_exit_ub = min(allowed_exit_ub, reachable_exit_ub)
                if allowed_exit_ub < reachable_exit_lb-1e-9:
                    raise RuntimeInputBlocked("H_ALLOWED_EXIT_WINDOW_UNREACHABLE",uav_id)
            h_plan_fields = {
                "resource_entry_station_m": crossing.entry_station_m,
                "resource_exit_station_m": crossing.exit_station_m,
                "resource_duration_s": duration,
                "allowed_exit_time_ub_s": allowed_exit_ub,
            }
            if crossing_speed is not None:
                h_plan_fields.update(h_entry_time_lb_s=window.t_lb, h_entry_time_ub_s=window.t_ub)
            if existing_target is not None:
                h_plan_fields.update(
                    committed_resource_entry_s=float(existing_target["entry_time_s"]),
                    committed_resource_exit_s=float(existing_target["exit_time_s"]),
                )
            plan_fields[uav_id] = h_plan_fields

    v_use_resources = {
        str(row["resource_id"]) for row in resource_uses if row["role"] == "V"
    }
    # The executor validates separation against *observed* V/H co-occupancy,
    # while this set is the only thing a published plan can ever be checked
    # against.  An intersection covers only the pairs SRCM predicted; an H that
    # actually slows into a resource would then find no published policy and
    # abort the run with ACTUAL_VH_POLICY_MISSING.  The union covers every
    # resource either side can physically occupy.
    vh_resources = sorted(v_use_resources | set(h_resource_ids))

    vv_events: list[dict[str, Any]] = []
    vh_events: list[dict[str, Any]] = []
    for event in result["events"]:
        row = {
            "event_id": str(event["event_id"]),
            "uav_a_id": str(event["uav_a_id"]),
            "uav_b_id": str(event["uav_b_id"]),
            "crossing_id": str(event["crossing_id"]),
            "competition_type": str(event["competition_type"]),
            "overlap_start_s": float(event["overlap_start_s"]),
            "overlap_end_s": float(event["overlap_end_s"]),
            "nominal_overlap_s": float(event["nominal_overlap_s"]),
            "overlap_class": str(event["overlap_class"]),
            "role_a": str(event.get("role_a", "")),
            "role_b": str(event.get("role_b", "")),
            "time_basis": (
                "REGISTERED_TEMPLATE_REFERENCE_ONLY"
                if str(event['uav_a_id']) in active_v_ids or str(event['uav_b_id']) in active_v_ids else
                "AS_COMMITTED_PLAN"
                if str(event["plan_a_id"]) in committed_plan_ids
                or str(event["plan_b_id"]) in committed_plan_ids
                else "CURRENT_SNAPSHOT_REBUILD"
            ),
        }
        if row["competition_type"] == "VV":
            vv_events.append(row)
        elif row["competition_type"] == "VH":
            vh_events.append(row)

    provenance = {
        "adapter_version": SRCM_ADAPTER_VERSION,
        "srcm_version": str(result["srcm_version"]),
        "srcm_snapshot_id": str(result["snapshot_id"]),
        "scenario_hash": str(result["scenario_hash"]),
        "geometry_hash": str(result["geometry_hash"]),
        "state_version": int(read.state_version),
        "state_semantic_sha256": read.state_semantic_sha256,
        "crossing_map_version": CROSSING_MAP_VERSION,
        "network_sha256": network.source_sha256,
        "network_geometry_hash": network.geometry_hash,
        "guard_s": float(policies.guard_s),
        "vh_margin_s": float(policies.vh_margin_s),
        "vh_version": str(policies.vh_version),
        "vv_entry_headway_s": float(policies.vv_entry_headway_s),
        "vv_version": str(policies.vv_version),
        "h_allowed_exit_delay_s": float(policies.h_allowed_exit_delay_s),
        "h_delay_version": str(policies.h_delay_version),
        "vertical_speed_mps": float(policies.vertical_speed_mps),
        "motion_parameter_source": "REGISTERED_FIXED_DESCENT_AND_OBSERVED_H_V1",
        'v_time_basis':'E_ENTRY_PRIMARY_FIXED_TEMPLATE',
        'e_entry_speed_cap_mps': float(policies.e_entry_speed_cap_mps),
        'h_time_basis':'NOMINAL_BACKGROUND_OR_PUBLISHED_RESOURCE_OVERRIDE',
        'template_overlap_events':'DIAGNOSTIC_ONLY_NOT_SCHEDULING_TIME_CONSTRAINTS',
        'coverage_scope':'FIXED_DESCENT_TEMPLATES_AND_NOMINAL_H_NOT_EXECUTABILITY',
        "input_generation_version": SRCM_ADAPTER_VERSION,
    }

    return NodeSrcmEvidence(
        node_id=read.node_id,
        direction=read.direction,
        state_version=int(read.state_version),
        t_now=t_now,
        srcm_snapshot_id=str(result["snapshot_id"]),
        scenario_hash=str(result["scenario_hash"]),
        geometry_hash=str(result["geometry_hash"]),
        guard_s=float(policies.guard_s),
        resource_uses=tuple(resource_uses),
        vv_events=tuple(vv_events),
        vh_events=tuple(vh_events),
        h_resource_ids=tuple(sorted(set(h_resource_ids))),
        vh_resources=tuple(vh_resources),
        plan_fields=MappingProxyType(plan_fields),
        coverage=MappingProxyType(dict(result["coverage_ledger"])),
        provenance=MappingProxyType(provenance),
    )


def _expected_visit_layers(source_layer: str) -> tuple[str, ...]:
    index = _LAYER_INDEX[source_layer]
    return tuple(f"L{position}" for position in range(index, 0, -1))


def _visit_layer(visit: Mapping[str, Any], maps: Mapping[str, Any]) -> str:
    crossing_id = str(visit["crossing_id"])
    for item in maps.values():
        if item.crossing_id == crossing_id:
            return item.layer
    raise RuntimeInputBlocked("SRCM_VISIT_CROSSING_UNKNOWN", crossing_id)
