"""Observe physical motion and immutable target deviations without changing either."""
from collections import Counter, defaultdict
import json
import math
import copy

from .following_time import physical_lane
from .numeric_motion import TickProfile, continuous_min_gap
from .resource_conflict_classification import is_cross_layer_vh_layers


class MeasuredMotionAudit:
    def __init__(self, config, output_dir):
        self.config=config
        self.path=output_dir/"MOTION_OBSERVATIONS.jsonl" if output_dir is not None else None
        self.counts=Counter()
        self.safety=Counter()
        self.deviations=defaultdict(list)
        self.uses=defaultdict(list)
        self.observed=set()
        self.minimum_gap=math.inf
        self.gap_violation_duration_s=0.
        # Positional criterion (unchanged) plus the moving-only refinement.
        self.moving_gap_violation_duration_s=0.
        self.minimum_moving_gap=math.inf
        self.moving_gap_violation_pairs=0
        self.stationary_spacing_deficit_pairs=0
        self.observed_motion_steps=0
        self.conflict_pairs=set()
        self.finalized=False

    def fork(self):
        """Isolate mutable audit facts without copying immutable config/history values.

        Counters, event identities, deviation lists and occupancy records can
        change during a candidate step. Scalars and configuration are read-only.
        No candidate fact becomes public until the store CAS succeeds.
        """
        trial = copy.copy(self)
        trial.path = None
        trial.counts = self.counts.copy()
        trial.safety = self.safety.copy()
        trial.observed = self.observed.copy()
        trial.conflict_pairs = self.conflict_pairs.copy()
        trial.deviations = defaultdict(list, ((key, list(values)) for key, values in self.deviations.items()))
        trial.uses = defaultdict(list, ((key, [dict(use) for use in uses]) for key, uses in self.uses.items()))
        trial._pending = []
        return trial

    def _record(self,row):
        self.counts[row["kind"]]+=1
        if row.get("severity")=="VIOLATION": self.safety[row["kind"]]+=1
        if "delta_s" in row: self.deviations[row["kind"]].append(row["delta_s"])
        self._pending.append(row)

    def observe(self,before,step,limits):
        if getattr(step,'substeps',()):
            pending=[]
            for sub_before,substep in step.substeps:
                self.observe(sub_before,substep,limits)
                pending.extend(self._pending)
            self._pending=pending
            return
        self._pending=[]
        self.observed_motion_steps+=1
        states={s.uav_id:s for s in step.states}
        for state in step.states:
            trajectory=state.current_motion_plan.get("realized_descent_trajectory")
            if trajectory and not before.states[state.uav_id].current_motion_plan.get("realized_descent_trajectory"):
                diagnostics=trajectory.get("kinematic_audit",{})
                exceeded={key:{"actual":diagnostics[key],"allowed":bound}
                          for key,bound in diagnostics.get("allowed",{}).items()
                          if diagnostics[key]>bound+1e-6}
                if exceeded:
                    self._record({"kind":"DESCENT_CAPABILITY_VIOLATION","severity":"VIOLATION",
                                  "uav_id":state.uav_id,"actual_time_s":step.t_to,"bounds":exceeded})
            for note in state.current_motion_plan.get("motion_deviations",()):
                if note["kind"]=="CONTINUOUS_GAP_VIOLATION": continue
                self._record({"uav_id":state.uav_id,"actual_time_s":step.t_to,**note})
        lanes=defaultdict(list)
        for uid,profile in step.mainline_profiles.items():
            state=before.states[uid]
            lanes[physical_lane(state)].append(state)
            bound=limits[state.vehicle_type]
            for piece in profile.pieces:
                if abs(piece.acceleration_mps2)>bound.max_abs_acceleration_mps2+1e-6 or any(
                        v < -1e-7 or v > bound.max_speed_mps+1e-6
                        for v in (piece.start_speed_mps,piece.state_at(piece.end_s)[1])):
                    self._record({"kind":"MOTION_CAPABILITY_VIOLATION","severity":"VIOLATION",
                                  "uav_id":uid,"actual_time_s":step.t_to})
        required=float(self.config["motion"]["min_gap_m"])
        for lane,rows in lanes.items():
            ordered=sorted(rows,key=lambda s:(-s.s_m,s.uav_id))
            # Adjacent physical trajectories share the same front-to-back step.
            for front,rear in zip(ordered,ordered[1:]):
                fp,rp=step.mainline_profiles[front.uav_id],step.mainline_profiles[rear.uav_id]
                duration=min(fp.duration_s,rp.duration_s)
                if duration<=1e-12: continue
                from .cpff_anomaly_response import gap_statistics
                stats=gap_statistics(TickProfile(fp.pieces,duration),TickProfile(rp.pieces,duration),required)
                gap=stats['minimum_gap_m']
                self.minimum_gap=min(self.minimum_gap,gap)
                if gap < required-1e-6:
                    self.gap_violation_duration_s+=stats['violation_duration_s']
                    moving_duration=stats['moving_violation_duration_s']
                    moving_gap=stats['moving_minimum_gap_m']
                    if moving_duration>1e-9:
                        self.moving_gap_violation_duration_s+=moving_duration
                        self.moving_gap_violation_pairs+=1
                        if moving_gap is not None:
                            self.minimum_moving_gap=min(self.minimum_moving_gap,moving_gap)
                    else:
                        self.stationary_spacing_deficit_pairs+=1
                    shared={"uav_id":rear.uav_id,"leader_id":front.uav_id,
                        "actual_time_s":step.t_to,"gap_m":gap,"required_gap_m":required,
                        "end_gap_m":stats['end_gap_m'],
                        "front_speed_mps":stats['front_start_speed_mps'],
                        "rear_speed_mps":stats['rear_start_speed_mps']}
                    # Registered positional criterion: recorded exactly as before,
                    # with the motion split attached to the same row.
                    self._record({"kind":"CONTINUOUS_GAP_VIOLATION","severity":"VIOLATION",
                        **shared,
                        "violation_duration_s":stats['violation_duration_s'],
                        "moving_violation_duration_s":moving_duration,
                        "moving_minimum_gap_m":moving_gap,
                        "stationary_violation_duration_s":stats['stationary_violation_duration_s'],
                        "moving":moving_duration>1e-9})
                    if moving_duration<=1e-9:
                        # Both aircraft hold a fixed sub-threshold spacing. Recorded
                        # so the deficit is not lost, but not a safety violation:
                        # at standstill the follower has no action that can widen
                        # the gap. The first tick it moves, the moving criterion
                        # above applies instead.
                        self._record({"kind":"STATIONARY_SPACING_DEFICIT","severity":"INFO",
                            **shared,
                            "stationary_duration_s":stats['stationary_violation_duration_s']})
        from .cpff_anomaly_response import collect_response_events
        for row in collect_response_events(step):
            self._record({**row,"severity":"INFO"})
        for event in sorted(step.events,key=lambda e:(e.actual_time_s,e.sequence,e.uav_id)):
            state=states[event.uav_id]
            # G/J/B_L1 identifiers are local to a fulfilled descent. A new
            # post-service episode can execute them again; repetition inside
            # the same episode remains a hard failure.
            identity=(event.uav_id,int(state.energy_episode_id),event.event_id)
            if identity in self.observed: raise ValueError(f"ACTUAL_EVENT_REEMITTED:{identity}")
            self.observed.add(identity)
            plan=state.current_motion_plan
            baseline=None
            if event.event_type in {"G","J"}:
                baseline=plan.get("g_time_s" if event.event_type=="G" else "j_time_s")
            elif event.resource_id:
                target=next((t for t in plan.get("timed_resource_targets",())
                             if str(t["resource_id"])==str(event.resource_id)),None)
                frozen_payload = plan.get("v5_frozen_trajectory") or plan.get("v4_frozen_trajectory") or {}
                flow = str(plan.get("flow") or frozen_payload.get("flow") or "").upper()
                g=plan.get("g_actual_time_s",math.inf)
                role="V" if flow == "V" or ':V5:V:' in event.event_id or ':REENTRY:' in event.event_id or event.actual_time_s>=g-1e-9 else "H"
                if role=="V":
                    window=next((w for w in plan.get("resource_windows",()) if str(w[0])==str(event.resource_id)),None)
                    if window: baseline=window[1 if event.event_type=="RESOURCE_ENTER" else 2]
                elif target:
                    baseline=target["entry_time_s" if event.event_type=="RESOURCE_ENTER" else "exit_time_s"]
                self._resource_event(event,role,state)
            if baseline is not None:
                delta=event.actual_time_s-float(baseline)
                self._record({"kind":event.event_type+"_DEVIATION","severity":"INFO",
                              "uav_id":event.uav_id,"resource_id":event.resource_id,
                              "planned_time_s":baseline,"actual_time_s":event.actual_time_s,
                              "delta_s":delta})
        if self._pending and self.path is not None:
            with self.path.open("a",encoding="utf-8") as stream:
                for row in self._pending: stream.write(json.dumps(row,ensure_ascii=False)+"\n")

    def finalize(self,states,observe_until_s):
        if self.finalized: return
        self.finalized=True
        self._pending=[]
        for state in states:
            plan=state.current_motion_plan
            targets=[]
            if plan.get("schedule_result")=="RELEASED":
                frozen_payload = plan.get("v5_frozen_trajectory") or plan.get("v4_frozen_trajectory") or {}
                flow = str(plan.get("flow") or frozen_payload.get("flow") or "").upper()
                if flow == "V":
                    # E-anchor V5 plans publish E/resource timing.  G and J
                    # are internal trajectory boundaries and have no active
                    # event or audit obligation.
                    if plan.get("e_time_s") is None:
                        # Keep archived G/J plans auditable without allowing
                        # that legacy requirement into the active V5 seam.
                        missing = [key for key in ("g_time_s", "j_time_s") if key not in plan]
                        if missing:
                            raise ValueError(
                                "RELEASED_V_PLAN_MISSING_TIMING:" + ",".join(missing)
                            )
                        targets.extend((kind, None, float(plan[key])) for kind, key in (
                            ("G", "g_time_s"), ("J", "j_time_s")
                        ))
                elif not flow:
                    # Legacy plans predate the explicit flow discriminator.
                    # Preserve their old audit behavior only when the fields
                    # are actually present; current H plans intentionally do
                    # not publish G/J timing fields.
                    targets.extend(
                        (kind, None, float(plan[key]))
                        for kind, key in (("G", "g_time_s"), ("J", "j_time_s"))
                        if key in plan
                    )
                for rid,enter,exit_ in plan.get("resource_windows",()):
                    targets.extend((("RESOURCE_ENTER",str(rid),float(enter)),("RESOURCE_EXIT",str(rid),float(exit_))))
            for target in plan.get("timed_resource_targets",()):
                targets.extend((kind,str(target["resource_id"]),float(target[key]))
                    for kind,key in (("RESOURCE_ENTER","entry_time_s"),("RESOURCE_EXIT","exit_time_s")))
            observed={(e["event_type"],str(e.get("resource_id")) if e.get("resource_id") else None)
                      for e in plan.get("motion_observed_events",())}
            for kind,rid,moment in set(targets):
                if (kind,rid) in observed: continue
                overdue=moment<float(observe_until_s)-1e-6
                self._record({"kind":"TARGET_UNREALIZED_AT_END" if overdue else "TARGET_CENSORED_AT_END",
                              "severity":"INFO","uav_id":state.uav_id,"target_event":kind,
                              "resource_id":rid,"planned_time_s":moment,"observed_until_s":observe_until_s,
                              "lateness_lower_bound_s":max(0.,observe_until_s-moment)})
        if self._pending and self.path is not None:
            with self.path.open("a",encoding="utf-8") as stream:
                for row in self._pending: stream.write(json.dumps(row,ensure_ascii=False)+"\n")

    def _resource_event(self,event,role,state):
        rows=self.uses[str(event.resource_id)]
        if event.event_type=="RESOURCE_EXIT":
            use=next((u for u in reversed(rows) if u["uav_id"]==event.uav_id and u["exit_s"] is None),None)
            if use is None: raise ValueError(f"ACTUAL_EXIT_WITHOUT_ENTER:{event.event_id}")
            use["exit_s"]=event.actual_time_s
            return
        if event.event_type!="RESOURCE_ENTER": return
        current={"uav_id":event.uav_id,"role":role,"entry_s":event.actual_time_s,"exit_s":None,
                 "layer":state.layer,"direction":state.direction,"lane_id":state.lane_id}
        policy=self.config["resource_safety"]
        for prior in rows:
            if prior["uav_id"]==event.uav_id or (role==prior["role"]=="H"): continue
            if role==prior["role"]=="V":
                violated=event.actual_time_s-prior["entry_s"] < float(policy["vv_min_entry_headway_s"])-1e-6
                kind="ACTUAL_VV_ENTRY_HEADWAY_VIOLATION"
            else:
                v_layer = state.layer if role == "V" else prior["layer"]
                h_layer = prior["layer"] if role == "V" else state.layer
                v_direction = state.direction if role == "V" else prior["direction"]
                h_direction = prior["direction"] if role == "V" else state.direction
                if not is_cross_layer_vh_layers(
                    h_layer=h_layer, v_layer=v_layer,
                    h_direction=h_direction, v_direction=v_direction,
                ):
                    continue
                margin=float(policy["vh_v_to_h_margin_s"] if prior["role"]=="V" else policy["vh_h_to_v_margin_s"])
                from traffic_simulation.cmlpm.joint_single_node.conflict_builder import SHARED_RESOURCE_ENTRY_HEADWAY_S
                violated=(prior["exit_s"] is None or event.actual_time_s < prior["exit_s"]+margin-1e-6
                          or event.actual_time_s-prior["entry_s"]<SHARED_RESOURCE_ENTRY_HEADWAY_S-1e-6)
                kind="ACTUAL_VH_RESOURCE_VIOLATION"
            if violated:
                self._record({"kind":kind,"severity":"VIOLATION","uav_id":event.uav_id,
                              "other_uav_id":prior["uav_id"],"resource_id":event.resource_id,
                              "actual_time_s":event.actual_time_s})
        rows.append(current)

    def summary(self):
        stats={}
        for kind,values in self.deviations.items():
            ordered=sorted(values)
            stats[kind]={"count":len(values),"mean_s":sum(values)/len(values),
                         "min_s":ordered[0],"max_s":ordered[-1],
                         "p95_abs_s":sorted(abs(v) for v in values)[int(.95*(len(values)-1))],
                         "late_count":sum(v>1e-6 for v in values),"early_count":sum(v < -1e-6 for v in values)}
        all_abs = sorted(abs(value) for values in self.deviations.values() for value in values)
        if all_abs:
            index = 0.95 * (len(all_abs) - 1)
            left = int(index)
            right = min(left + 1, len(all_abs) - 1)
            weight = index - left
            all_abs_p95 = all_abs[left] + weight * (all_abs[right] - all_abs[left])
        else:
            all_abs_p95 = None
        return {"executor":"MEASURED_KINEMATIC_EXECUTOR_V1","joint_motion_proof":False,
                "observation_counts":dict(self.counts),"safety_violation_counts":dict(self.safety),
                "safety_violation_count":sum(self.safety.values()),"timing_deviations":stats,
                "safety_passed":False if self.safety else True if self.observed_motion_steps else None,
                "observed_motion_steps":self.observed_motion_steps,
                "gap_violation_pair_seconds":self.gap_violation_duration_s,
                "moving_gap_violation_pair_seconds":self.moving_gap_violation_duration_s,
                "minimum_moving_gap_m":None if math.isinf(self.minimum_moving_gap) else self.minimum_moving_gap,
                "moving_gap_violation_pair_count":self.moving_gap_violation_pairs,
                "stationary_spacing_deficit_pair_count":self.stationary_spacing_deficit_pairs,
                "gap_criterion":{
                    "positional":"front - rear < min_gap_m at any time in the tick (registered, unchanged)",
                    "moving":"restricted to intervals where the rear aircraft speed > 0",
                    "stationary":"both aircraft holding a fixed sub-threshold spacing; "
                                 "recorded as STATIONARY_SPACING_DEFICIT, not a moving violation"},
                "gap_recovery_started":self.counts['GAP_RECOVERY_STARTED'],
                "gap_recovery_completed":self.counts['GAP_RECOVERED'],
                "all_deviation_event_count":sum(len(values) for values in self.deviations.values()),
                "all_abs_deviation_p95_s":all_abs_p95,
                "minimum_continuous_mainline_gap_m":None if math.isinf(self.minimum_gap) else self.minimum_gap,
                "actual_resource_open_occupancies":sum(u["exit_s"] is None for rows in self.uses.values() for u in rows)}
