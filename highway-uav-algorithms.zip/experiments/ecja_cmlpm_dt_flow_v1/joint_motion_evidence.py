"""Boundary timing and performance recording for the measured closed loop."""
from __future__ import annotations

from dataclasses import asdict, fields, is_dataclass
from hashlib import sha256
import json
from pathlib import Path
from collections.abc import Mapping
from enum import Enum

# Optional boundary instrumentation. No file I/O or function profiler runs in
# the measured loop. The default ContextVar is None for normal production use.
from contextvars import ContextVar
from contextlib import contextmanager
from functools import wraps
from time import perf_counter, process_time
import csv

_performance = ContextVar("joint_motion_performance", default=None)


class PerformanceRecorder:
    def __init__(self, *, copy_profile_sample_rate: int = 0):
        self.rows = []
        self.stack = []
        self.context = {"step": None, "sim_time_s": None, "execution_mode": "actual"}
        self.origin = perf_counter()
        self.bookkeeping_wall_s = 0.
        self.hot_calls = {}
        # Disabled in normal runs.  A positive rate samples every Nth
        # ``_copy_state`` call and aggregates field-level copy cost without
        # adding per-field timers to the production path.
        self.copy_profile_sample_rate = max(0, int(copy_profile_sample_rate))
        self.copy_profile_call_count = 0
        self.copy_profile = {}

    @contextmanager
    def activate(self):
        token = _performance.set(self)
        try:
            yield self
        finally:
            _performance.reset(token)

    def export(self, directory):
        root = Path(directory)
        root.mkdir(parents=True, exist_ok=True)
        _write_performance_csv(root / "CALLS.csv", self.rows)
        groups = {}
        for row in self.rows:
            key = (row["stage"], row.get("execution_mode"))
            groups.setdefault(key, []).append(row)
        summary = []
        for (stage, mode), rows in groups.items():
            times = sorted(r["wall_s"] for r in rows)
            summary.append({"stage": stage, "execution_mode": mode, "calls": len(rows),
                "wall_s": sum(times), "exclusive_wall_s": sum(r["exclusive_wall_s"] for r in rows),
                "cpu_s": sum(r["cpu_s"] for r in rows),
                "p50_s": times[(len(times)-1)//2], "p95_s": times[int((len(times)-1)*.95)],
                "max_s": times[-1], "exceptions": sum(r["status"] == "EXCEPTION" for r in rows)})
        summary.sort(key=lambda r: -r["exclusive_wall_s"])
        _write_performance_csv(root / "SUMMARY.csv", summary)
        if self.copy_profile:
            profile_rows = []
            for (scope, field), value in sorted(self.copy_profile.items()):
                samples = value["samples"]
                profile_rows.append({
                    "scope": scope, "field": field,
                    "samples": samples,
                    "sample_rate": self.copy_profile_sample_rate,
                    "estimated_calls": samples * self.copy_profile_sample_rate,
                    "sample_wall_s": value["wall_s"],
                    "mean_sample_us": value["wall_s"] * 1e6 / samples if samples else 0.0,
                    "sample_size_bytes": value["size_bytes"],
                    "mean_size_bytes": value["size_bytes"] / samples if samples else 0.0,
                })
            _write_performance_csv(root / "COPY_PROFILE.csv", profile_rows)
        steps = [dict(r) for r in self.rows if r["stage"] == "loop.step"]
        for row in steps:
            for child in self.rows:
                if child["parent_id"] == row["call_id"]:
                    row[child["stage"] + "_s"] = child["wall_s"]
        _write_performance_csv(root / "STEPS.csv", steps)
        worst = sorted(self.rows, key=lambda r: -r["wall_s"])[:100]
        payload = {"schema": "BOUNDARY_PERFORMANCE_V1", "summary": summary,
            "bookkeeping_wall_s": self.bookkeeping_wall_s, "call_count": len(self.rows),
            "worst_calls": worst,
            "semantics": "Inclusive stages overlap; exclusive time subtracts direct children. CPU is process CPU. Bookkeeping is measured separately and remains within unchanged wall deadlines."}
        (root / "PERFORMANCE.json").write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        (root / "WORST_CALLS.json").write_text(json.dumps(worst, indent=2, ensure_ascii=False), encoding="utf-8")
        return payload

    def profile_hot_calls(self, directory, limit=3):
        """Replay only pure solve/audit seams; never publish replayed results."""
        import cProfile
        import pstats
        root = Path(directory)
        root.mkdir(parents=True, exist_ok=True)
        reports = []
        token = _performance.set(None)
        try:
            selected = sorted(self.hot_calls.items(), key=lambda item: -item[1][0])[:limit]
            for stage, (wall, fn, args, kwargs, original) in selected:
                profiler = cProfile.Profile()
                start = perf_counter()
                try:
                    result = profiler.runcall(fn, *args, **kwargs)
                    outcome = _performance_outcome(result)
                except Exception as error:
                    outcome = {"exception": type(error).__name__, "detail": str(error)}
                elapsed = perf_counter()-start
                name = stage.replace(".", "_")
                profiler.dump_stats(str(root / (name + ".prof")))
                stats = pstats.Stats(profiler)
                functions = [{"file": k[0], "line": k[1], "function": k[2],
                    "primitive_calls": v[0], "calls": v[1], "total_s": v[2], "cumulative_s": v[3]}
                    for k, v in stats.stats.items()]
                functions.sort(key=lambda r: -r["cumulative_s"])
                _write_performance_csv(root / (name + ".csv"), functions)
                reports.append({"stage": stage, "original_wall_s": wall, "profile_wall_s": elapsed,
                    "original": original, "profile_outcome": outcome,
                    "same_outcome": original == outcome, "top_functions": functions[:30]})
        finally:
            _performance.reset(token)
        (root / "CPROFILE.json").write_text(json.dumps(reports, indent=2), encoding="utf-8")
        return reports


def _write_performance_csv(path, rows):
    keys = list(dict.fromkeys(k for row in rows for k in row))
    with path.open("w", newline="", encoding="utf-8-sig") as stream:
        writer = csv.DictWriter(stream, fieldnames=keys)
        writer.writeheader()
        for row in rows:
            writer.writerow({k: json.dumps(v, ensure_ascii=False) if isinstance(v, (dict, list, tuple)) else v
                             for k, v in row.items()})


def _performance_outcome(result):
    return {name: getattr(result, name) for name in ("status", "reason", "passed", "termination", "checker_passed")
            if hasattr(result, name)}


def performance_context(**values):
    recorder = _performance.get()
    if recorder is not None:
        recorder.context.update(values)


def performance_metrics(**values):
    recorder = _performance.get()
    if recorder is not None and recorder.stack:
        recorder.stack[-1]["row"].update(values)


def copy_profile_sample():
    """Return the active recorder when this copy call should be sampled."""
    recorder = _performance.get()
    if recorder is None or recorder.copy_profile_sample_rate <= 0:
        return None
    recorder.copy_profile_call_count += 1
    if recorder.copy_profile_call_count % recorder.copy_profile_sample_rate:
        return None
    return recorder


def record_copy_profile(recorder, field: str, wall_s: float, size_bytes: int) -> None:
    """Aggregate one sampled field copy under its enclosing stage."""
    if recorder is None:
        return
    scope = recorder.stack[-1]["row"].get("stage", "unscoped") if recorder.stack else "unscoped"
    key = (str(scope), str(field))
    value = recorder.copy_profile.setdefault(key, {"samples": 0, "wall_s": 0.0, "size_bytes": 0})
    value["samples"] += 1
    value["wall_s"] += float(wall_s)
    value["size_bytes"] += int(size_bytes)


@contextmanager
def performance_span(stage, **metadata):
    recorder = _performance.get()
    if recorder is None:
        yield
        return
    overhead = perf_counter()
    inherited = {}
    for frame in recorder.stack:
        inherited.update({k: v for k, v in frame["row"].items() if k in {
            "candidate_id", "node_id", "state_version", "uav_count", "event_count",
            "fixed_boundary_count", "pair_count", "variables", "equalities", "inequalities",
            "cuts", "knots", "new_member_count", "continuation_member_count"}})
    row = {"call_id": len(recorder.rows), "parent_id": recorder.stack[-1]["row"]["call_id"] if recorder.stack else None,
           "stage": stage, **recorder.context, **inherited, **metadata, "status": "RETURNED"}
    recorder.rows.append(row)
    entry = {"row": row, "child_wall": 0., "child_cpu": 0.}
    recorder.stack.append(entry)
    recorder.bookkeeping_wall_s += perf_counter()-overhead
    wall, cpu = perf_counter(), process_time()
    row["start_offset_s"] = wall-recorder.origin
    try:
        yield
    except BaseException as error:
        row.update(status="EXCEPTION", exception=type(error).__name__, detail=str(error))
        raise
    finally:
        elapsed, cpu_elapsed = perf_counter()-wall, process_time()-cpu
        overhead = perf_counter()
        row.update(wall_s=elapsed, cpu_s=cpu_elapsed,
                   exclusive_wall_s=max(0., elapsed-entry["child_wall"]),
                   exclusive_cpu_s=max(0., cpu_elapsed-entry["child_cpu"]))
        recorder.stack.pop()
        if recorder.stack:
            recorder.stack[-1]["child_wall"] += elapsed
            recorder.stack[-1]["child_cpu"] += cpu_elapsed
        recorder.bookkeeping_wall_s += perf_counter()-overhead


def measured(stage, *, capture=False):
    def decorate(fn):
        @wraps(fn)
        def call(*args, **kwargs):
            recorder = _performance.get()
            if recorder is None:
                return fn(*args, **kwargs)
            with performance_span(stage):
                for value in args:
                    if hasattr(value, "fixed_motion") and hasattr(value, "candidate_id"):
                        performance_metrics(candidate_id=value.candidate_id, uav_count=len(value.states),
                            fixed_boundary_count=len(value.fixed_motion), event_count=len(value.events),
                            fixed_prefix_piece_count=sum(map(len, value.fixed_prefixes.values())),
                            cross_node_pair_count=len(value.cross_node_pairs), state_version=getattr(value, "state_version", None))
                    elif hasattr(value, "sim_time_s") and hasattr(value, "states"):
                        performance_metrics(state_version=value.version, uav_count=len(value.states),
                                            call_sim_time_s=value.sim_time_s)
                for value in args:
                    if hasattr(value, "payload") and hasattr(value, "read"):
                        performance_metrics(v_new_count=len(value.read.v_new), h_count=len(value.read.h), timing_event_count=len(value.payload.get("events", ())), resource_use_count=len(value.payload.get("resource_uses", ())))
                result = fn(*args, **kwargs)
                outcome = _performance_outcome(result)
                performance_metrics(outcome=outcome)
                if hasattr(result, "metrics"):
                    performance_metrics(search_metrics=dict(result.metrics))
                if capture:
                    wall = perf_counter() - recorder.origin - recorder.stack[-1]["row"]["start_offset_s"]
                    prior = recorder.hot_calls.get(stage)
                    if prior is None or wall > prior[0]:
                        recorder.hot_calls[stage] = (wall, fn, args, dict(kwargs), outcome)
                return result
        return call
    return decorate


def performance_call(stage, fn, *args, **kwargs):
    if _performance.get() is None:
        return fn(*args, **kwargs)
    with performance_span(stage):
        return fn(*args, **kwargs)


def rehearsal_context(fn):
    @wraps(fn)
    def call(*args, **kwargs):
        recorder = _performance.get()
        if recorder is None:
            return fn(*args, **kwargs)
        previous = recorder.context.get("execution_mode")
        recorder.context["execution_mode"] = "rehearsal"
        try:
            return fn(*args, **kwargs)
        finally:
            recorder.context["execution_mode"] = previous
    return call


def benchmark_performance_overhead(repeats=20000):
    @measured("benchmark.noop")
    def noop():
        return None
    def baseline():
        return None
    start = perf_counter()
    for _ in range(repeats):
        baseline()
    plain = perf_counter()-start
    start = perf_counter()
    for _ in range(repeats):
        noop()
    disabled = perf_counter()-start
    recorder = PerformanceRecorder()
    start = perf_counter()
    with recorder.activate():
        for _ in range(repeats):
            noop()
    enabled = perf_counter()-start
    return {"repeats": repeats, "plain_s": plain, "disabled_s": disabled, "enabled_s": enabled,
            "disabled_extra_per_call_s": (disabled-plain)/repeats,
            "enabled_extra_per_call_s": (enabled-plain)/repeats,
            "bookkeeping_s": recorder.bookkeeping_wall_s}

