"""Measured ascent using the production descent transfer generator.

The registered descent frame is rotated around its shaft to the downstream
mainline segment. A newly generated descent clock is reversed to obtain an
upward curve with the configured forward merge speed. No guessed transition
length, access duration or independent motion capability is used.
"""
from copy import deepcopy
import math

import numpy as np

from build_airspace.corridor.network_contract_geometry import point_at_arc
from configs.mission_config import DEFAULT_UAV_TYPE_SPECS
from configs.runtime_parameters import vehicle_motion
from ecja_qsap.zhou_transfer import generate_transfer
from g25_param_env.extractor import project_station_xy
from .descent_trajectory import trajectory_state, _audit_hermite_motion, trajectory_resource_windows

VERSION = 'REGISTERED_DESCENT_REUSED_ASCENT_V1'
THIN_VERSION = 'REGISTERED_THIN_ASCENT_V1'


def _bounded_stop_go_segments(*, start_xyz, end_xyz, max_speed_mps,
                               acceleration_mps2, phase_type, start_s=0.0):
    """Build a zero-speed-to-zero-speed bounded straight-line motion."""
    start = np.asarray(start_xyz, dtype=float)
    end = np.asarray(end_xyz, dtype=float)
    delta = end - start
    distance = float(np.linalg.norm(delta))
    speed = float(max_speed_mps)
    acceleration = float(acceleration_mps2)
    if distance <= 1e-9 or speed <= 0.0 or acceleration <= 0.0:
        raise ValueError('REENTRY_STAGE_MOTION_INPUT_INVALID')
    direction = delta / distance
    ramp = speed / acceleration
    ramp_distance = 0.5 * acceleration * ramp * ramp
    if 2.0 * ramp_distance > distance + 1e-9:
        peak = math.sqrt(distance * acceleration)
        ramp = peak / acceleration
        ramp_distance = 0.5 * acceleration * ramp * ramp
        cruise = 0.0
        peak_speed = peak
    else:
        cruise = (distance - 2.0 * ramp_distance) / speed
        peak_speed = speed
    segments = []
    cursor = float(start_s)
    first = start.copy()
    first_end = first + direction * ramp_distance
    segments.append({
        'phase_type': phase_type,
        'point0_xyz': first.tolist(), 'point1_xyz': first_end.tolist(),
        'velocity0_xyz': [0.0, 0.0, 0.0],
        'velocity1_xyz': (direction * peak_speed).tolist(),
        'start_s': cursor, 'end_s': cursor + ramp,
    })
    cursor += ramp
    if cruise > 1e-9:
        cruise_end = first_end + direction * (peak_speed * cruise)
        segments.append({
            'phase_type': phase_type,
            'point0_xyz': first_end.tolist(), 'point1_xyz': cruise_end.tolist(),
            'velocity0_xyz': (direction * peak_speed).tolist(),
            'velocity1_xyz': (direction * peak_speed).tolist(),
            'start_s': cursor, 'end_s': cursor + cruise,
        })
        cursor += cruise
    final_start = end - direction * ramp_distance
    segments.append({
        'phase_type': phase_type,
        'point0_xyz': final_start.tolist(), 'point1_xyz': end.tolist(),
        'velocity0_xyz': (direction * peak_speed).tolist(),
        'velocity1_xyz': [0.0, 0.0, 0.0],
        'start_s': cursor, 'end_s': cursor + ramp,
    })
    return segments, float(cursor + ramp)


def _stage_trajectory(*, segments, stage_kind, start_xyz, end_xyz, duration_s):
    """Attach the same immutable audit fields used by registered trajectories."""
    return {
        'version': 'REENTRY_STAGE_PROFILE_V1',
        'stage_kind': str(stage_kind),
        'segments': segments,
        'duration_s': float(duration_s),
        'start_xyz': list(map(float, start_xyz)),
        'end_xyz': list(map(float, end_xyz)),
        'resource_windows_offsets': {},
        'kinematic_audit': _audit_hermite_motion(segments),
    }


def _node_xyz(network, node_id):
    nodes = getattr(network, 'service_nodes', None) or getattr(network, 'nodes', ())
    node = next(node for node in nodes if str(node['node_id']) == str(node_id))
    return np.asarray(node['facility_xyz'], dtype=float)


def build_ground_landing_trajectory(network, interface, config, vehicle_type):
    """Build the physical B_L1-to-facility landing path at zero speed endpoints."""
    access = registered_reentry_access(network, interface)
    node_xyz = _node_xyz(network, interface['service_node_id'])
    start = np.asarray((access['descent_column_station_m'], node_xyz[1], 50.0), dtype=float)
    end = np.asarray((node_xyz[0], node_xyz[1], node_xyz[2]), dtype=float)
    if np.linalg.norm(start[:2] - end[:2]) > 1e-6:
        raise ValueError('REENTRY_GROUND_LANDING_AXIS_MISMATCH')
    spec = DEFAULT_UAV_TYPE_SPECS[vehicle_type]
    segments, duration = _bounded_stop_go_segments(
        start_xyz=start, end_xyz=end,
        max_speed_mps=float(config['motion']['vertical_speed_mps']),
        acceleration_mps2=float(spec['max_vertical_acceleration_mps2']),
        phase_type='REENTRY_LAND_TO_GROUND',
    )
    return _stage_trajectory(
        segments=segments, stage_kind='LAND_TO_GROUND',
        start_xyz=start, end_xyz=end, duration_s=duration,
    )


def build_ground_access_trajectory(network, interface, config, vehicle_type):
    """Build ground transfer to the registered ascent column and 0-to-50 m climb."""
    access = registered_reentry_access(network, interface)
    facility = _node_xyz(network, interface['service_node_id'])
    column = np.asarray((access['column_station_m'], facility[1], 0.0), dtype=float)
    top = column.copy(); top[2] = 50.0
    spec = DEFAULT_UAV_TYPE_SPECS[vehicle_type]
    horizontal, transfer_end = _bounded_stop_go_segments(
        start_xyz=facility, end_xyz=column,
        max_speed_mps=float(vehicle_motion(config, vehicle_type)['max_speed_mps']),
        acceleration_mps2=float(vehicle_motion(config, vehicle_type)['max_acceleration_mps2']),
        phase_type='REENTRY_GROUND_TRANSFER',
    )
    vertical, climb_end = _bounded_stop_go_segments(
        start_xyz=column, end_xyz=top,
        max_speed_mps=float(config['motion']['vertical_speed_mps']),
        acceleration_mps2=float(spec['max_vertical_acceleration_mps2']),
        phase_type='REENTRY_ASCENT_TO_50M', start_s=transfer_end,
    )
    return _stage_trajectory(
        segments=horizontal + vertical, stage_kind='ASCENT_TO_50M',
        start_xyz=facility, end_xyz=top, duration_s=climb_end,
    )


def registered_reentry_access(network, interface):
    """Derive the downstream entry frame without changing registered geometry."""
    frame = network.formal_geometry[str(interface['interface_id'])]
    line = next(m for m in network.mainlines
                if m['mainline_id'] == interface['mainline_id'])
    path = line['path']
    descent_j = np.asarray(frame['zhou_j_xyz'], dtype=float)
    g = np.asarray(frame['zhou_g_xyz'], dtype=float)
    descent_column_s, error, _, _ = project_station_xy(path['centerline_xyz'], descent_j[:2])
    if error > 1e-5:
        raise ValueError('REENTRY_SHAFT_OFF_REGISTERED_MAINLINE')
    ascent = frame.get('reentry_ascent')
    if not isinstance(ascent, dict):
        # The registered G25 fixture predates the separate-column extension.
        # Keep that input readable for isolated tests; production synthetic
        # scenes carry an explicit reentry_ascent block and never use this
        # compatibility branch.
        if not str(getattr(network, 'contract_version', '')).startswith('G25-'):
            raise ValueError('REENTRY_ASCENT_GEOMETRY_REQUIRED')
        ascent = {
            'column_station_m': descent_column_s,
            'column_separation_m': 0.0,
            'column_id': interface['column_id'],
            'resource_ids': {},
        }
    required = ('column_station_m', 'column_separation_m', 'column_id', 'resource_ids')
    if any(key not in ascent for key in required):
        raise ValueError('REENTRY_ASCENT_GEOMETRY_INCOMPLETE')
    column_s = float(ascent['column_station_m'])
    separation = column_s-descent_column_s
    if abs(separation-float(ascent['column_separation_m'])) > 1e-6 or separation < 0:
        raise ValueError('REENTRY_COLUMN_SEPARATION_MISMATCH')
    j = descent_j.copy()
    j[:2] = np.asarray(point_at_arc(path,column_s))[:2]
    run = float(np.linalg.norm(g[:2]-descent_j[:2]))
    merge_s = column_s + run
    if merge_s >= float(path['length_m']):
        raise ValueError('REENTRY_MERGE_OUTSIDE_MAINLINE')
    merge_xyz = np.asarray(point_at_arc(path, merge_s), dtype=float)
    target = merge_xyz[:2]-j[:2]
    if abs(float(np.linalg.norm(target))-run) > 1e-5:
        raise ValueError('REENTRY_DOWNSTREAM_SEGMENT_NOT_STRAIGHT')
    # Registered G is upstream of J; its rotated image is downstream of J.
    source = g[:2]-descent_j[:2]
    angle = math.atan2(target[1],target[0])-math.atan2(source[1],source[0])
    c,s = math.cos(angle),math.sin(angle)
    rotation = np.asarray(((c,-s,0.),(s,c,0.),(0.,0.,1.)))
    def transform(point):
        return (j+rotation@(np.asarray(point,dtype=float)-descent_j)).tolist()
    cells=[]
    for original in frame['zhou_allowed_cells']:
        cell=deepcopy(original)
        cell['center_xyz']=transform(cell['center_xyz'])
        cell['basis_columns']=(rotation@np.asarray(cell['basis_columns'])).tolist()
        cells.append(cell)
    tangent=np.asarray(frame['zhou_mainline_tangent_xyz'],dtype=float)
    access={'zhou_g_xyz':merge_xyz.tolist(),'zhou_j_xyz':j.tolist(),
            'zhou_mainline_tangent_xyz':(rotation@tangent).tolist(),
            'zhou_allowed_cells':cells}
    return {'access':access,'column_station_m':column_s,'merge_station_m':merge_s,
            'descent_column_station_m':descent_column_s,'column_separation_m':separation,
            'ascent_column_id':ascent['column_id'],
            'resource_ids':ascent['resource_ids'],
            'mainline_path':deepcopy(path)}


def _thin_ascent_segments(*, bottom: float, top: float, column_xyz,
                           merge_xyz, climb_speed: float,
                           vertical_acceleration: float,
                           merge_speed: float, horizontal_acceleration: float,
                           start_s: float = 0.0):
    """Build the V5 thin executor's deterministic climb/merge profile.

    This is the active fallback for the separate-column synthetic scene.  It
    uses only registered column/merge geometry and bounded piecewise kinematics;
    it does not search the retired G/J transfer family.
    """
    import numpy as np

    bottom = float(bottom)
    top = float(top)
    climb_speed = float(climb_speed)
    vertical_acceleration = float(vertical_acceleration)
    merge_speed = float(merge_speed)
    horizontal_acceleration = float(horizontal_acceleration)
    # Every working point must own its storage.  The registered geometry is
    # reused by the caller; mutating the input column while constructing one
    # segment used to corrupt later endpoints and produced zero-length climb
    # segments with impossible Hermite accelerations.
    column = np.asarray(column_xyz, dtype=float).copy()
    merge = np.asarray(merge_xyz, dtype=float).copy()
    height = top - bottom
    if height <= 0.0 or climb_speed <= 0.0 or vertical_acceleration <= 0.0:
        raise ValueError('THIN_ASCENT_VERTICAL_INPUT_INVALID')
    if merge_speed <= 0.0 or horizontal_acceleration <= 0.0:
        raise ValueError('THIN_ASCENT_HORIZONTAL_INPUT_INVALID')
    run_vector = merge[:2] - column[:2]
    run = float(np.linalg.norm(run_vector))
    if run <= 1e-9:
        raise ValueError('THIN_ASCENT_MERGE_DISTANCE_INVALID')
    direction = run_vector / run

    ramp = climb_speed / vertical_acceleration
    ramp_height = 0.5 * vertical_acceleration * ramp * ramp
    if height < 2.0 * ramp_height - 1e-9:
        peak = math.sqrt(max(0.0, height * vertical_acceleration))
        ramp = peak / vertical_acceleration
        ramp_height = 0.5 * vertical_acceleration * ramp * ramp
        climb_speed = peak
    constant_height = max(0.0, height - 2.0 * ramp_height)
    vertical_constant = constant_height / max(climb_speed, 1e-9)
    vertical_total = 2.0 * ramp + vertical_constant
    points = np.asarray(column, dtype=float).copy()
    points[2] = bottom
    top_point = np.asarray(column, dtype=float).copy()
    top_point[2] = top
    segments = [{
        'phase_type': 'REENTRY_CLIMB', 'point0_xyz': points.tolist(),
        'point1_xyz': (points + np.asarray((0.0, 0.0, ramp_height))).tolist(),
        'velocity0_xyz': [0.0, 0.0, 0.0],
        'velocity1_xyz': [0.0, 0.0, climb_speed],
        'start_s': start_s, 'end_s': start_s + ramp,
    }]
    elapsed = start_s + ramp
    if vertical_constant > 1e-9:
        mid = np.asarray(column, dtype=float).copy()
        mid[2] = bottom + ramp_height
        mid_end = np.asarray(column, dtype=float).copy()
        mid_end[2] = top - ramp_height
        segments.append({
            'phase_type': 'REENTRY_CLIMB', 'point0_xyz': mid.tolist(),
            'point1_xyz': mid_end.tolist(),
            'velocity0_xyz': [0.0, 0.0, climb_speed],
            'velocity1_xyz': [0.0, 0.0, climb_speed],
            'start_s': elapsed, 'end_s': elapsed + vertical_constant,
        })
        elapsed += vertical_constant
    down_start = np.asarray(column, dtype=float).copy()
    down_start[2] = top - ramp_height
    segments.append({
        'phase_type': 'REENTRY_CLIMB', 'point0_xyz': down_start.tolist(),
        'point1_xyz': top_point.tolist(),
        'velocity0_xyz': [0.0, 0.0, climb_speed],
        'velocity1_xyz': [0.0, 0.0, 0.0],
        'start_s': elapsed, 'end_s': elapsed + ramp,
    })
    elapsed += ramp

    effective_acceleration = max(horizontal_acceleration, 1e-6)
    acceleration_time = merge_speed / effective_acceleration
    acceleration_distance = 0.5 * effective_acceleration * acceleration_time ** 2
    if acceleration_distance > run + 1e-9:
        raise ValueError('THIN_ASCENT_TRANSITION_TOO_SHORT')
    accel_end = np.asarray(column, dtype=float) + np.asarray((
        direction[0] * acceleration_distance,
        direction[1] * acceleration_distance,
        top - column[2],
    ))
    segments.append({
        'phase_type': 'REENTRY_TRANSFER', 'point0_xyz': top_point.tolist(),
        'point1_xyz': accel_end.tolist(),
        'velocity0_xyz': [0.0, 0.0, 0.0],
        'velocity1_xyz': [direction[0] * merge_speed, direction[1] * merge_speed, 0.0],
        'start_s': elapsed, 'end_s': elapsed + acceleration_time,
    })
    elapsed += acceleration_time
    cruise_distance = max(0.0, run - acceleration_distance)
    cruise_time = cruise_distance / merge_speed
    if cruise_time > 1e-9:
        segments.append({
            'phase_type': 'REENTRY_TRANSFER', 'point0_xyz': accel_end.tolist(),
            'point1_xyz': merge.tolist(),
            'velocity0_xyz': [direction[0] * merge_speed, direction[1] * merge_speed, 0.0],
            'velocity1_xyz': [direction[0] * merge_speed, direction[1] * merge_speed, 0.0],
            'start_s': elapsed, 'end_s': elapsed + cruise_time,
        })
        elapsed += cruise_time
    return segments, vertical_total, float(elapsed), {
        'height_m': height, 'ramp_time_s': ramp,
        'peak_speed_mps': climb_speed, 'ramp_height_m': ramp_height,
        'constant_height_m': constant_height,
    }


def _thin_vertical_time(profile, distance_m: float, acceleration_mps2: float) -> float:
    """Elapsed time to reach an altitude on the monotone thin climb."""
    distance = min(max(float(distance_m), 0.0), float(profile['height_m']))
    ramp = float(profile['ramp_time_s'])
    peak = float(profile['peak_speed_mps'])
    ramp_height = float(profile['ramp_height_m'])
    constant_height = float(profile['constant_height_m'])
    if distance <= ramp_height + 1e-9:
        return math.sqrt(max(0.0, 2.0 * distance / max(acceleration_mps2, 1e-9)))
    if distance <= ramp_height + constant_height + 1e-9:
        return ramp + (distance - ramp_height) / max(peak, 1e-9)
    remaining = distance - ramp_height - constant_height
    discriminant = max(0.0, peak * peak - 2.0 * acceleration_mps2 * remaining)
    return ramp + constant_height / max(peak, 1e-9) + (
        peak - math.sqrt(discriminant)
    ) / max(acceleration_mps2, 1e-9)


def build_ascent_template(network, interface, config, vehicle_type, *, merge_speed_mps=None):
    """Build a relative-time profile from actual registered G/J geometry."""
    geometry=registered_reentry_access(network,interface)
    access=geometry['access'];cells=access['zhou_allowed_cells']
    j=np.asarray(access['zhou_j_xyz']);column_s=geometry['column_station_m']
    merge_s=geometry['merge_station_m'];path=geometry['mainline_path']
    limits=vehicle_motion(config,vehicle_type)
    merge_speed=limits['max_speed_mps'] if merge_speed_mps is None else float(merge_speed_mps)
    if not math.isfinite(merge_speed) or not 0. < merge_speed <= limits['max_speed_mps']:
        raise ValueError('REENTRY_MERGE_SPEED_OUTSIDE_PROJECT_LIMITS')
    spec=DEFAULT_UAV_TYPE_SPECS[vehicle_type]
    try:
        result=generate_transfer(access,entry_speed_mps=merge_speed,
            max_speed_mps=limits['max_speed_mps'],
            max_acceleration_mps2=limits['max_acceleration_mps2'],
            vertical_speed_mps=limits['climb_speed_mps'],
            max_descent_speed_mps=limits['climb_speed_mps'],
            max_vertical_acceleration_mps2=float(spec['max_vertical_acceleration_mps2']))
    except ValueError as error:
        if str(error) != 'ZHOU_TRANSFER_GENERATION_FAILED':
            raise
        result = None
    bottom=float(config['network']['b_l1_z_m'])
    height=float(j[2])-bottom
    if height < 0.:
        raise ValueError('REENTRY_SHAFT_TOP_BELOW_SERVICE_BOUNDARY')
    # Leave the stopped service state continuously, using the same registered
    # vehicle acceleration capability; no new takeoff parameter is introduced.
    vertical_acceleration=min(float(spec['max_vertical_acceleration_mps2']),limits['max_acceleration_mps2'])
    if result is None:
        thin_top = float(access['zhou_g_xyz'][2])
        segments, climb, duration, thin_vertical = _thin_ascent_segments(
            bottom=bottom, top=thin_top, column_xyz=j,
            merge_xyz=access['zhou_g_xyz'], climb_speed=limits['climb_speed_mps'],
            vertical_acceleration=vertical_acceleration,
            merge_speed=merge_speed,
            horizontal_acceleration=limits['max_acceleration_mps2'])
        generator_method = THIN_VERSION
    else:
        points=result['execution_path_xyz'];times=result['execution_elapsed_s'];velocities=result['execution_velocity_xyz']
        ramp=limits['climb_speed_mps']/vertical_acceleration
        ramp_height=.5*vertical_acceleration*ramp*ramp
        if height < ramp_height-1e-6:
            raise ValueError('REENTRY_CLIMB_ACCELERATION_DISTANCE_INSUFFICIENT')
        climb=ramp+(height-ramp_height)/limits['climb_speed_mps']
        segments=[]
        segments.append({'phase_type':'REENTRY_CLIMB','point0_xyz':[j[0],j[1],bottom],
            'point1_xyz':[j[0],j[1],bottom+ramp_height],
            'velocity0_xyz':[0.,0.,0.],'velocity1_xyz':[0.,0.,limits['climb_speed_mps']],
            'start_s':0.,'end_s':ramp})
        if climb > ramp+1e-9:
            segments.append({'phase_type':'REENTRY_CLIMB','point0_xyz':[j[0],j[1],bottom+ramp_height],
                'point1_xyz':j.tolist(),'start_s':ramp,'end_s':climb})
        duration=float(times[-1])
        for index in range(len(points)-1,0,-1):
            segments.append({'phase_type':'REENTRY_TRANSFER',
                'point0_xyz':points[index],'point1_xyz':points[index-1],
                'velocity0_xyz':[-v for v in velocities[index]],
                'velocity1_xyz':[-v for v in velocities[index-1]],
                'start_s':climb+duration-float(times[index]),
                'end_s':climb+duration-float(times[index-1])})
        generator_method = result['method']
    trajectory_duration = float(segments[-1]['end_s'])
    trajectory={'version':VERSION,'segments':segments,'j_offset_s':climb,
        'generator_method':generator_method,'geometry_source':str(interface['interface_id']),
        'source_network_sha256':network.source_sha256,'derived_allowed_cells':cells,
        'column_station_m':column_s,'merge_station_m':merge_s,
        'merge_speed_mps':merge_speed,'duration_s':trajectory_duration,
        'mainline_path':deepcopy(path)}
    trajectory['descent_column_station_m']=geometry['descent_column_station_m']
    trajectory['column_separation_m']=geometry['column_separation_m']
    trajectory['ascent_column_id']=geometry['ascent_column_id']
    from .crossing_resource_mapping import build_crossing_resource_maps
    crossings=build_crossing_resource_maps(network)
    trajectory['geometries']={geometry['resource_ids'].get(m.segment_resource_id,m.segment_resource_id):{'type':'FINITE_CYLINDER',
        'axis_xy':[float(j[0]),float(j[1])],'radius_m':m.shaft_radius_m,
        'z_min_m':m.z_low_m,'z_max_m':m.z_high_m}
        for m in crossings.values() if m.node_id==interface['service_node_id']
        and m.direction==interface['direction'] and m.layer_index<=int(interface['source_layer'][1:])}
    if result is None:
        windows = {}
        for resource, resource_geometry in trajectory['geometries'].items():
            low = max(bottom, float(resource_geometry['z_min_m']))
            high = min(
                float(access['zhou_g_xyz'][2]) if result is None else float(j[2]),
                float(resource_geometry['z_max_m']),
            )
            if high <= low + 1e-9:
                raise ValueError(f'THIN_ASCENT_RESOURCE_BAND_INVALID:{resource}')
            windows[str(resource)] = (
                _thin_vertical_time(thin_vertical, low - bottom, vertical_acceleration),
                _thin_vertical_time(thin_vertical, high - bottom, vertical_acceleration),
            )
        trajectory['resource_windows_offsets'] = windows
    else:
        trajectory['resource_windows_offsets']=trajectory_resource_windows(trajectory)
    audit=_audit_hermite_motion(segments)
    for key,bound in [('max_speed_mps',limits['max_speed_mps']),
                      ('max_acceleration_mps2',limits['max_acceleration_mps2']),
                      ('max_vertical_acceleration_mps2',float(spec['max_vertical_acceleration_mps2']))]:
        if audit[key] > bound+1e-6:
            raise ValueError('REENTRY_TRAJECTORY_CAPABILITY:'+key)
    trajectory['kinematic_audit']={**audit,'allowed':{
        'max_speed_mps':limits['max_speed_mps'],
        'max_acceleration_mps2':limits['max_acceleration_mps2'],
        'max_vertical_acceleration_mps2':float(spec['max_vertical_acceleration_mps2'])}}
    return trajectory


def ascent_state(trajectory, elapsed):
    point,speed=trajectory_state(trajectory,elapsed)
    station=project_station_xy(trajectory['mainline_path']['centerline_xyz'],point[:2])[0]
    return point,station,speed
