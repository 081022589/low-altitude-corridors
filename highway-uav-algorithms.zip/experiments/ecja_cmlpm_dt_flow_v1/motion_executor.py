"""Common geometric events and the sole measured closed-loop executor.

Published timing targets are immutable comparison baselines. The measured
kinematic executor advances actual traffic and records deviations. No frozen
motion witness, legacy scalar descent or old executor fallback is available.
"""

from __future__ import annotations
from .joint_motion_evidence import measured, performance_span, performance_call, performance_metrics, performance_context

from dataclasses import dataclass, field, replace
import math
from typing import Any, Iterable, Mapping

from .crossing_resource_mapping import build_crossing_resource_maps
from .existing_v_continuation import ExecutedEvent
from .network_loader import RegisteredG25
from .numeric_motion import MotionLimits, MotionPiece, TickProfile, stop_start_limits
from .simulation_state import FlightState, TrafficSnapshot, UAVState
from .scheduled_speed import (
    MotionPlanRejected,
    TIME_TOL_S,
)
from .descent_trajectory import trajectory_state, trajectory_resource_windows
from .trigger_rules import commit_distance_m

MOTION_EXECUTOR_VERSION = "MEASURED_KINEMATIC_EXECUTOR_V1"
JOINT_CONTROL_VERSION = "MEASURED_KINEMATIC_EXECUTOR_V1"

_TERMINAL = frozenset(
    {FlightState.COMPLETED, FlightState.EXITED, FlightState.HORIZON_CENSORED}
)
_TIME_TOL = 1e-9


class MotionExecutionBlocked(RuntimeError):
    def __init__(self, code: str, detail: str = "") -> None:
        super().__init__(f"{code}:{detail}" if detail else code)
        self.code = code
        self.detail = detail


@dataclass(frozen=True)
class MotionStep:
    """One execution period: the advanced traffic state and what it observed."""

    t_from: float
    t_to: float
    states: tuple[UAVState, ...]
    events: tuple[ExecutedEvent, ...]
    following_response_edges: tuple[tuple[str, str], ...] = ()
    mainline_profiles: Mapping[str, TickProfile] = field(default_factory=dict)
    substeps: tuple = ()

    def events_for(self, uav_id: str) -> tuple[ExecutedEvent, ...]:
        return tuple(item for item in self.events if item.uav_id == uav_id)


def resource_z_bounds(network: RegisteredG25) -> dict[str, tuple[float, float]]:
    """``{resource_id: (z_high, z_low)}`` for each registered crossing band."""

    return {
        item.segment_resource_id: (float(item.z_high_m), float(item.z_low_m))
        for item in build_crossing_resource_maps(network).values()
    }


def b_l1_z_m(network: RegisteredG25) -> float:
    """Common registered lower endpoint of every G25 descent column."""

    lows = {
        float(min(resource["start_xyz"][2], resource["end_xyz"][2]))
        for resource in network.resources
        if str(resource.get("segment")) == "V10"
    }
    if len(lows) != 1:
        raise MotionExecutionBlocked("B_L1_GEOMETRY_AMBIGUOUS", str(sorted(lows)))
    return next(iter(lows))


def _crossed(before: float, after: float, boundary: float) -> bool:
    return (before - boundary) * (after - boundary) <= 0.0 and abs(after - before) > 0.0


def _interpolate(t0: float, v0: float, t1: float, v1: float, boundary: float) -> float:
    if abs(v1 - v0) <= _TIME_TOL:
        return t1
    ratio = (boundary - v0) / (v1 - v0)
    return t0 + ratio * (t1 - t0)


def _profile_crossing_time(
    profile: TickProfile | None,
    *,
    t_from: float,
    t_to: float,
    s_before: float,
    s_after: float,
    boundary: float,
) -> float:
    """Locate a mainline boundary on the bounded-acceleration tick profile."""

    if profile is None:
        return _interpolate(t_from, s_before, t_to, s_after, boundary)
    low = 0.0
    high = float(profile.duration_s)
    for _ in range(70):
        middle = 0.5 * (low + high)
        position, _ = profile.state_at(middle)
        if position < boundary:
            low = middle
        else:
            high = middle
    return t_from + high


def _sequence_index(existing: Iterable[ExecutedEvent]) -> int:
    return 1 + max((item.sequence for item in existing), default=0)


def _mainline_crossing_events(
    state: UAVState,
    profile: TickProfile,
    *,
    t_from: float,
    t_to: float,
    prior: tuple[ExecutedEvent, ...],
    mainline_crossings: Mapping[tuple[str, str], tuple[tuple[str, float, float], ...]],
    stop_at_station_m: float | None = None,
) -> tuple[ExecutedEvent, ...]:
    """Measure mainline resource edges on the flown profile, up to a V's G."""

    s_before = float(state.s_m)
    s_after = float(profile.state_at(float(profile.duration_s))[0])
    observed_end = min(s_after, float(stop_at_station_m)) if stop_at_station_m is not None else s_after
    seen = {(item.event_type, item.resource_id) for item in prior}
    rows: list[ExecutedEvent] = []
    for resource_id, entry_station, exit_station in mainline_crossings.get(
        (state.direction, state.layer), ()
    ):
        for event_type, boundary in (
            ("RESOURCE_ENTER", entry_station),
            ("RESOURCE_EXIT", exit_station),
        ):
            if (event_type, resource_id) in seen or not (
                s_before < boundary <= observed_end + _TIME_TOL
            ):
                continue
            rows.append(
                ExecutedEvent(
                    event_id=f"{state.uav_id}:{resource_id}:{event_type}",
                    event_type=event_type,
                    actual_time_s=_profile_crossing_time(
                        profile,
                        t_from=t_from,
                        t_to=t_to,
                        s_before=s_before,
                        s_after=s_after,
                        boundary=boundary,
                    ),
                    sequence=_sequence_index(prior) + len(rows),
                    resource_id=resource_id,
                    uav_id=state.uav_id,
                )
            )
    return tuple(rows)


def _is_pending_wait(state: UAVState) -> bool:
    plan = state.current_motion_plan
    explicit_wait = (
        plan.get("schedule_result") == "WAITING"
        or plan.get("execution_mode") == "CMLPM_RETRY_HOLD"
    )
    return (state.assigned_node is not None and state.commit_status == "COMMITTED"
            and not state.cmlpm_managed
            and state.state in {FlightState.ASSIGNED, FlightState.DEFERRED, FlightState.MOTION_INFEASIBLE}
            and explicit_wait)


def _pending_stop_profile(state: UAVState, *, stop_station: float,
                          limits: MotionLimits, dt_s: float) -> TickProfile:
    """Cruise/recover while possible, then brake to zero at the commit line.

    Exact phase switches can occur INSIDE a tick. No position truncation,
    instantaneous speed change, reverse travel, or wait-until-next-cycle guard.
    Following may brake earlier and leave the UAV safely upstream instead.
    """
    position, speed = float(state.s_m), float(state.speed_mps)
    b = float(limits.max_abs_acceleration_mps2)
    nominal = min(float(state.nominal_speed_mps or limits.max_speed_mps), limits.max_speed_mps)
    if (not all(math.isfinite(v) for v in (position, speed, b, stop_station, dt_s, nominal,
                                          limits.min_speed_mps, limits.max_speed_mps))
            or b <= 0 or dt_s <= 0 or speed < -1e-8 or speed > limits.max_speed_mps+1e-8):
        raise MotionExecutionBlocked("PENDING_HOLD_MOTION_INVALID", state.uav_id)
    speed = max(0., speed)
    distance = stop_station-position
    if distance < -1e-6 or speed*speed/(2*b) > distance+1e-6:
        blocked = MotionExecutionBlocked("SAFETY_HOLD_UNAVAILABLE",
            f"{state.uav_id}:remaining={distance}:stop={speed*speed/(2*b)}")
        blocked.feedback = {"uav_id":state.uav_id, "assigned_node":state.assigned_node,
            "reason":"SAFETY_HOLD_UNAVAILABLE", "position_m":position, "speed_mps":speed,
            "g_station_m":state.current_motion_plan.get("g_station_m"),
            "stop_station_m":stop_station, "remaining_m":distance,
            "stopping_distance_m":speed*speed/(2*b), "max_deceleration_mps2":b}
        raise blocked
    if speed <= 1e-8 and abs(distance) <= 1e-6:
        return TickProfile((MotionPiece(0.,dt_s,position,speed,0.),),dt_s)
    pieces: list[MotionPiece] = []
    clock = 0.

    def append(duration, acceleration):
        nonlocal position, speed, clock
        duration = min(max(0., duration), dt_s-clock)
        if duration <= 1e-9:
            return
        piece = MotionPiece(clock, clock+duration, position, speed, acceleration)
        pieces.append(piece)
        position, speed = piece.state_at(piece.end_s)
        clock = piece.end_s

    peak = min(nominal, math.sqrt(max(0.,b*distance+.5*speed*speed)))
    if peak > speed+1e-10:
        append((peak-speed)/b, b)
    if clock < dt_s and speed > 1e-10:
        # At/above the braking envelope the coasting phase has zero length.
        coast = max(0., (stop_station-position-speed*speed/(2*b))/speed)
        append(coast, 0.)
        if clock < dt_s:
            append(speed/b, -b)
    if clock < dt_s:
        append(dt_s-clock, 0.)
    return TickProfile(tuple(pieces), dt_s)




@measured("execution.measured_step")
def execute_frozen_motion(snapshot: TrafficSnapshot, *, dt_s: float, **kwargs) -> MotionStep:
    """The sole closed-loop executor; published times remain comparison baselines."""
    from .v5_thin_executor import has_v5_state, execute_v5_thin_step
    use_v5_thin = bool(kwargs.pop("v5_thin_executor", False))
    e_anchor_execution = bool(kwargs.pop("e_anchor_execution", False))
    from .motion_advance_v1 import execute_frozen_motion_v1
    if any(s.state in {FlightState.REENTRY_CLIMB, FlightState.REENTRY_FINAL_APPROACH,
                       FlightState.REENTRY_LAND_TO_GROUND, FlightState.REENTRY_ASCENT_TO_50M}
           or s.state in {FlightState.REENTRY_LOCAL_BRAKING, FlightState.REENTRY_LOCAL_HOLD}
           or (s.state == FlightState.REENTRY_HOLD and s.current_motion_plan.get('reentry_profile'))
           for s in snapshot.states.values()):
        from .reentry_execution import execute_reentry_step
        return execute_reentry_step(
            snapshot, dt_s=dt_s,
            _v5_base_executor=(use_v5_thin or has_v5_state(snapshot)),
            **kwargs,
        )
    if use_v5_thin or has_v5_state(snapshot):
        return execute_v5_thin_step(snapshot, dt_s=dt_s, **kwargs)
    return execute_frozen_motion_v1(
        snapshot, dt_s=dt_s, e_anchor_execution=e_anchor_execution, **kwargs
    )























def _advance_transfer(state, *, t_from, t_to, resource_z, vertical_speed_mps, completion_z_m, prior):
    """Advance the measured geometric path, with no scalar/frozen-time fallback."""
    if not state.current_motion_plan.get("realized_descent_trajectory"):
        raise MotionExecutionBlocked("REALIZED_DESCENT_TRAJECTORY_MISSING", state.uav_id)
    return _advance_path_descent(state,t_from=t_from,t_to=t_to,prior=prior,
        vertical_speed_mps=vertical_speed_mps,completion_z_m=completion_z_m)



def _advance_descent(state, *, t_from, t_to, resource_z, vertical_speed_mps, completion_z_m, prior):
    """Advance the measured geometric path, with no scalar/frozen-time fallback."""
    if not state.current_motion_plan.get("realized_descent_trajectory"):
        raise MotionExecutionBlocked("REALIZED_DESCENT_TRAJECTORY_MISSING", state.uav_id)
    return _advance_path_descent(state,t_from=t_from,t_to=t_to,prior=prior,
        vertical_speed_mps=vertical_speed_mps,completion_z_m=completion_z_m)



def _advance_path_descent(state, *, t_from, t_to, prior, vertical_speed_mps, completion_z_m):
    """Advance the SRCM SOURCE_EXIT + V_DESCENT path, including intra-tick edges."""
    from dataclasses import replace

    plan = state.current_motion_plan
    trajectory = plan.get("realized_descent_trajectory", plan["descent_trajectory"])
    g = float(plan["g_actual_time_s"])
    j = g + float(trajectory["j_offset_s"])
    if not plan.get("descent_trajectory_realized") and abs(j-float(plan["j_time_s"])) > TIME_TOL_S:
        raise MotionExecutionBlocked("FROZEN_J_TIME_NOT_REALIZED", state.uav_id)
    vertical = [s for s in trajectory["segments"] if s["phase_type"] == "V_DESCENT"]
    for segment in vertical:
        physical_speed = ((segment["point0_xyz"][2]-segment["point1_xyz"][2]) /
                          (segment["end_s"]-segment["start_s"]))
        if abs(physical_speed-vertical_speed_mps) > TIME_TOL_S:
            raise MotionExecutionBlocked("DESCENT_VERTICAL_SPEED_MISMATCH", state.uav_id)
    point_before, _ = trajectory_state(trajectory, t_from-g)
    if abs(state.z_m-point_before[2]) > 1e-6:
        raise MotionExecutionBlocked("DESCENT_INITIAL_STATE_MISMATCH", state.uav_id)
    previous_xyz = plan.get("motion_position_xyz")
    if previous_xyz is not None and math.dist(previous_xyz, point_before) > 1e-6:
        raise MotionExecutionBlocked("DESCENT_INITIAL_STATE_MISMATCH", state.uav_id)
    end = g + float(trajectory["segments"][-1]["end_s"])
    if abs(trajectory["segments"][-1]["point1_xyz"][2]-completion_z_m) > 1e-6:
        raise MotionExecutionBlocked("DESCENT_COMPLETION_BOUNDARY_MISMATCH", state.uav_id)
    candidates = [(j, "J", None), (end, "B_L1", None)]
    for resource, (enter, exit_) in trajectory_resource_windows(trajectory).items():
        candidates.extend(((g+enter, "RESOURCE_ENTER", resource),
                           (g+exit_, "RESOURCE_EXIT", resource)))
    seen = {(e.event_type, e.resource_id) for e in prior}
    rows = []
    for moment, kind, resource in sorted(candidates, key=lambda e: (e[0], e[1], str(e[2]))):
        if (kind, resource) in seen:
            continue
        if moment < t_from-_TIME_TOL:
            raise MotionExecutionBlocked("DESCENT_RESOURCE_EVENT_MISSING", f"{state.uav_id}:{kind}:{resource}")
        if moment > t_to+_TIME_TOL:
            continue
        event_id = (f"{state.uav_id}:{resource}:{'ENTER' if kind == 'RESOURCE_ENTER' else 'EXIT'}"
                    if resource else f"{state.uav_id}:{kind}")
        rows.append(ExecutedEvent(event_id, kind, moment, _sequence_index(prior)+len(rows),
                                  resource, state.uav_id))
    point, speed = trajectory_state(trajectory, t_to-g)
    motion = {**plan, "motion_position_xyz": point,
              "descent_elapsed_s": min(t_to-g, end-g)}
    if t_to >= j-_TIME_TOL:
        motion.update(j_actual_time_s=j, j_z_m=vertical[0]["point0_xyz"][2])
    return tuple(rows), replace(
        state, z_m=point[2], speed_mps=speed, current_motion_plan=motion,
        state=(FlightState.COMPLETED if t_to >= end-_TIME_TOL else
               FlightState.VERTICAL if t_to >= j-_TIME_TOL else FlightState.TRANSITION),
        event_version=state.event_version+1,
    )


def apply_execution_events(
    committed: Any,
    events: Iterable[ExecutedEvent],
    *,
    state_version: int,
) -> Any:
    """Attach observed events to their published plans and mark releases.

    A resource is released only by an observed RESOURCE_EXIT.  Simulation time
    having passed the planned exit is not evidence of release, so a delayed
    descent keeps an open occupancy and the resource stays protected.
    """

    from dataclasses import replace

    grouped: dict[str, list[ExecutedEvent]] = {}
    for event in events:
        grouped.setdefault(event.uav_id, []).append(event)

    rows = dict(committed.plans)
    changed = False
    for uav_id, fresh in grouped.items():
        plan = rows.get(uav_id)
        if plan is None:
            raise MotionExecutionBlocked("EXECUTION_WITHOUT_PUBLISHED_PLAN", uav_id)
        merged = tuple(plan.executed_events) + tuple(
            sorted(fresh, key=lambda item: item.actual_time_s)
        )
        released = set(plan.released_resources)
        for item in fresh:
            if item.event_type == "RESOURCE_EXIT" and item.resource_id:
                released.add(item.resource_id)
        rows[uav_id] = replace(
            plan,
            executed_events=merged,
            released_resources=tuple(sorted(released)),
            state_version=int(state_version),
        )
        changed = True
    if not changed:
        return committed
    return type(committed)(
        plans=type(committed.plans)(rows), version=committed.version + 1
    )
