"""One event-triggered C-MLPM node solve input construction.

This module is the runtime-input orchestration entry for one node at one
registered scheduling event.
It follows the agreed pipeline:

    registered request/resource/execution event
      -> read authoritative traffic state (versioned snapshot)
      -> spatial scope [G-3Dcommit, current resource exit] plus inherited V and
         frozen-reservation identities
      -> same-version state read
      -> real SRCM resource-competition identification (crossing uses, VV/VH
         evidence)
      -> kinematic reachability (event windows inside the snapshot builder)
      -> FIFO / shared-resource order and fixed passage timing
      -> formal NodeSnapshot construction and validation
      -> (solve / freeze / feedback stay owned by the caller)

The module never invents resource uses, safety parameters or frozen
reservations: every contract is either rebuilt from the same traffic state
version or taken from the declared research parameters, and every branch that
cannot close fails with a structured ``RuntimeInputBlocked`` error.
"""

from __future__ import annotations

from dataclasses import dataclass, replace
import math
from types import MappingProxyType
from typing import Any, Iterable, Mapping

from .cmlpm_safety_order import SafetyOrderContracts, build_safety_order_contracts
from .cmlpm_runtime_input import NodeTrafficRead, RuntimeInputBlocked, read_node_traffic_snapshot
from .cmlpm_snapshot_builder import build_node_snapshot_payload
from .cmlpm_srcm_adapter import NodeSrcmEvidence, RuntimePolicies, run_node_srcm
from .config import approved_cmlpm_evaluation_time_bounds, load_config
from .existing_v_continuation import (
    CONTINUATION_VERSION,
    ContinuationBlocked,
    ExistingVContinuation,
    ExecutedEvent,
    VerifiedPlanView,
    build_existing_v_continuation,
    classify_existing_v,
    frozen_vh_resources,
    frozen_vv_constraints,
)
from .network_loader import RegisteredG25
from .numeric_motion import MotionLimits
from .crossing_resource_mapping import (
    build_crossing_resource_maps,
    crossing_map_for_node_layer,
)
from .simulation_state import TrafficSnapshot, UAVState


PIPELINE_VERSION = "CMLPM_NODE_EVENT_PIPELINE_V7_E_ANCHOR_LOCAL_3D"


@dataclass(frozen=True)
class NodeSchedulingResult:
    node_id: str
    read: NodeTrafficRead
    evidence: NodeSrcmEvidence
    contracts: SafetyOrderContracts
    continuations: tuple[ExistingVContinuation, ...]
    payload: Mapping[str, Any]
    provenance: Mapping[str, Any]
    resource_time_records: tuple[Mapping[str, Any], ...] = ()

    @property
    def state_version(self) -> int:
        return int(self.read.state_version)


def motion_limits_from_config(config: Mapping[str, Any]) -> dict[str, MotionLimits]:
    motion = config.get("motion", {})
    if not isinstance(motion, Mapping):
        raise ValueError("INVALID_MOTION_CONFIG")
    minimum = motion.get("min_speed_mps", {})
    maximum = motion.get("nominal_and_normal_max_speed_mps", {})
    acceleration = motion.get("max_abs_acceleration_mps2", {})
    limits: dict[str, MotionLimits] = {}
    for vehicle_type in sorted(maximum):
        if vehicle_type not in minimum or vehicle_type not in acceleration:
            raise ValueError(f"INCOMPLETE_MOTION_LIMITS:{vehicle_type}")
        limits[vehicle_type] = MotionLimits(
            min_speed_mps=float(minimum[vehicle_type]),
            max_speed_mps=float(maximum[vehicle_type]),
            max_abs_acceleration_mps2=float(acceleration[vehicle_type]),
        )
    return limits


def _enrich_states(
    read: NodeTrafficRead,
    evidence: NodeSrcmEvidence,
    contracts: SafetyOrderContracts,
) -> tuple[UAVState, ...]:
    enriched: list[UAVState] = []
    for state in read.traffic_states:
        plan = dict(state.current_motion_plan)
        plan.update(dict(evidence.plan_fields.get(state.uav_id, {})))
        if plan.get('resource_geometry_basis')=='REGISTERED_FIXED_DESCENT_TEMPLATE':
            plan.pop('nominal_j_time_s',None)
        plan.update(dict(contracts.fifo_ranks.get(state.uav_id, {})))
        enriched.append(replace(state, current_motion_plan=plan))
    return tuple(enriched)


def run_node_cmlpm_event(
    network: RegisteredG25,
    node_id: str,
    *,
    config: Mapping[str, Any],
    snapshot: TrafficSnapshot,
    frozen_reservation_uav_ids: Iterable[str],
    frozen_ledger_version: str,
    existing_v_ledger: Mapping[
        str, tuple[VerifiedPlanView, tuple[ExecutedEvent, ...]]
    ] | None = None,
    seed: int = 0,
    enable_waiting: bool = False,
    next_check_time_s: float | None = None,
    static_context=None,
    traffic_index=None,
    e_anchor_execution: bool = False,
) -> NodeSchedulingResult:
    """Build one complete C-MLPM node input at a registered event.

    ``frozen_reservation_uav_ids`` and ``frozen_ledger_version`` are mandatory:
    an authoritative empty frozen ledger must be distinguishable from a missing
    provider.  ``existing_v_ledger`` supplies the read-only verified plan view
    and the actually executed event prefix for every V that has crossed the
    spatial commit boundary or already passed G; a missing record fails closed
    instead of inferring a history.

    The event handler reads the traffic state, performs the real SRCM call, derives the
    safety ordering contracts, inherits the remaining events and protected
    occupancy of existing V, and constructs the formal ``NodeSnapshot``
    payload through the official converter.
    """

    from .cmlpm_input_context import StaticNodeContext, NodeTrafficIndex
    context = static_context if static_context is not None else StaticNodeContext(network)
    context.require_network(network)
    network = context.network
    traffic_index = traffic_index if traffic_index is not None else NodeTrafficIndex(snapshot)
    policies = RuntimePolicies.from_config(config)
    limits = motion_limits_from_config(config)
    dt_s = float(config.get("simulation", {}).get("dt_s", 0.5))
    if dt_s <= 0.0:
        raise ValueError("INVALID_EVENT_DT")

    bounds = ({"t_commit": float(snapshot.sim_time_s) + dt_s} if e_anchor_execution else
              approved_cmlpm_evaluation_time_bounds(config, t_now=float(snapshot.sim_time_s)))
    read = read_node_traffic_snapshot(
        snapshot,
        network,
        node_id,
        frozen_reservation_uav_ids=frozen_reservation_uav_ids,
        static_context=context,
        traffic_index=traffic_index,
        h_reach_horizon_s=(bounds["t_clear"] - snapshot.sim_time_s
                           if "t_clear" in bounds else None),
        h_max_speed_by_type={
            vehicle_type: item.max_speed_mps for vehicle_type, item in limits.items()
        },
        h_motion_limits_by_type=limits,
        v_reach_horizon_s=None,
        v_max_speed_by_type={
            vehicle_type: item.max_speed_mps for vehicle_type, item in limits.items()
        },
    )
    published_h_reservations: list[dict[str, Any]] = []
    published_h_resources: set[str] = set()
    for state in read.published_h:
        crossing = crossing_map_for_node_layer(
            context.crossings, read.node_id, read.direction, state.layer
        )
        resource_id = str(crossing.segment_resource_id)
        exited_resources = {
            str(row.get("resource_id"))
            for row in state.current_motion_plan.get("motion_observed_events", ())
            if isinstance(row, Mapping)
            and row.get("event_type") == "RESOURCE_EXIT"
            and row.get("resource_id") is not None
        }
        target = next(
            (
                item for item in state.current_motion_plan.get("timed_resource_targets", ())
                if isinstance(item, Mapping)
                and str(item.get("resource_id")) == resource_id
                and resource_id not in exited_resources
            ),
            None,
        )
        if target is None:
            raise RuntimeInputBlocked("PUBLISHED_H_RESERVATION_MISSING", state.uav_id)
        entry = float(target["entry_time_s"])
        exit_ = float(target["exit_time_s"])
        if not math.isfinite(entry) or not math.isfinite(exit_) or exit_ <= entry:
            raise RuntimeInputBlocked("PUBLISHED_H_RESERVATION_INVALID", state.uav_id)
        published_h_resources.add(resource_id)
        published_h_reservations.append({
            "reservation_id": f"{state.uav_id}:{resource_id}:COMMITTED_MAINLINE_PREFIX",
            "uav_id": state.uav_id,
            "resource_id": resource_id,
            "role": "M",
            "occupancy_start": entry,
            "occupancy_end": exit_,
            "version": "PUBLISHED_TARGET_NOT_REACHABILITY_PROOF",
            "source_layer": state.layer,
        })
    continuations: list[ExistingVContinuation] = []
    replan_existing_v: list[dict[str, str]] = []
    continued_ids: set[str] = set()
    for state in read.v_existing:
        classification, _ = classify_existing_v(
            network, state, t_now=read.t_now
        )
        if classification != "continuation":
            continue
        record = (existing_v_ledger or {}).get(state.uav_id)
        if record is None:
            raise RuntimeInputBlocked(
                "MISSING_VERIFIED_FROZEN_PLAN", state.uav_id
            )
        plan, executed = record
        try:
            continuation = build_existing_v_continuation(
                network,
                state,
                plan=plan,
                executed=tuple(executed),
                t_now=read.t_now,
                state_version=read.state_version,
                vv_entry_headway_s=policies.vv_entry_headway_s,
                vh_margin_s=policies.vh_margin_s,
            )
        except ContinuationBlocked as error:
            # An active E-anchor plan is an execution offer, not a permanent
            # G/J reservation. If measured resource events no longer match
            # its immutable chain, abandon that continuation and let this
            # round publish a fresh E plan. The UAV remains in the snapshot;
            # no legacy G/J timing is resurrected.
            replannable = {
                "RESOURCE_CLASSIFICATION_ORDER",
                "ACTIVE_WITHOUT_FUTURE_EXIT",
                "ACTIVE_ENTER_IN_FUTURE",
            }
            if getattr(plan, "e_time_s", None) is None or error.code not in replannable:
                raise
            replan_existing_v.append({
                "uav_id": state.uav_id,
                "reason": error.code,
            })
            continue
        continuations.append(continuation)
        continued_ids.add(state.uav_id)

    evidence = run_node_srcm(
        network,
        read,
        policies=policies,
        seed=seed,
        motion_limits_by_type=limits,
        continued_uav_ids=tuple(continued_ids),
        replan_existing_v_ids=tuple(item["uav_id"] for item in replan_existing_v),
        evaluation_clear_time_s=bounds.get("t_clear"),
        use_bounded_h_crossing=e_anchor_execution,
        static_context=context,
    )
    extra_vh = frozen_vh_resources(
        continuations,
        mainline_resources=(
            row["resource_id"] for row in evidence.resource_uses if row["role"] == "M"
        ),
    )
    extra_vh = tuple(sorted(set(extra_vh) | published_h_resources))
    contracts = build_safety_order_contracts(
        network, read, evidence, policies,
        extra_vh_resources=extra_vh,
        excluded_uav_ids=tuple(continued_ids),
        preserve_pending_ranks=enable_waiting,
        motion_limits_by_type=limits,
        min_mainline_gap_m=float(config["motion"]["min_gap_m"]),
        static_context=context,
    )
    new_v_layers = {
        state.uav_id: state.layer
        for state in (*read.v_new, *read.v_existing)
        if state.uav_id not in continued_ids
    }
    new_v_resources: dict[str, list[str]] = {}
    for row in evidence.resource_uses:
        if row["role"] != "V":
            continue
        new_v_resources.setdefault(str(row["uav_id"]), []).append(str(row["resource_id"]))
    frozen_vv = frozen_vv_constraints(
        continuations,
        new_v_layers=new_v_layers,
        new_v_resources=new_v_resources,
        entry_headway_s=policies.vv_entry_headway_s,
        separation_version=policies.vv_version,
    )

    enriched = _enrich_states(read, evidence, contracts)
    provenance = {
        "state_version": int(read.state_version),
        "state_semantic_sha256": read.state_semantic_sha256,
        "srcm_state_version": int(read.state_version),
        "kinematic_state_version": int(read.state_version),
        "safety_state_version": int(read.state_version),
        "frozen_ledger_version": str(frozen_ledger_version),
        "srcm_evaluation_id": evidence.srcm_snapshot_id,
        "motion_parameter_source": evidence.provenance["motion_parameter_source"],
        "fifo_source": contracts.provenance["fifo_source"],
        "input_generation_version": PIPELINE_VERSION,
        "following_control": "MEASURED_KINEMATIC_EXECUTOR_V1",
        "existing_v_continuation_version": CONTINUATION_VERSION,
        "existing_v_plan_versions": {
            item.uav_id: item.plan_version for item in continuations
        },
        "replan_existing_v": tuple(replan_existing_v),
    }
    payload = build_node_snapshot_payload(
        network,
        node_id=node_id,
        t_now=read.t_now,
        dt_s=dt_s,
        evaluation_time_bounds=bounds,
        input_mode="real_traffic",
        traffic_states=enriched,
        following_traffic_states=read.all_traffic_states,
        motion_limits_by_type=limits,
        actual_resource_uses=evidence.resource_uses,
        actual_vv_constraints=contracts.vv_constraints,
        actual_vh_separation=contracts.vh_separation,
        frozen_reservations=tuple(published_h_reservations),
        frozen_vv_constraints=frozen_vv,
        existing_v_continuations=tuple(continuations),
        replan_existing_v_ids=tuple(item["uav_id"] for item in replan_existing_v),
        frozen_mainline_e_times={
            uid: existing_v_ledger[uid][0].e_time_s
            for uid in continued_ids
            if existing_v_ledger[uid][0].e_time_s is not None
        },
        min_mainline_gap_m=float(config["motion"]["min_gap_m"]),
        runtime_provenance=provenance,
        static_context=context,
        waiting_next_check_s=next_check_time_s if enable_waiting else None,
        waiting_parameters=(dict(config["cmlpm_waiting"]) if enable_waiting else None),
    )
    from .resource_time_semantics import build_time_records
    time_records=build_time_records(snapshot,payload,existing_v_ledger or {},dt_s=dt_s)
    return NodeSchedulingResult(
        node_id=node_id,
        resource_time_records=time_records,
        read=read,
        evidence=evidence,
        contracts=contracts,
        continuations=tuple(continuations),
        payload=MappingProxyType(dict(payload)),
        provenance=MappingProxyType(dict(provenance)),
    )
