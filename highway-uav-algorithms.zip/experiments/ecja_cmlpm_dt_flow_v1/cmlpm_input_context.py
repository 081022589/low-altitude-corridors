"""Owned static network context and same-snapshot node candidate index.

The index is a conservative retrieval layer. The authoritative reader still
classifies candidates; spatial departure never erases a request or promise.
"""
from __future__ import annotations

from bisect import bisect_left, bisect_right
import copy
from dataclasses import fields, replace
from types import MappingProxyType

from .network_loader import directed_node_interval, to_ecja_g25_source
from .simulation_state import freeze_plan_payload
from .trigger_rules import latest_assignment_distance_m


def _mutable_copy(value):
    if isinstance(value, dict):
        return {key: _mutable_copy(item) for key, item in value.items()}
    if isinstance(value, list):
        return [_mutable_copy(item) for item in value]
    if isinstance(value, tuple):
        return tuple(_mutable_copy(item) for item in value)
    return value


class StaticNodeContext:
    """One detached, recursively read-only network for a dispatcher lifetime.

    Replacing the network requires a new context. Dynamic traffic/configuration
    is deliberately not cached here.
    """

    def __init__(self, network):
        from .crossing_resource_mapping import build_crossing_resource_maps, verify_registered_geometry
        from .route_identity import build_route_index
        from ecja_qsap.p3r_forward import ForwardServiceCatalog
        from g25_param_env.scenario import build_scenario_bundle

        self._owner = network
        self.network = replace(network, **{
            f.name: freeze_plan_payload(copy.deepcopy(getattr(network, f.name)))
            for f in fields(network)
        })
        verify_registered_geometry(self.network)
        self.crossings = MappingProxyType(build_crossing_resource_maps(self.network))
        self.routes = MappingProxyType(build_route_index(self.network))
        self.interfaces = MappingProxyType({(str(i['service_node_id']), str(i['source_layer'])): i
                                           for i in self.network.interfaces})
        self.resource_lengths = MappingProxyType({str(r['resource_id']): float(r['length_m'])
                                                 for r in self.network.resources})
        keys = {(str(i['service_node_id']), str(i['direction']), str(i['source_layer']))
                for i in self.network.interfaces}
        self.intervals = MappingProxyType({k: directed_node_interval(self.network, *k) for k in keys})
        self.source = freeze_plan_payload(to_ecja_g25_source(self.network, include_formal_motion=True))
        self.catalog = ForwardServiceCatalog(self.source)
        self._scene = freeze_plan_payload(build_scenario_bundle(self.source, plans=[]))

    def require_network(self, network):
        if network is not self._owner and network is not self.network:
            raise ValueError('STATIC_NODE_CONTEXT_NETWORK_MISMATCH')

    def scene(self, scenario_id, seed, plans):
        # Static fields stay read-only. Every mutable dynamic field is owned
        # by this call, matching build_scenario_bundle's original structure.
        scene = dict(self._scene)
        scene['meta'] = dict(scene['meta'], scenario_id=scenario_id, fixture_id=scenario_id,
            snapshot_id=scenario_id + ':SNAPSHOT:0', seed=int(seed), scenario_hash='',
            t0_s=min((p['activity_start_s'] for p in plans), default=0.),
            horizon_s=max((p['activity_end_s'] for p in plans), default=0.) + 1.)
        scene['time_profile'] = dict(scene['time_profile'])
        scene['traffic_profile'] = dict(scene['traffic_profile'], arrival_seed=int(seed))
        scene['plans'] = copy.deepcopy(plans)
        # The SRCM registry normalizer owns and annotates copies of crossing
        # records. FrozenPlanPayload.__deepcopy__ intentionally returns self,
        # so provide ordinary owned records at that mutation boundary.
        scene['crossing_resources'] = _mutable_copy(scene['crossing_resources'])
        return scene


class NodeTrafficIndex:
    """Build once per exact TrafficSnapshot; query by station and history."""

    def __init__(self, snapshot):
        self.snapshot = snapshot
        groups, assigned, targets, occupied = {}, {}, {}, {}
        for state in snapshot.states.values():
            groups.setdefault((state.direction, state.layer, state.vehicle_type), []).append(state)
            if state.assigned_node is not None:
                assigned.setdefault(str(state.assigned_node), []).append(state)
            exits = set()
            opens = set()
            for event in state.current_motion_plan.get('motion_observed_events', ()):
                rid = str(event.get('resource_id'))
                if event.get('event_type') == 'RESOURCE_ENTER':
                    opens.add(rid)
                elif event.get('event_type') == 'RESOURCE_EXIT':
                    exits.add(rid)
                    opens.discard(rid)
            for target in state.current_motion_plan.get('timed_resource_targets', ()):
                rid = str(target['resource_id'])
                if rid not in exits:
                    targets.setdefault(rid, []).append(state)
            for rid in opens:
                occupied.setdefault(rid, []).append(state)
        self.groups = {}
        for key, states in groups.items():
            ordered = sorted(states, key=lambda s: (s.s_m, s.uav_id))
            self.groups[key] = ([s.s_m for s in ordered], ordered)
        self.assigned = {k: tuple(sorted(v, key=lambda s: s.uav_id)) for k, v in assigned.items()}
        self.targets, self.occupied = targets, occupied

    def require_snapshot(self, snapshot):
        if snapshot is not self.snapshot:
            raise ValueError('NODE_TRAFFIC_INDEX_SNAPSHOT_MISMATCH')

    def candidates(self, context, node_id):
        selected = {s.uav_id: s for s in self.assigned.get(node_id, ())}
        for crossing in context.crossings.values():
            if crossing.node_id != node_id:
                continue
            interval = context.intervals[(node_id, crossing.direction, crossing.layer)]
            for (direction, layer, kind), (positions, states) in self.groups.items():
                if (direction, layer) != (crossing.direction, crossing.layer):
                    continue
                lower = interval.upper_q_m - latest_assignment_distance_m(kind)
                start = bisect_left(positions, lower - 1e-9)
                end = bisect_right(positions, crossing.exit_station_m + 1e-9)
                selected.update((s.uav_id, s) for s in states[start:end])
            rid = crossing.segment_resource_id
            for state in (*self.targets.get(rid, ()), *self.occupied.get(rid, ())):
                selected[state.uav_id] = state
        return tuple(selected[uid] for uid in sorted(selected))
