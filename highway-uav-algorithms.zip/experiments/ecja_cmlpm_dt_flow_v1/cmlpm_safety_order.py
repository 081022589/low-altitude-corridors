"""Same-layer request FIFO and shared-resource V/V and V/H ordering.

Published traffic is inherited through immutable resource reservations.
Positive physical following time bounds are constructed separately from these
resource-order contracts and from zero-gap mainline FIFO.
"""

from __future__ import annotations

from dataclasses import dataclass
from itertools import combinations
from typing import Any, Iterable, Mapping

from .crossing_resource_mapping import (
    CrossingResourceMap,
    build_crossing_resource_maps,
    crossing_map_for_node_layer,
)
from .cmlpm_runtime_input import NodeTrafficRead
from .cmlpm_srcm_adapter import NodeSrcmEvidence, RuntimePolicies
from .network_loader import RegisteredG25
from .simulation_state import FlightState, UAVState


ORDER_PROVIDER_VERSION = "CMLPM_RESOURCE_ORDER_PROVIDER_V3_UAV_LOCAL"


@dataclass(frozen=True)
class SafetyOrderContracts:
    fifo_ranks: Mapping[str, Mapping[str, Any]]
    vv_constraints: tuple[dict[str, Any], ...]
    vh_separation: Mapping[str, dict[str, Any]]
    provenance: Mapping[str, Any]


def _nominal_entry(
    state: UAVState, crossing: CrossingResourceMap, t_now: float
) -> float:
    nominal_speed = float(state.nominal_speed_mps or state.speed_mps)
    if nominal_speed <= 0.0:
        raise ValueError(f"INVALID_NOMINAL_SPEED:{state.uav_id}")
    return float(t_now) + (crossing.entry_station_m - float(state.s_m)) / nominal_speed


def _active_v_states(
    read: NodeTrafficRead, excluded_uav_ids: frozenset[str]
) -> tuple[UAVState, ...]:
    """V candidates that are still optimizable in this scheduling event.

    ``SCHEDULED`` before the spatial commit boundary remains adjustable; only
    TRANSITION/VERTICAL, explicitly frozen plans and V inherited through the
    existing-V continuation contract are excluded.
    """

    return tuple(
        state for state in (*read.v_new, *read.v_existing)
        if state.state not in {
            FlightState.TRANSITION, FlightState.VERTICAL,
            FlightState.SERVICING, FlightState.REENTRY_HOLD, FlightState.REENTRY_CLIMB,
            FlightState.REENTRY_LAND_TO_GROUND, FlightState.REENTRY_ASCENT_TO_50M,
            FlightState.REENTRY_STAGING_HOLD, FlightState.REENTRY_FINAL_APPROACH,
        }
        and state.commit_status != "FROZEN"
        and state.uav_id not in excluded_uav_ids
    )


def build_safety_order_contracts(
    network: RegisteredG25,
    read: NodeTrafficRead,
    evidence: NodeSrcmEvidence,
    policies: RuntimePolicies,
    *,
    extra_vh_resources: Iterable[str] = (),
    excluded_uav_ids: Iterable[str] = (),
    preserve_pending_ranks: bool = False,
    motion_limits_by_type: Mapping[str, Any] | None = None,
    min_mainline_gap_m: float | None = None,
    static_context=None,
) -> SafetyOrderContracts:
    """Derive FIFO ranks, VV/HH constraints and VH separation from the read.

    ``extra_vh_resources`` carries resources where a protected existing-V
    occupancy meets new H traffic; those need the same declared VH separation
    even though no new V use appears on them.
    """

    if static_context is not None:
        static_context.require_network(network)
    maps = static_context.crossings if static_context else build_crossing_resource_maps(network)
    excluded = frozenset(str(value) for value in excluded_uav_ids)
    active_v = _active_v_states(read, excluded)
    t_now = float(read.t_now)

    fifo_ranks: dict[str, dict[str, Any]] = {}
    by_layer: dict[str, list[UAVState]] = {}
    # Descending station: the V closest to the crossing joins the descent
    # queue first, exactly as the H closest to the crossing leads the
    # mainline chain.  Rank 0 is the first served.
    for state in sorted(active_v, key=lambda item: (item.layer, -item.s_m, item.uav_id)):
        by_layer.setdefault(state.layer, []).append(state)
    for layer, states in by_layer.items():
        ranks = {s.uav_id:float(s.current_motion_plan["fifo_rank"])
                 for s in states if preserve_pending_ranks and s.cmlpm_pending is not None}
        if preserve_pending_ranks:
            # Stable order labels, not a per-roll renumbering. New requests
            # can legitimately lie ahead of an older request on the mainline.
            # Insert labels between existing ones without moving either UAV.
            left, start = 0., 0
            for end in range(len(states)+1):
                if end < len(states) and states[end].uav_id not in ranks:
                    continue
                right = ranks[states[end].uav_id] if end < len(states) else left+(end-start)+1.
                if right <= left:
                    raise ValueError("PENDING_FIFO_ORDER_CHANGED")
                for index in range(start,end):
                    ranks[states[index].uav_id] = left+(right-left)*(index-start+1)/(end-start+1)
                if end < len(states):
                    left,start = right,end+1
        for rank, state in enumerate(states):
            fifo_ranks[state.uav_id] = {
                "fifo_rank": ranks[state.uav_id] if preserve_pending_ranks else rank,
                "fifo_queue_id": f"{read.node_id}:{layer}",
            }

    chain_by_layer = {
        layer: tuple(str(value) for value in crossing_map_for_node_layer(
            maps, read.node_id, read.direction, layer
        ).resource_chain)
        for layer in ("L1", "L2", "L3")
    }

    vv_rows: list[dict[str, Any]] = []
    for first, second in combinations(sorted(active_v, key=lambda item: item.uav_id), 2):
        shared = [
            value for value in chain_by_layer[first.layer]
            if value in chain_by_layer[second.layer]
        ]
        if not shared:
            continue
        fixed_order = None
        if first.layer == second.layer:
            # The V closer to the crossing reaches the descent queue first.
            leader = first if first.s_m >= second.s_m else second
            fixed_order = leader.uav_id
        vv_rows.append({
            "first_id": first.uav_id,
            "second_id": second.uav_id,
            "first_before_second_gap": float(policies.vv_entry_headway_s),
            "second_before_first_gap": float(policies.vv_entry_headway_s),
            "fixed_order": fixed_order,
            "shared_segments": shared,
        })

    h_by_layer: dict[str, list[UAVState]] = {}
    for state in sorted(read.h, key=lambda item: (item.layer, -item.s_m, item.uav_id)):
        h_by_layer.setdefault(state.layer, []).append(state)

    # Certified joint functions own continuous motion; this module supplies resource ordering.
    vh_keys = set(evidence.vh_resources) | {str(value) for value in extra_vh_resources}
    vh_separation = {
        resource_id: {
            "first_to_second": float(policies.vh_margin_s),
            "second_to_first": float(policies.vh_margin_s),
            "version": str(policies.vh_version),
        }
        for resource_id in sorted(vh_keys)
    }

    provenance = {
        "provider_version": ORDER_PROVIDER_VERSION,
        "state_version": int(read.state_version),
        "state_semantic_sha256": read.state_semantic_sha256,
        "fifo_source": "ACTUAL_DIRECTED_MAINLINE_ORDER",
        "e3_source": "LOCAL_JOINT_CERTIFICATION",
        "e4_source": "LOCAL_JOINT_CERTIFICATION",
        "vh_separation_source": str(policies.vh_version),
        "vh_separation_authorized": False,
        "vv_headway_source": str(policies.vv_version),
        "h_delay_source": str(policies.h_delay_version),
    }

    return SafetyOrderContracts(
        fifo_ranks=dict(fifo_ranks),
        vv_constraints=tuple(vv_rows),
        vh_separation=dict(vh_separation),
        provenance=dict(provenance),
    )
