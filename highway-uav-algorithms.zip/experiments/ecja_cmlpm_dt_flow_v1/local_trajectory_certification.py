"""Deterministic local trajectories and joint execution certification.

Uses the nominal joint selection only. Incompatible frozen H events or missing
dependencies reject publication instead of changing resource reservations.
"""
from dataclasses import asdict
import hashlib
import json
import math
from .joint_motion_evidence import measured,performance_metrics

from experiments.kinematic_layer_v1.kinematic_advance import (
    Aircraft, Limits, Piece, Profile, Slot, build_profile, terminal_slot_profile,
)
from .descent_trajectory import trajectory_resource_windows
from .following_time import physical_lane
from .resource_conflict_classification import is_cross_layer_vh_pair
from .following_reference import following_reference
from traffic_simulation.cmlpm.joint_single_node.conflict_builder import SHARED_RESOURCE_ENTRY_HEADWAY_S


class TrajectoryCertificationError(ValueError):
    def __init__(self, reason, diagnostics):
        super().__init__(reason)
        self.diagnostics = diagnostics


def continuous_gap_evidence(front, rear):
    """Analytic minimum and witness time on all overlapping quadratic pieces."""
    candidates = []
    duration = min(front.duration_s,rear.duration_s)
    for p in front.pieces:
        for q in rear.pieces:
            left,right = max(p.start_s,q.start_s),min(p.end_s,q.end_s,duration)
            if right<=left:
                continue
            s,v = p.state_at(left)
            r,w = q.state_at(left)
            relative_a = p.a-q.a
            times = [0.,right-left]
            if relative_a:
                vertex = (w-v)/relative_a
                if 0.<vertex<right-left:
                    times.append(vertex)
            candidates.extend((s-r+(v-w)*t+.5*relative_a*t*t,left+t) for t in times)
    if not candidates:
        raise ValueError("LTG_NO_OVERLAPPING_PROFILE")
    gap,time = min(candidates)
    return dict(gap_m=gap,time_offset_s=time,
                front_position_m=front.state_at(time)[0],rear_position_m=rear.state_at(time)[0],
                front_speed_mps=front.state_at(time)[1],rear_speed_mps=rear.state_at(time)[1])


@measured('motion.continuous_gap_batch')
def collect_gap_conflicts(states, profiles, lanes, *, required_gap_m, now, snapshot_version):
    """Inspect every current adjacent pair using the unchanged analytic minimum.

    No PASS is produced here. Missing/invalid trajectories still fail closed.
    Witnesses all refer to the same immutable candidate, never repaired profiles.
    """
    minimum=math.inf
    conflicts=[]
    for lane in sorted(lanes,key=repr):
        ordered=sorted((s for s in states if physical_lane(s)==lane),key=lambda s:(-s.s_m,s.uav_id))
        for front,rear in zip(ordered,ordered[1:]):
            first,second=profiles[front.uav_id],profiles[rear.uav_id]
            witness=continuous_gap_evidence(first,second)
            minimum=min(minimum,witness['gap_m'])
            if witness['gap_m'] >= required_gap_m-1e-6:
                continue
            conflicts.append(dict(snapshot_version=snapshot_version,time_s=now,
                lane=lane,front_uav_id=front.uav_id,rear_uav_id=rear.uav_id,
                required_gap_m=required_gap_m,gap_deficit_m=required_gap_m-witness['gap_m'],
                absolute_time_s=now+witness['time_offset_s'],
                checked_duration_s=min(first.duration_s,second.duration_s),witness=witness,
                associated_events={state.uav_id:dict(
                    e_time_s=state.current_motion_plan.get('e_time_s'),
                    resource_windows=state.current_motion_plan.get('resource_windows',()),
                    timed_resource_targets=state.current_motion_plan.get('timed_resource_targets',()))
                    for state in (front,rear)}))
    performance_metrics(conflict_count=len(conflicts),checked_lanes=len(lanes))
    return minimum,conflicts


def profile_from_record(record):
    return Profile(tuple(Piece(**p) for p in record["pieces"]),record["duration_s"])


def reference_interval(record, state, now_s, duration_s):
    profile = profile_from_record(record)
    start = now_s-record["start_time_s"]
    end = min(start+duration_s,profile.duration_s)
    if start < -1e-8 or end <= start:
        raise ValueError("LTG_REFERENCE_EXPIRED")
    position,speed = profile.state_at(start)
    if abs(position-state.s_m)>1e-6 or abs(speed-state.speed_mps)>1e-6:
        raise ValueError("LTG_REFERENCE_DEVIATED")
    pieces = []
    for piece in profile.pieces:
        left,right = max(start,piece.start_s),min(end,piece.end_s)
        if right > left:
            s,v = piece.state_at(left)
            pieces.append(Piece(left-start,right-start,s,v,piece.a))
    return Profile(tuple(pieces),end-start)


@measured("motion.trajectory_certification")
def generate_and_certify(snapshot, limits, config, schedule_id,*,execution_feedback=None,decision_ids=None):
    """Return PASS with an auditable bundle, or UNAVAILABLE without commands."""
    try:
        bundle = _generate(snapshot,limits,config,schedule_id,decision_ids=decision_ids)
        bundle["snapshot_version"] = snapshot.version
        if execution_feedback is not None:
            if execution_feedback['snapshot_version']!=snapshot.version:
                raise ValueError('CPFF_STALE_INPUT')
            bundle['execution_feedback']=json.loads(json.dumps(execution_feedback,sort_keys=True,default=str))
        bundle["inherited_references"] = {
            uid:{key:state.current_motion_plan.get(key) for key in (
                "local_trajectory_reference","local_trajectory_id","local_certification_id")}
            for uid,state in snapshot.states.items()
            if uid in bundle["trajectories"] and (
                (decision_ids is not None and uid not in decision_ids) or
                state.current_motion_plan.get("local_trajectory_reference")
                and bundle["trajectories"][uid].get("inherited_reference",False))}
        bundle["schedule_events"] = {
            uid:{key:state.current_motion_plan.get(key) for key in (
                "schedule_round_id","plan_version","e_time_s","e_station_m",
                "e_entry_speed_mps","resource_windows","timed_resource_targets")}
            for uid,state in snapshot.states.items() if uid in bundle["trajectories"]}
        bundle["trajectory_id"] = bundle_digest(bundle)
        bundle["certification_id"] = hashlib.sha256(
            (str(snapshot.version)+":"+bundle["trajectory_id"]+":PASS").encode()).hexdigest()
        return bundle
    except ValueError as error:
        return dict(certification_status="UNAVAILABLE",reason=str(error),
                    diagnostics=getattr(error,"diagnostics",{}))


def bundle_digest(bundle):
    payload = {key:value for key,value in bundle.items()
               if key not in {"trajectory_id","certification_id"}}
    return hashlib.sha256(json.dumps(payload,sort_keys=True,default=str).encode()).hexdigest()


def verify_bundle(bundle, proposed, version):
    def same(left,right):
        return json.dumps(left,sort_keys=True,default=str)==json.dumps(right,sort_keys=True,default=str)
    if bundle.get("certification_status")!="PASS" or bundle.get("snapshot_version")!=version:
        raise ValueError("LTG_CERTIFICATION_VERSION_MISMATCH")
    identity = bundle_digest(bundle)
    expected = hashlib.sha256((str(version)+":"+identity+":PASS").encode()).hexdigest()
    if bundle.get("trajectory_id")!=identity or bundle.get("certification_id")!=expected:
        raise ValueError("LTG_CERTIFICATION_CONTENT_CHANGED")
    for uid,state in proposed.items():
        plan = state.current_motion_plan
        if uid not in bundle["trajectories"]:
            continue
        inherited=bundle.get("inherited_references",{}).get(uid)
        if inherited is not None:
            if any(not same(plan.get(key),value) for key,value in inherited.items()):
                raise ValueError("LTG_FROZEN_REFERENCE_CHANGED")
            if any(not same(plan.get(key),value) for key,value in bundle["schedule_events"][uid].items()):
                raise ValueError("LTG_PUBLICATION_SCHEDULE_MISMATCH")
            continue
        if (plan.get("local_trajectory_id")!=identity
                or not same(plan.get("local_trajectory_reference"),bundle["trajectories"][uid])
                or plan.get("local_certification_id")!=expected):
            raise ValueError("LTG_PUBLICATION_TRAJECTORY_MISMATCH")
        if any(not same(plan.get(key),value) for key,value in bundle["schedule_events"][uid].items()):
            raise ValueError("LTG_PUBLICATION_SCHEDULE_MISMATCH")


def _generate(snapshot, limits, config, schedule_id,*,decision_ids=None):
    now = snapshot.sim_time_s
    decision_ids=set(snapshot.states) if decision_ids is None else set(decision_ids)
    vertical = [s for s in snapshot.states.values()
                if s.current_motion_plan.get("schedule_result")=="RELEASED"
                and s.current_motion_plan.get("g_actual_time_s") is None]
    horizontal = [s for s in snapshot.states.values()
                  if s.current_motion_plan.get('schedule_result')!='RELEASED'
                  and s.state.value not in {'TRANSITION','VERTICAL','COMPLETED','EXITED','SERVICING',
                                           'REENTRY_HOLD','REENTRY_CLIMB','REENTRY_LAND_TO_GROUND',
                                           'REENTRY_ASCENT_TO_50M','REENTRY_STAGING_HOLD',
                                           'REENTRY_FINAL_APPROACH','HORIZON_CENSORED'}
                  and any(float(t['exit_time_s'])>now
                          for t in s.current_motion_plan.get('timed_resource_targets',()))]
    if not vertical and not horizontal:
        return dict(certification_status="PASS",trajectories={},resource_events=[],
                    e_entry_states={},dependencies=[],schedule_id=schedule_id)
    horizon = max([now+float(config['simulation']['dt_s'])]+
                  [float(s.current_motion_plan.get('e_time_s', now))
                   for s in vertical if s.uav_id in decision_ids]+
                  [float(t['exit_time_s']) for s in horizontal
                   if s.uav_id in decision_ids for t in s.current_motion_plan['timed_resource_targets']])-now
    if horizon <= 0:
        raise ValueError("LTG_E_TIME_EXPIRED")
    profiles,records,resources,terminals = {},{},{},{}
    v_ids = {s.uav_id for s in vertical}
    lane_front = {}
    lanes = {physical_lane(s) for s in (*vertical,*horizontal)}
    # All on-mainline members of affected lanes are retained. This is a
    # conservative superset of direct leaders/followers.
    states = sorted([s for s in snapshot.states.values()
              if physical_lane(s) in lanes and s.state.value not in
              {"TRANSITION","VERTICAL","COMPLETED","EXITED","SERVICING","REENTRY_HOLD","REENTRY_CLIMB",
               "REENTRY_LAND_TO_GROUND","REENTRY_ASCENT_TO_50M","REENTRY_STAGING_HOLD","REENTRY_FINAL_APPROACH",
               "HORIZON_CENSORED"}],
              key=lambda s:(-s.s_m,s.uav_id))
    for state in states:
        plan = state.current_motion_plan
        bound = limits[state.vehicle_type]
        kinematic = Limits(0.,bound.max_speed_mps,bound.max_abs_acceleration_mps2)
        aircraft = Aircraft(state.uav_id,state.s_m,state.speed_mps,
                            state.nominal_speed_mps or bound.max_speed_mps,kinematic)
        prior = plan.get("local_trajectory_reference")
        if state.uav_id not in decision_ids:
            # Existing targets remain immutable comparison baselines. A
            # departed reference is not a new exact execution obligation.
            try:
                if plan.get('runtime_reference_status')=='DEVIATED':
                    prior=None
                elif prior:
                    reference_interval(prior,state,now,float(config['simulation']['dt_s']))
            except ValueError:
                prior=None
        from .motion_executor import _is_pending_wait
        waiting = _is_pending_wait(state)
        front = lane_front.get(physical_lane(state))
        front_profile = profiles[front.uav_id] if front else None
        front_braking = limits[front.vehicle_type].max_abs_acceleration_mps2 if front else None
        future_targets = [t for t in plan.get("timed_resource_targets",()) if float(t["exit_time_s"])>now]
        duration = (horizon if state.uav_id in v_ids else
                    max(horizon,max((float(t["exit_time_s"])-now for t in future_targets),default=0.)))
        if state.uav_id not in v_ids and not future_targets:
            prior = None
        if waiting and not future_targets:
            prior = None
        if prior and now>=prior["start_time_s"]+prior["duration_s"]-1e-8:
            pending_targets = any(float(t["exit_time_s"])>now for t in plan.get("timed_resource_targets",()))
            if state.uav_id in decision_ids and (pending_targets or state.uav_id in v_ids):
                raise ValueError("LTG_REFERENCE_EXPIRED")
            prior = None
        cpff_witness=None
        if state.uav_id in v_ids and state.uav_id not in decision_ids and prior is None:
            duration=max(horizon,(float(plan.get('resource_entry_station_m', plan.get('e_station_m', state.s_m)))-state.s_m)/max(aircraft.nominal,.1)
                         +2*kinematic.v_max/kinematic.a_max+2.)
            profile=following_reference(aircraft,duration,front_profile,front_braking,
                                        min_gap=config['motion']['min_gap_m'])
            crossing=profile.crossing(float(plan['resource_entry_station_m']))
            if crossing is not None:
                profile=reference_interval(dict(start_time_s=now,duration_s=profile.duration_s,
                    pieces=[asdict(p) for p in profile.pieces]),state,now,crossing)
        elif (future_targets and state.uav_id not in v_ids and prior is None
                and state.uav_id in decision_ids
                and plan.get('cpff_execution',{}).get('status')=='ACTIVE'
                and plan['cpff_execution'].get('releases')):
            from .conditional_feasibility_feedback import protected_h_profile,verify_release_scope
            verify_release_scope(plan['cpff_execution'],snapshot)
            first=min(future_targets,key=lambda t:float(t['entry_time_s']))
            profile,cpff_witness=protected_h_profile(state,aircraft,first,now,duration,front,front_profile,
                                                    config['motion']['min_gap_m'])
        elif future_targets and state.uav_id not in v_ids and prior is None and state.uav_id in decision_ids:
            first=min(future_targets,key=lambda t:float(t["entry_time_s"]))
            speed=(float(first["exit_station_m"])-float(first["entry_station_m"])) / (
                float(first["exit_time_s"])-float(first["entry_time_s"]))
            if not 0<speed<=kinematic.v_max+1e-8:
                raise ValueError("LTG_H_SPEED_INVALID")
            speed=min(speed,kinematic.v_max)
            edge="entry" if float(first["entry_time_s"])>now else "exit"
            target_time=float(first[edge+"_time_s"])
            target_station=float(first[edge+"_station_m"])
            approach=terminal_slot_profile(aircraft,Slot(target_time,target_station,speed),
                                           now,target_time-now)
            pieces=approach.pieces
            if duration>approach.duration_s:
                pieces += (Piece(approach.duration_s,duration,approach.end[0],speed,0.),)
            profile=Profile(pieces,duration)
        elif waiting and not future_targets:
            from .trigger_rules import commit_distance_m
            if plan.get("execution_mode") == "CMLPM_RETRY_HOLD":
                boundary = float(state.s_m)
            else:
                boundary = float(plan.get("pending_hold",{}).get("stop_station_m",
                    float(plan.get("resource_entry_station_m", plan.get("e_station_m", state.s_m)))-commit_distance_m(state.vehicle_type)))
            profile = following_reference(aircraft,duration,front_profile,front_braking,
                stop_station=boundary,min_gap=config["motion"]["min_gap_m"])
        elif prior:
            profile = reference_interval(prior,state,now,duration)
            if profile.duration_s < duration-1e-8 and state.uav_id not in v_ids:
                position,speed = profile.end
                prefix_duration = profile.duration_s
                continuation = following_reference(
                    Aircraft(state.uav_id,position,speed,aircraft.nominal,kinematic),
                    duration-prefix_duration,front_profile,front_braking,
                    min_gap=config["motion"]["min_gap_m"],leader_time_offset=prefix_duration)
                tail = tuple(Piece(p.start_s+prefix_duration,p.end_s+prefix_duration,p.s0,p.v0,p.a)
                             for p in continuation.pieces)
                profile = Profile(profile.pieces+tail,duration)
        elif state.uav_id in v_ids:
            if plan.get("e_time_s") is not None:
                # C-MLPM schedules E; the approach profile realises the
                # template's actual E terminal state (which is below the
                # registered cap because the template decelerates into J).
                duration = float(plan["e_time_s"])-now
                profile = terminal_slot_profile(aircraft,Slot(
                    float(plan["e_time_s"]),
                    float(plan["resource_entry_station_m"]),
                    float(plan["e_entry_speed_mps"])),now,duration)
            else:
                raise ValueError("LTG_E_ANCHOR_MISSING")
        else:
            targets = [t for t in plan.get("timed_resource_targets",())
                       if float(t["exit_time_s"])>now]
            speed = min(aircraft.nominal,kinematic.v_max)
            if targets:
                first = targets[0]
                speed = ((float(first["exit_station_m"])-float(first["entry_station_m"])) /
                         (float(first["exit_time_s"])-float(first["entry_time_s"])))
            if not 0 < speed <= kinematic.v_max+1e-8:
                raise ValueError("LTG_H_SPEED_INVALID")
            speed = min(speed,kinematic.v_max)
            last_exit = max((float(t["exit_time_s"]) for t in targets),default=now)
            if targets:
                profile = build_profile(aircraft,speed,max(horizon,last_exit-now))
            else:
                profile = following_reference(aircraft,horizon,front_profile,front_braking,
                    min_gap=config["motion"]["min_gap_m"])
        profiles[state.uav_id] = profile
        lane_front[physical_lane(state)] = state
        records[state.uav_id] = dict(start_time_s=now,duration_s=profile.duration_s,
                                    pieces=[asdict(p) for p in profile.pieces],
                                    inherited_reference=prior is not None)
        if cpff_witness is not None:records[state.uav_id]['cpff_witness']=cpff_witness
        if state.uav_id in v_ids and state.uav_id in decision_ids:
            check_time = float(plan["e_time_s"])
            check_station = float(plan["resource_entry_station_m"])
            check_speed = float(plan["e_entry_speed_mps"])
            position,speed = profile.state_at(check_time-now)
            if abs(position-check_station)>1e-6 or abs(speed-check_speed)>1e-6:
                raise ValueError("LTG_E_TERMINAL_MISMATCH")
            terminals[state.uav_id] = dict(time_s=check_time,position_m=position,speed_mps=speed)
            trajectory = plan["descent_trajectory"]
            origin_time = check_time
            measured = trajectory_resource_windows(trajectory)
            for rid,entry,exit_ in plan["resource_windows"]:
                if rid not in measured or max(abs(origin_time+measured[rid][0]-entry),
                                               abs(origin_time+measured[rid][1]-exit_))>1e-6:
                    raise ValueError("LTG_V_RESOURCE_MISMATCH")
                resources.setdefault(rid,[]).append((entry,exit_,state.uav_id,"V"))
            records[state.uav_id]["descent_trajectory"] = trajectory
        elif state.uav_id in v_ids:
            # Dependency forecasts use the actual state. They neither reset a
            # published G target nor require an expired target to be reached.
            from .existing_v_continuation import current_v_resource_windows,ExecutedEvent
            forecast,_=current_v_resource_windows(state,t_now=now,
                resource_windows=plan['resource_windows'],
                e_time_s=float(plan["e_time_s"]),
                e_to_j_s=float(plan.get("e_to_j_s", 0.0)),
                executed=tuple(ExecutedEvent(**e) for e in plan.get('motion_observed_events',())))
            for rid,(entry,exit_) in forecast.items():
                resources.setdefault(rid,[]).append((entry,exit_,state.uav_id,'V'))
        else:
            for target in plan.get("timed_resource_targets",()):
                if float(target["exit_time_s"]) <= now:
                    continue
                for edge in ("entry","exit"):
                    expected = float(target[edge+"_time_s"])
                    station = float(target[edge+"_station_m"])
                    if expected > now and state.uav_id in decision_ids:
                        crossing = profile.crossing(station)
                        if crossing is None or abs(now+crossing-expected)>1e-6:
                            raise ValueError("LTG_FROZEN_H_EVENT_MISMATCH")
                resources.setdefault(target["resource_id"],[]).append((
                    float(target["entry_time_s"]),float(target["exit_time_s"]),state.uav_id,"H"))
        for piece in profile.pieces:
            speeds = (piece.v0,piece.state_at(piece.end_s)[1])
            if (piece.end_s<=piece.start_s or abs(piece.a)>kinematic.a_max+1e-6
                    or min(speeds)<-1e-8 or max(speeds)>kinematic.v_max+1e-6):
                raise ValueError("LTG_CAPABILITY_FAILED")

    minimum, conflicts = collect_gap_conflicts(states, profiles, lanes,
        required_gap_m=float(config['motion']['min_gap_m']), now=now,
        snapshot_version=snapshot.version)
    if conflicts:
        # Keep the first witness fields for existing diagnostic consumers;
        # CPFF consumes the complete, deterministic batch from this candidate.
        raise TrajectoryCertificationError('LTG_CONTINUOUS_GAP_FAILED',dict(
            **conflicts[0], conflicts=conflicts, conflict_count=len(conflicts),
            trajectories=records,resource_events=resources,e_entry_states=terminals))
    # Frozen trajectory events from vehicles already off the mainline remain
    # resource dependencies even when they have no approach profile.
    for state in {**snapshot.resource_dependencies,**snapshot.states}.values():
        if state.uav_id in profiles:
            continue
        for rid,entry,exit_ in state.current_motion_plan.get("resource_windows",()):
            resources.setdefault(rid,[]).append((entry,exit_,state.uav_id,"V"))
    safety = config["resource_safety"]
    state_by_id = {
        state.uav_id: state
        for state in {**snapshot.resource_dependencies, **snapshot.states}.values()
    }
    for uses in resources.values():
        for i,prior in enumerate(sorted(uses)):
            for current in sorted(uses)[i+1:]:
                if prior[2]==current[2] or prior[3]==current[3]=="H":
                    continue
                if prior[3] != current[3]:
                    vertical_id = prior[2] if prior[3] == "V" else current[2]
                    mainline_id = current[2] if prior[3] == "V" else prior[2]
                    mainline_state = state_by_id.get(mainline_id)
                    vertical_state = state_by_id.get(vertical_id)
                    if (mainline_state is not None and vertical_state is not None
                            and not is_cross_layer_vh_pair(mainline_state, vertical_state)):
                        continue
                headway = float(safety["vv_min_entry_headway_s"]) if prior[3]==current[3] else SHARED_RESOURCE_ENTRY_HEADWAY_S
                if current[0]-prior[0] < headway-1e-6:
                    raise ValueError("LTG_RESOURCE_ENTRY_HEADWAY")
                if prior[3]!=current[3]:
                    margin = float(safety["vh_v_to_h_margin_s"] if prior[3]=="V" else safety["vh_h_to_v_margin_s"])
                    if current[0]<prior[1]+margin-1e-6:
                        raise ValueError("LTG_VH_EXIT_MARGIN")
    dependencies = [dict(uav_id=s.uav_id,position_m=s.s_m,speed_mps=s.speed_mps,
                         motion_plan=s.current_motion_plan) for s in states]
    identity = dict(version=snapshot.version,time_s=now,dependencies=dependencies,
                    resource_dependencies=snapshot.resource_dependencies,
                    motion_limits={key:asdict(value) for key,value in limits.items()},
                    resource_safety=safety)
    digest = hashlib.sha256(json.dumps(identity,sort_keys=True,default=str).encode()).hexdigest()
    bundle = dict(snapshot_hash=digest,schedule_id=schedule_id,trajectories=records,
                  e_entry_states=terminals,resource_events=resources,
                  dependencies=[s.uav_id for s in states],certification_status="PASS",
                  minimum_gap_m=minimum if math.isfinite(minimum) else None)
    bundle["trajectory_id"] = hashlib.sha256(json.dumps(bundle,sort_keys=True,default=str).encode()).hexdigest()
    return bundle


def certified_approach_covers(snapshot, h, v,*,mainline_crossings=None,resource_safety=None,min_mainline_gap_m=None):
    """Check the pair and its upstream leaders, not unrelated lane members.

    Bundle identity is provenance, not a physical dependency. References from
    different publications may coexist only when their current intervals,
    continuous gaps and the actual H/V crossing order remain compatible.
    """
    if not is_cross_layer_vh_pair(h, v):
        return False
    anchors={physical_lane(s):s.s_m for s in (h,v)}
    if physical_lane(h)==physical_lane(v):
        anchors[physical_lane(v)]=min(h.s_m,v.s_m)
    profiles={};members=[]
    for state in snapshot.states.values():
        lane=physical_lane(state)
        if lane not in anchors or state.s_m<anchors[lane]-1e-8 or state.state.value in {
            "TRANSITION","VERTICAL","COMPLETED","EXITED","SERVICING","REENTRY_HOLD","REENTRY_CLIMB",
            "REENTRY_LAND_TO_GROUND","REENTRY_ASCENT_TO_50M","REENTRY_STAGING_HOLD","REENTRY_FINAL_APPROACH"}:
            continue
        plan = state.current_motion_plan
        if plan.get("runtime_reference_status")=="DEVIATED":
            return False
        if not plan.get("local_trajectory_id") or not plan.get("local_certification_id"):
            return False
        record = plan.get("local_trajectory_reference")
        if not record:
            return False
        try:
            profiles[state.uav_id]=reference_interval(record,state,snapshot.sim_time_s,
                float(record['duration_s']))
        except ValueError:
            return False
        members.append(state)
    if h.uav_id not in profiles or v.uav_id not in profiles:
        return False
    from .execution_precedence import registered_mainline_gap,registered_environment
    if mainline_crossings is None or resource_safety is None:
        crossings,_,safety=registered_environment()
        if mainline_crossings is None:mainline_crossings=crossings
        if resource_safety is None:resource_safety=safety
    gap=registered_mainline_gap() if min_mainline_gap_m is None else float(min_mainline_gap_m)
    for lane in anchors:
        ordered=sorted((s for s in members if physical_lane(s)==lane),key=lambda s:(-s.s_m,s.uav_id))
        if any(continuous_gap_evidence(profiles[a.uav_id],profiles[b.uav_id])['gap_m']<
               gap-1e-6 for a,b in zip(ordered,ordered[1:])):
            return False
    # Verify every shared H-before-V resource with these same physical
    # references. A matching ID alone must never authorize continuation.
    checked=False
    v_profile=profiles[v.uav_id]
    tau=v_profile.crossing(float(v.current_motion_plan['resource_entry_station_m']))
    if tau is None:return False
    record=v.current_motion_plan['local_trajectory_reference']
    descent=record.get('descent_trajectory')
    if not descent:return False
    windows=trajectory_resource_windows(descent)
    actual={str(e['resource_id']):float(e['actual_time_s']) for e in h.current_motion_plan.get('motion_observed_events',())
            if e['event_type']=='RESOURCE_EXIT'}
    entries={str(e['resource_id']):float(e['actual_time_s']) for e in h.current_motion_plan.get('motion_observed_events',())
             if e['event_type']=='RESOURCE_ENTER'}
    for rid,entry,exit_ in mainline_crossings.get((h.direction,h.layer),()):
        if rid not in windows:continue
        checked=True
        h_exit=(actual[rid]-snapshot.sim_time_s if rid in actual else profiles[h.uav_id].crossing(float(exit_)))
        h_entry=(entries[rid]-snapshot.sim_time_s if rid in entries else profiles[h.uav_id].crossing(float(entry)))
        if (h_exit is None or h_entry is None or tau+windows[rid][0]<max(
                h_exit+float(resource_safety['vh_h_to_v_margin_s']),
                h_entry+SHARED_RESOURCE_ENTRY_HEADWAY_S)-1e-6):
            return False
    return checked
