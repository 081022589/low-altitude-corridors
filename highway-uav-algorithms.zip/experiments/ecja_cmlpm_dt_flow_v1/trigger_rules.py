"""Canonical ECJA request-boundary and trigger-distance rules."""

from __future__ import annotations

import json
import math
from pathlib import Path
from types import MappingProxyType
from typing import Any, Mapping


_ROOT = Path(__file__).resolve().parents[2]
_PARAMETER_PATH = _ROOT / "configs" / "G25_TRAFFIC_TRIGGER_PARAMS_20261015.json"


def _load_parameters() -> Mapping[str, Any]:
    payload = json.loads(_PARAMETER_PATH.read_text(encoding="utf-8"))
    period = float(payload["decisions"]["delta_t_ecja_s"]["value"])
    multiplier = float(payload["decisions"]["request_guard_multiplier"]["value"])
    if not math.isfinite(period) or period <= 0.0:
        raise ValueError("INVALID_REGISTERED_ECJA_PERIOD")
    if not math.isfinite(multiplier) or multiplier < 1.0:
        raise ValueError("INVALID_REGISTERED_REQUEST_GUARD_MULTIPLIER")
    return MappingProxyType(payload)


PARAMETERS = _load_parameters()
# Preserve the registered distance scale. This is no longer an active ECJA
# solve period; the old name remains for explicit historical coordinator users.
ECJA_REGULAR_PERIOD_S = float(PARAMETERS["decisions"]["delta_t_ecja_s"]["value"])
BATCH_PARAMETERS = MappingProxyType(json.loads(
    (_ROOT / "configs/ECJA_BATCH_TRIGGER_PARAMS_20261021.json").read_text(encoding="utf-8")))
COMMIT_DISTANCE_REFERENCE_S = float(BATCH_PARAMETERS["commit_distance_reference_s"])
REQUEST_GUARD_MULTIPLIER = float(BATCH_PARAMETERS["request_generation_multiplier"])
LATEST_ASSIGNMENT_MULTIPLIER = float(BATCH_PARAMETERS["latest_assignment_multiplier"])
ECJA_DEADLINE_MULTIPLIER = float(BATCH_PARAMETERS["ecja_deadline_multiplier"])
DEFAULT_ECJA_BATCH_SIZE = int(BATCH_PARAMETERS["batch_size"])
if not (math.isfinite(REQUEST_GUARD_MULTIPLIER) and math.isfinite(ECJA_DEADLINE_MULTIPLIER)
        and math.isfinite(LATEST_ASSIGNMENT_MULTIPLIER)
        and REQUEST_GUARD_MULTIPLIER > ECJA_DEADLINE_MULTIPLIER > LATEST_ASSIGNMENT_MULTIPLIER > 0
        and COMMIT_DISTANCE_REFERENCE_S == ECJA_REGULAR_PERIOD_S):
    raise ValueError("ECJA_BATCH_DISTANCE_REGISTRY_INVALID")


def adjustment_distance_m(vehicle_type: str) -> float:
    row = PARAMETERS["per_type"][vehicle_type]
    nominal = float(row["nominal_cruise_speed_mps"])
    minimum = float(row["min_forward_speed_mps"])
    deceleration = float(row["max_deceleration_mps2"])
    return (nominal * nominal - minimum * minimum) / (2.0 * deceleration)


def commit_distance_m(vehicle_type: str) -> float:
    row = PARAMETERS["per_type"][vehicle_type]
    value = (
        float(row["nominal_cruise_speed_mps"]) * COMMIT_DISTANCE_REFERENCE_S
        + adjustment_distance_m(vehicle_type)
    )
    registered = float(row["commit_distance_m"])
    if not math.isclose(value, registered, rel_tol=0.0, abs_tol=1e-9):
        raise ValueError(f"REGISTERED_COMMIT_DISTANCE_MISMATCH:{vehicle_type}")
    return value


def request_guard_distance_m(vehicle_type: str) -> float:
    """Return the active request/energy guard from the batch registry.

    The current frozen value is 5*D_commit. This boundary is distinct from
    the 3.5*D_commit ECJA deadline and the 3*D_commit C-MLPM boundary.
    """
    return REQUEST_GUARD_MULTIPLIER * commit_distance_m(vehicle_type)


def latest_assignment_distance_m(vehicle_type: str) -> float:
    """C-MLPM control boundary: the node starts owning this aircraft here."""
    return LATEST_ASSIGNMENT_MULTIPLIER * commit_distance_m(vehicle_type)


def ecja_deadline_distance_m(vehicle_type: str) -> float:
    """ECJA assignment deadline, one half-step upstream of the C-MLPM boundary.

    Keeping the two apart gives the assignment one observation step of margin:
    an aircraft that is assigned exactly at this deadline still reaches the
    C-MLPM read with an assignment rather than entering it as an unassigned H.
    """
    return ECJA_DEADLINE_MULTIPLIER * commit_distance_m(vehicle_type)
