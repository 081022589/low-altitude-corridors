from __future__ import annotations

from dataclasses import dataclass, replace
import math

from ecja_qsap.history_context import request_allows_stop_start
from .simulation_state import UAVState


# Positions accumulate thousands of 0.5 s integrations.  Use the same
# absolute metre tolerance as the formal hard audit so nanometre roundoff at a
# mathematically exact 50 m boundary does not become a false infeasibility.
_GAP_TOL_M = 1e-6
_SPEED_TOL_MPS = 1e-8
# Absolute seconds, for piece coverage only. This is the existing validation
# tolerance, not additional distance clearance or event-time slack.
TIME_COVERAGE_TOL_S = 1e-9


@dataclass(frozen=True)
class MotionLimits:
    min_speed_mps: float
    max_speed_mps: float
    max_abs_acceleration_mps2: float


def stop_start_limits(state: UAVState, normal: MotionLimits) -> MotionLimits:
    """Allow an assigned G approach to brake or restart without a speed quota.

    The ordinary cruising floor is not a minimum physical speed for a UAV
    that already has registered G and stop geometry. The model's bounded
    braking/restart capability applies before any scheduling or waiting label.
    """
    plan = state.current_motion_plan
    assigned_g=(state.assigned_node is not None and state.commit_status=="COMMITTED"
                and "g_station_m" in plan and "stop_station_m" in plan)
    if assigned_g or request_allows_stop_start(plan) or "pending_hold" in plan:
        return replace(normal, min_speed_mps=0.)
    return normal


@dataclass(frozen=True)
class MotionPiece:
    start_s: float
    end_s: float
    start_position_m: float
    start_speed_mps: float
    acceleration_mps2: float

    def state_at(self, time_s: float) -> tuple[float, float]:
        tau = min(max(time_s, self.start_s), self.end_s) - self.start_s
        velocity = self.start_speed_mps + self.acceleration_mps2 * tau
        if -_SPEED_TOL_MPS <= velocity < 0.:
            velocity = 0.  # roundoff at an analytically exact braking zero
        return (
            self.start_position_m + self.start_speed_mps * tau + 0.5 * self.acceleration_mps2 * tau * tau,
            velocity,
        )


@dataclass(frozen=True)
class TickProfile:
    pieces: tuple[MotionPiece, ...]
    duration_s: float

    def state_at(self, time_s: float) -> tuple[float, float]:
        for piece in self.pieces:
            if time_s <= piece.end_s + 1e-12:
                return piece.state_at(time_s)
        return self.pieces[-1].state_at(self.duration_s)


def validate_tick_profile(profile: TickProfile, state: UAVState, limits: MotionLimits, dt_s: float) -> None:
    """Check finite, contiguous bounded motion before accepting a tick."""
    if (not profile.pieces or not math.isfinite(dt_s) or dt_s <= 0
            or not math.isfinite(profile.duration_s)
            or abs(profile.duration_s-dt_s) > TIME_COVERAGE_TOL_S):
        raise ValueError("INVALID_TICK_PROFILE_DURATION")
    clock, position, speed = 0., float(state.s_m), float(state.speed_mps)
    for piece in profile.pieces:
        if (not all(math.isfinite(v) for v in (piece.start_s, piece.end_s, piece.start_position_m,
                                              piece.start_speed_mps, piece.acceleration_mps2))
                or piece.end_s <= piece.start_s or abs(piece.start_s-clock) > TIME_COVERAGE_TOL_S
                or abs(piece.start_position_m-position) > _GAP_TOL_M
                or abs(piece.start_speed_mps-speed) > _SPEED_TOL_MPS
                or abs(piece.acceleration_mps2) > limits.max_abs_acceleration_mps2+1e-8):
            raise ValueError("INVALID_TICK_PROFILE_CONTINUITY")
        position, end_speed = piece.state_at(piece.end_s)
        if (min(piece.start_speed_mps, end_speed) < limits.min_speed_mps-_SPEED_TOL_MPS
                or max(piece.start_speed_mps, end_speed) > limits.max_speed_mps+_SPEED_TOL_MPS):
            raise ValueError("INVALID_TICK_PROFILE_SPEED")
        speed, clock = end_speed, piece.end_s
    if abs(clock-dt_s) > TIME_COVERAGE_TOL_S:
        raise ValueError("INVALID_TICK_PROFILE_COVERAGE")
    _covered_time_intervals(profile)


def _covered_time_intervals(profile: TickProfile) -> tuple[tuple[float, float, MotionPiece], ...]:
    """Read-only coverage normalization, also supporting intentional prefixes.

    A piece may continue beyond a profile's queried duration (e.g. until G).
    Only sub-tolerance endpoint differences are normalized. Real holes or
    overlaps fail closed; neither positions nor input pieces are rewritten.
    """
    duration = profile.duration_s
    if not profile.pieces or not math.isfinite(duration) or duration <= 0:
        raise ValueError("INVALID_TICK_PROFILE_DURATION")
    intervals = []
    clock = 0.
    for index, piece in enumerate(profile.pieces):
        if (not all(math.isfinite(value) for value in (
                piece.start_s, piece.end_s, piece.start_position_m,
                piece.start_speed_mps, piece.acceleration_mps2))
                or piece.end_s <= piece.start_s
                or abs(piece.start_s-clock) > TIME_COVERAGE_TOL_S):
            raise ValueError("INVALID_TICK_PROFILE_CONTINUITY")
        end = min(piece.end_s, duration)
        if index == len(profile.pieces)-1 and abs(end-duration) <= TIME_COVERAGE_TOL_S:
            end = duration
        if end <= clock:
            raise ValueError("INVALID_TICK_PROFILE_CONTINUITY")
        intervals.append((clock, end, piece))
        clock = end
        if clock == duration:
            return tuple(intervals)
    raise ValueError("INVALID_TICK_PROFILE_COVERAGE")


def _continuous_piece_state(piece: MotionPiece, time_s: float) -> tuple[float, float]:
    # On a normalized time boundary use the same polynomial continuously,
    # rather than clamping position/speed to the rounded raw endpoint.
    tau = time_s-piece.start_s
    return (piece.start_position_m+piece.start_speed_mps*tau+.5*piece.acceleration_mps2*tau*tau,
            piece.start_speed_mps+piece.acceleration_mps2*tau)


def bounded_profile(state: UAVState, acceleration: float, limits: MotionLimits, dt_s: float) -> TickProfile:
    if (not all(math.isfinite(v) for v in (dt_s, acceleration, state.s_m, state.speed_mps,
                                          limits.min_speed_mps, limits.max_speed_mps,
                                          limits.max_abs_acceleration_mps2))
            or dt_s <= 0 or limits.min_speed_mps < 0 or limits.min_speed_mps > limits.max_speed_mps
            or limits.max_abs_acceleration_mps2 <= 0):
        raise ValueError("INVALID_MOTION_CONTRACT")
    acceleration = max(-limits.max_abs_acceleration_mps2, min(limits.max_abs_acceleration_mps2, acceleration))
    speed = float(state.speed_mps)
    if not limits.min_speed_mps - _SPEED_TOL_MPS <= speed <= limits.max_speed_mps + _SPEED_TOL_MPS:
        raise ValueError("INITIAL_SPEED_OUTSIDE_D1")
    speed = min(limits.max_speed_mps, max(limits.min_speed_mps, speed))
    if (
        acceleration < 0.0 and speed <= limits.min_speed_mps + _SPEED_TOL_MPS
    ) or (
        acceleration > 0.0 and speed >= limits.max_speed_mps - _SPEED_TOL_MPS
    ):
        acceleration = 0.0
    target = limits.max_speed_mps if acceleration > 0 else limits.min_speed_mps
    hit = math.inf if abs(acceleration) < 1e-15 else (target - speed) / acceleration
    pieces: list[MotionPiece] = []
    if 0.0 < hit < dt_s:
        first = MotionPiece(0.0, hit, state.s_m, speed, acceleration)
        position, bounded_speed = first.state_at(hit)
        pieces.extend((first, MotionPiece(hit, dt_s, position, bounded_speed, 0.0)))
    else:
        pieces.append(MotionPiece(0.0, dt_s, state.s_m, speed, acceleration))
    return TickProfile(tuple(pieces), dt_s)


def reservation_distance_interval(
    initial_speed_mps: float,
    terminal_speed_mps: float,
    duration_s: float,
    limits: MotionLimits,
) -> tuple[float, float] | None:
    """Exact free-flow distance interval at a prescribed arrival time.

    This is the first, kinematic stage of G reservation screening. It assumes
    symmetric acceleration bounds and no leader or spatial obstruction. A
    value inside this interval still requires trajectory and safety auditing.
    """
    v0=float(initial_speed_mps)
    vf=float(terminal_speed_mps)
    T=float(duration_s)
    a=float(limits.max_abs_acceleration_mps2)
    lo=float(limits.min_speed_mps)
    hi=float(limits.max_speed_mps)
    if not all(map(math.isfinite,(v0,vf,T,a,lo,hi))) or T<0. or a<=0. or lo<0. or hi<lo:
        raise ValueError("RESERVATION_REACHABILITY_PARAMETERS_INVALID")
    if min(v0,vf)<lo-_SPEED_TOL_MPS or max(v0,vf)>hi+_SPEED_TOL_MPS:
        return None
    if abs(vf-v0)>a*T+_SPEED_TOL_MPS:
        return None
    if T==0.:
        return (0.,0.)

    # Maximal displacement: accelerate to the peak, cruise if the cap is hit,
    # then decelerate to the prescribed terminal speed.
    peak=min(hi,.5*(v0+vf+a*T))
    up=max(0.,(peak-v0)/a)
    down=max(0.,(peak-vf)/a)
    maximum=.5*(v0+peak)*up+peak*max(0.,T-up-down)+.5*(vf+peak)*down

    # Minimal displacement is the time-reversed valley construction.
    valley=max(lo,.5*(v0+vf-a*T))
    down=max(0.,(v0-valley)/a)
    up=max(0.,(vf-valley)/a)
    minimum=.5*(v0+valley)*down+valley*max(0.,T-down-up)+.5*(valley+vf)*up
    return (minimum,maximum)


def reservation_profile_to_g(
    state: UAVState,
    limits: MotionLimits,
    *,
    duration_s: float,
    g_station_m: float,
    terminal_speed_mps: float,
) -> TickProfile:
    """Construct a bounded continuous trajectory to a prescribed G event.

    The upper and lower reachable speed envelopes are piecewise linear. Their
    convex combination has the requested displacement and terminal speed,
    without a grid, a numerical optimizer, or any adjustment of the event.
    Leader-dependent feasibility is checked separately before publication.
    """
    T=float(duration_s)
    if not math.isfinite(T) or T <= 0.:
        raise ValueError("G_RESERVATION_TIME_INVALID")
    start=float(state.s_m)
    target=float(g_station_m)
    v0=float(state.speed_mps)
    vf=float(terminal_speed_mps)
    distance=target-start
    interval=reservation_distance_interval(v0,vf,T,limits)
    if interval is None or distance<interval[0]-_GAP_TOL_M or distance>interval[1]+_GAP_TOL_M:
        raise ValueError("G_RESERVATION_KINEMATICALLY_UNREACHABLE")
    a=float(limits.max_abs_acceleration_mps2)
    if abs(distance-v0*T)<=1e-9 and abs(vf-v0)<=_SPEED_TOL_MPS:
        return TickProfile((MotionPiece(0.,T,start,v0,0.),),T)

    # Every change of the active affine bound occurs at an intersection.
    upper=((v0,a),(vf+a*T,-a),(float(limits.max_speed_mps),0.))
    lower=((v0,-a),(vf-a*T,a),(float(limits.min_speed_mps),0.))
    cuts=[0.,T]
    for family in (upper,lower):
        for i,(b0,m0) in enumerate(family):
            for b1,m1 in family[i+1:]:
                if abs(m0-m1)>1e-14:
                    t=(b1-b0)/(m0-m1)
                    if 1e-10<t<T-1e-10:
                        cuts.append(t)
    cuts=sorted(cuts)
    knots=[]
    for t in cuts:
        if not knots or t-knots[-1]>1e-9:
            knots.append(t)
    knots[0],knots[-1]=0.,T

    def bounds(t: float) -> tuple[float,float]:
        return (max(b+m*t for b,m in lower),min(b+m*t for b,m in upper))

    low_distance=high_distance=0.
    for left,right in zip(knots,knots[1:]):
        low0,high0=bounds(left)
        low1,high1=bounds(right)
        width=right-left
        low_distance+=.5*(low0+low1)*width
        high_distance+=.5*(high0+high1)*width
    spread=high_distance-low_distance
    if spread<=1e-10:
        if abs(distance-low_distance)>_GAP_TOL_M:
            raise ValueError("G_RESERVATION_NUMERIC_RANGE")
        weight=0.
    else:
        weight=min(1.,max(0.,(distance-low_distance)/spread))

    def speed(t: float) -> float:
        low,high=bounds(t)
        return low+weight*(high-low)

    pieces=[]
    position=start
    for left,right in zip(knots,knots[1:]):
        left_speed,right_speed=speed(left),speed(right)
        width=right-left
        acceleration=(right_speed-left_speed)/width
        pieces.append(MotionPiece(left,right,position,left_speed,acceleration))
        position+=.5*(left_speed+right_speed)*width
    profile=TickProfile(tuple(pieces),T)
    validate_tick_profile(profile,state,limits,T)
    actual_position,actual_speed=profile.state_at(T)
    if abs(actual_position-target)>_GAP_TOL_M or abs(actual_speed-vf)>_SPEED_TOL_MPS:
        raise ValueError("G_RESERVATION_NUMERIC_ENDPOINT")
    return profile


def continuous_min_gap(leader: TickProfile, follower: TickProfile) -> float:
    intervals = (_covered_time_intervals(leader), _covered_time_intervals(follower))
    duration = min(leader.duration_s, follower.duration_s)
    boundaries = {0.0, duration}
    for spans in intervals:
        for start, end, _ in spans:
            if 0.0 < start < duration:
                boundaries.add(start)
            if 0.0 < end < duration:
                boundaries.add(end)
    ordered = sorted(boundaries)
    indices = [0, 0]
    minimum = math.inf
    for start, end in zip(ordered, ordered[1:]):
        pieces = []
        for owner, spans in enumerate(intervals):
            # The right segment owns the interval after a knot, even if the
            # interval is too narrow to represent a distinct midpoint.
            while indices[owner] < len(spans) and spans[indices[owner]][1] <= start:
                indices[owner] += 1
            if indices[owner] == len(spans):
                raise ValueError("INVALID_TICK_PROFILE_COVERAGE")
            left, right, piece = spans[indices[owner]]
            if left > start or right < end:
                raise ValueError("INVALID_TICK_PROFILE_COVERAGE")
            pieces.append(piece)
        lp, fp = pieces
        ls, lv = _continuous_piece_state(lp, start)
        fs, fv = _continuous_piece_state(fp, start)
        initial_gap = ls-fs
        end_gap = _continuous_piece_state(lp, end)[0]-_continuous_piece_state(fp, end)[0]
        minimum = min(minimum, initial_gap, end_gap)
        relative_acceleration = lp.acceleration_mps2 - fp.acceleration_mps2
        if relative_acceleration != 0.:
            tau = -(lv-fv)/relative_acceleration
            if 0. < tau < end-start:
                minimum = min(minimum, initial_gap+(lv-fv)*tau+.5*relative_acceleration*tau*tau)
    return minimum


