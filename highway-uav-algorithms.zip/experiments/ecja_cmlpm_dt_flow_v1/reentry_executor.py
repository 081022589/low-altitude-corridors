"""Advance the three post-service re-entry states.

This module is deliberately separate from ``motion_executor.py`` and
``motion_advance_v1.py``: the existing mainline and descent motion paths are not
touched.  The closed loop calls these functions only for ``SERVICING``,
``REENTRY_HOLD`` and ``REENTRY_CLIMB``.

Phase contract::

    B_L1 descent handoff --begin_service--> SERVICING
    B_L1 --ground profile--> SERVICING
    SERVICING --service_duration--> REENTRY_ASCENT_TO_50M
    REENTRY_ASCENT_TO_50M --stage profile--> REENTRY_STAGING_HOLD
    REENTRY_STAGING_HOLD --certificate + release--> REENTRY_FINAL_APPROACH
    REENTRY_FINAL_APPROACH --profile merge--> MAINLINE
"""

from __future__ import annotations

from dataclasses import replace
from configs.runtime_parameters import runtime_config

from .reentry_motion import ReentryMotionProfile
from .simulation_state import FlightState, UAVState


TIME_TOLERANCE_S = 1e-9


def _require(state: UAVState, *allowed: FlightState) -> None:
    if state.state not in allowed:
        raise ValueError(
            f"REENTRY_PHASE_INVALID:{state.uav_id}:{state.state.value}:"
            f"{','.join(item.value for item in allowed)}"
        )


def begin_service(state: UAVState, *, now_s: float, config=None) -> UAVState:
    """Move a just-landed UAV into ``SERVICING``."""

    _require(state, FlightState.COMPLETED)
    plan = dict(state.current_motion_plan)
    plan.setdefault('reentry_node_id', state.assigned_node)
    plan["reentry_service_started_s"] = float(now_s)
    return replace(
        state,
        state=FlightState.SERVICING,
        z_m=min(float(state.z_m), float(runtime_config(config)["network"]["b_l1_z_m"])),
        speed_mps=0.0,
        current_motion_plan=plan,
        event_version=state.event_version + 1,
    )


def advance_servicing(
    state: UAVState, *, now_s: float, service_duration_s: float
) -> UAVState:
    """Hold in ``SERVICING`` until the fixed ground service finishes."""

    _require(state, FlightState.SERVICING)
    duration = max(0.0, float(service_duration_s))
    started = float(state.current_motion_plan.get("reentry_service_started_s", 0.0))
    done = started + duration
    if float(now_s) < done - TIME_TOLERANCE_S:
        return state
    plan = dict(state.current_motion_plan)
    plan["reentry_service_done_s"] = done
    plan["reentry_hold_started_s"] = done
    return replace(
        state,
        state=FlightState.REENTRY_HOLD,
        speed_mps=0.0,
        current_motion_plan=plan,
        event_version=state.event_version + 1,
    )


def begin_ground_landing(state: UAVState, *, now_s: float, profile) -> UAVState:
    """Start the physical B_L1-to-ground stage."""
    # V5 emits the B_L1 handoff as SERVICING before the outer lifecycle
    # wrapper gets a chance to attach the physical landing profile.  Treat
    # that value as a provisional handoff, not as service having started.
    _require(state, FlightState.COMPLETED, FlightState.SERVICING)
    plan = dict(state.current_motion_plan)
    plan.setdefault('reentry_node_id', plan.get('service_node_id') or state.assigned_node)
    plan['reentry_stage_profile'] = profile.as_dict()
    plan['reentry_stage_kind'] = 'LAND_TO_GROUND'
    plan['reentry_stage_started_s'] = float(now_s)
    start_xyz = tuple(profile.trajectory.get('start_xyz', (state.s_m, 0.0, state.z_m)))
    plan['motion_position_xyz'] = start_xyz
    return replace(state, state=FlightState.REENTRY_LAND_TO_GROUND,
                   s_m=float(start_xyz[0]), z_m=float(start_xyz[2]), speed_mps=0.0,
                   current_motion_plan=plan,
                   event_version=state.event_version + 1)


def begin_ground_access(state: UAVState, *, now_s: float, profile, staging_token: str) -> UAVState:
    """Start ground transfer plus independent ascent to the staging height."""
    _require(state, FlightState.REENTRY_HOLD)
    plan = dict(state.current_motion_plan)
    plan.pop('reentry_profile', None)
    plan['reentry_stage_profile'] = profile.as_dict()
    plan['reentry_stage_kind'] = 'ASCENT_TO_50M'
    plan['reentry_stage_started_s'] = float(now_s)
    plan['staging_occupancy_token'] = str(staging_token)
    return replace(state, state=FlightState.REENTRY_ASCENT_TO_50M,
                   speed_mps=0.0, current_motion_plan=plan,
                   event_version=state.event_version + 1)


def hold_wait_s(state: UAVState, *, now_s: float) -> float:
    if state.state is not FlightState.REENTRY_HOLD:
        return 0.0
    started = float(state.current_motion_plan.get("reentry_hold_started_s", now_s))
    return max(0.0, float(now_s) - started)


def start_climb(
    state: UAVState,
    *,
    now_s: float,
    certificate: object,
    profile: ReentryMotionProfile,
) -> UAVState:
    """Start the certified climb once ``release`` arrives."""

    _require(state, FlightState.REENTRY_HOLD, FlightState.REENTRY_STAGING_HOLD,
             FlightState.REENTRY_LOCAL_HOLD)
    if str(certificate.uav_id) != str(state.uav_id):
        raise ValueError(f"REENTRY_CERTIFICATE_UAV_MISMATCH:{state.uav_id}")
    if certificate.geometry.direction != state.direction or certificate.geometry.layer != state.layer:
        raise ValueError('REENTRY_CERTIFICATE_FLOW_MISMATCH')
    if max(abs(certificate.geometry.merge_station_m-profile.merge_station_m),
           abs(certificate.geometry.ascent_column_station_m-profile.column_station_m)) > 1e-6:
        raise ValueError('REENTRY_CERTIFICATE_GEOMETRY_MISMATCH')
    if abs(float(certificate.release_time_s) - float(profile.release_time_s)) > 1e-6:
        raise ValueError("REENTRY_CERTIFICATE_RELEASE_MISMATCH")
    if abs(float(certificate.merge_time_s) - float(profile.merge_time_s)) > 1e-6:
        raise ValueError("REENTRY_CERTIFICATE_MERGE_MISMATCH")
    if abs(float(certificate.merge_speed_mps) - float(profile.merge_speed_mps)) > 1e-6:
        raise ValueError("REENTRY_CERTIFICATE_SPEED_MISMATCH")
    waiting=float(now_s) < float(certificate.release_time_s) - TIME_TOLERANCE_S
    plan = dict(state.current_motion_plan)
    plan.pop('reentry_hold_reason', None)
    ready_time = float(plan.get("reentry_ready_time_s",
                               plan.get("reentry_hold_started_s", now_s)))
    plan.update({
        "reentry_certificate_id": str(certificate.certificate_id),
        "reentry_release_s": float(certificate.release_time_s),
        "reentry_merge_s": float(certificate.merge_time_s),
        "reentry_column_station_m": float(profile.column_station_m),
        "reentry_merge_station_m": float(profile.merge_station_m),
        "reentry_merge_speed_mps": float(profile.merge_speed_mps),
        "reentry_layer_altitude_m": float(profile.layer_altitude_m),
        "reentry_profile": profile.as_dict(),
        "reentry_scheduler": str(certificate.model_version),
        "reentry_wait_s": max(0.0, float(certificate.release_time_s) - ready_time),
        "reentry_total_hold_s": max(0.0, float(certificate.release_time_s) - float(
            plan.get("reentry_hold_started_s", ready_time))),
    })
    motion = profile.state_at(now_s)
    if motion.position_xyz is not None:
        plan['motion_position_xyz'] = motion.position_xyz
    target_state = (FlightState.REENTRY_FINAL_APPROACH
                    if state.state in {FlightState.REENTRY_STAGING_HOLD, FlightState.REENTRY_LOCAL_HOLD}
                    else FlightState.REENTRY_CLIMB)
    return replace(
        state,
        state=FlightState.REENTRY_HOLD if waiting else target_state,
        s_m=float(motion.station_m),
        z_m=float(motion.z_m),
        speed_mps=float(motion.speed_mps),
        current_motion_plan=plan,
        event_version=state.event_version + 1,
    )


def advance_climb(
    state: UAVState, *, now_s: float, profile: ReentryMotionProfile
) -> UAVState:
    """Advance the certified climb/transition and rejoin the mainline."""

    _require(state, FlightState.REENTRY_CLIMB)
    merge = float(profile.merge_time_s)
    motion = profile.state_at(float(now_s))
    plan = dict(state.current_motion_plan)
    if motion.position_xyz is not None:
        plan['motion_position_xyz'] = motion.position_xyz
    if float(now_s) >= merge - TIME_TOLERANCE_S:
        plan["reentry_joined_s"] = merge
        return replace(
            state,
            state=FlightState.MAINLINE,
            s_m=float(profile.merge_station_m),
            z_m=float(profile.layer_altitude_m),
            speed_mps=float(profile.merge_speed_mps),
            current_motion_plan=plan,
            event_version=state.event_version + 1,
        )
    return replace(
        state,
        s_m=float(motion.station_m),
        z_m=float(motion.z_m),
        speed_mps=float(motion.speed_mps),
        current_motion_plan=plan,
        event_version=state.event_version + 1,
    )


def is_reentry_state(state: UAVState) -> bool:
    return state.state in {
        FlightState.SERVICING,
        FlightState.REENTRY_HOLD,
        FlightState.REENTRY_CLIMB,
        FlightState.REENTRY_LAND_TO_GROUND,
        FlightState.REENTRY_ASCENT_TO_50M,
        FlightState.REENTRY_STAGING_HOLD,
        FlightState.REENTRY_FINAL_APPROACH,
        FlightState.REENTRY_LOCAL_BRAKING,
        FlightState.REENTRY_LOCAL_HOLD,
    }
