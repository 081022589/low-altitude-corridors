"""Runtime-only time provenance and publication guards; never changes MILP input.

The physical NodeSnapshot retains its current occupancy intervals. A separate
commitment-only view is used solely to diagnose immutable target consistency.
"""
from __future__ import annotations
from dataclasses import replace
from itertools import combinations
from collections.abc import Mapping
import math

SEMANTICS_VERSION = "RESOURCE_TIME_PROVENANCE_V1"

def build_time_records(snapshot, payload, ledger, *, dt_s):
    records=[]
    for reservation in payload["frozen_reservations"]:
        uid,rid=str(reservation["uav_id"]),str(reservation["resource_id"])
        try:
            state=snapshot.states[uid]
            plan=state.current_motion_plan
            if reservation["role"]=="V":
                view,events=ledger[uid]
                if not (view.frozen and view.plan_version and view.freeze_record_id and view.checker_evidence):
                    raise ValueError("UNVERIFIED_V_PUBLICATION")
                original=next(w for w in view.resource_windows if str(w[0])==rid)
                state_window=next(w for w in plan["resource_windows"] if str(w[0])==rid)
                if tuple(original)!=tuple(state_window):raise ValueError("V_PUBLICATION_SOURCE_MISMATCH")
                a,b=float(original[1]),float(original[2])
                publication={"version":view.plan_version,"state_version":view.source_state_version,
                             "published_at_s":view.frozen_at_s,"round_id":view.freeze_record_id}
            else:
                target=next(t for t in plan["timed_resource_targets"] if str(t["resource_id"])==rid)
                a,b=float(target["entry_time_s"]),float(target["exit_time_s"])
                publication=plan.get("resource_target_provenance",{}).get(rid)
                if publication is None:
                    raise ValueError("MISSING_H_PUBLICATION_PROVENANCE")
                events=tuple(plan.get("motion_observed_events",()))
            if not (uid and rid and publication.get("version") and math.isfinite(a) and math.isfinite(b) and b>a):
                raise ValueError("INVALID_PUBLICATION_IDENTITY_OR_WINDOW")
            common={"uav_id":uid,"resource_id":rid,"role":reservation["role"],
                    "state_version":snapshot.version,"observed_at_s":snapshot.sim_time_s,
                    "reservation_id":reservation["reservation_id"]}
            records.append({**common,"kind":"COMMITTED_TARGET","enter_s":a,"exit_s":b,
                "publication":dict(publication),"enter_source":"PUBLISHED_TARGET","exit_source":"PUBLISHED_TARGET"})
            observed={}
            for event in events:
                get=(lambda key,default=None: event.get(key,default)) if isinstance(event,Mapping) else (lambda key,default=None:getattr(event,key,default))
                if str(get("resource_id"))!=rid or get("event_type") not in {"RESOURCE_ENTER","RESOURCE_EXIT"}:continue
                if not get("event_id") or str(get("uav_id",uid))!=uid:raise ValueError("REALIZED_EVENT_IDENTITY_MISSING")
                kind=get("event_type");time=float(get("actual_time_s"))
                if time>snapshot.sim_time_s+1e-6:raise ValueError("FUTURE_EVENT_IN_REALIZED_PREFIX")
                observed[kind]=time
                tick=max(0,math.ceil(time/dt_s-1e-12)-1)
                records.append({**common,"kind":"REALIZED_EVENT","event_id":get("event_id"),
                    "event_type":kind,"actual_time_s":time,"sequence":get("sequence"),
                    "source_tick_interval_s":[tick*dt_s,(tick+1)*dt_s],
                    "source_tick_basis":"REGISTERED_GRID_AND_EXECUTOR_EVENT_TIME",
                    "audit_source":"MEASURED_KINEMATIC_EXECUTOR_V1"})
            if reservation["role"]=="V":
                fa,fb=float(reservation["occupancy_start"]),float(reservation["occupancy_end"])
                for key,value in (("RESOURCE_ENTER",fa),("RESOURCE_EXIT",fb)):
                    if key in observed and observed[key]!=value:raise ValueError("ACTUAL_ENDPOINT_OVERWRITTEN")
                records.append({**common,"kind":"CURRENT_OCCUPANCY_FORECAST","enter_s":fa,"exit_s":fb,
                    "publication":dict(publication),"forecast_method":"CURRENT_STATE_FORECAST_WITH_OBSERVED_EDGES",
                    "enter_source":"REALIZED_EVENT" if "RESOURCE_ENTER" in observed else "CURRENT_FORECAST",
                    "exit_source":"REALIZED_EVENT" if "RESOURCE_EXIT" in observed else "CURRENT_FORECAST"})
        except (KeyError,StopIteration,TypeError,ValueError) as error:
            records.append({"kind":"PROVENANCE_ERROR","uav_id":uid,"resource_id":rid,"reason":str(error)})
    return tuple(records)

def classify_time_conflicts(snapshot, records):
    from traffic_simulation.cmlpm.joint_single_node.independent_checker import historical_frozen_conflicts
    from traffic_simulation.cmlpm.joint_single_node.conflict_builder import SHARED_RESOURCE_ENTRY_HEADWAY_S
    from traffic_simulation.cmlpm.joint_single_node.conflict_builder import is_cross_layer_vh_frozen
    errors=[r for r in records if r.get("kind")=="PROVENANCE_ERROR"]
    committed={r["reservation_id"]:r for r in records if r.get("kind")=="COMMITTED_TARGET"}
    forecasts={r["reservation_id"]:r for r in records if r.get("kind")=="CURRENT_OCCUPANCY_FORECAST"}
    if errors or len(committed)!=len(snapshot.frozen_reservations):
        return {"status":"RESOURCE_TIME_PROVENANCE_ERROR","conflicts":errors or [{"reason":"COMMITMENT_COVERAGE_MISSING"}],"deviations":[]}
    protections={r['reservation_id']:r for r in records if r.get('kind')=='CURRENT_PHYSICAL_PROTECTION'}
    certificates=[r for r in records if r.get('kind')=='CURRENT_PHYSICAL_PROTECTION_CERTIFICATE' and r.get('passed')]
    binding=snapshot.metadata.get('current_physical_protection')
    if protections:
        from .execution_precedence import digest
        if len(certificates)!=1 or not binding:
            return {'status':'RESOURCE_TIME_PROVENANCE_ERROR','conflicts':[{'reason':'PROTECTION_CERTIFICATE_MISSING'}],'deviations':[]}
        cert=certificates[0]
        signed=dict(cert);signed.pop('witness_sha256',None)
        if (digest(signed)!=cert.get('witness_sha256') or cert['state_version']!=snapshot.metadata.get('state_version')
                or cert['time_s']!=snapshot.t_now or any(binding.get(k)!=cert.get(k) for k in ('state_version','time_s','state_sha256','witness_sha256'))):
            return {'status':'RESOURCE_TIME_PROVENANCE_ERROR','conflicts':[{'reason':'PROTECTION_CERTIFICATE_STALE_OR_CHANGED'}],'deviations':[]}
        for rid,p in protections.items():
            f=next((f for f in snapshot.frozen_reservations if f.reservation_id==rid),None)
            if (f is None or f.role!='M' or (p['uav_id'],p['resource_id'])!=(f.uav_id,f.resource_id)
                    or (p['enter_s'],p['exit_s'])!=(f.occupancy_start,f.occupancy_end)
                    or p.get('state_version')!=cert['state_version'] or p.get('state_sha256')!=cert['state_sha256']
                    or p.get('witness_sha256')!=cert['witness_sha256']):
                return {'status':'RESOURCE_TIME_PROVENANCE_ERROR','conflicts':[{'reason':'PROTECTION_WINDOW_MISMATCH'}],'deviations':[]}
    for f in snapshot.frozen_reservations:
        c=committed[f.reservation_id]
        if not c.get("publication",{}).get("version") or not c.get("publication",{}).get("round_id") or c.get("state_version") is None or c.get("observed_at_s") is None or (c.get("uav_id"),c.get("resource_id"),c.get("role"))!=(f.uav_id,f.resource_id,f.role):
            return {"status":"RESOURCE_TIME_PROVENANCE_ERROR","conflicts":[{"reason":"IDENTITY_OR_VERSION_MISMATCH"}],"deviations":[]}
        if f.role=="V":
            p=forecasts.get(f.reservation_id)
            if p is None or not p.get("forecast_method") or p.get("state_version") is None or (p.get("uav_id"),p.get("resource_id"),p.get("role"))!=(f.uav_id,f.resource_id,f.role) or (p["enter_s"],p["exit_s"])!=(f.occupancy_start,f.occupancy_end):
                return {"status":"RESOURCE_TIME_PROVENANCE_ERROR","conflicts":[{"reason":"PHYSICAL_FORECAST_MISSING_OR_CHANGED"}],"deviations":[]}
    # Only the diagnostic view contains target endpoints. The actual solver
    # snapshot is untouched, retaining all current physical protections.
    target_view=replace(snapshot,frozen_reservations=tuple(replace(f,
        occupancy_start=committed[f.reservation_id]["enter_s"],occupancy_end=committed[f.reservation_id]["exit_s"])
        for f in snapshot.frozen_reservations))
    historical=list(historical_frozen_conflicts(target_view))
    risks=[];checks=[];deviations=[]
    for a,b in combinations(snapshot.frozen_reservations,2):
        if a.resource_id!=b.resource_id or a.role==b.role:continue
        v,h=(a,b) if a.role=="V" else (b,a)
        if not is_cross_layer_vh_frozen(v, h):
            continue
        sep=snapshot.vh_separation[v.resource_id]
        margin=max(h.occupancy_start-v.occupancy_end-sep.first_to_second,
                   v.occupancy_start-h.occupancy_end-sep.second_to_first)
        headway=abs(h.occupancy_start-v.occupancy_start)-SHARED_RESOURCE_ENTRY_HEADWAY_S
        if h.reservation_id in protections:
            order=cert['execution_orders'].get('|'.join((v.resource_id,h.uav_id,v.uav_id)))
            if order=='V_FIRST':
                margin=h.occupancy_start-v.occupancy_end-sep.first_to_second
                headway=h.occupancy_start-v.occupancy_start-SHARED_RESOURCE_ENTRY_HEADWAY_S
            elif order=='H_FIRST':
                margin=v.occupancy_start-h.occupancy_end-sep.second_to_first
                headway=v.occupancy_start-h.occupancy_start-SHARED_RESOURCE_ENTRY_HEADWAY_S
            else:
                return {'status':'RESOURCE_TIME_PROVENANCE_ERROR','conflicts':[{'reason':'PROTECTION_ORDER_MISSING'}],'deviations':[]}
        row={"category":"CURRENT_FORECAST_VS_COMMITMENT","resource_id":v.resource_id,
             "v_uav_id":v.uav_id,"h_uav_id":h.uav_id,"signed_vh_margin_s":margin,
             "signed_entry_headway_margin_s":headway,"tolerance_s":snapshot.tolerance,
             "current_forecast":forecasts[v.reservation_id],"h_commitment":committed[h.reservation_id]}
        checks.append(row)
        if margin < -snapshot.tolerance or headway < -snapshot.tolerance:risks.append(row)
    for event in records:
        if event.get("kind")!="REALIZED_EVENT":continue
        target=committed[event["reservation_id"]]
        nominal=target["enter_s"] if event["event_type"]=="RESOURCE_ENTER" else target["exit_s"]
        delta=event["actual_time_s"]-nominal
        if abs(delta)>snapshot.tolerance:
            deviations.append({"category":"REALIZED_EXECUTION_DEVIATION","event":event,
                "committed_time_s":nominal,"delta_s":delta})
    status="HISTORICAL_FROZEN_CONFLICT" if historical else "CURRENT_FORECAST_COMMITMENT_CONFLICT" if risks else "TIME_SEMANTICS_CHECKED"
    return {"status":status,"conflicts":historical or risks,"commitment_conflicts":historical,
            "forecast_conflicts":risks,"physical_checks":checks,"deviations":deviations}


def protection_state_identity(snapshot):
    """Complete physical and commitment identity; never cache across versions."""
    from .handoff_transaction import state_digest
    return (snapshot.version, snapshot.sim_time_s,
            state_digest({**snapshot.resource_dependencies, **snapshot.states}))


def validate_physical_protection(snapshot, certificate):
    version, now, state_hash = protection_state_identity(snapshot)
    if (certificate.get('state_version'), certificate.get('time_s'), certificate.get('state_sha256')) != (version, now, state_hash):
        raise ValueError('CURRENT_PHYSICAL_PROTECTION_STALE_STATE')
    if not certificate.get('passed'):
        raise ValueError('CURRENT_PHYSICAL_PROTECTION_UNPROVEN')


def prepare_physical_protection(snapshot, result, *, config, network, budget_s):
    """On-demand, fail-closed physical projection; original targets stay separate.

    The private rehearsal is evidence only. A new candidate must still pass
    the original Checker, joint handoff continuation and atomic publication.
    """
    from copy import deepcopy
    from time import perf_counter
    from types import MappingProxyType
    from dataclasses import asdict
    from traffic_simulation.cmlpm.active import build_complete_snapshot
    from .simulation_state import TrafficStateStore
    from .handoff_transaction import seed_actual_audit, commit_motion_step
    from .motion_executor import execute_frozen_motion, resource_z_bounds
    from .crossing_resource_mapping import mainline_crossing_stations
    from .cmlpm_runtime_pipeline import motion_limits_from_config
    from .conditional_feasibility_feedback import CPFFPolicy
    from .execution_precedence import digest

    formal = build_complete_snapshot(result.payload)
    previous = classify_time_conflicts(formal, result.resource_time_records)
    if previous['status'] != 'CURRENT_FORECAST_COMMITMENT_CONFLICT':
        return result
    started = perf_counter()
    version, now, state_hash = protection_state_identity(snapshot)
    certificate = dict(kind='CURRENT_PHYSICAL_PROTECTION_CERTIFICATE', state_version=version,
        time_s=now, state_sha256=state_hash, passed=False, horizon_s=120.,
        lifetime='EXACT_STATE_ONLY', parameter_sha256=digest(config))
    try:
        if int(result.read.state_version) != version or float(result.read.t_now) != now:
            raise ValueError('CURRENT_PHYSICAL_PROTECTION_INPUT_VERSION_MISMATCH')
        if budget_s <= 0:
            raise ValueError('CURRENT_PHYSICAL_PROTECTION_BUDGET_EXHAUSTED')
        states = {**snapshot.resource_dependencies, **snapshot.states}
        requirements = {(r['uav_id'], str(r['resource_id'])) for r in result.payload['frozen_reservations']}
        existing_v = {r['uav_id'] for r in result.payload['frozen_reservations'] if r['role'] == 'V'}
        requirements.update((u, str(r)) for u in existing_v for r, _, _ in states[u].current_motion_plan.get('resource_windows', ()))
        windows = {}
        def observe(uid, resource, event, time):
            if resource is not None and event in ('RESOURCE_ENTER', 'RESOURCE_EXIT'):
                windows.setdefault((uid, str(resource)), {})[event] = float(time)
        for u, state in states.items():
            for e in state.current_motion_plan.get('motion_observed_events', ()):
                observe(u, e.get('resource_id'), e['event_type'], e['actual_time_s'])
        store = TrafficStateStore(states.values(), sim_time_s=now)
        store._version = version
        audit = seed_actual_audit(store.final_snapshot(), config)
        limits = motion_limits_from_config(config)
        dt = float(config['simulation']['dt_s'])
        kwargs = dict(dt_s=dt, vertical_speed_mps=config['motion']['vertical_speed_mps'], completion_z_m=50.,
            motion_limits_by_type=limits, resource_z=resource_z_bounds(network),
            mainline_crossings=mainline_crossing_stations(network), min_mainline_gap_m=config['motion']['min_gap_m'],
            resource_safety=config['resource_safety'], cpff_policy=CPFFPolicy.from_config(config))
        steps = 0
        while not all('RESOURCE_EXIT' in windows.get(key, {}) for key in requirements):
            if perf_counter() - started >= budget_s:
                raise ValueError('CURRENT_PHYSICAL_PROTECTION_BUDGET_EXHAUSTED')
            if store.read_metadata()[1] + dt > now + 120. + 1e-9:
                raise ValueError('CURRENT_PHYSICAL_PROTECTION_UNKNOWN_HORIZON')
            before = store.snapshot()
            step = execute_frozen_motion(before, **kwargs)
            commit_motion_step(store, before, step, audit, limits, return_snapshot=False, allow_gap_recovery=False)
            for e in step.events:
                observe(e.uav_id, e.resource_id, e.event_type, e.actual_time_s)
            steps += 1
        if perf_counter() - started >= budget_s:
            raise ValueError('CURRENT_PHYSICAL_PROTECTION_BUDGET_EXHAUSTED')
        orders = {}
        for pair in previous.get('physical_checks', ()):
            key = (pair['resource_id'], pair['h_uav_id'], pair['v_uav_id'])
            found = {r['order'] for state in states.values()
                for r in state.current_motion_plan.get('execution_precedence', {}).values()
                if (r['resource_id'], r['h_uid'], r['v_uid']) == key}
            if len(found) != 1 or not found <= {'V_FIRST', 'H_FIRST'}:
                raise ValueError('CURRENT_PHYSICAL_PROTECTION_EXECUTION_ORDER_UNKNOWN')
            order = next(iter(found))
            hw, vw = windows[(key[1], key[0])], windows[(key[2], key[0])]
            vf = pair['current_forecast']
            if any(abs(vw[event] - vf[field]) > formal.tolerance
                   for event, field in (('RESOURCE_ENTER', 'enter_s'), ('RESOURCE_EXIT', 'exit_s'))):
                raise ValueError('CURRENT_PHYSICAL_PROTECTION_V_FORECAST_UNPROVEN')
            sep = formal.vh_separation[key[0]]
            if order == 'V_FIRST':
                margins = (hw['RESOURCE_ENTER'] - vw['RESOURCE_ENTER'] - 2.5,
                           hw['RESOURCE_ENTER'] - vw['RESOURCE_EXIT'] - sep.first_to_second)
            else:
                margins = (vw['RESOURCE_ENTER'] - hw['RESOURCE_ENTER'] - 2.5,
                           vw['RESOURCE_ENTER'] - hw['RESOURCE_EXIT'] - sep.second_to_first)
            if min(margins) < -formal.tolerance:
                raise ValueError('CURRENT_PHYSICAL_PROTECTION_DIRECTED_CONFLICT')
            orders['|'.join(key)] = order
        certificate.update(passed=True, steps=steps, checked_to_s=store.read_metadata()[1],
            audit=audit.summary(), execution_orders=orders,
            resource_windows=[dict(uav_id=u, resource_id=r, **w) for (u, r), w in sorted(windows.items())],
            seconds=perf_counter() - started)
        certificate['witness_sha256'] = digest(certificate)
        validate_physical_protection(snapshot, certificate)
        payload = deepcopy(dict(result.payload))
        records = list(result.resource_time_records)
        for reservation in payload['frozen_reservations']:
            if reservation['role'] != 'M':
                continue
            key = (reservation['uav_id'], str(reservation['resource_id']))
            w = windows[key]
            if 'RESOURCE_ENTER' not in w or 'RESOURCE_EXIT' not in w:
                raise ValueError('CURRENT_PHYSICAL_PROTECTION_WINDOW_MISSING')
            reservation['occupancy_start'] = w['RESOURCE_ENTER']
            reservation['occupancy_end'] = w['RESOURCE_EXIT']
            records.append(dict(kind='CURRENT_PHYSICAL_PROTECTION', reservation_id=reservation['reservation_id'],
                uav_id=key[0], resource_id=key[1], role='M', enter_s=w['RESOURCE_ENTER'], exit_s=w['RESOURCE_EXIT'],
                state_version=version, observed_at_s=now, state_sha256=state_hash,
                witness_sha256=certificate['witness_sha256']))
        payload['metadata'] = dict(payload.get('metadata', {}), current_physical_protection=dict(
            state_version=version, time_s=now, state_sha256=state_hash, witness_sha256=certificate['witness_sha256']))
        projected = replace(result, payload=MappingProxyType(payload), resource_time_records=tuple(records + [certificate]))
        checked = classify_time_conflicts(build_complete_snapshot(projected.payload), projected.resource_time_records)
        if checked['status'] != 'TIME_SEMANTICS_CHECKED':
            raise ValueError('CURRENT_PHYSICAL_PROTECTION_PROJECTED_CHECK_FAILED:' + checked['status'])
        return projected
    except (ValueError, RuntimeError, KeyError, TypeError) as error:
        certificate.update(passed=False, reason=str(error), seconds=perf_counter() - started)
        return replace(result, resource_time_records=tuple(result.resource_time_records) + (certificate,))
