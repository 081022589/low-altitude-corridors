"""Versioned traffic read for the real C-MLPM node-input path.

This module owns only the spatial/state-selection seam.  It deliberately does
not invent SRCM uses, safety constraints, or frozen reservations when their
authoritative providers are absent.

The scheduling read is local to the current node. A V enters when it has an
ECJA assignment for this node and reaches the local ``G-3Dcommit`` boundary;
an H enters when its physical path crosses this node's resource and it has no
valid resource time for this node. H eligibility is not inferred from the
previous service node's station interval.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
import hashlib
import json
import math
from typing import Iterable, Mapping

from ecja_qsap.formal_motion import TYPE_BY_LAYER

from .crossing_resource_mapping import (
    build_crossing_resource_maps,
    crossing_map_for_node_layer,
)
from .network_loader import DirectedNodeInterval, RegisteredG25, directed_node_interval
from .numeric_motion import MotionLimits, stop_start_limits
from .reachable_window import bounded_reachability_window
from .route_identity import (
    RouteIdentityError,
    build_route_index,
    resolve_route_identity,
)
from .simulation_state import FlightState, TrafficSnapshot, UAVState
from .speed_control_scope import speed_control_blocks_target_scheduling
from .trigger_rules import latest_assignment_distance_m


RUNTIME_INPUT_READER_VERSION = "CMLPM_RUNTIME_NODE_READ_LOCAL_ALL_TRAFFIC_V4"


class RuntimeInputBlocked(ValueError):
    """Structured fail-closed error at the runtime-input seam."""

    def __init__(self, code: str, detail: str):
        super().__init__(f"{code}:{detail}")
        self.code = code
        self.detail = detail


@dataclass(frozen=True)
class NodeTrafficRead:
    node_id: str
    direction: str
    state_version: int
    t_now: float
    intervals: tuple[DirectedNodeInterval, ...]
    v_new: tuple[UAVState, ...]
    v_existing: tuple[UAVState, ...]
    h: tuple[UAVState, ...]
    inherited_outside_interval_ids: tuple[str, ...]
    assigned_waiting_uav_ids: tuple[str, ...]
    frozen_only_uav_ids: tuple[str, ...]
    h_scope: tuple[tuple[str, float, float], ...]
    state_semantic_sha256: str
    reader_version: str = RUNTIME_INPUT_READER_VERSION
    published_h: tuple[UAVState, ...] = ()

    @property
    def traffic_states(self) -> tuple[UAVState, ...]:
        return self.v_new + self.v_existing + self.h

    @property
    def all_traffic_states(self) -> tuple[UAVState, ...]:
        """Return schedulable traffic plus immutable published H traffic."""

        return self.v_new + self.v_existing + self.h + self.published_h

    @property
    def published_uav_ids(self) -> tuple[str, ...]:
        return tuple(sorted(item.uav_id for item in self.published_h))


# Physical scope only: a UAV that completed service, exited the registered
# mainline, or left the observation horizon is no longer node traffic.
_LEFT_SYSTEM = {
    FlightState.COMPLETED,
    FlightState.EXITED,
    FlightState.HORIZON_CENSORED,
}
# The UAV has left the mainline and is executing its committed vertical path
# at some service node.
_V_PATH_STATES = {FlightState.TRANSITION, FlightState.VERTICAL}
_EXISTING_V = {FlightState.SCHEDULED, FlightState.TRANSITION, FlightState.VERTICAL}
# These unresolved request states may still be mainline H at the local node.
_REQUEST_SIDE_UNRESOLVED = {
    FlightState.NOT_YET_REQUESTED,
    FlightState.PENDING_ASSIGNMENT,
    FlightState.DEFERRED,
    FlightState.ENERGY_INFEASIBLE,
    FlightState.UNASSIGNED,
    FlightState.MOTION_INFEASIBLE,
}
_ON_MAINLINE = {FlightState.MAINLINE, FlightState.ASSIGNED, FlightState.SCHEDULED} | _REQUEST_SIDE_UNRESOLVED


def _node_direction(network: RegisteredG25, node_id: str) -> str:
    directions = {
        str(row["direction"])
        for row in network.interfaces
        if str(row["service_node_id"]) == node_id
    }
    if len(directions) != 1:
        raise RuntimeInputBlocked("NODE_DIRECTION_UNRESOLVED", f"{node_id}:{sorted(directions)}")
    return next(iter(directions))


def _semantic_hash(snapshot: TrafficSnapshot, states: Iterable[UAVState]) -> str:
    rows = []
    for state in sorted(states, key=lambda item: item.uav_id):
        rows.append({
            "uav_id": state.uav_id,
            "event_version": state.event_version,
            "direction": state.direction,
            "layer": state.layer,
            "s_m": state.s_m,
            "z_m": state.z_m,
            "speed_mps": state.speed_mps,
            "state": state.state.value,
            "assigned_node": state.assigned_node,
            "assigned_route": state.assigned_route,
            "commit_status": state.commit_status,
            "cmlpm_managed": state.cmlpm_managed,
            "cmlpm_plan_immutable": state.cmlpm_plan_immutable,
            "cmlpm_pending":asdict(state.cmlpm_pending) if state.cmlpm_pending else None,
            "cmlpm_request_baseline": state.cmlpm_request_baseline,
            "current_motion_plan": state.current_motion_plan,
        })
    raw = json.dumps(
        {"version": snapshot.version, "t_now": snapshot.sim_time_s, "states": rows},
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
        allow_nan=False,
    ).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()


def read_node_traffic_snapshot(
    snapshot: TrafficSnapshot,
    network: RegisteredG25,
    node_id: str,
    *,
    frozen_reservation_uav_ids: Iterable[str] | None,
    h_reach_horizon_s: float | None = None,
    h_max_speed_by_type: Mapping[str, float] | None = None,
    h_motion_limits_by_type: Mapping[str, MotionLimits] | None = None,
    v_reach_horizon_s: float | None = None,
    v_max_speed_by_type: Mapping[str, float] | None = None,
    static_context=None,
    traffic_index=None,
) -> NodeTrafficRead:
    """Read one immutable node set from the local 3D region plus inherited V.

    ``frozen_reservation_uav_ids`` is mandatory even when empty so that an
    authoritative empty ledger cannot be confused with a missing provider.
    Frozen-only identities are reported separately; reservation payloads stay
    owned by the frozen ledger.

    A V first enters scheduling at its registered G-3Dcommit. Every mainline H
    that will cross this node's resource enters the local read at G-3Dcommit,
    regardless of ECJA assignment. The node's authority ends at the local
    resource exit, without controlling later flight toward another node.

    ``v_reach_horizon_s`` can further restrict the current optimization
    horizon, but never admit an aircraft before the local 3D boundary.

    ``h_reach_horizon_s`` further removes H that cannot clear the crossing
    within the declared evaluation horizon.
    """

    if frozen_reservation_uav_ids is None:
        raise RuntimeInputBlocked("MISSING_FROZEN_LEDGER", node_id)
    if v_reach_horizon_s is not None:
        if float(v_reach_horizon_s) <= 0.0:
            raise RuntimeInputBlocked("INVALID_V_REACH_HORIZON", str(v_reach_horizon_s))
        if not v_max_speed_by_type:
            raise RuntimeInputBlocked("MISSING_V_MAX_SPEED_TABLE", node_id)
    if h_reach_horizon_s is not None:
        if float(h_reach_horizon_s) <= 0.0:
            raise RuntimeInputBlocked("INVALID_H_REACH_HORIZON", str(h_reach_horizon_s))
        if not h_max_speed_by_type:
            raise RuntimeInputBlocked("MISSING_H_MAX_SPEED_TABLE", node_id)
    frozen_ids = frozenset(str(value) for value in frozen_reservation_uav_ids)
    if static_context is not None:
        static_context.require_network(network)
        network = static_context.network
    if traffic_index is not None:
        traffic_index.require_snapshot(snapshot)
        if static_context is None:
            raise ValueError("NODE_TRAFFIC_INDEX_REQUIRES_STATIC_CONTEXT")
    interval_lookup = (lambda n, d, l: static_context.intervals[(n, d, l)]) if static_context else (
        lambda n, d, l: directed_node_interval(network, n, d, l))
    direction = _node_direction(network, node_id)
    intervals = tuple(
        interval_lookup(node_id, direction, layer)
        for layer in ("L1", "L2", "L3")
    )
    interval_by_layer = {item.layer: item for item in intervals}
    crossing_maps = static_context.crossings if static_context else build_crossing_resource_maps(network)
    crossing_by_layer = {}
    h_scope: list[tuple[str, float, float]] = []
    for layer in ("L1", "L2", "L3"):
        crossing = crossing_map_for_node_layer(crossing_maps, node_id, direction, layer)
        crossing_by_layer[layer] = crossing
        lower = max(0.0, interval_by_layer[layer].upper_q_m -
                    latest_assignment_distance_m(TYPE_BY_LAYER[layer]))
        h_scope.append((layer, lower, crossing.entry_station_m))
    route_index = static_context.routes if static_context else build_route_index(network)
    v_new: list[UAVState] = []
    v_existing: list[UAVState] = []
    h: list[UAVState] = []
    published_h: list[UAVState] = []
    inherited: list[str] = []
    assigned_waiting: list[str] = []

    candidates = (traffic_index.candidates(static_context, node_id) if traffic_index else
                  sorted(snapshot.states.values(), key=lambda item: item.uav_id))
    for state in candidates:
        if state.state in {FlightState.SERVICING,FlightState.REENTRY_HOLD,FlightState.REENTRY_CLIMB,
                           FlightState.REENTRY_LAND_TO_GROUND,FlightState.REENTRY_ASCENT_TO_50M,
                           FlightState.REENTRY_STAGING_HOLD,FlightState.REENTRY_FINAL_APPROACH}:
            continue
        if state.state in _LEFT_SYSTEM:
            continue
        frozen_nonrelease = (
            state.commit_status == "FROZEN"
            and state.state in {FlightState.DEFERRED, FlightState.MOTION_INFEASIBLE}
        )
        if state.assigned_node == node_id and not frozen_nonrelease:
            if state.direction != direction or state.layer not in interval_by_layer:
                raise RuntimeInputBlocked("CURRENT_NODE_V_FLOW_MISMATCH", state.uav_id)
            if not state.assigned_route:
                raise RuntimeInputBlocked("CURRENT_NODE_V_ROUTE_MISSING", state.uav_id)
            try:
                # Identity is resolved against the G25 registry, not by string
                # surgery: ECJA writes ``route:<interface_id>`` while the
                # registered interface uses ``<interface_id>:route``.
                resolve_route_identity(
                    network,
                    state.assigned_route,
                    node_id=node_id,
                    direction=state.direction,
                    source_layer=state.layer,
                    index=route_index,
                )
            except RouteIdentityError as exc:
                raise RuntimeInputBlocked(
                    "CURRENT_NODE_V_ROUTE_MISMATCH",
                    f"{state.uav_id}:{exc.code}",
                ) from exc
            local_lower = interval_by_layer[state.layer].upper_q_m - latest_assignment_distance_m(state.vehicle_type)
            in_interval = local_lower - 1e-9 <= state.s_m < interval_by_layer[state.layer].upper_q_m
            if state.cmlpm_managed or state.state in _EXISTING_V or state.commit_status == "FROZEN":
                v_existing.append(state)
                if not in_interval:
                    inherited.append(state.uav_id)
            elif speed_control_blocks_target_scheduling(state,t_now=float(snapshot.sim_time_s)):
                assigned_waiting.append(state.uav_id)
            elif in_interval:
                if state.current_motion_plan.get("execution_mode") == "CMLPM_RETRY_HOLD":
                    # The thin V5 executor holds the measured state locally;
                    # this marker never denotes a G-point parking command.
                    # It is nevertheless a schedulable V request: the next
                    # periodic round must be able to replace the failed
                    # timing decision with a fresh E-anchor plan.
                    v_new.append(state)
                    continue
                if v_reach_horizon_s is not None:
                    limit_speed = float(
                        (v_max_speed_by_type or {}).get(state.vehicle_type, float("nan"))
                    )
                    if not math.isfinite(limit_speed) or limit_speed <= 0.0:
                        raise RuntimeInputBlocked(
                            "MISSING_V_MAX_SPEED", f"{state.uav_id}:{state.vehicle_type}"
                        )
                    remaining_to_fork = max(
                        0.0, interval_by_layer[state.layer].upper_q_m - float(state.s_m)
                    )
                    if remaining_to_fork > limit_speed * float(v_reach_horizon_s) + 1e-9:
                        assigned_waiting.append(state.uav_id)
                        continue
                v_new.append(state)
            elif state.s_m >= interval_by_layer[state.layer].upper_q_m - 1e-9:
                # Keep a past-boundary active V visible to the SRCM adapter,
                # which owns the established fail-closed plan-rebuild check.
                v_new.append(state)
            else:
                assigned_waiting.append(state.uav_id)
            # A current-node ECJA assignment has no C-MLPM plan to inherit yet
            # while the aircraft is still upstream of this node's 3D boundary.
            # It remains in the unified traffic state until local entry.
            continue
        if state.direction != direction or state.layer not in interval_by_layer:
            continue
        crossing = crossing_by_layer[state.layer]
        resource_id = str(crossing.segment_resource_id)
        exited_resources = {
            str(row.get("resource_id"))
            for row in state.current_motion_plan.get("motion_observed_events", ())
            if isinstance(row, Mapping)
            and row.get("event_type") == "RESOURCE_EXIT"
            and row.get("resource_id") is not None
        }
        published_target = next(
            (
                target for target in state.current_motion_plan.get("timed_resource_targets", ())
                if isinstance(target, Mapping)
                and str(target.get("resource_id")) == resource_id
                and resource_id not in exited_resources
            ),
            None,
        )
        if published_target is not None and not state.cmlpm_managed:
            # A published H remains part of this node's historical input even
            # after it leaves the ordinary spatial read interval.  It is not a
            # new scheduling variable; the pipeline converts its target into a
            # frozen resource reservation.
            published_h.append(state)
            continue
        if state.assigned_node is not None:
            target_interval = interval_lookup(str(state.assigned_node), state.direction, state.layer)
            if target_interval.upper_q_m <= interval_by_layer[state.layer].upper_q_m + 1e-9:
                continue
        if state.state in _V_PATH_STATES:
            continue
        if state.state not in _ON_MAINLINE:
            raise RuntimeInputBlocked(
                "UNCLASSIFIED_FLIGHT_STATE", f"{state.uav_id}:{state.state.value}"
            )
        # The local C-MLPM boundary is derived from this node's formal G. The
        # registered upstream station is geometry metadata only; it is not a
        # scheduling/read lower bound.  The H read ends at the layer-gate
        # crossing entry rather than at G: an H between the fork and the gate
        # has not touched the shared resource yet and must stay protected.
        upper_h = float(crossing.entry_station_m)
        lower_h = max(0.0, interval_by_layer[state.layer].upper_q_m
                      - latest_assignment_distance_m(state.vehicle_type))
        if not (lower_h - 1e-9 <= state.s_m < upper_h):
            continue
        if h_reach_horizon_s is not None:
            limit_speed = float(
                (h_max_speed_by_type or {}).get(state.vehicle_type, float("nan"))
            )
            if not math.isfinite(limit_speed) or limit_speed <= 0.0:
                raise RuntimeInputBlocked(
                    "MISSING_H_MAX_SPEED", f"{state.uav_id}:{state.vehicle_type}"
                )
            reach_floor = float(upper_h) - limit_speed * float(h_reach_horizon_s)
            if state.s_m < reach_floor - 1e-9:
                continue
            if h_motion_limits_by_type is not None:
                limits = h_motion_limits_by_type.get(state.vehicle_type)
                if limits is None:
                    raise RuntimeInputBlocked(
                        "MISSING_H_MOTION_LIMITS",
                        f"{state.uav_id}:{state.vehicle_type}",
                    )
                crossing = crossing_by_layer[state.layer]
                # The executor may be in a bounded braking segment when this
                # read is taken.  In that transient state the measured speed
                # can legitimately be below the nominal cruise floor; using
                # the nominal floor here would reject a valid current state
                # before C-MLPM sees it.  Keep the observed speed as this
                # round's conservative lower envelope instead.
                observed_speed = max(1e-6, float(state.speed_mps))
                effective_v_min = min(float(limits.min_speed_mps), observed_speed)
                window = bounded_reachability_window(
                    t_now=float(snapshot.sim_time_s),
                    length_m=float(crossing.entry_station_m) - float(state.s_m),
                    v_now=float(state.speed_mps),
                    v_min=effective_v_min,
                    v_max=float(limits.max_speed_mps),
                    a_max=float(limits.max_abs_acceleration_mps2),
                    b_max=float(limits.max_abs_acceleration_mps2),
                    v_terminal=None,
                    source_state_id=f"{state.uav_id}:h-clear-filter",
                    allow_stop_start=stop_start_limits(state,limits).min_speed_mps == 0.,
                    latest_time_s=float(snapshot.sim_time_s)+float(h_reach_horizon_s),
                )
                crossing_duration = (
                    float(crossing.exit_station_m) - float(crossing.entry_station_m)
                ) / float(state.nominal_speed_mps if stop_start_limits(state,limits).min_speed_mps == 0. else state.speed_mps)
                clear_limit = float(snapshot.sim_time_s) + float(h_reach_horizon_s)
                if window.t_lb + crossing_duration > clear_limit + 1e-9:
                    continue
        h.append(state)

    selected_ids = {row.uav_id for row in (*v_new, *v_existing, *h)}
    frozen_only = tuple(sorted(frozen_ids - selected_ids))
    selected = tuple((*v_new, *v_existing, *h, *published_h))
    return NodeTrafficRead(
        node_id=node_id,
        direction=direction,
        state_version=int(snapshot.version),
        t_now=float(snapshot.sim_time_s),
        intervals=intervals,
        v_new=tuple(v_new),
        v_existing=tuple(v_existing),
        h=tuple(h),
        inherited_outside_interval_ids=tuple(sorted(inherited)),
        assigned_waiting_uav_ids=tuple(sorted(assigned_waiting)),
        frozen_only_uav_ids=frozen_only,
        h_scope=tuple(h_scope),
        state_semantic_sha256=_semantic_hash(snapshot, selected),
        published_h=tuple(published_h),
    )


def require_same_state_version(expected: int, **branch_versions: int) -> None:
    mismatched = {
        name: int(value) for name, value in branch_versions.items()
        if int(value) != int(expected)
    }
    if mismatched:
        detail = ",".join(f"{name}={value}" for name, value in sorted(mismatched.items()))
        raise RuntimeInputBlocked(
            "RUNTIME_INPUT_STATE_VERSION_MISMATCH",
            f"expected={expected};{detail}",
        )
