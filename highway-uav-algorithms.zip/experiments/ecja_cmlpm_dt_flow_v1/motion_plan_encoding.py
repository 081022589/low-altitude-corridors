"""Lossless bounded polynomials alongside absolute event/compatibility knots.

Relative piece times and accelerations are stored directly. Consumers never
infer acceleration by subtracting nearly equal absolute timestamps. Published
event times are not rounded or changed by this representation.
"""
from __future__ import annotations
from dataclasses import asdict
import math

from .numeric_motion import MotionPiece, TickProfile

ENCODING = "RELATIVE_CONSTANT_ACCELERATION_V1"


def encode_profile(profile: TickProfile, *, origin_s: float) -> dict:
    return {"motion_encoding":ENCODING,"motion_origin_s":float(origin_s),
            "motion_duration_s":float(profile.duration_s),
            "motion_pieces":tuple(asdict(p) for p in profile.pieces)}


def decoded_profile(plan) -> TickProfile | None:
    if plan.get("motion_encoding") != ENCODING:
        return None
    duration = float(plan["motion_duration_s"])
    if not math.isfinite(duration) or duration <= 0:
        raise ValueError("INVALID_ENCODED_MOTION_DURATION")
    return TickProfile(tuple(MotionPiece(**p) for p in plan["motion_pieces"]),duration)
