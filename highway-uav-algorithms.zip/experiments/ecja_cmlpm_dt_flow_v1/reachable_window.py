"""Event reachable-time-window model for C-MLPM input generation (v1.0 spec).

Three separated time concepts (spec section 1.3):

* **outer bound**      - ``L / v`` interval from the admissible cruise-speed range;
* **kinematic bound**  - analytic refinement from the observed speed plus bounded
  acceleration/deceleration and any prescribed terminal speed;
* **executable plan**  - produced and certified by the *existing* motion executor.

This module implements the first two. Dynamic following adds separately
versioned necessary event relations in ``following_time``. The active runtime
uses strict execution handoff for each unpublished candidate. An envelope
never certifies an executable trajectory.

Nothing here touches SRCM, ECJA QSAP, the C-MLPM B3 MILP, the independent
Checker, the G25 geometry or the fixed-trajectory assets.  No SRCM prediction
ETA is used as an event bound.
"""
from __future__ import annotations

from dataclasses import dataclass, field, replace
import math
from typing import Any, Mapping


STATUS_OK = "OK"
STATUS_SPEED_DOMAIN_INVALID = "INPUT_SPEED_DOMAIN_INVALID"
STATUS_LENGTH_INVALID = "INPUT_LENGTH_INVALID"
STATUS_INFEASIBLE_TERMINAL_SPEED = "REACHABILITY_INFEASIBLE_TERMINAL_SPEED"
STATUS_KINEMATIC_NESTING_VIOLATION = "KINEMATIC_BOUND_NESTING_VIOLATION"
STATUS_INFEASIBLE_KINEMATIC = "INFEASIBLE_KINEMATIC"

#: Absolute tolerance for the nesting identity ``t0 + L/v_max <= kin_lb <= kin_ub <= t0 + L/v_min``.
NESTING_TOLERANCE_S = 1e-6
# The motion executor clamps analytically exact speed-floor/ceiling contacts.
# Apply the same narrow boundary normalization at the scheduling input seam so
# a value such as 5.99999999999729 is not rejected as a physical violation of
# the declared [6, 12] domain.
SPEED_DOMAIN_TOLERANCE_MPS = 1e-8


class ReachabilityError(ValueError):
    """Fail-closed error for an infeasible or invalid reachability request."""

    def __init__(self, code: str, detail: str, *, d_req_m: float | None = None):
        super().__init__(f"{code}: {detail}")
        self.code = code
        self.detail = detail
        self.d_req_m = d_req_m


@dataclass(frozen=True)
class ReachabilityWindow:
    """Outer and kinematic time bounds for one directed event point.

    ``t_lb`` / ``t_ub`` are the *kinematic* bounds after refinement.  The raw
    ``L/v`` outer bounds are kept alongside so a caller can never mistake one for
    the other; only ``layer`` reports which refinement level was reached.
    """

    t_now: float
    length_m: float
    v_now: float
    v_terminal: float | None
    t_lb_outer: float
    t_ub_outer: float
    t_lb: float
    t_ub: float
    travel_time_lb: float
    travel_time_ub: float
    status: str
    layer: str
    source_state_id: str
    terminal_condition: str
    assumptions: tuple[str, ...]
    d_req_m: float | None = None
    peak_speed_lb_mps: float | None = None
    trough_speed_ub_mps: float | None = None
    failure_code: str | None = None
    notes: Mapping[str, Any] = field(default_factory=dict)

    @property
    def feasible(self) -> bool:
        return self.status == STATUS_OK

    def contains(self, time_s: float, tolerance_s: float = NESTING_TOLERANCE_S) -> bool:
        return self.feasible and self.t_lb - tolerance_s <= time_s <= self.t_ub + tolerance_s


def bounded_reachability_window(
    *,
    t_now: float,
    length_m: float,
    v_now: float,
    v_min: float,
    v_max: float,
    a_max: float,
    b_max: float,
    v_terminal: float | None = None,
    source_state_id: str = "",
    allow_stop_start: bool = False,
    latest_time_s: float | None = None,
) -> ReachabilityWindow:
    """Outer ``L/v`` bounds plus analytic bounded-accel/decel refinement.

    ``v_terminal`` is the speed that must hold at the event point (for example the
    validated fixed-transfer entry speed ``v_i^G``).  When it is ``None`` the
    single-ended bounds of spec section 3.5 are used (mainline position events
    such as an H resource crossing with no prescribed entry speed).
    """

    if allow_stop_start:
        values = (t_now, length_m, v_now, v_max, a_max, b_max)
        if (not all(math.isfinite(v) for v in values) or length_m < 0
                or not -1e-8 <= v_now <= v_max+1e-8 or min(v_max, a_max, b_max) <= 0
                or (latest_time_s is not None and (not math.isfinite(latest_time_s) or latest_time_s <= t_now))):
            raise ReachabilityError(STATUS_SPEED_DOMAIN_INVALID, "invalid explicit stop/start envelope")
        # Match the motion executor's declared 1e-8 m/s roundoff tolerance.
        # A full analytical brake can evaluate to -8.9e-16, not reverse flight.
        v_now = min(v_max,max(0.,v_now))
        latest = math.inf if latest_time_s is None else latest_time_s-t_now
        vf = v_terminal
        if vf is None:
            early, _, notes = _single_ended_bounds(length_m, v_now, max(v_now, 1e-9), v_max, a_max, b_max)
            stop_distance = v_now*v_now/(2*b_max)
            late = (latest if length_m >= stop_distance else
                    (v_now-math.sqrt(max(0.,v_now*v_now-2*b_max*length_m)))/b_max)
        else:
            if not math.isfinite(vf) or not 0 < vf <= v_max:
                raise ReachabilityError(STATUS_SPEED_DOMAIN_INVALID, "invalid stop/start terminal speed")
            required = ((vf*vf-v_now*v_now)/(2*a_max) if vf >= v_now
                        else (v_now*v_now-vf*vf)/(2*b_max))
            if length_m < required-1e-9:
                raise ReachabilityError(STATUS_INFEASIBLE_TERMINAL_SPEED, "restart distance insufficient")
            peak = min(v_max, math.sqrt((length_m+v_now*v_now/(2*a_max)+vf*vf/(2*b_max))
                                       /(1/(2*a_max)+1/(2*b_max))))
            cruise = max(0., length_m-(peak*peak-v_now*v_now)/(2*a_max)-(peak*peak-vf*vf)/(2*b_max))
            early = (peak-v_now)/a_max+cruise/peak+(peak-vf)/b_max
            if length_m >= v_now*v_now/(2*b_max)+vf*vf/(2*a_max)-1e-9:
                late = latest
            else:
                _, _, late, _ = _terminal_bounds(length_m,v_now,vf,1e-9,v_max,a_max,b_max)
            notes = {"source": "EXPLICIT_BOUNDED_STOP_START"}
        # An earliest arrival outside this roll is retained as wait-only by the
        # adapter. This is an envelope, not an executable motion certificate.
        late = min(late, latest)
        status = STATUS_OK if early <= late else STATUS_INFEASIBLE_KINEMATIC
        return ReachabilityWindow(t_now,length_m,v_now,vf,t_now+length_m/v_max,
            t_now+late,t_now+early,t_now+late,early,late,status,
            "BOUNDED_STOP_START_ENVELOPE",source_state_id,str(vf),
            ("Explicit stop/start mode; actual initial speed retained; motion certification required",),
            failure_code=None if status == STATUS_OK else "EMPTY_EVENT_TIME_DOMAIN", notes=notes)
    assumptions = (
        "1D motion along a fixed directed path; no reverse travel, no dwell",
        f"v in [{v_min}, {v_max}] m/s, a in [0, {a_max}] m/s^2, b in [0, {b_max}] m/s^2",
        "analytic extremal profile with at most one accel segment, one cruise segment and one decel segment",
        "kinematic bounds are necessary, not sufficient for the smoothstep profile family",
    )
    if not (v_min > 0 and v_max >= v_min and a_max > 0 and b_max > 0):
        raise ReachabilityError(STATUS_SPEED_DOMAIN_INVALID, f"v_min={v_min}, v_max={v_max}, a={a_max}, b={b_max}")
    if not (v_min - SPEED_DOMAIN_TOLERANCE_MPS <= v_now <= v_max + SPEED_DOMAIN_TOLERANCE_MPS):
        raise ReachabilityError(
            STATUS_SPEED_DOMAIN_INVALID,
            f"v_now={v_now} outside [{v_min}, {v_max}]",
        )
    v_now = min(v_max, max(v_min, v_now))
    if not (length_m >= 0.0) or t_now != t_now:
        raise ReachabilityError(STATUS_LENGTH_INVALID, f"length_m={length_m}, t_now={t_now}")
    if v_terminal is not None and not (v_min - SPEED_DOMAIN_TOLERANCE_MPS <= v_terminal <= v_max + SPEED_DOMAIN_TOLERANCE_MPS):
        raise ReachabilityError(
            STATUS_SPEED_DOMAIN_INVALID,
            f"v_terminal={v_terminal} outside [{v_min}, {v_max}]",
        )
    if v_terminal is not None:
        v_terminal = min(v_max, max(v_min, v_terminal))

    t_lb_outer = t_now + length_m / v_max
    t_ub_outer = t_now + length_m / v_min
    terminal_condition = "none" if v_terminal is None else f"prescribed v_f={v_terminal} m/s"

    if v_terminal is None:
        t_early, t_late, notes = _single_ended_bounds(length_m, v_now, v_min, v_max, a_max, b_max)
        layer = "LAYER_A_OUTER_AND_LAYER_B_KINEMATIC_SINGLE_ENDED"
        d_req = None
    else:
        d_req, t_early, t_late, notes = _terminal_bounds(length_m, v_now, v_terminal, v_min, v_max, a_max, b_max)
        layer = "LAYER_A_OUTER_AND_LAYER_B_KINEMATIC"

    t_lb = t_now + t_early
    t_ub = t_now + t_late
    status = STATUS_OK
    failure_code = None
    if (t_lb_outer - NESTING_TOLERANCE_S > t_lb or t_ub > t_ub_outer + NESTING_TOLERANCE_S):
        status = STATUS_KINEMATIC_NESTING_VIOLATION
        failure_code = STATUS_KINEMATIC_NESTING_VIOLATION

    return ReachabilityWindow(
        t_now=t_now, length_m=length_m, v_now=v_now, v_terminal=v_terminal,
        t_lb_outer=t_lb_outer, t_ub_outer=t_ub_outer,
        t_lb=t_lb, t_ub=t_ub, travel_time_lb=t_early, travel_time_ub=t_late,
        status=status, layer=layer, source_state_id=source_state_id,
        terminal_condition=terminal_condition, assumptions=assumptions,
        d_req_m=d_req, failure_code=failure_code, notes=notes,
    )


def published_reachability_window(state, **kwargs):
    """Current-state kinematic bounds; frozen event targets are retained separately."""
    if state.current_motion_plan.get("joint_motion_witness"):
        raise ValueError(f"RETIRED_MOTION_CERTIFICATE_IN_NEW_RUN:{state.uav_id}")
    return bounded_reachability_window(**kwargs)



def _terminal_bounds(length_m, v0, vf, v_min, v_max, a, b):
    """Spec section 3.1-3.4: bounds with a prescribed terminal speed."""
    notes: dict[str, Any] = {}
    if vf >= v0:
        d_req = (vf * vf - v0 * v0) / (2.0 * a)
    else:
        d_req = (v0 * v0 - vf * vf) / (2.0 * b)
    if length_m < d_req - 1e-9:
        notes["d_req_m"] = d_req
        raise ReachabilityError(
            STATUS_INFEASIBLE_TERMINAL_SPEED,
            f"L={length_m} < d_req={d_req} for v0={v0} -> vf={vf}",
            d_req_m=d_req,
        )

    # Earliest: accelerate first, then decelerate.
    one_a, one_b = 1.0 / (2.0 * a), 1.0 / (2.0 * b)
    vp_sq = (length_m + v0 * v0 * one_a + vf * vf * one_b) / (one_a + one_b)
    if vp_sq < 0.0:
        raise ReachabilityError(STATUS_INFEASIBLE_TERMINAL_SPEED, "degenerate peak-speed data")
    vp = min(v_max, vp_sq ** 0.5)
    d_a = (vp * vp - v0 * v0) / (2.0 * a)
    d_b = (vp * vp - vf * vf) / (2.0 * b)
    d_c = length_m - d_a - d_b
    if min(d_a, d_b) < -1e-9 or d_c < -1e-9:
        raise ReachabilityError(STATUS_INFEASIBLE_TERMINAL_SPEED, "negative segment distances")
    t_early = (vp - v0) / a + max(0.0, d_c) / vp + (vp - vf) / b
    notes["earliest"] = {"v_peak_mps": vp, "d_accel_m": d_a, "d_decel_m": d_b, "d_cruise_m": d_c}

    # Latest: decelerate first, then accelerate.
    d_slow = (v0 * v0 - v_min * v_min) / (2.0 * b) + (vf * vf - v_min * v_min) / (2.0 * a)
    if length_m >= d_slow:
        vl = float(v_min)
    else:
        vl_sq = (v0 * v0 * one_b + vf * vf * one_a - length_m) / (one_b + one_a)
        if vl_sq < 0.0:
            raise ReachabilityError(STATUS_INFEASIBLE_TERMINAL_SPEED, "degenerate trough-speed data")
        vl = vl_sq ** 0.5
    if vl > min(v0, vf) + 1e-9:
        raise ReachabilityError(
            STATUS_INFEASIBLE_TERMINAL_SPEED,
            f"trough speed {vl} exceeds min(v0,vf)={min(v0, vf)}",
        )
    d_d = (v0 * v0 - vl * vl) / (2.0 * b)
    d_u = (vf * vf - vl * vl) / (2.0 * a)
    d_c2 = length_m - d_d - d_u
    if min(d_d, d_u) < -1e-9 or d_c2 < -1e-9:
        raise ReachabilityError(STATUS_INFEASIBLE_TERMINAL_SPEED, "negative late-profile segments")
    t_late = (v0 - vl) / b + max(0.0, d_c2) / vl + (vf - vl) / a
    notes["latest"] = {"v_trough_mps": vl, "d_decel_m": d_d, "d_accel_m": d_u, "d_cruise_m": d_c2}
    return d_req, t_early, t_late, notes


def _single_ended_bounds(length_m, v0, v_min, v_max, a, b):
    """Spec section 3.5: bounds with no prescribed terminal speed (H position events)."""
    notes: dict[str, Any] = {}
    d_a_max = (v_max * v_max - v0 * v0) / (2.0 * a)
    if length_m <= d_a_max:
        t_early = ((v0 * v0 + 2.0 * a * length_m) ** 0.5 - v0) / a
        notes["earliest"] = "accelerate-to-speed-at-event"
    else:
        t_early = (v_max - v0) / a + (length_m - d_a_max) / v_max
        notes["earliest"] = {"d_accel_max_m": d_a_max, "cruise_speed_mps": v_max}

    d_d_min = (v0 * v0 - v_min * v_min) / (2.0 * b)
    if length_m <= d_d_min:
        t_late = (v0 - (v0 * v0 - 2.0 * b * length_m) ** 0.5) / b
        notes["latest"] = "decelerate-to-speed-at-event"
    else:
        t_late = (v0 - v_min) / b + (length_m - d_d_min) / v_min
        notes["latest"] = {"d_decel_min_m": d_d_min, "cruise_speed_mps": v_min}
    return t_early, t_late, notes
