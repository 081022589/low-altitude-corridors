"""Own-motion polynomial storage, crossing arithmetic and independent audit."""
from __future__ import annotations

from dataclasses import dataclass, replace
import math
from typing import Iterable, Mapping, Any

import numpy as np

from .numeric_motion import MotionPiece, TickProfile, continuous_min_gap
from .simulation_state import UAVState
from .speed_control_scope import (
    speed_control_token_is_active, is_scoped_h_resource_control,
    h_resource_control_required, unfinished_resource_targets,
)

VERSION = "CMLPM_TIMED_SPEED_EXECUTION_V2"
POSITION_TOL_M = 1e-6
TIME_TOL_S = 1e-6


class MotionPlanRejected(ValueError):
    def __init__(self, code: str, detail: str = ""):
        self.code, self.detail = code, detail
        super().__init__(f"{code}:{detail}")


@dataclass(frozen=True)
class MotionTarget:
    uav_id: str
    event_id: str
    time_s: float
    station_m: float
    terminal_speed_mps: float | None = None
    leaves_mainline: bool = False




def state_at(plan: Mapping[str, Any], time_s: float) -> tuple[float, float]:
    from .motion_plan_encoding import decoded_profile
    encoded = decoded_profile(plan)
    if encoded is not None:
        elapsed = time_s-float(plan["motion_origin_s"])
        if not -TIME_TOL_S <= elapsed <= encoded.duration_s+TIME_TOL_S:
            raise MotionPlanRejected("SPEED_PROFILE_TIME_OUTSIDE",str(time_s))
        return encoded.state_at(min(encoded.duration_s,max(0.,elapsed)))
    knots = plan["knots"]
    if not float(knots[0][0]) - TIME_TOL_S <= time_s <= float(knots[-1][0]) + TIME_TOL_S:
        raise MotionPlanRejected("SPEED_PROFILE_TIME_OUTSIDE", str(time_s))
    for first, second in zip(knots, knots[1:]):
        if time_s <= float(second[0]):
            width = float(second[0]) - float(first[0])
            tau = min(width, max(0.0, time_s - float(first[0])))
            acceleration = (float(second[2]) - float(first[2])) / width
            return (float(first[1]) + float(first[2])*tau + .5*acceleration*tau*tau,
                    float(first[2]) + acceleration*tau)
    return float(knots[-1][1]), float(knots[-1][2])


def tick_profile(plan: Mapping[str, Any], start_s: float, end_s: float) -> TickProfile:
    from .motion_plan_encoding import decoded_profile
    encoded = decoded_profile(plan)
    if encoded is not None:
        origin = float(plan["motion_origin_s"])
        start,end = start_s-origin,end_s-origin
        if start < -1e-9 or end > encoded.duration_s+1e-9 or end <= start:
            raise MotionPlanRejected("SPEED_PROFILE_TIME_OUTSIDE",str((start_s,end_s)))
        pieces = []
        for source in encoded.pieces:
            left,right = max(start,source.start_s),min(end,source.end_s)
            if right <= left:
                continue
            position,speed = source.state_at(left)
            pieces.append(MotionPiece(left-start,right-start,position,speed,source.acceleration_mps2))
        return TickProfile(tuple(pieces),end_s-start_s)
    cuts = sorted({start_s, end_s, *(float(k[0]) for k in plan["knots"] if start_s < float(k[0]) < end_s)})
    pieces = []
    for left, right in zip(cuts, cuts[1:]):
        position, speed = state_at(plan, left)
        _, next_speed = state_at(plan, right)
        pieces.append(MotionPiece(left-start_s, right-start_s, position, speed,
                                  (next_speed-speed)/(right-left)))
    return TickProfile(tuple(pieces), end_s-start_s)


def crossing_time(plan: Mapping[str, Any], station_m: float) -> float:
    first, last = plan["knots"][0], plan["knots"][-1]
    if station_m < float(first[1])-POSITION_TOL_M or station_m > float(last[1])+POSITION_TOL_M:
        raise MotionPlanRejected("RESOURCE_OUTSIDE_SPEED_PROFILE", str(station_m))
    low, high = float(first[0]), float(last[0])
    for _ in range(65):
        middle = .5*(low+high)
        if state_at(plan, middle)[0] < station_m:
            low = middle
        else:
            high = middle
    return .5*(low+high)


def _position_row(times: np.ndarray, moment: float) -> np.ndarray:
    row = np.zeros(len(times))
    for index, (left, right) in enumerate(zip(times, times[1:])):
        if moment <= left:
            break
        width = right-left
        tau = min(width, moment-left)
        row[index] += tau - tau*tau/(2*width)
        row[index+1] += tau*tau/(2*width)
    return row


def _gap_witness(leader: Mapping[str, Any], follower: Mapping[str, Any], until_s: float,
                 *, evaluate_state=None, all_witnesses: bool = False):
    evaluate = state_at if evaluate_state is None else evaluate_state
    start = max(float(leader["knots"][0][0]), float(follower["knots"][0][0]))
    end = min(float(leader["knots"][-1][0]), float(follower["knots"][-1][0]), until_s)
    cuts = sorted({start, end, *(float(k[0]) for p in (leader, follower) for k in p["knots"] if start < float(k[0]) < end)})
    witnesses = [(evaluate(leader, t)[0]-evaluate(follower, t)[0], t) for t in cuts]
    for left, right in zip(cuts, cuts[1:]):
        lp, lv = evaluate(leader, left)
        fp, fv = evaluate(follower, left)
        _, l_end = evaluate(leader, right)
        _, f_end = evaluate(follower, right)
        relative_a = ((l_end-lv)-(f_end-fv))/(right-left)
        if abs(relative_a) > 1e-12:
            tau = -(lv-fv)/relative_a
            if 0 < tau < right-left:
                witnesses.append((lp-fp+(lv-fv)*tau+.5*relative_a*tau*tau, left+tau))
    return tuple(witnesses) if all_witnesses else min(witnesses)








