"""Integrate measured ascent and an exact handoff to the mainline executor."""
from dataclasses import asdict, replace
import math

from .simulation_state import FlightState as F, TrafficSnapshot
from .reentry_motion import ReentryMotionProfile, ReentryStageProfile
from .reentry_executor import advance_climb
from .motion_executor import MotionStep, MotionExecutionBlocked
from .existing_v_continuation import ExecutedEvent
from .following_time import physical_lane, OFF_MAINLINE
from .numeric_motion import MotionPiece, TickProfile
from .motion_executor import _TIME_TOL


def _event_boundaries(begin, end, events):
    """Use the executor's time tolerance for endpoints and coincident edges.

    Keep original event clocks in the emitted records; only the integration
    boundaries are coalesced. Distinct events still split the physical tick.
    """
    points = [begin]
    for moment in sorted(events):
        if moment <= begin + _TIME_TOL or moment >= end - _TIME_TOL:
            continue
        if moment - points[-1] > _TIME_TOL:
            points.append(moment)
    points.append(end)
    return points


def _profile(state):
    payload=state.current_motion_plan.get('reentry_profile')
    if not payload or not payload.get('trajectory'):
        raise MotionExecutionBlocked('MEASURED_REENTRY_PROFILE_REQUIRED',state.uav_id)
    segments = payload['trajectory'].get('segments')
    if not isinstance(segments, (list, tuple)) or not segments:
        raise MotionExecutionBlocked('REENTRY_PROFILE_EMPTY', state.uav_id)
    return ReentryMotionProfile(**payload)


def _stage_profile(state):
    payload = state.current_motion_plan.get('reentry_stage_profile')
    if not payload or not payload.get('trajectory'):
        raise MotionExecutionBlocked('REENTRY_STAGE_PROFILE_REQUIRED', state.uav_id)
    return ReentryStageProfile(
        release_time_s=float(payload['release_time_s']),
        end_time_s=float(payload['end_time_s']),
        stage_kind=str(payload['stage_kind']),
        trajectory=payload['trajectory'],
    )


def _participates(state):
    return state.state==F.REENTRY_CLIMB or (
        state.state in {F.REENTRY_HOLD, F.REENTRY_FINAL_APPROACH}
        and state.current_motion_plan.get('reentry_profile')) or (
        state.state in {F.REENTRY_LAND_TO_GROUND, F.REENTRY_ASCENT_TO_50M}
        and state.current_motion_plan.get('reentry_stage_profile')) or (
        state.state == F.REENTRY_LOCAL_BRAKING
        and state.current_motion_plan.get('reentry_local_braking'))


def _is_stage(state):
    return state.state in {F.REENTRY_LAND_TO_GROUND, F.REENTRY_ASCENT_TO_50M}


def _base_state(state):
    """Keep off-mainline stage states out of the frozen V5 base executor."""
    if _is_stage(state):
        return replace(state, state=F.REENTRY_HOLD)
    if state.state == F.REENTRY_FINAL_APPROACH:
        return replace(state, state=F.REENTRY_HOLD)
    if state.state in {F.REENTRY_LOCAL_BRAKING, F.REENTRY_LOCAL_HOLD}:
        return replace(state, state=F.REENTRY_HOLD)
    return state


def _local_braking_payload(state):
    payload = state.current_motion_plan.get('reentry_local_braking')
    if not isinstance(payload, dict):
        raise MotionExecutionBlocked('REENTRY_LOCAL_BRAKING_PROFILE_REQUIRED', state.uav_id)
    return payload


def _advance_local_braking(state, *, right):
    payload = _local_braking_payload(state)
    elapsed = max(0.0, float(right) - float(payload['start_time_s']))
    speed0 = float(payload['start_speed_mps'])
    deceleration = float(payload['deceleration_mps2'])
    stop_time = float(payload['stop_time_s'])
    used = min(elapsed, stop_time)
    distance = speed0 * used - 0.5 * deceleration * used * used
    direction = tuple(float(value) for value in payload['direction_xyz'])
    start_xyz = tuple(float(value) for value in payload['start_position_xyz'])
    position = tuple(start_xyz[index] + direction[index] * distance for index in range(3))
    speed = max(0.0, speed0 - deceleration * used)
    station = float(payload['start_station_m']) + math.copysign(distance, direction[0] or 1.0)
    plan = dict(state.current_motion_plan)
    plan['motion_position_xyz'] = position
    if elapsed + 1e-9 >= stop_time:
        plan.pop('reentry_local_braking', None)
        plan['reentry_local_wait_position_xyz'] = position
        plan['reentry_local_wait_s'] = station
        plan['reentry_local_wait_started_s'] = float(right)
        plan['reentry_execution_feedback'] = {
            **dict(plan.get('reentry_execution_feedback', {})),
            'status': 'LOCAL_MERGE_REJECTED',
            'reason': 'REENTRY_ACTUAL_INSERTION_GAP',
            'actual_gap_m': float(payload.get('actual_gap_m', 0.0)),
            'required_gap_m': float(payload.get('required_gap_m', 0.0)),
            'time_s': float(right),
        }
        return replace(state, state=F.REENTRY_LOCAL_HOLD, s_m=station,
                       z_m=position[2], speed_mps=0.0,
                       current_motion_plan=plan, event_version=state.event_version + 1)
    return replace(state, s_m=station, z_m=position[2], speed_mps=speed,
                   current_motion_plan=plan, event_version=state.event_version + 1)


def _local_brake_after_conflict(state, profile, *, left, right, conflicts,
                                required_gap_m, actual_gap_m, limits):
    expected = profile.state_at(left)
    start_xyz = tuple(expected.position_xyz or state.current_motion_plan.get('motion_position_xyz'))
    speed = float(expected.speed_mps)
    acceleration = float(limits.max_abs_acceleration_mps2)
    if speed < 1e-9:
        raise MotionExecutionBlocked('REENTRY_ACTUAL_INSERTION_GAP',
                                     f'{state.uav_id}:LOCAL_WAIT_UNAVAILABLE:ZERO_SPEED_NO_PROFILE')
    tangent_state = profile.state_at(min(float(profile.merge_time_s), float(left) + 1e-3))
    next_xyz = tangent_state.position_xyz or start_xyz
    norm = math.dist(start_xyz, next_xyz)
    direction = tuple((next_xyz[index] - start_xyz[index]) / norm for index in range(3)) if norm > 1e-12 else (1.0, 0.0, 0.0)
    stop_distance = speed * speed / (2.0 * acceleration)
    ahead_limits = [float(other.s_m) - float(required_gap_m)
                    for other in conflicts if float(other.s_m) >= float(expected.station_m)]
    behind_limits = [float(other.s_m) + float(required_gap_m)
                     for other in conflicts if float(other.s_m) < float(expected.station_m)]
    if ahead_limits:
        safe_limit = min(ahead_limits)
        available = safe_limit - float(expected.station_m)
    elif behind_limits:
        # A rear conflict cannot be resolved by reversing the UAV along
        # its approach tangent. Without a verified forward stopping
        # envelope before the merge boundary, isolate the failure rather
        # than emitting a physically discontinuous reverse trajectory.
        raise MotionExecutionBlocked(
            'REENTRY_ACTUAL_INSERTION_GAP',
            f'{state.uav_id}:LOCAL_WAIT_UNAVAILABLE:REVERSE_BRAKING_FORBIDDEN',
        )
    else:
        raise MotionExecutionBlocked('REENTRY_ACTUAL_INSERTION_GAP',
                                     f'{state.uav_id}:LOCAL_WAIT_UNAVAILABLE:NO_SAFE_BOUND')
    if stop_distance > available + 1e-6:
        raise MotionExecutionBlocked('REENTRY_ACTUAL_INSERTION_GAP',
                                     f'{state.uav_id}:LOCAL_WAIT_UNAVAILABLE:need={stop_distance}:available={available}')
    payload = dict(state.current_motion_plan)
    payload.pop('reentry_profile', None)
    payload.pop('reentry_certificate_id', None)
    payload['reentry_local_braking'] = {
        'start_time_s': float(left),
        'start_position_xyz': start_xyz,
        'start_station_m': float(expected.station_m),
        'start_speed_mps': speed,
        'direction_xyz': direction,
        'deceleration_mps2': acceleration,
        'stop_time_s': speed / acceleration,
        'safe_limit_station_m': float(safe_limit),
        'actual_gap_m': float(actual_gap_m),
        'required_gap_m': float(required_gap_m),
    }
    braking = replace(state, state=F.REENTRY_LOCAL_BRAKING,
                      current_motion_plan=payload)
    return _advance_local_braking(braking, right=right)


def _advance_stage(state, profile, *, right):
    motion = profile.state_at(right)
    plan = dict(state.current_motion_plan)
    plan['motion_position_xyz'] = tuple(motion.position_xyz)
    if right < profile.end_time_s - _TIME_TOL:
        return replace(state, s_m=motion.station_m, z_m=motion.z_m,
                       speed_mps=motion.speed_mps, current_motion_plan=plan)
    plan.pop('reentry_stage_profile', None)
    plan['reentry_stage_completed_s'] = float(profile.end_time_s)
    if profile.stage_kind == 'LAND_TO_GROUND':
        plan['reentry_service_started_s'] = float(profile.end_time_s)
        plan['reentry_service_ground_arrival_s'] = float(profile.end_time_s)
        return replace(state, state=F.SERVICING, s_m=motion.station_m,
                       z_m=motion.z_m, speed_mps=0.0,
                       current_motion_plan=plan,
                       event_version=state.event_version + 1)
    plan['reentry_staging_started_s'] = float(profile.end_time_s)
    return replace(state, state=F.REENTRY_STAGING_HOLD, s_m=motion.station_m,
                   z_m=motion.z_m, speed_mps=0.0,
                   current_motion_plan=plan,
                   event_version=state.event_version + 1)


def execute_reentry_step(snapshot, *, dt_s, **kwargs):
    from .motion_advance_v1 import execute_frozen_motion_v1
    v5_base = bool(kwargs.pop("_v5_base_executor", False))
    if v5_base:
        from .v5_thin_executor import execute_v5_thin_step
        base_executor = execute_v5_thin_step
    else:
        base_executor = execute_frozen_motion_v1
    if not math.isfinite(dt_s) or dt_s <= 0.:
        raise MotionExecutionBlocked('INVALID_STEP',str(dt_s))
    begin=float(snapshot.sim_time_s);end=begin+dt_s
    cuts={begin,end}
    for state in snapshot.states.values():
        if _participates(state):
            if state.state == F.REENTRY_LOCAL_BRAKING:
                payload = _local_braking_payload(state)
                stop_at = float(payload['start_time_s']) + float(payload['stop_time_s'])
                if stop_at < begin - _TIME_TOL:
                    raise MotionExecutionBlocked(
                        'REENTRY_LOCAL_BRAKING_TIME_MISSED', state.uav_id,
                    )
                if begin < stop_at < end:
                    cuts.add(stop_at)
                continue
            if _is_stage(state):
                p = _stage_profile(state)
                if begin < p.release_time_s < end: cuts.add(p.release_time_s)
                if p.end_time_s < begin - 1e-9:
                    raise MotionExecutionBlocked('REENTRY_STAGE_TIME_MISSED', state.uav_id)
                if begin < p.end_time_s < end: cuts.add(p.end_time_s)
            else:
                p=_profile(state)
                if begin < p.release_time_s < end:cuts.add(p.release_time_s)
                if p.merge_time_s < begin-1e-9:
                    raise MotionExecutionBlocked('REENTRY_MERGE_TIME_MISSED',state.uav_id)
                if begin < p.merge_time_s < end:cuts.add(p.merge_time_s)
    points=_event_boundaries(begin,end,cuts);current=snapshot;parts=[];all_events=[];edges=[]
    for left,right in zip(points,points[1:]):
        base_snapshot = replace(current, states={uid: _base_state(value)
            for uid, value in current.states.items()})
        step=base_executor(base_snapshot,dt_s=right-left,**kwargs)
        states=[];events=list(step.events);merged=[]
        for state in step.states:
            old=current.states[state.uav_id]
            if old.state == F.REENTRY_LOCAL_HOLD:
                # A local hold is already a verified zero-speed state.  The
                # base executor must not reinterpret it as ordinary traffic.
                states.append(old)
                continue
            if not _participates(old):
                states.append(state);continue
            if old.state == F.REENTRY_LOCAL_BRAKING:
                states.append(_advance_local_braking(old, right=right))
                continue
            if _is_stage(old):
                p = _stage_profile(old)
                expected = p.state_at(left)
                actual = old.current_motion_plan.get('motion_position_xyz')
                if actual is None or max(abs(old.s_m-expected.station_m),
                                         abs(old.z_m-expected.z_m),
                                         abs(old.speed_mps-expected.speed_mps),
                                         math.dist(actual, expected.position_xyz)) > 1e-6:
                    raise MotionExecutionBlocked('REENTRY_STAGE_INITIAL_STATE_MISMATCH', old.uav_id)
                advanced = _advance_stage(old, p, right=right)
                prior = tuple(old.current_motion_plan.get('motion_observed_events', ()))
                known = {row['event_id'] for row in prior}
                candidates = [(p.release_time_s, 'REENTRY_STAGE_RELEASE', None),
                              (p.end_time_s, 'SERVICE_GROUND_ARRIVAL' if p.stage_kind == 'LAND_TO_GROUND'
                               else 'REENTRY_STAGING_ARRIVAL', None)]
                fresh = []
                for moment, kind, resource in candidates:
                    eid = f"{old.uav_id}:REENTRY_STAGE:{kind}"
                    if eid in known or moment > right + 1e-9:
                        continue
                    if moment < left - 1e-9:
                        raise MotionExecutionBlocked('REENTRY_STAGE_EVENT_MISSED', eid)
                    fresh.append(ExecutedEvent(eid, kind, moment, len(prior)+len(fresh), resource, old.uav_id))
                advanced = replace(advanced, current_motion_plan={**advanced.current_motion_plan,
                    'motion_observed_events': prior + tuple(asdict(e) for e in fresh)})
                events.extend(fresh)
                states.append(advanced)
                continue
            p=_profile(old)
            # Match the state to the same curve used for actual event times.
            expected=p.state_at(left)
            if max(abs(old.s_m-expected.station_m),abs(old.z_m-expected.z_m),abs(old.speed_mps-expected.speed_mps))>1e-6:
                raise MotionExecutionBlocked('REENTRY_INITIAL_STATE_MISMATCH',old.uav_id)
            if right < p.release_time_s-1e-9:
                advanced=state
            else:
                advanced=advance_climb(replace(state,state=F.REENTRY_CLIMB),now_s=right,profile=p)
                if advanced.state == F.REENTRY_CLIMB and old.state == F.REENTRY_FINAL_APPROACH:
                    advanced = replace(advanced, state=F.REENTRY_FINAL_APPROACH)
            prior=tuple(old.current_motion_plan.get('motion_observed_events',()))
            known={r['event_id'] for r in prior}
            prefix=old.uav_id+':REENTRY:'+str(old.current_motion_plan['reentry_certificate_id'])+':'
            candidates=[(p.release_time_s,'REENTRY_RELEASE',None),
                (p.release_time_s+p.climb_duration_s,'REENTRY_CURVE_START',None),
                (p.merge_time_s,'REENTRY_MERGE',None)]
            for rid,(enter,exit_) in p.trajectory['resource_windows_offsets'].items():
                candidates.extend(((p.release_time_s+enter,'RESOURCE_ENTER',rid),
                                   (p.release_time_s+exit_,'RESOURCE_EXIT',rid)))
            fresh=[]
            for moment,kind,rid in sorted(candidates,key=lambda r:(r[0],r[1],str(r[2]))):
                eid=prefix+str(rid)+':'+kind
                if eid in known or moment>right+1e-9:continue
                if moment<left-1e-9:
                    raise MotionExecutionBlocked('REENTRY_EVENT_MISSED',eid)
                fresh.append(ExecutedEvent(eid,kind,moment,len(prior)+len(fresh),rid,old.uav_id))
            advanced=replace(advanced,current_motion_plan={**advanced.current_motion_plan,
                'motion_observed_events':prior+tuple(asdict(e) for e in fresh)})
            events.extend(fresh)
            if advanced.state==F.MAINLINE:merged.append(advanced)
            states.append(advanced)
        # Check both neighbours at the exact insertion boundary, before any CAS.
        gap_required=float(kwargs['min_mainline_gap_m'])
        for new in tuple(merged):
            conflicts = []
            for other in states:
                if (other.uav_id == new.uav_id
                        or other.state in OFF_MAINLINE
                        or other.state in {F.REENTRY_LOCAL_BRAKING, F.REENTRY_LOCAL_HOLD}):
                    continue
                if physical_lane(other)!=physical_lane(new):continue
                gap=abs(other.s_m-new.s_m)
                if gap<gap_required-1e-6:
                    conflicts.append(other)
            if not conflicts:
                continue
            old = current.states[new.uav_id]
            profile = _profile(old)
            replacement = _local_brake_after_conflict(
                old, profile, left=left, right=right, conflicts=conflicts,
                required_gap_m=gap_required,
                actual_gap_m=min(abs(float(other.s_m) - float(new.s_m)) for other in conflicts),
                limits=kwargs['motion_limits_by_type'][old.vehicle_type],
            )
            states = [replacement if row.uav_id == new.uav_id else row for row in states]
            merged = [row for row in merged if row.uav_id != new.uav_id]
            events = [event for event in events
                      if not (event.uav_id == new.uav_id and event.event_type == 'REENTRY_MERGE')]
        step=replace(step,states=tuple(states),events=tuple(events))
        parts.append((current,step));all_events.extend(events);edges.extend(step.following_response_edges)
        current=TrafficSnapshot(snapshot.version,right,{s.uav_id:s for s in states},
                                getattr(snapshot,'resource_dependencies',{}))
    # Profiles are available for callers that inspect ordinary mainline motion.
    # Audit uses the exact substeps so a newly merged aircraft is present only
    # for the interval in which it actually belongs to that lane.
    profiles={}
    for before,step in parts:
        offset=step.t_from-begin
        for uid,p in step.mainline_profiles.items():
            pieces=list(profiles.get(uid,()))
            pieces.extend(MotionPiece(x.start_s+offset,x.end_s+offset,x.start_position_m,x.start_speed_mps,x.acceleration_mps2) for x in p.pieces)
            profiles[uid]=tuple(pieces)
    return MotionStep(begin,end,tuple(current.states.values()),tuple(all_events),tuple(edges),
        {uid:TickProfile(pieces,dt_s) for uid,pieces in profiles.items()},tuple(parts))
