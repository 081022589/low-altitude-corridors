"""Existing-V continuation: executed prefix -> remaining events and occupancy.

This module owns one question only: given the current traffic state of an
already-committed descent, a read-only view of its published and verified
motion plan, and the actually executed event prefix, how are the remaining
motion events and resource occupancies expressed for C-MLPM inheritance?

Three-way classification of the ordered resource chain:

* ``released``  - the UAV has an actual EXIT record; no future occupancy.
                  The occupancy is kept only while its trailing entry headway
                  can still influence a new vehicle.
* ``active``    - the UAV has an actual ENTER record but no EXIT record; the
                  occupancy spans the current scheduling event and keeps its actual entry
                  time and the planned exit time.
* ``future``    - no ENTER record yet; the occupancy keeps the verified plan's
                  absolute entry and exit times.

The module never fabricates an actual event: a missing executed prefix is a
closed failure, not a reconstructed history.  It never re-runs SRCM or ECJA,
never changes a frozen plan, and never replaces an actual entry time with the
current scheduling-event time.
"""

from __future__ import annotations

from dataclasses import dataclass
import math
from types import MappingProxyType
from typing import Any, Iterable, Mapping, Sequence

from .crossing_resource_mapping import (
    build_crossing_resource_maps,
    crossing_map_for_node_layer,
)
from .network_loader import RegisteredG25
from .simulation_state import FlightState, UAVState


CONTINUATION_VERSION = "CMLPM_EXISTING_V_CONTINUATION_V1"
_LAYER_INDEX = {"L1": 1, "L2": 2, "L3": 3}
_Z_CONTINUITY_TOLERANCE_M = 0.5
_TIME_TOLERANCE_S = 1e-6

_EXECUTED_TYPES = {"G", "J", "RESOURCE_ENTER", "RESOURCE_EXIT", "B_L1"}


class ContinuationBlocked(ValueError):
    """Structured fail-closed error at the existing-V continuation seam."""

    def __init__(self, code: str, detail: str):
        super().__init__(f"{code}:{detail}")
        self.code = code
        self.detail = detail


@dataclass(frozen=True)
class ExecutedEvent:
    """One event actually observed during execution.

    ``uav_id`` is kept explicitly so an event never has to be attributed by
    parsing its identifier.  When it is not supplied it is derived from the
    event id, which keeps older constructions working.
    """

    event_id: str
    event_type: str
    actual_time_s: float
    sequence: int
    resource_id: str | None = None
    uav_id: str = ""

    def __post_init__(self) -> None:
        if not self.uav_id:
            object.__setattr__(self, "uav_id", str(self.event_id).split(":", 1)[0])


@dataclass(frozen=True)
class VerifiedPlanView:
    """Read-only view of a published, independently verified motion plan."""

    plan_version: str
    source_state_version: int
    checker_evidence: str
    route_id: str
    resource_windows: tuple[tuple[str, float, float], ...]
    # E-anchor is the active contract.  G/J remain optional only so archived
    # legacy fixtures can still be replayed without being treated as current
    # C-MLPM output.
    g_time_s: float | None = None
    j_time_s: float | None = None
    e_time_s: float | None = None
    e_to_j_s: float | None = None
    frozen: bool = False
    freeze_record_id: str | None = None
    frozen_plan_version: str | None = None
    frozen_at_s: float | None = None


@dataclass(frozen=True)
class ExistingVContinuation:
    uav_id: str
    node_id: str
    route_id: str
    source_layer: str
    direction: str
    phase: str
    state_version: int
    t_now: float
    plan_version: str
    freeze_record_id: str | None
    released: tuple[str, ...]
    active: tuple[tuple[str, float, float], ...]
    future: tuple[tuple[str, float, float], ...]
    frozen_reservations: tuple[dict[str, Any], ...]
    executed: tuple[ExecutedEvent, ...]
    provenance: Mapping[str, Any]

    @property
    def remaining_resources(self) -> tuple[str, ...]:
        return tuple(item[0] for item in (*self.active, *self.future))

    @property
    def is_inert(self) -> bool:
        """True when the UAV holds no occupancy that still needs protection."""

        return not self.frozen_reservations


def _chain(network: RegisteredG25, node_id: str, layer: str) -> tuple[str, ...]:
    matches = [
        row for row in network.interfaces
        if str(row["service_node_id"]) == node_id and str(row["source_layer"]) == layer
    ]
    if len(matches) != 1:
        raise ContinuationBlocked("INTERFACE_CARDINALITY", f"{node_id}:{layer}")
    return tuple(str(value) for value in matches[0]["route_template"]["resource_chain"])


def _phase_matches_events(
    phase: str,
    executed: Sequence[ExecutedEvent],
    *,
    e_anchor: bool = False,
) -> None:
    kinds = {item.event_type for item in executed}
    if e_anchor:
        # The active V5 executor emits only physical resource events and the
        # B_L1 service handoff.  E/J are trajectory boundaries, not scheduler
        # events, so phase consistency is determined by the measured state and
        # resource prefix rather than fabricated G/J records.
        if "B_L1" in kinds:
            raise ContinuationBlocked(
                "PHASE_EVENT_CONFLICT", f"{phase} with executed B_L1 record"
            )
        return
    has_g, has_j = "G" in kinds, "J" in kinds
    if phase == FlightState.SCHEDULED.value:
        if has_g or has_j:
            raise ContinuationBlocked(
                "PHASE_EVENT_CONFLICT", "SCHEDULED with executed G/J record"
            )
        return
    if phase == FlightState.TRANSITION.value:
        if not has_g or has_j:
            raise ContinuationBlocked(
                "PHASE_EVENT_CONFLICT", "TRANSITION requires executed G and future J"
            )
        return
    if phase == FlightState.VERTICAL.value:
        if not has_g or not has_j:
            raise ContinuationBlocked(
                "PHASE_EVENT_CONFLICT", "VERTICAL requires executed G and J"
            )
        return
    raise ContinuationBlocked("UNSUPPORTED_EXISTING_V_PHASE", phase)


def _validate_executed(
    executed: Sequence[ExecutedEvent],
    chain: Sequence[str],
    t_now: float,
) -> None:
    if not executed:
        return
    sequences = [item.sequence for item in executed]
    if sequences != sorted(sequences) or len(set(sequences)) != len(sequences):
        raise ContinuationBlocked("EXECUTED_EVENT_SEQUENCE_INVALID", "non-monotone sequence")
    for item in executed:
        if item.event_type not in _EXECUTED_TYPES:
            raise ContinuationBlocked("EXECUTED_EVENT_TYPE_INVALID", item.event_type)
        if not math.isfinite(item.actual_time_s) or item.actual_time_s > t_now + _TIME_TOLERANCE_S:
            raise ContinuationBlocked(
                "EXECUTED_EVENT_IN_FUTURE", f"{item.event_id}:{item.actual_time_s}>{t_now}"
            )
        if item.event_type in {"RESOURCE_ENTER", "RESOURCE_EXIT"}:
            if item.resource_id not in chain:
                raise ContinuationBlocked(
                    "EXECUTED_RESOURCE_NOT_ON_CHAIN", f"{item.event_id}:{item.resource_id}"
                )
    for resource_id in chain:
        enters = [item for item in executed if item.event_type == "RESOURCE_ENTER" and item.resource_id == resource_id]
        exits = [item for item in executed if item.event_type == "RESOURCE_EXIT" and item.resource_id == resource_id]
        if len(enters) > 1 or len(exits) > 1:
            raise ContinuationBlocked("DUPLICATE_RESOURCE_EVENT", resource_id)
        if exits and not enters:
            raise ContinuationBlocked("EXIT_WITHOUT_ENTER", resource_id)
        if enters and exits and exits[0].actual_time_s < enters[0].actual_time_s:
            raise ContinuationBlocked("EXIT_BEFORE_ENTER", resource_id)


def _validate_plan(
    state: UAVState,
    plan: VerifiedPlanView,
    chain: Sequence[str],
    state_version: int,
) -> None:
    if not plan.plan_version or not plan.checker_evidence:
        raise ContinuationBlocked("MISSING_VERIFIED_FROZEN_PLAN", state.uav_id)
    if plan.route_id != state.assigned_route:
        raise ContinuationBlocked(
            "PLAN_ROUTE_MISMATCH", f"{state.uav_id}:{plan.route_id}!={state.assigned_route}"
        )
    if int(plan.source_state_version) > int(state_version):
        raise ContinuationBlocked(
            "PLAN_SOURCE_STATE_IN_FUTURE",
            f"{state.uav_id}:{plan.source_state_version}>{state_version}",
        )
    if plan.frozen:
        if not plan.freeze_record_id or not plan.frozen_plan_version:
            raise ContinuationBlocked("MISSING_FREEZE_RECORD", state.uav_id)
        if plan.frozen_plan_version != plan.plan_version:
            raise ContinuationBlocked(
                "FREEZE_PLAN_VERSION_MISMATCH",
                f"{state.uav_id}:{plan.frozen_plan_version}!={plan.plan_version}",
            )
    if tuple(item[0] for item in plan.resource_windows) != tuple(chain):
        raise ContinuationBlocked(
            "PLAN_CHAIN_MISMATCH", f"{state.uav_id}:{plan.resource_windows}"
        )
    for resource_id, enter_s, exit_s in plan.resource_windows:
        if not math.isfinite(enter_s) or not math.isfinite(exit_s) or exit_s <= enter_s:
            raise ContinuationBlocked("PLAN_WINDOW_INVALID", f"{state.uav_id}:{resource_id}")
    if plan.e_time_s is not None:
        if not math.isfinite(plan.e_time_s):
            raise ContinuationBlocked("PLAN_EVENT_TIME_INVALID", state.uav_id)
        if plan.e_to_j_s is None or not math.isfinite(plan.e_to_j_s) or plan.e_to_j_s <= 0.0:
            raise ContinuationBlocked("PLAN_E_TO_J_TIME_INVALID", state.uav_id)
        if plan.resource_windows and plan.resource_windows[0][1] < plan.e_time_s - _TIME_TOLERANCE_S:
            raise ContinuationBlocked("PLAN_CHAIN_BEFORE_E", state.uav_id)
    else:
        if (plan.g_time_s is None or plan.j_time_s is None
                or not math.isfinite(plan.g_time_s)
                or not math.isfinite(plan.j_time_s)
                or plan.j_time_s <= plan.g_time_s):
            raise ContinuationBlocked("PLAN_EVENT_TIME_INVALID", state.uav_id)
        # The transfer arc may already occupy the first crossing before its
        # end J. Occupancy must follow G for archived G/J plans.
        if plan.resource_windows and plan.resource_windows[0][1] < plan.g_time_s - _TIME_TOLERANCE_S:
            raise ContinuationBlocked("PLAN_CHAIN_BEFORE_G", state.uav_id)


def _classify_resources(
    chain: Sequence[str],
    executed: Sequence[ExecutedEvent],
    windows: Mapping[str, tuple[float, float]],
    t_now: float,
) -> tuple[
    tuple[str, ...],
    tuple[tuple[str, float, float], ...],
    tuple[tuple[str, float, float], ...],
    tuple[str, ...],
]:
    released: list[str] = []
    active: list[tuple[str, float, float]] = []
    future: list[tuple[str, float, float]] = []
    stale: list[str] = []
    for resource_id in chain:
        enter = next(
            (item for item in executed
             if item.event_type == "RESOURCE_ENTER" and item.resource_id == resource_id),
            None,
        )
        exit_ = next(
            (item for item in executed
             if item.event_type == "RESOURCE_EXIT" and item.resource_id == resource_id),
            None,
        )
        planned_enter, planned_exit = windows[resource_id]
        if exit_ is not None:
            if exit_.actual_time_s > t_now + _TIME_TOLERANCE_S:
                raise ContinuationBlocked("RELEASED_IN_FUTURE", resource_id)
            released.append(resource_id)
        elif enter is not None:
            if enter.actual_time_s > t_now + _TIME_TOLERANCE_S:
                raise ContinuationBlocked("ACTIVE_ENTER_IN_FUTURE", resource_id)
            if planned_exit <= t_now + _TIME_TOLERANCE_S:
                raise ContinuationBlocked(
                    "ACTIVE_WITHOUT_FUTURE_EXIT", f"{resource_id}:{planned_exit}"
                )
            active.append((resource_id, enter.actual_time_s, planned_exit))
        else:
            if planned_enter <= t_now + _TIME_TOLERANCE_S:
                # Published entry has passed with no observed ENTER: the
                # aircraft failed to realise its release and is holding short
                # of G. Fabricating a past occupancy would be wrong, and
                # aborting the round would turn one failed release into a
                # dead run. Report it as stale, keep the plan frozen, and let
                # C-MLPM decide next round.
                stale.append(resource_id)
            else:
                future.append((resource_id, planned_enter, planned_exit))
    if len(active) > 1:
        raise ContinuationBlocked("MULTIPLE_ACTIVE_RESOURCES", ",".join(item[0] for item in active))
    ordered = [
        *released,
        *(item[0] for item in active),
        *(item[0] for item in future),
        *stale,
    ]
    if ordered != list(chain):
        raise ContinuationBlocked("RESOURCE_CLASSIFICATION_ORDER", ",".join(ordered))
    return tuple(released), tuple(active), tuple(future), tuple(stale)


def _reservation(
    *,
    uav_id: str,
    resource_id: str,
    occupancy_start: float,
    occupancy_end: float,
    q_time: float,
    plan_version: str,
    version: str,
    source_layer: str,
) -> dict[str, Any]:
    return {
        "reservation_id": f"existing-v:{uav_id}:{resource_id}",
        "uav_id": uav_id,
        "resource_id": resource_id,
        "role": "V",
        "occupancy_start": float(occupancy_start),
        "occupancy_end": float(occupancy_end),
        "version": version,
        "q_reference_time": float(q_time),
        "q_reference_section": "existing-v:J",
        "q_reference_version": plan_version,
        "q_start_offset": float(occupancy_start) - float(q_time),
        "q_end_offset": float(occupancy_end) - float(q_time),
        "source_layer": source_layer,
    }


def current_v_resource_windows(
    state: UAVState, *, t_now: float,
    resource_windows: Sequence[tuple[str, float, float]],
    e_time_s: float | None = None, e_to_j_s: float | None = None,
    g_time_s: float | None = None, j_time_s: float | None = None,
    executed: Sequence[ExecutedEvent],
) -> tuple[dict[str, tuple[float, float]], float]:
    """Shared current-state forecast for scheduling and execution protection.

    Active E-anchor publications provide ``e_time_s`` and ``e_to_j_s``.  The
    older G/J keyword pair remains accepted only for historical continuation
    fixtures; it is not read from an active E-anchor plan.
    """
    windows = {str(r): (float(a), float(b)) for r, a, b in resource_windows}
    runtime = state.current_motion_plan
    payload = runtime.get("v5_frozen_trajectory") or {}
    if e_time_s is not None and "mainline_pieces" in payload:
        forecast = windows
        forecast_q = float(payload["boundary_times"]["J"])
    elif runtime.get("motion_control_owner") != "MEASURED_KINEMATIC_EXECUTOR_V1":
        if e_time_s is not None:
            return windows, float(e_time_s) + float(e_to_j_s or 0.0)
        return windows, float(j_time_s if j_time_s is not None else t_now)
    elif realized := runtime.get("realized_resource_windows"):
        forecast = {str(r): tuple(v) for r, v in realized.items()}
        forecast_q = float(runtime.get("j_realized_time_s",
            runtime.get("e_realized_time_s", t_now)))
    else:
        if e_time_s is not None:
            entry_station = runtime.get("e_station_m", runtime.get("resource_entry_station_m"))
            if entry_station is None:
                raise ValueError("E_ANCHOR_ENTRY_STATION_MISSING")
            original_entry = float(e_time_s)
            remaining = max(0., float(entry_station) - state.s_m)
            forecast_entry = max(original_entry, float(t_now) + remaining / max(
                float(state.nominal_speed_mps or state.speed_mps), 1e-6))
            shift = forecast_entry - original_entry
            forecast = {r: (a + shift, b + shift) for r, (a, b) in windows.items()}
            forecast_q = float(e_time_s) + float(e_to_j_s or 0.0) + shift
        else:
            if g_time_s is None or j_time_s is None:
                raise ValueError("GJ_ANCHOR_TIMING_MISSING")
            remaining = max(0., float(runtime["g_station_m"]) - state.s_m)
            original_g = float(g_time_s)
            forecast_g = max(original_g, float(t_now) + remaining / max(
            float(state.nominal_speed_mps or state.speed_mps), 1e-6))
            shift = forecast_g - original_g
            forecast = {r: (a + shift, b + shift) for r, (a, b) in windows.items()}
            forecast_q = float(j_time_s) + shift
    enters = {e.resource_id: e.actual_time_s for e in executed if e.event_type == "RESOURCE_ENTER"}
    exits = {e.resource_id: e.actual_time_s for e in executed if e.event_type == "RESOURCE_EXIT"}
    return {r: (enters.get(r, forecast[r][0]), exits.get(r, forecast[r][1]))
            for r in windows}, forecast_q


def build_existing_v_continuation(
    network: RegisteredG25,
    state: UAVState,
    *,
    plan: VerifiedPlanView,
    executed: Sequence[ExecutedEvent],
    t_now: float,
    state_version: int,
    vv_entry_headway_s: float,
    vh_margin_s: float,
) -> ExistingVContinuation:
    """Derive the remaining events and protected occupancy of one existing V."""

    phase = str(getattr(state.state, "value", state.state))
    if phase not in {"SCHEDULED", "TRANSITION", "VERTICAL"}:
        raise ContinuationBlocked("UNSUPPORTED_EXISTING_V_PHASE", phase)
    if state.assigned_node is None or state.assigned_route is None:
        raise ContinuationBlocked("EXISTING_V_NOT_ASSIGNED", state.uav_id)
    chain = _chain(network, state.assigned_node, state.layer)
    _validate_plan(state, plan, chain, state_version)
    _validate_executed(executed, chain, t_now)
    _phase_matches_events(phase, executed, e_anchor=plan.e_time_s is not None)

    windows, forecast_q = current_v_resource_windows(
        state, t_now=t_now, resource_windows=plan.resource_windows,
        e_time_s=getattr(plan, "e_time_s", None),
        e_to_j_s=state.current_motion_plan.get("e_to_j_s", 0.0),
        g_time_s=getattr(plan, "g_time_s", None),
        j_time_s=getattr(plan, "j_time_s", None),
        executed=executed)
    measured = state.current_motion_plan.get("motion_control_owner") == "MEASURED_KINEMATIC_EXECUTOR_V1"
    # The published plan remains immutable. Protection of upcoming physical
    # occupancy is rebuilt from the measured path/current state, as a forecast
    # at this traffic-state version, never a rewritten historical target.
    released, active, future, stale = _classify_resources(chain, executed, windows, t_now)

    j_event = next((item for item in executed if item.event_type == "J"), None)
    q_time = j_event.actual_time_s if j_event is not None else forecast_q
    if active or future:
        if q_time > t_now + _TIME_TOLERANCE_S and phase == FlightState.VERTICAL.value:
            raise ContinuationBlocked("VERTICAL_J_IN_FUTURE", state.uav_id)

    reservations: list[dict[str, Any]] = []
    for resource_id, enter_s, exit_s in active:
        reservations.append(_reservation(
            uav_id=state.uav_id, resource_id=resource_id,
            occupancy_start=enter_s, occupancy_end=exit_s,
            q_time=q_time, plan_version=plan.plan_version,
            version=plan.frozen_plan_version or plan.plan_version,
            source_layer=state.layer,
        ))
    for resource_id, enter_s, exit_s in future:
        reservations.append(_reservation(
            uav_id=state.uav_id, resource_id=resource_id,
            occupancy_start=enter_s, occupancy_end=exit_s,
            q_time=q_time, plan_version=plan.plan_version,
            version=plan.frozen_plan_version or plan.plan_version,
            source_layer=state.layer,
        ))

    # Trailing history: a released resource keeps protecting new vehicles
    # while its exit is still inside the declared entry headway.
    protection_window = max(float(vv_entry_headway_s), float(vh_margin_s))
    for resource_id in released:
        exit_event = next(
            item for item in executed
            if item.event_type == "RESOURCE_EXIT" and item.resource_id == resource_id
        )
        if exit_event.actual_time_s + protection_window <= t_now + _TIME_TOLERANCE_S:
            continue
        enter_event = next(
            item for item in executed
            if item.event_type == "RESOURCE_ENTER" and item.resource_id == resource_id
        )
        reservations.append(_reservation(
            uav_id=state.uav_id, resource_id=resource_id,
            occupancy_start=enter_event.actual_time_s,
            occupancy_end=exit_event.actual_time_s,
            q_time=q_time, plan_version=plan.plan_version,
            version=plan.frozen_plan_version or plan.plan_version,
            source_layer=state.layer,
        ))

    if phase == FlightState.VERTICAL.value and active:
        maps = build_crossing_resource_maps(network)
        crossing = crossing_map_for_node_layer(
            maps, state.assigned_node, state.direction, state.layer
        )
        active_resource = active[0][0]
        if active_resource == crossing.segment_resource_id:
            z = float(state.z_m)
            if not (
                crossing.segment_z_low_m - _Z_CONTINUITY_TOLERANCE_M
                <= z
                <= crossing.segment_z_high_m + _Z_CONTINUITY_TOLERANCE_M
            ):
                raise ContinuationBlocked(
                    "ACTIVE_RESOURCE_Z_INCONSISTENT",
                    f"{state.uav_id}:z={z}:resource={active_resource}",
                )

    provenance = {
        "continuation_version": CONTINUATION_VERSION,
        "plan_version": plan.plan_version,
        "source_state_version": int(plan.source_state_version),
        "state_version": int(state_version),
        "checker_evidence": plan.checker_evidence,
        "freeze_record_id": plan.freeze_record_id,
        "frozen_plan_version": plan.frozen_plan_version,
        "frozen_at_s": plan.frozen_at_s,
        "executed_event_count": len(executed),
        "released_resources": list(released),
        "active_resources": [item[0] for item in active],
        "future_resources": [item[0] for item in future],
        "network_geometry_hash": network.geometry_hash,
        "network_sha256": network.source_sha256,
        "actual_entry_preserved": True,
        "q_reference_time": float(q_time),
        "occupancy_basis": "CURRENT_STATE_FORECAST_WITH_OBSERVED_EDGES" if measured else "PUBLISHED_PLAN",
        "published_resource_windows": plan.resource_windows,
    }
    return ExistingVContinuation(
        uav_id=state.uav_id,
        node_id=state.assigned_node,
        route_id=str(state.assigned_route),
        source_layer=state.layer,
        direction=state.direction,
        phase=phase,
        state_version=int(state_version),
        t_now=float(t_now),
        plan_version=plan.plan_version,
        freeze_record_id=plan.freeze_record_id,
        released=released,
        active=active,
        future=future,
        frozen_reservations=tuple(reservations),
        executed=tuple(executed),
        provenance=MappingProxyType(provenance),
    )


def frozen_vv_constraints(
    continuations: Iterable[ExistingVContinuation],
    *,
    new_v_layers: Mapping[str, str],
    new_v_resources: Mapping[str, Sequence[str]],
    entry_headway_s: float,
    separation_version: str,
) -> tuple[dict[str, Any], ...]:
    """Pair every protected existing-V occupancy with every sharing new V.

    The frozen order is fixed to ``frozen`` only when the new V starts from the
    same or a higher layer: it is then physically behind the descending
    existing V.  A new V from a lower layer may legitimately enter a shared
    lower resource first, so its order stays free and the interval constraints
    decide.
    """

    rows: list[dict[str, Any]] = []
    for continuation in continuations:
        for reservation in continuation.frozen_reservations:
            resource_id = str(reservation["resource_id"])
            for new_uav, resources in new_v_resources.items():
                if resource_id not in resources:
                    continue
                new_layer = new_v_layers[new_uav]
                fixed_order = (
                    "frozen"
                    if _LAYER_INDEX[new_layer] >= _LAYER_INDEX[continuation.source_layer]
                    else None
                )
                rows.append({
                    "constraint_id": f"existing-v-vv:{continuation.uav_id}:{new_uav}:{resource_id}",
                    "frozen_reservation_id": str(reservation["reservation_id"]),
                    "new_uav_id": new_uav,
                    "resource_id": resource_id,
                    "frozen_to_new_gap": float(entry_headway_s),
                    "new_to_frozen_gap": float(entry_headway_s),
                    "separation_version": separation_version,
                    "fixed_order": fixed_order,
                })
    return tuple(rows)


def frozen_vh_resources(
    continuations: Iterable[ExistingVContinuation],
    *,
    mainline_resources: Iterable[str],
) -> tuple[str, ...]:
    """Resources where a protected existing-V occupancy meets new H traffic."""

    mainline = set(str(value) for value in mainline_resources)
    shared: set[str] = set()
    for continuation in continuations:
        for reservation in continuation.frozen_reservations:
            resource_id = str(reservation["resource_id"])
            if resource_id in mainline:
                shared.add(resource_id)
    return tuple(sorted(shared))


def classify_existing_v(
    network: RegisteredG25,
    state: UAVState,
    *,
    t_now: float,
) -> tuple[str, float]:
    """Return ``("continuation"|"active", distance_to_fork)`` for one V.

    Every published ``SCHEDULED`` plan is immutable immediately.  Therefore
    ``SCHEDULED``, ``TRANSITION`` and ``VERTICAL`` states are all inherited
    from the verified-plan ledger; no distance crossing controls freezing.
    """

    phase = str(getattr(state.state, "value", state.state))
    if phase in {"TRANSITION", "VERTICAL"}:
        return "continuation", 0.0
    if phase != "SCHEDULED":
        raise ContinuationBlocked("UNSUPPORTED_EXISTING_V_PHASE", phase)
    interface = next(
        (row for row in network.interfaces
         if str(row["service_node_id"]) == state.assigned_node
         and str(row["source_layer"]) == state.layer),
        None,
    )
    if interface is None:
        raise ContinuationBlocked("INTERFACE_CARDINALITY", f"{state.assigned_node}:{state.layer}")
    from .network_loader import formal_g_station
    fork = formal_g_station(network, interface)
    distance = max(0.0, fork - float(state.s_m))
    return "continuation", distance
