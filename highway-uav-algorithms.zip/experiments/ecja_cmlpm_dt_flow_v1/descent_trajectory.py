"""Execute the same piecewise path/time representation used by SRCM.

G starts SOURCE_EXIT; J ends it. Resource crossings are geometric measurements,
including those on SOURCE_EXIT before J. No scheduled window creates an event.
"""
from __future__ import annotations

import copy
import math
from dataclasses import dataclass
from functools import lru_cache
import json
from typing import Any, Mapping

from srcm.interval_clip import clip_segment
from srcm.plan_motion import iter_plan_motion_segments, motion_sha256

VERSION = "DESCENT_PATH_TIME_EXECUTION_V1"
TOL = 1e-7
# The independent C-MLPM checker accepts solver equality residuals up to this
# value.  The motion certificate is intentionally stricter, so the adapter
# below canonicalizes only residuals that are already within the checker
# contract.  Larger discrepancies remain a hard failure.
MAX_SOLVER_TIME_RECONCILIATION_S = 2e-6


@dataclass(frozen=True)
class DescentTimingNormalization:
    """Canonical event/resource times passed from C-MLPM to motion execution."""

    event_times: Mapping[str, float]
    resource_occupancies: tuple[Mapping[str, Any], ...]
    residual_s: float


def canonicalize_descent_timing(
    plan: Mapping[str, Any],
    *,
    uav_id: str,
    g_event_id: str,
    j_event_id: str,
    event_times: Mapping[str, float],
    resource_occupancies: tuple[Mapping[str, Any], ...],
) -> DescentTimingNormalization:
    """Reconcile a solver's V timing with the registered physical trajectory.

    The MILP and the published plan use the same predicted transfer curve, but
    a floating-point MILP equality can return ``J-G`` with a small residual.
    This is the single interface seam where that numerical representation is
    converted into the trajectory's authoritative value.  Only residuals
    within the independent checker's tolerance are repaired; a larger mismatch
    is still rejected instead of being hidden by normalization.
    """

    trajectory = plan.get("descent_trajectory")
    if not trajectory or trajectory.get("version") != VERSION:
        raise ValueError("DESCENT_TRAJECTORY_MISSING")
    if g_event_id not in event_times or j_event_id not in event_times:
        raise ValueError(f"DESCENT_EVENT_TIME_MISSING:{uav_id}")
    g_time = float(event_times[g_event_id])
    solver_j_time = float(event_times[j_event_id])
    trajectory_j_offset = float(trajectory["j_offset_s"])
    canonical_j_time = g_time + trajectory_j_offset
    residual_s = solver_j_time - canonical_j_time
    if not all(math.isfinite(value) for value in (
        g_time, solver_j_time, trajectory_j_offset, residual_s,
    )):
        raise ValueError(f"DESCENT_TIMING_INVALID:{uav_id}")
    if abs(residual_s) > MAX_SOLVER_TIME_RECONCILIATION_S:
        raise ValueError(
            f"DESCENT_J_TIME_RESIDUAL_TOO_LARGE:{uav_id}:{residual_s}"
        )

    physical_windows = trajectory_resource_windows(trajectory)
    normalized_events = dict(event_times)
    normalized_events[j_event_id] = canonical_j_time
    normalized_occupancies: list[Mapping[str, Any]] = []
    for raw in resource_occupancies:
        row = dict(raw)
        if str(row.get("uav_id")) == str(uav_id) and str(row.get("role")) == "V":
            resource_id = str(row["resource_id"])
            if resource_id in physical_windows:
                start_offset, end_offset = physical_windows[resource_id]
                row["start"] = g_time + start_offset
                row["end"] = g_time + end_offset
        normalized_occupancies.append(row)
    return DescentTimingNormalization(
        event_times=normalized_events,
        resource_occupancies=tuple(normalized_occupancies),
        residual_s=residual_s,
    )


def build_descent_trajectory(plan: Mapping[str, Any], geometries: Mapping[str, Any]) -> dict:
    segments = [dict(s) for s in iter_plan_motion_segments(plan)
                if s["phase_type"] in {"SOURCE_EXIT", "V_DESCENT"}]
    transfer = [s for s in segments if s["phase_type"] == "SOURCE_EXIT"]
    vertical = [s for s in segments if s["phase_type"] == "V_DESCENT"]
    if not transfer or not vertical:
        raise ValueError("DESCENT_PHASES_MISSING")
    g = transfer[0]["start_s"]
    for segment in segments:
        segment["start_s"] -= g
        segment["end_s"] -= g
    return {
        "version": VERSION,
        "source_motion_sha256": motion_sha256(plan),
        "segments": segments,
        "j_offset_s": transfer[-1]["end_s"],
        "geometries": copy.deepcopy(dict(geometries)),
    }


def realize_descent_at_g(plan: Mapping[str, Any], **kwargs) -> dict:
    """Pure geometry/initial-speed result; each caller owns its returned copy."""
    key=json.dumps({'plan':{'zhou_transfer_access':plan['zhou_transfer_access'],
        'descent_trajectory':{'geometries':plan['descent_trajectory']['geometries']}},'kwargs':kwargs},allow_nan=False)
    return copy.deepcopy(_realized_curve_cache(key))


@lru_cache(maxsize=128)
def _realized_curve_cache(key):
    inputs=json.loads(key)
    return _realize_descent_at_g(inputs['plan'],**inputs['kwargs'])


def _realize_descent_at_g(plan: Mapping[str, Any], *, entry_speed_mps: float,
                         vertical_speed_mps: float, completion_z_m: float,
                         max_speed_mps: float, max_acceleration_mps2: float,
                         vehicle_type: str) -> dict:
    """Generate the flown G-to-J curve from measured G speed, then locate events."""
    from ecja_qsap.zhou_transfer import generate_transfer
    from configs.mission_config import DEFAULT_UAV_TYPE_SPECS
    spec = DEFAULT_UAV_TYPE_SPECS[vehicle_type]
    access = plan["zhou_transfer_access"]
    result = generate_transfer(access, entry_speed_mps=entry_speed_mps,
                               max_speed_mps=max_speed_mps,
                               max_acceleration_mps2=max_acceleration_mps2,
                               vertical_speed_mps=vertical_speed_mps,
                               max_descent_speed_mps=float(spec["max_descent_speed"]),
                               max_vertical_acceleration_mps2=float(spec["max_vertical_acceleration_mps2"]))
    points = result.get("execution_path_xyz",result["path_xyz"])
    times = result.get("execution_elapsed_s",result["elapsed_s"])
    velocities = result.get("execution_velocity_xyz",result["velocity_xyz"])
    segments = []
    for index in range(len(points)-1):
        segments.append({"phase_type":"SOURCE_EXIT", "phase_id":"ZHOU_TRANSFER",
                         "point0_xyz":points[index], "point1_xyz":points[index+1],
                         "start_s":times[index], "end_s":times[index+1],
                         "velocity0_xyz":velocities[index],"velocity1_xyz":velocities[index+1]})
    j = points[-1]
    bottom = [j[0], j[1], float(completion_z_m)]
    duration = math.dist(j, bottom)/vertical_speed_mps
    segments.append({"phase_type":"V_DESCENT", "phase_id":"VERTICAL_DESCENT_3MPS",
                     "point0_xyz":j, "point1_xyz":bottom,
                     "start_s":times[-1], "end_s":times[-1]+duration})
    trajectory = {"version":VERSION, "source_motion_sha256":None,
                  "segments":segments,"j_offset_s":times[-1],
                  "geometries":copy.deepcopy(plan["descent_trajectory"]["geometries"]),
                  "entry_speed_mps":entry_speed_mps,"generator_method":result["method"],
                  "generation_source":result["generation_source"],
                  "transfer_elapsed_s":times,"transfer_velocity_xyz":velocities,
                  }
    # A sampled-path transfer carries no control polygon; trajectory_state then
    # falls back to the piecewise segments plus the velocity table.
    if "spline_control_xyz" in result and "spline_knots" in result:
        trajectory["transfer_spline"] = {"knots": result["spline_knots"],
                                         "controls": result["spline_control_xyz"],
                                         "duration_s": result["duration_s"]}
    trajectory["kinematic_audit"] = _audit_hermite_motion(segments)
    trajectory["kinematic_audit"]["allowed"] = {
        "max_speed_mps":max_speed_mps,"max_acceleration_mps2":max_acceleration_mps2,
        "max_descent_speed_mps":float(spec["max_descent_speed"]),
        "max_vertical_acceleration_mps2":float(spec["max_vertical_acceleration_mps2"])}
    trajectory["resource_windows_offsets"] = trajectory_resource_windows(trajectory)
    return trajectory


def trajectory_state(trajectory: Mapping[str, Any], elapsed_s: float):
    segments = trajectory["segments"]
    elapsed = min(max(float(elapsed_s), 0.), float(segments[-1]["end_s"]))
    spline_data = trajectory.get("transfer_spline")
    if spline_data and elapsed <= float(trajectory["j_offset_s"]):
        from scipy.interpolate import BSpline
        curve = BSpline(spline_data["knots"],spline_data["controls"],3,extrapolate=False)
        duration = float(spline_data["duration_s"])
        parameter = min(1.,max(0.,elapsed/duration))
        point = curve(parameter)
        velocity = curve.derivative()(parameter)/duration
        return tuple(float(v) for v in point), float(math.sqrt(sum(v*v for v in velocity)))
    segment = next((s for s in segments if elapsed < s["end_s"] - 1e-12), segments[-1])
    duration = float(segment["end_s"]) - float(segment["start_s"])
    ratio = min(1., max(0., (elapsed - float(segment["start_s"])) / duration))
    first, second = segment["point0_xyz"], segment["point1_xyz"]
    if "velocity0_xyz" in segment:
        c = _hermite_coefficients(segment)
        point = tuple(c[0][axis]+ratio*(c[1][axis]+ratio*(c[2][axis]+ratio*c[3][axis])) for axis in range(3))
        velocity = tuple((c[1][axis]+ratio*(2*c[2][axis]+3*ratio*c[3][axis]))/duration for axis in range(3))
        return point, math.sqrt(sum(v*v for v in velocity))
    point = tuple(float(a) + ratio * (float(b) - float(a)) for a, b in zip(first, second))
    return point, math.dist(first, second) / duration


def _hermite_coefficients(segment):
    """Normalized-time cubic; its derivative is the reported velocity."""
    dt=float(segment["end_s"])-float(segment["start_s"])
    p,q=segment["point0_xyz"],segment["point1_xyz"]
    v,w=segment["velocity0_xyz"],segment["velocity1_xyz"]
    return (tuple(p),tuple(dt*x for x in v),
            tuple(3*(q[i]-p[i])-dt*(2*v[i]+w[i]) for i in range(3)),
            tuple(2*(p[i]-q[i])+dt*(v[i]+w[i]) for i in range(3)))


def _audit_hermite_motion(segments):
    """Exact speed extrema and endpoint acceleration extrema of each cubic."""
    import numpy as np
    from numpy.polynomial import polynomial as poly
    maxima={"max_speed_mps":0.,"max_acceleration_mps2":0.,
            "max_descent_speed_mps":0.,"max_vertical_acceleration_mps2":0.}
    for segment in segments:
        dt=float(segment["end_s"])-float(segment["start_s"])
        if "velocity0_xyz" not in segment:
            v=np.asarray(segment["point1_xyz"])-np.asarray(segment["point0_xyz"])
            v=v/dt
            maxima["max_speed_mps"]=max(maxima["max_speed_mps"],float(np.linalg.norm(v)))
            maxima["max_descent_speed_mps"]=max(maxima["max_descent_speed_mps"],float(-v[2]))
            continue
        c=np.asarray(_hermite_coefficients(segment),dtype=float)
        v=np.asarray([c[1],2*c[2],3*c[3]])/dt
        a=np.asarray([2*c[2],6*c[3]])/dt**2
        equation=np.zeros(4)
        for axis in range(3):
            term=poly.polymul(v[:,axis],a[:,axis])
            equation[:len(term)]+=term
        probes=[0.,1.]
        for root in poly.polyroots(poly.polytrim(equation,tol=1e-12)):
            if abs(root.imag)<1e-7 and 0.<root.real<1.: probes.append(float(root.real))
        if abs(v[2,2])>1e-12:
            vertex=-v[1,2]/(2*v[2,2])
            if 0.<vertex<1.: probes.append(float(vertex))
        for u in probes:
            velocity=poly.polyval(u,v)
            maxima["max_speed_mps"]=max(maxima["max_speed_mps"],float(np.linalg.norm(velocity)))
            maxima["max_descent_speed_mps"]=max(maxima["max_descent_speed_mps"],float(-velocity[2]))
        for u in (0.,1.):
            acceleration=poly.polyval(u,a)
            maxima["max_acceleration_mps2"]=max(maxima["max_acceleration_mps2"],float(np.linalg.norm(acceleration)))
            maxima["max_vertical_acceleration_mps2"]=max(maxima["max_vertical_acceleration_mps2"],float(abs(acceleration[2])))
    return maxima


def _clip_hermite_segment(segment,geometry):
    """Find resource boundary roots on the same cubic used by execution."""
    import numpy as np
    from numpy.polynomial import polynomial as poly
    c=np.asarray(_hermite_coefficients(segment),dtype=float)
    equations=[]
    if geometry["type"]=="FINITE_CYLINDER":
        x,y=c[:,0].copy(),c[:,1].copy()
        x[0]-=float(geometry["axis_xy"][0]); y[0]-=float(geometry["axis_xy"][1])
        radial=poly.polyadd(poly.polymul(x,x),poly.polymul(y,y))
        radial[0]-=float(geometry["radius_m"])**2
        equations.append(radial)
        for height in (geometry["z_min_m"],geometry["z_max_m"]):
            z=c[:,2].copy(); z[0]-=height; equations.append(z)
    elif geometry["type"]=="CONVEX_HALFSPACES":
        for plane in geometry["halfspaces"]:
            equation=c @ np.asarray(plane["normal"],dtype=float)
            equation[0]-=float(plane["offset"]); equations.append(equation)
    else:
        raise ValueError("UNSUPPORTED_CROSSING_GEOMETRY:"+str(geometry["type"]))
    cuts=[0.,1.]
    for equation in equations:
        for root in poly.polyroots(poly.polytrim(equation,tol=1e-12)):
            if abs(root.imag)<1e-7 and 0.<root.real<1.: cuts.append(float(root.real))
    cuts=sorted(set(cuts)); intervals=[]
    for lo,hi in zip(cuts,cuts[1:]):
        u=.5*(lo+hi)
        point=poly.polyval(u,c)
        if clip_segment(point,point,geometry) is not None:
            intervals.append((lo,hi))
    return intervals


def trajectory_resource_windows(trajectory: Mapping[str, Any]) -> dict[str, tuple[float, float]]:
    """Clip the physical path; return measured offsets from G, never plan times."""
    if "resource_windows_offsets" in trajectory:
        return dict(trajectory["resource_windows_offsets"])
    windows = {}
    for resource, geometry in trajectory["geometries"].items():
        intervals = []
        for segment in trajectory["segments"]:
            clipped = (_clip_hermite_segment(segment,geometry) if "velocity0_xyz" in segment else
                       [clip_segment(segment["point0_xyz"], segment["point1_xyz"], geometry)])
            for interval in clipped:
                if interval is None: continue
                start, end = float(segment["start_s"]), float(segment["end_s"])
                enter, exit_ = (start + r * (end - start) for r in interval)
                if intervals and enter <= intervals[-1][1] + TOL:
                    intervals[-1] = (intervals[-1][0], max(exit_, intervals[-1][1]))
                else:
                    intervals.append((enter, exit_))
        if len(intervals) != 1:
            raise ValueError(f"DESCENT_RESOURCE_VISIT_CARDINALITY:{resource}:{len(intervals)}")
        windows[str(resource)] = intervals[0]
    return windows


def certify_descent_trajectory(plan: Mapping[str, Any], *, vertical_speed_mps: float,
                               completion_z_m: float) -> dict[str, tuple[float, float]]:
    """Check the execution trajectory against every published V edge before commit."""
    trajectory = plan.get("descent_trajectory")
    if not trajectory or trajectory.get("version") != VERSION:
        raise ValueError("DESCENT_TRAJECTORY_MISSING")
    segments = trajectory["segments"]
    phase_order = tuple(dict.fromkeys(s["phase_type"] for s in segments))
    if not segments or phase_order != ("SOURCE_EXIT", "V_DESCENT"):
        raise ValueError("DESCENT_PHASE_ORDER_INVALID")
    if not all(math.isfinite(float(x)) for x in (
        plan["g_time_s"], plan["j_time_s"], trajectory["j_offset_s"],
        vertical_speed_mps, completion_z_m,
    )) or vertical_speed_mps <= 0:
        raise ValueError("DESCENT_TIMING_INVALID")
    previous = None
    for segment in segments:
        first, second = segment["point0_xyz"], segment["point1_xyz"]
        if len(first) != 3 or len(second) != 3:
            raise ValueError("DESCENT_TRAJECTORY_INVALID")
        start, end = float(segment["start_s"]), float(segment["end_s"])
        if not all(math.isfinite(float(x)) for x in (*first, *second, start, end)) or end <= start:
            raise ValueError("DESCENT_TRAJECTORY_INVALID")
        if previous and (abs(start-previous["end_s"]) > TOL or
                         math.dist(first, previous["point1_xyz"]) > TOL):
            raise ValueError("DESCENT_TRAJECTORY_DISCONNECTED")
        if segment["phase_type"] == "V_DESCENT":
            if (math.dist(first[:2], second[:2]) > TOL or second[2] >= first[2] or
                    abs((first[2]-second[2])/(end-start)-vertical_speed_mps) > TOL):
                raise ValueError("DESCENT_VERTICAL_SPEED_MISMATCH")
        previous = segment
    transfers = [s for s in segments if s["phase_type"] == "SOURCE_EXIT"]
    if (not transfers or abs(segments[0]["start_s"]) > TOL or
            abs(transfers[-1]["end_s"]-trajectory["j_offset_s"]) > TOL or
            abs(segments[-1]["point1_xyz"][2]-completion_z_m) > TOL):
        raise ValueError("DESCENT_PHASE_BOUNDARY_MISMATCH")
    g, j = float(plan["g_time_s"]), float(plan["j_time_s"])
    if abs(j-g-float(trajectory["j_offset_s"])) > TOL:
        raise ValueError("DESCENT_J_TIME_MISMATCH")
    physical = {r: (g+a, g+b) for r, (a, b) in trajectory_resource_windows(trajectory).items()}
    planned = {str(r): (float(a), float(b)) for r, a, b in plan["resource_windows"]}
    if len(planned) != len(plan["resource_windows"]) or physical.keys() != planned.keys():
        raise ValueError("DESCENT_RESOURCE_SET_MISMATCH")
    for resource, edges in physical.items():
        if not all(math.isfinite(x) for x in planned[resource]):
            raise ValueError("DESCENT_TIMING_INVALID")
        if max(abs(a-b) for a, b in zip(edges, planned[resource])) > TOL:
            raise ValueError(f"V_RESOURCE_TIME_NOT_REALIZED:{resource}:{edges}!={planned[resource]}")
    return physical
