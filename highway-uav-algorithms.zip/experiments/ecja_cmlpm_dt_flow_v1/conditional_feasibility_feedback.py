"""CPFF pure candidate feedback and final strict-gate reference construction.

No function in this module publishes a schedule or releases actual occupancy.
"""
from dataclasses import asdict,replace,dataclass
import hashlib
import json
import math
from experiments.kinematic_layer_v1.kinematic_advance import (
    Aircraft,Limits,Slot,Piece,Profile,terminal_slot_profile,build_profile,stop_satisfied)
from traffic_simulation.cmlpm.joint_single_node.physical_entry_contract import PhysicalEntryCondition,VERSION
from .joint_motion_evidence import measured,performance_metrics


@dataclass(frozen=True)
class CPFFPolicy:
    """One channel policy for candidate feedback and measured execution.

    The master switch dominates both channels. Missing switches preserve the
    historical all-on default; strings and numbers are rejected, not coerced.
    Hard resource/following safety is independent of these ablation switches.
    """
    vv: bool = True
    vh: bool = True

    @classmethod
    def from_config(cls, config):
        motion = config.get("motion", {})
        values = [motion.get(key, True) for key in
                  ("cpff_enabled", "cpff_vv_enabled", "cpff_vh_enabled")]
        if any(type(value) is not bool for value in values):
            raise ValueError("CPFF_SWITCH_MUST_BE_BOOLEAN")
        enabled, vv, vh = values
        return cls(enabled and vv, enabled and vh)

    @property
    def enabled(self):
        return self.vv or self.vh

    def as_dict(self):
        return {"VV": self.vv, "VH": self.vh}


def digest(value):
    return hashlib.sha256(json.dumps(value,sort_keys=True,default=str,allow_nan=False).encode()).hexdigest()


def v_content(v):
    p=v.current_motion_plan
    windows=p.get('realized_resource_windows')
    if windows is None:windows={str(r):(a,z) for r,a,z in p.get('resource_windows',())}
    return dict(g=p.get('g_time_s'),j=p.get('j_time_s'),speed=p.get('terminal_speed_mps'),
        windows=windows,trajectory=p.get('realized_descent_trajectory',p.get('descent_trajectory')),
        approach=p.get('local_trajectory_reference'),initial_state=(v.s_m,v.speed_mps))


def verify_release_scope(scope,snapshot):
    if scope['snapshot_version']!=snapshot.version:raise ValueError('CPFF_STALE_INPUT')
    states={**snapshot.resource_dependencies,**snapshot.states}
    for row in scope['releases']:
        v=states.get(row['v_uid'])
        if v is None or digest(v_content(v))!=row['v_content_digest']:
            raise ValueError('CPFF_V_DEPENDENCY_CHANGED')


def build_feedback_payload(payload,snapshot,*,limits,resource_lengths,model_signature,dt_s):
    """Emit only domain-proven necessary conditions; no witness-as-cut."""
    from traffic_simulation.cmlpm.active import build_complete_snapshot
    from traffic_simulation.cmlpm.joint_single_node.conflict_builder import (
        is_cross_layer_vh_frozen,
        is_cross_layer_vh_use,
    )
    formal=build_complete_snapshot(payload)
    domain={a.uav_id:a for a in formal.following_domain.aircraft}
    conditions=[];unsupported=[]
    for h in formal.resource_uses:
        if h.role!='M':continue
        row=domain[h.uav_id];bound=limits[snapshot.states[h.uav_id].vehicle_type]
        length=resource_lengths[h.resource_id]
        speed=length/(h.end_offset-h.start_offset)
        if abs(speed-bound.max_speed_mps)>1e-7:
            unsupported.append(dict(h_uid=h.uav_id,reason='UNSUPPORTED_DOMAIN:ENTRY_SPEED_NOT_MAXIMUM'))
            continue
        for v in (*[u for u in formal.resource_uses if u.role=='V'],
                  *[u for u in formal.frozen_reservations if u.role=='V']):
            if v.resource_id!=h.resource_id or v.uav_id==h.uav_id:continue
            # Same-layer V/H traffic is governed by the mainline FIFO and
            # following contract.  CPFF physical-entry recovery is only for
            # orthogonal cross-layer V/H competition; adding a condition for
            # same-layer pairs creates a condition without a corresponding
            # VH order guard in the timing model.
            if hasattr(v, "use_id"):
                if not is_cross_layer_vh_use(v, h):
                    continue
            elif not is_cross_layer_vh_frozen(v, h):
                continue
            state=snapshot.states.get(v.uav_id) or snapshot.resource_dependencies.get(v.uav_id)
            if state is None:
                unsupported.append(dict(h_uid=h.uav_id,reason='CPFF_V_DEPENDENCY_MISSING'));continue
            events=state.current_motion_plan.get('motion_observed_events',())
            if any(e['event_type']=='RESOURCE_EXIT' and str(e.get('resource_id'))==h.resource_id for e in events):continue
            key=dict(h=h.use_id,v=getattr(v,'use_id',getattr(v,'reservation_id',None)),version=snapshot.version)
            condition=PhysicalEntryCondition(condition_id=digest(key),h_use_id=h.use_id,
                v_use_id=getattr(v,'use_id',None),v_reservation_id=getattr(v,'reservation_id',None),
                entry_speed_mps=min(speed,bound.max_speed_mps),max_speed_mps=bound.max_speed_mps,
                acceleration_mps2=bound.max_abs_acceleration_mps2,braking_mps2=bound.max_abs_acceleration_mps2,
                resource_length_m=length,entry_station_m=row.resource_entry_station_m,
                stop_station_m=row.resource_entry_station_m-1e-6,observation_dt_s=dt_s,
                observation_origin_s=0.,state_version=snapshot.version,model_signature=model_signature)
            conditions.append(condition)
    updated={**payload}
    existing_conditions = {
        str(row.get("condition_id"))
        for row in payload.get("physical_entry_conditions", ())
        if isinstance(row, dict) and row.get("condition_id")
    }
    new_conditions = [c for c in conditions if c.condition_id not in existing_conditions]
    if conditions:
        prior = [dict(row) for row in payload.get("physical_entry_conditions", ())]
        updated.update(
            physical_entry_conditions=prior + [asdict(c) for c in new_conditions],
            execution_contract_version=VERSION,
        )
        build_complete_snapshot(updated)  # fail closed before mathematical compilation
    return updated,dict(status='NEEDS_RESOLVE' if new_conditions else 'NO_NEW_CONDITIONS',
        condition_ids=[c.condition_id for c in new_conditions],unsupported=unsupported,
        base_problem_hash=digest(payload),snapshot_version=snapshot.version)


def _vv_feedback_gap(payload, *, front_id, rear_id, candidate, diagnostics):
    """Return a monotone extra VV event gap for a failed continuous witness.

    The local trajectory certificate is deliberately not copied into the MILP.
    It is reduced to a conservative time separation: the observed spatial
    deficit divided by the rear vehicle's witness speed, plus a small numeric
    margin.  The existing VV order and all frozen/waiting constraints remain
    the model's source of truth.
    """
    witness = diagnostics.get("witness") or {}
    required = float(diagnostics.get("required_gap_m", 0.0))
    actual = float(witness.get("gap_m", required))
    rear_speed = max(float(witness.get("rear_speed_mps", 0.0)), 1e-3)
    deficit = max(0.0, required - actual)
    if deficit <= 1e-7:
        return 0.0
    # This is a conservative candidate repair, not a general proof that every
    # smaller gap is physically impossible. Certification is still required.
    return deficit / rear_speed + 1e-3


def _following_feedback_gap(diagnostics):
    """Convert a continuous longitudinal deficit into a time lower bound."""
    witness = diagnostics.get("witness") or {}
    required = float(diagnostics.get("required_gap_m", 0.0))
    actual = float(witness.get("gap_m", required))
    rear_speed = max(float(witness.get("rear_speed_mps", 0.0)), 1e-3)
    deficit = max(0.0, required - actual)
    return deficit / rear_speed + 1e-3, deficit


def _mixed_following_feedback(updated, snapshot, candidate, diagnostics, *, front_id, rear_id):
    """Delay the follower event for an H/H or H/V continuous-gap witness.

    Following-time rows are derived exactly from the physical domain and are
    therefore immutable at this seam.  Candidate feedback instead tightens
    the existing event lower bound, matching the already-supported VH prefix
    repair path.
    """
    delta, deficit = _following_feedback_gap(diagnostics)
    if delta <= 0.0:
        return updated, None
    event_times = getattr(candidate.result, "event_times", {}) or {}
    matching = next((row for row in updated.get("following_time_conditions", ())
                     if str(row.get("leader_id")) == front_id
                     and str(row.get("follower_id")) == rear_id), None)
    follower_event = str(matching["follower_event_id"]) if matching else None
    if follower_event is None:
        # A missing derived row is an input adapter defect; use the follower's
        # mainline resource event as a conservative event-level fallback.
        follower_event = None
    uses = [u for u in updated.get("resource_uses", ()) if u.get("role") == "M"]
    follower_use = next((u for u in uses if str(u.get("uav_id")) == rear_id), None)
    if follower_event is None and follower_use is not None:
        follower_event = str(follower_use["anchor_event_id"])
    if follower_event is None or follower_event not in event_times:
        return updated, None
    current_time = float(event_times[follower_event])
    lower = current_time + delta
    events=[];changed_event=None
    for event in updated.get("events", ()):
        item=dict(event)
        if str(item.get("event_id")) == follower_event:
            old_lower=float(item.get("time_lb", current_time))
            upper=float(item.get("time_ub", old_lower))
            if lower <= old_lower + 1e-7:
                return updated, None
            if lower > upper + 1e-7:
                return updated, dict(
                    condition_kind="MOTION_FEEDBACK_WINDOW_EXHAUSTED",
                    front_uav_id=front_id, rear_uav_id=rear_id,
                    follower_event_id=follower_event, gap_deficit_m=deficit,
                    additional_event_gap_s=delta, required_time_lb=lower,
                    event_time_ub=upper)
            item["time_lb"] = lower
            changed_event=item
        events.append(item)
    if changed_event is None:
        return updated, None
    changed = dict(
        condition_kind="CONSERVATIVE_CANDIDATE_REPAIR",
        front_uav_id=front_id, rear_uav_id=rear_id,
        follower_event_id=follower_event, gap_deficit_m=deficit,
        additional_event_gap_s=delta, required_time_lb=float(changed_event["time_lb"]),
    )
    return {**updated, "events": events}, changed


@measured("cpff.candidate_feedback", capture=False)
def build_motion_feedback_payload(
    payload, snapshot, *, candidate, candidate_snapshot, limits,
    resource_lengths, model_signature, dt_s, config,
):
    """Build candidate-driven physical feedback for the current solve stage.

    VH conditions use the existing physical-entry contract.  VV feedback is
    obtained only after a candidate exists: a failed continuous-gap witness is
    converted into a stronger existing VV order gap.  No feedback is produced
    before the first mathematical candidate, and no publication is performed
    here.
    """
    policy = CPFFPolicy.from_config(config)
    if policy.vh:
        updated, feedback = build_feedback_payload(
            payload, snapshot, limits=limits, resource_lengths=resource_lengths,
            model_signature=model_signature, dt_s=dt_s,
        )
    else:
        updated, feedback = dict(payload), dict(status="NO_NEW_CONDITIONS", condition_ids=[])
    feedback = dict(feedback)
    feedback["channels"] = policy.as_dict()
    feedback.setdefault("condition_groups", {})
    feedback["condition_groups"].setdefault("VH", list(feedback.get("condition_ids", ())))
    feedback["condition_groups"].setdefault("VV", [])

    if not policy.enabled or candidate_snapshot is None or not getattr(candidate.result, "event_times", None):
        return updated, feedback

    from .local_trajectory_certification import generate_and_certify

    # The same unpublished V and H decisions must be evaluated here and at
    # the final publication gate; inherited H targets are fixed dependencies.
    candidate_states=dict(candidate_snapshot.states)
    for uid,state in candidate_states.items():
        old=snapshot.states.get(uid)
        if old is not None and state.current_motion_plan.get('timed_resource_targets')!=old.current_motion_plan.get('timed_resource_targets'):
            plan=dict(state.current_motion_plan)
            for key in ('local_trajectory_reference','local_trajectory_id','local_certification_id'):
                plan.pop(key,None)
            candidate_states[uid]=replace(state,current_motion_plan=plan)
    candidate_snapshot=replace(candidate_snapshot,states=candidate_states)
    try:
        bound_states = bind_release_conditions(
            snapshot, candidate_states, limits=limits, config=config)
    except ValueError as error:
        reason = str(error)
        if not reason.startswith("CPFF_"):
            raise
        feedback.setdefault("unsupported", []).append({"reason": reason, "type": "MOTION"})
        return updated, feedback
    candidate_snapshot=replace(candidate_snapshot,states=bound_states)
    decision_ids={str(d['uav_id']) for d in payload.get('descents',())}|{
        uid for uid,state in candidate_states.items() if uid in snapshot.states and
        state.current_motion_plan.get('timed_resource_targets')!=snapshot.states[uid].current_motion_plan.get('timed_resource_targets')}
    bundle = generate_and_certify(
        candidate_snapshot, limits, config,
        str(getattr(candidate.result, "model_version", "CPFF_FEEDBACK")),
        decision_ids=decision_ids,
    )
    if bundle.get("certification_status") != "UNAVAILABLE":
        return updated, feedback
    if policy.vh and bundle.get('reason')=='CPFF_H_FOLLOWING_PREFIX_UNREACHABLE':
        diagnostics=bundle.get('diagnostics',{})
        uid=diagnostics['h_uav_id']
        use=next((u for u in updated.get('resource_uses',())
                  if u['role']=='M' and str(u['uav_id'])==uid and
                  str(u['resource_id'])==diagnostics['resource_id']),None)
        if use is not None:
            lower=float(diagnostics['entry_lower_bound_s'])-float(use['start_offset'])
            events=[dict(e,time_lb=max(float(e['time_lb']),lower))
                    if str(e['event_id'])==str(use['anchor_event_id']) else dict(e)
                    for e in updated['events']]
            # This is a conservative repair of this candidate's chosen
            # following prefix, not a universal physical infeasibility cut.
            cid='VH_MOTION:'+digest(diagnostics)
            updated={**updated,'events':events}
            feedback.update(status='NEEDS_RESOLVE')
            feedback['condition_ids']=list(feedback['condition_ids'])+[cid]
            feedback['condition_groups']['VH'].append(cid)
            feedback['candidate_repairs']=[dict(type='CONSERVATIVE_CANDIDATE_REPAIR',**diagnostics)]
        return updated,feedback
    if bundle.get("reason") != "LTG_CONTINUOUS_GAP_FAILED":
        feedback.setdefault("unsupported", []).append({
            "reason": bundle.get("reason", "CPFF_MOTION_FEEDBACK_UNAVAILABLE"),
            "type": "MOTION",
        })
        return updated, feedback

    diagnostics=bundle.get('diagnostics') or {}
    conflicts=diagnostics.get('conflicts') or [diagnostics]
    updated,batch=merge_gap_repairs(updated,snapshot,candidate,conflicts,policy)
    feedback['conflict_count']=len(conflicts)
    feedback['conflict_witnesses']=conflicts
    feedback['batch_repairs']=batch['witnesses']
    feedback.setdefault('unsupported',[]).extend(batch['unsupported'])
    for group in ('VV','VH'):
        feedback['condition_groups'][group].extend(batch['condition_groups'][group])
    feedback['condition_ids'].extend(batch['condition_ids'])
    if batch['changed']:
        feedback['status']='NEEDS_RESOLVE'
    return updated,feedback


@measured('cpff.merge_gap_repairs')
def merge_gap_repairs(payload,snapshot,candidate,conflicts,policy):
    """Merge absolute bounds, never sum per-witness delays.

    Mathematical compatibility is decided by the unchanged joint solve; this
    seam rejects window exhaustion and validates the complete augmented input.
    Repairs remain conservative candidate restrictions, not infeasibility proofs.
    """
    events={str(e['event_id']):dict(e) for e in payload.get('events',())}
    vv={(str(r['first_id']),str(r['second_id'])):dict(r) for r in payload.get('vv_constraints',())}
    report=dict(changed=False,condition_groups={'VV':[],'VH':[]},condition_ids=[],unsupported=[],witnesses=[])
    ordered=sorted(conflicts,key=lambda d:(str(d.get('front_uav_id')),str(d.get('rear_uav_id')),
        float(d.get('absolute_time_s',0.)),float((d.get('witness') or {}).get('gap_m',0.))))
    for diagnostic in ordered:
        proposal,detail=_single_gap_repair(payload,snapshot,candidate,diagnostic,policy)
        accepted=proposal!=payload
        exhausted=[c for c in detail['condition_groups']['VH']
                   if isinstance(c,dict) and c.get('condition_kind')=='MOTION_FEEDBACK_WINDOW_EXHAUSTED']
        if exhausted:
            accepted=False
            detail['unsupported'].extend(dict(reason='MOTION_FEEDBACK_WINDOW_EXHAUSTED',**c) for c in exhausted)
        if accepted:
            for e in proposal.get('events',()):
                target=events[str(e['event_id'])]
                target['time_lb']=max(float(target['time_lb']),float(e['time_lb']))
            for r in proposal.get('vv_constraints',()):
                target=vv[(str(r['first_id']),str(r['second_id']))]
                for key in ('first_before_second_gap','second_before_first_gap'):
                    target[key]=max(float(target[key]),float(r[key]))
            for group in ('VV','VH'):
                report['condition_groups'][group].extend(detail['condition_groups'][group])
            report['condition_ids'].extend(detail['condition_ids'])
        report['unsupported'].extend(detail['unsupported'])
        report['witnesses'].append(dict(front_uav_id=diagnostic.get('front_uav_id'),
            rear_uav_id=diagnostic.get('rear_uav_id'),accepted=accepted,
            condition_ids=detail['condition_ids'] if accepted else [],unsupported=detail['unsupported']))
    augmented={**payload,'events':type(payload.get('events',[]))(events[str(e['event_id'])] for e in payload.get('events',())),
        'vv_constraints':type(payload.get('vv_constraints',[]))(vv[(str(r['first_id']),str(r['second_id']))] for r in payload.get('vv_constraints',()))}
    if augmented!=payload:
        from traffic_simulation.cmlpm.active import build_complete_snapshot
        build_complete_snapshot(augmented)
        report['changed']=True
    report['condition_ids']=sorted(set(report['condition_ids']))
    performance_metrics(conflict_count=len(conflicts),accepted_repairs=sum(r['accepted'] for r in report['witnesses']),changed=report['changed'])
    return augmented,report


def _single_gap_repair(updated,snapshot,candidate,diagnostics,policy):
    feedback=dict(status='NO_NEW_CONDITIONS',condition_ids=[],
        condition_groups={'VV':[],'VH':[]},unsupported=[])
    front_id = str(diagnostics.get("front_uav_id", ""))
    rear_id = str(diagnostics.get("rear_uav_id", ""))
    if not front_id or not rear_id:
        return updated, feedback

    rows = []
    entry_events = {
        str(item["uav_id"]): str(item["entry_event_id"])
        for item in updated.get("descents", ())
        if item.get("entry_event_id")
    }
    event_times = getattr(candidate.result, "event_times", {})
    front_entry = entry_events.get(front_id)
    rear_entry = entry_events.get(rear_id)
    # H/H and H/V witnesses use the existing mainline following seam.  They
    # must not be classified as V/V unless both sides have a current E anchor.
    if front_entry is None or rear_entry is None:
        if not policy.vh:
            feedback.setdefault("unsupported", []).append({"reason": "VH_CHANNEL_DISABLED"})
            return updated, feedback
        mixed_updated, condition = _mixed_following_feedback(
            updated, snapshot, candidate, diagnostics,
            front_id=front_id, rear_id=rear_id)
        if condition is None:
            feedback.setdefault("unsupported", []).append({"reason": "MIXED_MOTION_CONDITION_MISSING"})
            return updated, feedback
        updated = mixed_updated
        feedback["condition_groups"]["VH"].append(condition)
        feedback["condition_ids"] = list(feedback.get("condition_ids", ())) + [
            "VH_MOTION:" + digest(condition)]
        feedback["status"] = "NEEDS_RESOLVE"
        return updated, feedback
    if not policy.vv:
        return updated,feedback
    current_order_gap = None
    if front_entry in event_times and rear_entry in event_times:
        current_order_gap = float(event_times[rear_entry]) - float(event_times[front_entry])
    for row in updated.get("vv_constraints", ()):
        row = dict(row)
        pair = {str(row.get("first_id")), str(row.get("second_id"))}
        if pair != {front_id, rear_id}:
            rows.append(row)
            continue
        delta = _vv_feedback_gap(
            updated, front_id=front_id, rear_id=rear_id,
            candidate=candidate, diagnostics=diagnostics,
        )
        if delta <= 0.0:
            rows.append(row)
            continue
        if str(row.get("first_id")) == rear_id and str(row.get("second_id")) == front_id:
            lower = (current_order_gap + delta
                     if current_order_gap is not None else
                     float(row["second_before_first_gap"]) + delta)
            row["second_before_first_gap"] = max(float(row["second_before_first_gap"]), lower)
        elif str(row.get("first_id")) == front_id and str(row.get("second_id")) == rear_id:
            lower = (current_order_gap + delta
                     if current_order_gap is not None else
                     float(row["first_before_second_gap"]) + delta)
            row["first_before_second_gap"] = max(float(row["first_before_second_gap"]), lower)
        else:
            rows.append(row)
            continue
        feedback["condition_groups"]["VV"].append({
            "condition_kind": "CONSERVATIVE_CANDIDATE_REPAIR",
            "front_uav_id": front_id, "rear_uav_id": rear_id,
            "gap_deficit_m": max(0.0, float(diagnostics.get("required_gap_m", 0.0))
                                   - float((diagnostics.get("witness") or {}).get("gap_m", 0.0))),
            "additional_event_gap_s": delta,
        })
        rows.append(row)

    if feedback["condition_groups"]["VV"]:
        updated = {**updated, "vv_constraints": rows}
        # Validate the augmented mathematical snapshot before the next solve.
        from traffic_simulation.cmlpm.active import build_complete_snapshot
        feedback["status"] = "NEEDS_RESOLVE"
        feedback["condition_ids"] = list(feedback.get("condition_ids", ())) + [
            "VV_MOTION:" + digest(feedback["condition_groups"]["VV"])
        ]
    return updated, feedback


@measured("cpff.bind_release_conditions")
def bind_release_conditions(snapshot,proposed,*,limits,config):
    """Bind current-candidate blockers, not the old joint bundle's identity."""
    if not CPFFPolicy.from_config(config).vh:
        return dict(proposed)
    merged={**snapshot.resource_dependencies,**snapshot.states,**proposed}
    result=dict(proposed)
    for uid,h in proposed.items():
        hp=h.current_motion_plan
        if hp.get('schedule_result')=='RELEASED' or hp.get('local_trajectory_reference'):continue
        targets=[t for t in hp.get('timed_resource_targets',()) if t['entry_time_s']>snapshot.sim_time_s]
        releases=[];new_targets=[]
        for target in targets:
            rid=str(target['resource_id'])
            original=snapshot.states[uid].current_motion_plan.get('timed_resource_targets',())
            if any(str(t['resource_id'])==rid for t in original):continue
            new_targets.append(dict(target))
            b=limits[h.vehicle_type]
            speed=(target['exit_station_m']-target['entry_station_m'])/(target['exit_time_s']-target['entry_time_s'])
            for v in merged.values():
                if v.uav_id==uid:continue
                vp=v.current_motion_plan
                if any(e['event_type']=='RESOURCE_EXIT' and str(e.get('resource_id'))==rid
                       for e in vp.get('motion_observed_events',())):continue
                windows=vp.get('realized_resource_windows')
                if windows is None:
                    windows={str(r):(a,z) for r,a,z in vp.get('resource_windows',())}
                # Existing V occupancy is a current-state forecast.  The
                # published window remains an immutable baseline, but it must
                # not be reused as if a late V had already exited.
                if vp.get('g_time_s') is not None and vp.get('resource_windows'):
                    from .existing_v_continuation import ExecutedEvent, current_v_resource_windows
                    observed=[]
                    for index,event in enumerate(vp.get('motion_observed_events', ())):
                        observed.append(ExecutedEvent(
                            event_id=str(event.get('event_id', f'{v.uav_id}:observed:{index}')),
                            event_type=str(event.get('event_type')),
                            actual_time_s=float(event.get('actual_time_s', event.get('time_s', snapshot.sim_time_s))),
                            sequence=int(event.get('sequence', index)),
                            resource_id=event.get('resource_id'),
                            uav_id=str(event.get('uav_id', v.uav_id)),
                        ))
                    windows,_=current_v_resource_windows(
                        v, t_now=snapshot.sim_time_s,
                        resource_windows=tuple(vp.get('resource_windows', ())),
                        g_time_s=float(vp['g_time_s']),
                        j_time_s=float(vp.get('j_time_s', vp['g_time_s'])),
                        executed=tuple(observed),
                    )
                if rid not in windows:continue
                enter,exit_=map(float,windows[rid])
                if target['entry_time_s']<exit_+config['resource_safety']['vh_v_to_h_margin_s']-1e-6:continue
                if target['entry_time_s']<enter+2.5-1e-6:continue
                if not 0.<speed<=b.max_speed_mps+1e-7:
                    raise ValueError('CPFF_INVALID_ENTRY_SPEED')
                if abs(speed-b.max_speed_mps)>1e-7:
                    # This optional sufficient witness is defined only for
                    # maximum-speed entry. Other legal H speeds use the
                    # common bounded executor and strict publication audit.
                    continue
                dt=float(config['simulation']['dt_s'])
                # A predicted exit in the past means that the V is late or
                # stopped relative to its plan.  Keep the dependency alive at
                # the next observation tick until actual RESOURCE_EXIT is
                # present; never reinterpret a forecast as an observed event.
                observation=math.ceil((max(exit_, snapshot.sim_time_s+dt)-1e-9)/dt)*dt
                releases.append(dict(resource_id=rid,v_uid=v.uav_id,release_observation_s=observation,
                    predicted_exit_s=exit_,v_content_digest=digest(v_content(v)),
                    release_observation_source='CURRENT_STATE_FORECAST',
                    actual_exit_observed=False,target=dict(target)))
        if new_targets:
            scope=dict(version=VERSION,snapshot_version=snapshot.version,snapshot_time_s=snapshot.sim_time_s,
                h_initial_state=(h.s_m,h.speed_mps),releases=releases,targets=new_targets,
                budget_contract=hp.get('cpff_budget_contract'))
            scope['grant_id']='H-GRANT:'+digest(scope)
            scope['status']='ACTIVE'
            result[uid]=replace(h,current_motion_plan={**hp,'cpff_execution':scope})
    return result


def shifted(profile,offset):
    return tuple(Piece(p.start_s+offset,p.end_s+offset,p.s0,p.v0,p.a) for p in profile.pieces
                 if p.end_s+offset>p.start_s+offset)


def protected_h_profile(state,aircraft,target,now,duration,front,front_profile,min_gap):
    scope=state.current_motion_plan['cpff_execution']
    rows=[r for r in scope['releases'] if r['resource_id']==str(target['resource_id'])]
    if not rows:raise ValueError('CPFF_FINAL_WITNESS_SCOPE_MISSING')
    release=max(r['release_observation_s'] for r in rows)
    if (abs(scope['snapshot_time_s']-now)>1e-9
            or max(abs(a-b) for a,b in zip(scope['h_initial_state'],(aircraft.s,aircraft.v)))>1e-6
            or any(r['target']!=target for r in rows)):
        raise ValueError('CPFF_FINAL_WITNESS_DEPENDENCY_CHANGED')
    entry=float(target['entry_time_s']);station=float(target['entry_station_m'])
    speed=(target['exit_station_m']-station)/(target['exit_time_s']-entry)
    a=aircraft.limits.a_max
    if abs(speed-aircraft.limits.v_max)>1e-7 or entry<=release:
        raise ValueError('UNSUPPORTED_DOMAIN:CPFF_FINAL_TERMINAL')
    speed=min(speed,aircraft.limits.v_max)
    delta=entry-release
    u=max(0.,speed-a*delta)
    distance=(speed*speed-u*u)/(2*a)
    release_station=station-distance
    stop=station-1e-6
    if release_station+u*u/(2*a)>stop+1e-9:
        raise ValueError('CPFF_RECOVERY_BOUND_NOT_REALIZED')
    prefix=Profile((),0.)
    clock=0.
    # Reuse the actual leader approach where its G removes the lane obstacle.
    if (front is not None and front_profile is not None
            and front.current_motion_plan.get('schedule_result')=='RELEASED'
            and front_profile.duration_s<release-now-1e-8
            and abs(front.speed_mps-aircraft.v)<1e-7
            and front.s_m-aircraft.s>=min_gap-1e-6
            and all(abs(p.a)<=a+1e-8 for p in front_profile.pieces)):
        gap=front.s_m-aircraft.s
        prefix=Profile(tuple(Piece(p.start_s,p.end_s,p.s0-gap,p.v0,p.a) for p in front_profile.pieces),front_profile.duration_s)
        clock=prefix.duration_s
    start=aircraft if not prefix.pieces else replace(aircraft,s=prefix.end[0],v=prefix.end[1])
    if not prefix.pieces:
        # A non-released H leader does not provide a reusable V prefix.  The
        # final H entry itself is still the correct terminal target; forcing a
        # separate state at the predicted V release time over-constrains H/H
        # and H/V queues.
        try:
            approach=terminal_slot_profile(start,Slot(entry,station,speed),now,entry-now)
            pieces=approach.pieces
            if duration>entry-now:
                pieces+=(Piece(entry-now,duration,station,speed,0.),)
            return Profile(pieces,duration),dict(
                grant_id=scope['grant_id'],snapshot_version=scope['snapshot_version'],
                release_observation_s=release,entry_time_s=entry,
                entry_speed_mps=speed,prefix_stopping_margin_m=None,
                dependency_digest=digest(scope),direct_terminal=True)
        except ValueError:
            pass
    if prefix.pieces:
        # Once the physical leader has left at G, use the existing bounded
        # terminal construction over the remaining approach. The old witness
        # unnecessarily required a single prescribed state at the release
        # observation, rejecting later entries that were actually reachable.
        try:
            remaining=terminal_slot_profile(start,Slot(entry,station,speed),now+clock,entry-now-clock)
            candidate=Profile(prefix.pieces+shifted(remaining,clock),entry-now)
            from .local_trajectory_certification import reference_interval
            held=reference_interval(dict(start_time_s=now,duration_s=candidate.duration_s,
                pieces=[asdict(p) for p in candidate.pieces]),state,now,release-now)
            if stop_satisfied(held,aircraft,stop):
                pieces=candidate.pieces
                if duration>entry-now:pieces+=(Piece(entry-now,duration,station,speed,0.),)
                margin=min(stop-(p.state_at(p.end_s)[0]+p.state_at(p.end_s)[1]**2/(2*a)) for p in held.pieces)
                return Profile(pieces,duration),dict(grant_id=scope['grant_id'],snapshot_version=scope['snapshot_version'],
                    release_observation_s=release,entry_time_s=entry,entry_speed_mps=speed,
                    prefix_stopping_margin_m=margin,dependency_digest=digest(scope))
        except ValueError:
            # Try the strict stop-and-restart construction below; candidate
            # failure is reported through the existing feedback loop.
            pass
    try:
        middle=terminal_slot_profile(start,Slot(release,release_station,u),now+clock,release-now-clock)
    except ValueError as error:
        if not prefix.pieces or front is None:
            # Turn the failed fixed-time endpoint into the same monotone
            # necessary event bound used by the mixed-following feedback.
            # This preserves the H target and asks MILP for a later entry
            # instead of treating an artificial release state as a proof that
            # the whole queue is infeasible.
            def feasible(delay):
                try:
                    terminal_slot_profile(start,Slot(now+delay,station,speed),now,delay)
                    return True
                except ValueError:
                    return False
            lower=max(entry-now, 1e-6)
            upper=lower
            for _ in range(40):
                if feasible(upper):
                    break
                upper*=2.
            else:
                raise
            for _ in range(50):
                middle_time=(lower+upper)/2.
                if feasible(middle_time):
                    upper=middle_time
                else:
                    lower=middle_time
            from .local_trajectory_certification import TrajectoryCertificationError
            raise TrajectoryCertificationError('CPFF_H_FOLLOWING_PREFIX_UNREACHABLE',dict(
                h_uav_id=state.uav_id,front_uav_id=front.uav_id if front is not None else None,
                resource_id=str(target['resource_id']),candidate_entry_s=entry,
                entry_lower_bound_s=now+upper+1e-6,front_departure_s=now+clock,
                following_prefix_end_station_m=start.s,
                following_prefix_end_speed_mps=start.v)) from error
        length=station-start.s
        accelerate=max(0.,(speed-start.v)/a)
        accelerate_distance=(start.v+speed)*accelerate/2
        if length<accelerate_distance-1e-8:
            raise
        earliest=now+clock+accelerate+max(0.,length-accelerate_distance)/speed
        if earliest<=entry+1e-7:
            raise
        from .local_trajectory_certification import TrajectoryCertificationError
        raise TrajectoryCertificationError('CPFF_H_FOLLOWING_PREFIX_UNREACHABLE',dict(
            h_uav_id=state.uav_id,front_uav_id=front.uav_id,resource_id=str(target['resource_id']),
            candidate_entry_s=entry,entry_lower_bound_s=earliest+1e-6,
            front_departure_s=now+clock,following_prefix_end_station_m=start.s,
            following_prefix_end_speed_mps=start.v)) from error
    prefix=Profile(prefix.pieces+shifted(middle,clock),release-now)
    if not stop_satisfied(prefix,aircraft,stop):raise ValueError('CPFF_STOPPING_PREFIX_FAILED')
    pieces=prefix.pieces
    acceleration_start=max(release,entry-speed/a)
    if acceleration_start>release:
        pieces+=(Piece(release-now,acceleration_start-now,release_station,0.,0.),)
    post=build_profile(replace(aircraft,s=release_station,v=u),speed,entry-acceleration_start)
    pieces+=shifted(post,acceleration_start-now)
    position,velocity=post.end
    if abs(position-station)>1e-6 or abs(velocity-speed)>1e-6:
        raise ValueError('CPFF_FINAL_TERMINAL_MISMATCH')
    if duration>entry-now:pieces+=(Piece(entry-now,duration,position,speed,0.),)
    margin=min(stop-(p.state_at(p.end_s)[0]+p.state_at(p.end_s)[1]**2/(2*a)) for p in prefix.pieces)
    evidence=dict(grant_id=scope['grant_id'],snapshot_version=scope['snapshot_version'],
        release_observation_s=release,entry_time_s=entry,entry_speed_mps=speed,
        prefix_stopping_margin_m=margin,dependency_digest=digest(scope))
    return Profile(pieces,duration),evidence
