"""Registered G25 route identity resolution.

ECJA and C-MLPM refer to the same physical descent path through two different
identifier conventions:

    ECJA      route:<interface_id>
    C-MLPM    <interface_id>:route

Neither is wrong, and neither may be rewritten by string surgery.  A route
identity is only valid if the reference resolves to exactly one registered G25
interface whose service node, direction, source layer and resource chain all
agree with the caller's expectation.  Stripping a prefix and concatenating a
suffix would happily produce a plausible-looking identifier for a path that does
not exist, or worse, for a different path.

This module owns that resolution and fails closed on every ambiguity.  It does
not modify either algorithm's output format; the original reference is retained
in ``raw_reference`` so a published record stays traceable to what was written.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Mapping

from .network_loader import RegisteredG25

ROUTE_IDENTITY_VERSION = "G25_ROUTE_IDENTITY_V1"

FORMAT_ECJA_PREFIX = "ECJA_ROUTE_PREFIX"
FORMAT_CMLPM_SUFFIX = "CMLPM_ROUTE_SUFFIX"
FORMAT_BARE = "BARE_INTERFACE_ID"

_ECJA_PREFIX = "route:"
_CMLPM_SUFFIX = ":route"


class RouteIdentityError(ValueError):
    """A route reference could not be resolved to one registered interface."""

    def __init__(self, code: str, detail: str = "") -> None:
        super().__init__(f"{code}:{detail}" if detail else code)
        self.code = code
        self.detail = detail


@dataclass(frozen=True)
class ResolvedRoute:
    """One registered descent path, identified independently of its spelling."""

    interface_id: str
    route_id: str
    node_id: str
    direction: str
    source_layer: str
    resource_chain: tuple[str, ...]
    input_format: str
    raw_reference: str
    resolver_version: str = ROUTE_IDENTITY_VERSION


def split_reference(route_ref: str) -> tuple[str, str]:
    """Return ``(candidate_interface_id, format_tag)`` for one reference.

    Both conventions are recognised explicitly.  A reference that carries
    neither is treated as a bare interface id, which is then still required to
    resolve against the registry.
    """

    text = str(route_ref).strip()
    if not text:
        raise RouteIdentityError("ROUTE_IDENTITY_EMPTY")
    if text.startswith(_ECJA_PREFIX) and len(text) > len(_ECJA_PREFIX):
        return text[len(_ECJA_PREFIX):], FORMAT_ECJA_PREFIX
    if text.endswith(_CMLPM_SUFFIX) and len(text) > len(_CMLPM_SUFFIX):
        return text[: -len(_CMLPM_SUFFIX)], FORMAT_CMLPM_SUFFIX
    return text, FORMAT_BARE


def _resolved(interface: Mapping[str, Any], *, interface_id: str, fmt: str, raw: str) -> ResolvedRoute:
    template = interface.get("route_template") or {}
    chain = template.get("resource_chain")
    if not chain:
        raise RouteIdentityError(
            "ROUTE_RESOURCE_CHAIN_MISSING", str(interface.get("interface_id"))
        )
    return ResolvedRoute(
        interface_id=interface_id,
        route_id=str(interface["route_id"]),
        node_id=str(interface["service_node_id"]),
        direction=str(interface["direction"]),
        source_layer=str(interface["source_layer"]),
        resource_chain=tuple(str(item) for item in chain),
        input_format=fmt,
        raw_reference=raw,
    )


def build_route_index(network: RegisteredG25) -> dict[str, Mapping[str, Any]]:
    """Index registered interfaces by ``interface_id``.

    Duplicate ids would make every later resolution ambiguous, so the index
    itself refuses to be built.
    """

    index: dict[str, Mapping[str, Any]] = {}
    for interface in network.interfaces:
        interface_id = str(interface["interface_id"])
        if interface_id in index:
            raise RouteIdentityError("ROUTE_IDENTITY_AMBIGUOUS", interface_id)
        index[interface_id] = interface
    if not index:
        raise RouteIdentityError("ROUTE_REGISTRY_EMPTY")
    return index


def resolve_route_identity(
    network: RegisteredG25,
    route_ref: str,
    *,
    node_id: str | None = None,
    direction: str | None = None,
    source_layer: str | None = None,
    index: Mapping[str, Mapping[str, Any]] | None = None,
) -> ResolvedRoute:
    """Resolve ``route_ref`` to exactly one registered interface.

    When ``node_id``/``direction``/``source_layer`` are supplied they are treated
    as caller expectations and must match the registered interface.  A mismatch
    is reported rather than silently accepted, because it means the caller and
    the registry disagree about which path this is.
    """

    candidate, fmt = split_reference(route_ref)
    registry = index if index is not None else build_route_index(network)
    interface = registry.get(candidate)
    if interface is None:
        raise RouteIdentityError(
            "ROUTE_INTERFACE_NOT_REGISTERED", f"{route_ref}->{candidate}"
        )

    expected = {
        "node_id": str(interface["service_node_id"]),
        "direction": str(interface["direction"]),
        "source_layer": str(interface["source_layer"]),
    }
    given = {
        "node_id": node_id,
        "direction": direction,
        "source_layer": source_layer,
    }
    for key, value in given.items():
        if value is None:
            continue
        if str(value) != expected[key]:
            raise RouteIdentityError(
                "ROUTE_IDENTITY_FIELD_MISMATCH",
                f"{key}:{value}!={expected[key]}",
            )
    return _resolved(interface, interface_id=candidate, fmt=fmt, raw=route_ref)


def resolve_node_route(
    network: RegisteredG25,
    node_id: str,
    source_layer: str,
    *,
    direction: str | None = None,
    index: Mapping[str, Mapping[str, Any]] | None = None,
) -> ResolvedRoute:
    """Resolve the unique descent interface of one node and source layer."""

    registry = index if index is not None else build_route_index(network)
    matches = [
        row
        for row in registry.values()
        if str(row["service_node_id"]) == str(node_id)
        and str(row["source_layer"]) == str(source_layer)
        and (direction is None or str(row["direction"]) == str(direction))
    ]
    if not matches:
        raise RouteIdentityError(
            "ROUTE_INTERFACE_NOT_REGISTERED", f"{node_id}:{source_layer}:{direction}"
        )
    if len(matches) > 1:
        raise RouteIdentityError(
            "ROUTE_IDENTITY_AMBIGUOUS", f"{node_id}:{source_layer}:{direction}"
        )
    interface = matches[0]
    return _resolved(
        interface,
        interface_id=str(interface["interface_id"]),
        fmt=FORMAT_CMLPM_SUFFIX,
        raw=str(interface["route_id"]),
    )


def same_physical_path(first: ResolvedRoute, second: ResolvedRoute) -> bool:
    """True only when both references denote the same registered path."""

    return (
        first.interface_id == second.interface_id
        and first.resource_chain == second.resource_chain
    )
