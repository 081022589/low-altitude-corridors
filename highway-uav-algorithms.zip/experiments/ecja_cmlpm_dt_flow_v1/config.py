from __future__ import annotations

import json
from pathlib import Path
from typing import Any
import math

from .trigger_rules import (
    DEFAULT_ECJA_BATCH_SIZE,
    ECJA_DEADLINE_MULTIPLIER,
    LATEST_ASSIGNMENT_MULTIPLIER,
    REQUEST_GUARD_MULTIPLIER,
)
from traffic_simulation.cmlpm.joint_single_node.schema import MODEL_VERSION as CMLPM_MODEL_VERSION


ROOT = Path(__file__).resolve().parents[2]


def approved_cmlpm_evaluation_time_bounds(
    config: dict[str, Any], *, t_now: float,
) -> dict[str, float]:
    """Project the registered C-MLPM evaluation limits onto one event solve."""

    registration = config["cmlpm_evaluation_time"]
    source = ROOT / registration["parameter_contract_source"]
    contract = json.loads(source.read_text(encoding="utf-8"))
    if contract.get("contract_version") != registration["contract_version"]:
        raise ValueError("CMLPM_EVALUATION_TIME_CONTRACT_VERSION_MISMATCH")
    registered = contract["time_bounds"]
    registered_now = float(registered["t_now"])
    projected = {
        key: float(t_now) + float(registered[key]) - registered_now
        for key in ("t_commit", "t_request", "t_clear")
    }
    if not float(t_now) <= projected["t_commit"] <= projected["t_request"] <= projected["t_clear"]:
        raise ValueError("CMLPM_EVALUATION_TIME_CONTRACT_INVALID")
    return projected


def load_config(path: str | Path) -> dict[str, Any]:
    source = Path(path)
    config = json.loads(source.read_text(encoding="utf-8"))
    if config.get("experiment_id") != "G25_ECJA_CMLPM_DT_FLOW_V1":
        raise ValueError("EXPERIMENT_ID_MISMATCH")
    if float(config["simulation"]["dt_s"]) != 0.5:
        raise ValueError("DT_CONTRACT_MISMATCH")
    trigger = config["ecja_trigger"]
    if (trigger.get("policy") != "ECJA_BATCH_AND_DISTANCE_GUARD_V1"
            or isinstance(trigger.get("batch_size"), bool) or not isinstance(trigger.get("batch_size"), int)
            or trigger["batch_size"] != DEFAULT_ECJA_BATCH_SIZE
            or trigger.get("request_generation_multiplier") != REQUEST_GUARD_MULTIPLIER
            or trigger.get("ecja_deadline_multiplier") != ECJA_DEADLINE_MULTIPLIER
            or trigger.get("latest_assignment_multiplier") != LATEST_ASSIGNMENT_MULTIPLIER
            or trigger.get("observation_step_s") != config["simulation"]["dt_s"]
            or config["simulation"].get("cmlpm_period_s") != 5.0):
        raise ValueError("ECJA_BATCH_TRIGGER_CONFIG_INVALID")
    approved_cmlpm_evaluation_time_bounds(config, t_now=0.0)
    waiting = config.get("cmlpm_waiting")
    if waiting is not None:
        step,age,fraction = (float(waiting[k]) for k in
            ("wait_step_weight","wait_age_weight","full_attempt_fraction"))
        if not all(math.isfinite(v) for v in (step,age,fraction)) or step <= 0 or age < 0 or not 0 < fraction < 1:
            raise ValueError("CMLPM_WAITING_CONFIG_INVALID")
    scheduling = config.get("scheduling")
    if not isinstance(scheduling, dict) or not isinstance(scheduling.get("enable_waiting"), bool):
        raise ValueError("SCHEDULING_WAITING_CONFIG_INVALID")
    methods = config.get("methods")
    if not isinstance(methods, dict) or methods.get("cmlpm_identity") != CMLPM_MODEL_VERSION:
        raise ValueError("CMLPM_MODEL_IDENTITY_MISMATCH")
    safety = config["resource_safety"]
    from .conditional_feasibility_feedback import CPFFPolicy
    CPFFPolicy.from_config(config)
    from .cpff_anomaly_response import AnomalyResponsePolicy
    AnomalyResponsePolicy.from_config(config)
    if safety.get("interval_includes_guard") is not True or float(safety.get("additional_guard_s", -1)) != 0.0:
        raise ValueError("DOUBLE_GUARD_FORBIDDEN")
    return config

