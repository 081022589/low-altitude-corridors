"""E-anchored descent template: E -> J (horizontal deceleration) -> P (vertical).

B design (2026-11-13): E is the scheduling anchor and the only trajectory
origin.  The aircraft arrives at the shaft boundary E at ``v_e`` (an upper
bound, registered per type), decelerates horizontally to the axis J over the
10 m shaft radius while the vertical speed ramps to the descent speed, then
descends vertically to the completion altitude.  G is no longer a template
origin, so the L3 case (which cannot decelerate from cruise to the descent
speed inside the shaft with the old G->J generator) becomes feasible.

The returned dict follows the existing descent-template schema
(``segments`` / ``j_offset_s`` / ``geometries``) and additionally publishes
``resource_windows_offsets`` relative to E, so existing window consumers can
skip geometric clipping.
"""

from __future__ import annotations

import math
from typing import Any, Mapping

VERSION = "E_TO_J_DESCENT_TEMPLATE_V1"
_TOL = 1e-9


def _vertical_profile(*, drop_m: float, acceleration_mps2: float,
                      descent_speed_mps: float) -> dict[str, Any]:
    """0 -> descent speed at the declared acceleration, then constant."""

    if drop_m <= 0.0 or acceleration_mps2 <= 0.0 or descent_speed_mps <= 0.0:
        raise ValueError("E_TO_J_VERTICAL_INPUT_INVALID")
    ramp_time = descent_speed_mps / acceleration_mps2
    ramp_drop = 0.5 * acceleration_mps2 * ramp_time * ramp_time
    if drop_m <= ramp_drop:
        peak = math.sqrt(2.0 * acceleration_mps2 * drop_m)
        total = peak / acceleration_mps2
        return {"duration_s": total, "ramp_time_s": total, "peak_speed_mps": peak,
                "profile": "ACCELERATE_ONLY"}
    total = ramp_time + (drop_m - ramp_drop) / descent_speed_mps
    return {"duration_s": total, "ramp_time_s": ramp_time,
            "peak_speed_mps": descent_speed_mps, "profile": "ACCELERATE_THEN_CONSTANT"}


def _vertical_state(profile: Mapping[str, Any], time_s: float) -> tuple[float, float]:
    """Return (dropped_m, vertical_speed_mps) at an elapsed time."""

    ramp_time = float(profile["ramp_time_s"])
    peak = float(profile["peak_speed_mps"])
    acceleration = peak / ramp_time if ramp_time > _TOL else 0.0
    if time_s <= ramp_time:
        return 0.5 * acceleration * time_s * time_s, acceleration * time_s
    return (0.5 * peak * ramp_time + peak * (time_s - ramp_time)), peak


def build_e_to_j_template(
    *,
    e_station_m: float,
    e_altitude_m: float,
    axis_station_m: float,
    completion_z_m: float,
    v_e_mps: float,
    descent_speed_mps: float,
    horizontal_acceleration_mps2: float,
    vertical_acceleration_mps2: float,
    resource_bands: Mapping[str, tuple[float, float]],
    e_xyz: tuple[float, float] | None = None,
    axis_xyz: tuple[float, float] | None = None,
    sample_period_s: float = 0.05,
    require_first_resource_at_e: bool = True,
) -> dict[str, Any]:
    """Build one deterministic E -> J -> P template.

    ``resource_bands`` maps resource id -> (high_z, low_z).  The windows are
    returned relative to E (``resource_windows_offsets``); the first resource
    is entered at t=0 by construction.
    """

    horizontal = float(axis_station_m) - float(e_station_m)
    if horizontal <= 0.0:
        raise ValueError("E_TO_J_AXIS_NOT_DOWNSTREAM_OF_E")
    if v_e_mps <= 0.0 or horizontal_acceleration_mps2 <= 0.0:
        raise ValueError("E_TO_J_INPUT_INVALID")
    a_h = v_e_mps * v_e_mps / (2.0 * horizontal)
    if a_h > horizontal_acceleration_mps2 + 1e-9:
        raise ValueError(
            f"E_TO_J_HORIZONTAL_ACCEL_EXCEEDED:{a_h:.6f}>{horizontal_acceleration_mps2:.6f}")
    t_h = 2.0 * horizontal / v_e_mps
    if sample_period_s <= 0.0:
        raise ValueError("E_TO_J_SAMPLE_PERIOD_INVALID")

    drop_total = float(e_altitude_m) - float(completion_z_m)
    vertical = _vertical_profile(
        drop_m=drop_total, acceleration_mps2=vertical_acceleration_mps2,
        descent_speed_mps=descent_speed_mps)
    if t_h > float(vertical["duration_s"]) + 1e-9:
        raise ValueError("E_TO_J_HORIZONTAL_EXCEEDS_VERTICAL_END")

    # Sampled E -> J motion (horizontal deceleration + vertical ramp).  The
    # scalar station remains the scheduling coordinate; the optional XY pair
    # preserves the registered corridor geometry for SRCM intersection tests.
    e_x, e_y = e_xyz if e_xyz is not None else (float(e_station_m), 0.0)
    axis_x, axis_y = axis_xyz if axis_xyz is not None else (float(axis_station_m), 0.0)
    count = max(1, math.ceil(t_h / sample_period_s))
    samples = []
    for index in range(count + 1):
        tau = t_h * index / count
        distance = v_e_mps * tau - 0.5 * a_h * tau * tau
        fraction = distance / horizontal
        x = float(e_x) + (float(axis_x) - float(e_x)) * fraction
        y = float(e_y) + (float(axis_y) - float(e_y)) * fraction
        dropped, v_z = _vertical_state(vertical, tau)
        v_x = max(0.0, v_e_mps - a_h * tau)
        samples.append((tau, x, y, float(e_altitude_m) - dropped, v_x, v_z))
    samples[-1] = (t_h, float(axis_x), float(axis_y),
                   float(e_altitude_m) - _vertical_state(vertical, t_h)[0], 0.0,
                   _vertical_state(vertical, t_h)[1])

    segments = []
    for (t0, x0, y0, z0, vx0, vz0), (t1, x1, y1, z1, vx1, vz1) in zip(samples, samples[1:]):
        segments.append({
            "phase_type": "SOURCE_EXIT", "phase_id": "E_TO_J_DECELERATION",
            "point0_xyz": [x0, y0, z0], "point1_xyz": [x1, y1, z1],
            "start_s": t0, "end_s": t1,
            "velocity0_xyz": [vx0, 0.0, vz0], "velocity1_xyz": [vx1, 0.0, vz1],
        })
    j_time = t_h
    j_altitude = float(e_altitude_m) - _vertical_state(vertical, t_h)[0]
    j_to_p = float(vertical["duration_s"]) - j_time
    segments.append({
        "phase_type": "V_DESCENT", "phase_id": "VERTICAL_DESCENT",
        "point0_xyz": [float(axis_x), float(axis_y), j_altitude],
        "point1_xyz": [float(axis_x), float(axis_y), float(completion_z_m)],
        "start_s": j_time, "end_s": j_time + j_to_p,
        "velocity0_xyz": [0.0, 0.0, _vertical_state(vertical, j_time)[1]],
        "velocity1_xyz": [0.0, 0.0, vertical["peak_speed_mps"]],
    })

    # Resource windows relative to E.  The first band is entered at t=0.
    offsets: dict[str, tuple[float, float]] = {}
    for resource_id, band in resource_bands.items():
        high, low = float(max(band)), float(min(band))
        enter = 0.0 if high >= float(e_altitude_m) - 1e-9 else _time_at_altitude(
            vertical, float(e_altitude_m) - high)
        exit_ = _time_at_altitude(vertical, float(e_altitude_m) - low)
        if exit_ <= enter - 1e-9:
            raise ValueError(f"E_TO_J_RESOURCE_WINDOW_INVALID:{resource_id}")
        offsets[str(resource_id)] = (enter, exit_)
    first = min(offsets.values(), key=lambda pair: pair[0]) if offsets else None
    if require_first_resource_at_e and first is not None and first[0] > 1e-9:
        raise ValueError("E_TO_J_FIRST_RESOURCE_NOT_ENTERED_AT_E")

    return {
        "version": VERSION,
        "origin": "E",
        "segments": segments,
        "j_offset_s": j_time,
        "j_altitude_m": j_altitude,
        "e_to_j_s": j_time,
        "j_to_p_s": j_to_p,
        "e_to_p_s": j_time + j_to_p,
        "v_e_mps": float(v_e_mps),
        "horizontal_acceleration_mps2": a_h,
        "vertical_profile": dict(vertical),
        "resource_windows_offsets": offsets,
        "completion_z_m": float(completion_z_m),
    }


def to_motion_prediction(template: Mapping[str, Any], *, reference_time_s: float) -> dict[str, Any]:
    """Convert the E-origin template into the SRCM motion-prediction schema."""

    segments = list(template["segments"])
    exits = [row for row in segments if row["phase_type"] == "SOURCE_EXIT"]
    verticals = [row for row in segments if row["phase_type"] == "V_DESCENT"]
    if not exits or not verticals:
        raise ValueError("E_TO_J_PHASES_MISSING")
    path = [list(exits[0]["point0_xyz"])]
    stations = [0.0]
    times = [0.0]
    for row in exits:
        distance = math.dist(path[-1], row["point1_xyz"])
        path.append(list(row["point1_xyz"]))
        stations.append(stations[-1] + distance)
        times.append(float(row["end_s"]))
    return {
        "model_version": "SRCM_PATH_TIME_V1",
        "anchor_time_s": float(reference_time_s),
        "current_state": {"position_xyz": list(exits[0]["point0_xyz"]),
                          "speed_mps": float(template["v_e_mps"])},
        "phases": [
            {"phase_id": "E_TO_J", "phase_type": "SOURCE_EXIT",
             "path_xyz": path, "start_offset_s": 0.0,
             "timing": {"model": "ARC_TIME_TABLE",
                        "arc_stations_m": stations, "elapsed_s": times}},
            {"phase_id": "VERTICAL_DESCENT", "phase_type": "V_DESCENT",
             "path_xyz": [list(verticals[0]["point0_xyz"]), list(verticals[0]["point1_xyz"])],
             "start_offset_s": float(template["j_offset_s"]),
             "timing": {"model": "CONSTANT_SPEED",
                        "speed_mps": float(template["vertical_profile"]["peak_speed_mps"])}},
        ],
    }


def _time_at_altitude(vertical: Mapping[str, Any], dropped_m: float) -> float:
    """Elapsed time at which the vertical profile has dropped ``dropped_m``."""

    ramp_time = float(vertical["ramp_time_s"])
    peak = float(vertical["peak_speed_mps"])
    ramp_drop = 0.5 * peak * ramp_time
    if dropped_m <= ramp_drop + 1e-9:
        acceleration = peak / ramp_time if ramp_time > _TOL else 0.0
        return math.sqrt(2.0 * dropped_m / acceleration) if acceleration > 0 else 0.0
    return ramp_time + (dropped_m - ramp_drop) / peak
