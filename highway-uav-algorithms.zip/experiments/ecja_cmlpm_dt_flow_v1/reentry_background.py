"""Expose a frozen measured ascent as fixed ECJA/SRCM background traffic."""
from dataclasses import replace
import math

from .descent_trajectory import trajectory_state


def build_reentry_fixed_plan(source, state, now_s):
    from ecja_qsap.history_context import build_mainline_fixed_plan
    payload = state.current_motion_plan.get('reentry_profile')
    if payload is None:
        raise ValueError('REENTRY_BACKGROUND_PROFILE_REQUIRED:' + state.uav_id)
    trajectory = payload['trajectory']
    release = float(payload['release_time_s'])
    merge = float(payload['merge_time_s'])
    if now_s >= merge:
        raise ValueError('REENTRY_BACKGROUND_MERGE_NOT_ADVANCED:' + state.uav_id)
    point, speed = trajectory_state(trajectory, max(0., now_s-release))
    merge_state = replace(state, s_m=float(payload['merge_station_m']),
                          speed_mps=float(payload['merge_speed_mps']), current_motion_plan={})
    plan = build_mainline_fixed_plan(source, merge_state, merge)
    phases = []
    for index, segment in enumerate(trajectory['segments']):
        begin = max(float(segment['start_s']), now_s-release, 0.)
        end = float(segment['end_s'])
        if end <= begin:
            continue
        clocks = [begin+(end-begin)*i/4 for i in range(5)]
        points = [list(trajectory_state(trajectory, t)[0]) for t in clocks]
        stations = [0.]
        for a, b in zip(points, points[1:]):
            stations.append(stations[-1]+math.dist(a, b))
        phases.append({'phase_id': state.uav_id+':REENTRY:'+str(index),
            'phase_type': segment['phase_type'], 'path_xyz': points,
            'start_offset_s': release+begin-now_s,
            'timing': {'model': 'ARC_TIME_TABLE', 'arc_stations_m': stations,
                       'elapsed_s': [t-begin for t in clocks]}})
    for phase in plan['motion_prediction']['phases']:
        phases.append({**phase, 'start_offset_s': merge-now_s})
    plan.update(mode='REGISTERED_REENTRY_FIXED_BACKGROUND', activity_start_s=now_s,
                coverage_window=[now_s, plan['activity_end_s']],
                reentry_certificate_id=state.current_motion_plan.get('reentry_certificate_id'),
                energy_episode_id=state.energy_episode_id)
    plan['motion_prediction'] = {'model_version': 'SRCM_PATH_TIME_V1',
        'anchor_time_s': now_s, 'current_state': {'position_xyz': list(point), 'speed_mps': speed},
        'phases': phases}
    return plan
