from __future__ import annotations

from dataclasses import dataclass, replace
from itertools import combinations
import math
from typing import Any, Iterable, Mapping

from .network_loader import RegisteredG25
from .numeric_motion import MotionLimits, stop_start_limits
from .reachable_window import (
    published_reachability_window,
    bounded_reachability_window, ReachabilityError, STATUS_INFEASIBLE_TERMINAL_SPEED,
)
from .route_identity import (
    RouteIdentityError,
    build_route_index,
    resolve_route_identity,
)
from .simulation_state import FlightState, UAVState
from traffic_simulation.cmlpm.active import build_complete_snapshot


SNAPSHOT_ADAPTER_VERSION = "G25_DT_FLOW_NODE_SNAPSHOT_V1"
D2_SCENARIO_ID = "D2_UNIFORM_DESCENT_3MPS_RESEARCH_V2"
MAX_COMMITTED_TIME_RECONCILIATION_S = 2e-6


def _canonicalize_committed_time(
    value: float | None,
    *,
    lower_s: float,
    upper_s: float,
    uav_id: str,
    event_id: str,
) -> float | None:
    """Snap an authenticated event to a numerically adjacent window edge.

    Motion execution owns the already-certified time.  This helper only
    removes representation residue when that time is within the same numeric
    tolerance used by the C-MLPM input checker; a real window violation still
    fails closed.
    """

    if value is None:
        return None
    value = float(value)
    lower_s = float(lower_s)
    upper_s = float(upper_s)
    if lower_s <= value <= upper_s:
        return value
    if value < lower_s and lower_s - value <= MAX_COMMITTED_TIME_RECONCILIATION_S:
        return lower_s
    if value > upper_s and value - upper_s <= MAX_COMMITTED_TIME_RECONCILIATION_S:
        return upper_s
    raise ValueError(
        f"COMMITTED_TIME_OUTSIDE_WINDOW:{uav_id}:{event_id}:{value}!="
        f"[{lower_s},{upper_s}]"
    )


@dataclass(frozen=True)
class DescentObservation:
    uav_id: str
    vehicle_type: str
    source_layer: str
    fifo_rank: float
    earliest_control_s: float | None
    latest_control_s: float | None
    # Fixed realization-layer duration after the sole C-MLPM decision event E.
    committed_e_time_s: float | None = None
    e_to_j_s: float | None = None
    fifo_queue_id: str | None = None
    time_domain_reason: str | None = None
    nominal_control_s: float | None = None


@dataclass(frozen=True)
class MainlineObservation:
    uav_id: str
    source_layer: str
    nominal_resource_entry_s: float
    resource_duration_s: float
    max_delay_s: float
    resource_id: str | None = None
    resource_entry_time_lb_s: float | None = None
    resource_entry_time_ub_s: float | None = None
    allowed_exit_time_ub_s: float | None = None
    committed_resource_entry_s: float | None = None
    committed_resource_exit_s: float | None = None
    committed_prefix_source: str | None = None


def _actual_uses_by_uav(
    rows: Iterable[Mapping[str, Any]],
) -> dict[str, tuple[Mapping[str, Any], ...]]:
    grouped: dict[str, list[Mapping[str, Any]]] = {}
    for row in rows:
        grouped.setdefault(str(row["uav_id"]), []).append(row)
    return {
        uav_id: tuple(sorted(items, key=lambda item: (int(item.get("route_order", 0)), str(item["use_id"]))))
        for uav_id, items in grouped.items()
    }


def _observations_from_traffic_states(
    network: RegisteredG25,
    *,
    node_id: str,
    t_now: float,
    t_commit: float,
    traffic_states: Iterable[UAVState],
    motion_limits_by_type: Mapping[str, MotionLimits],
    actual_resource_uses: Iterable[Mapping[str, Any]],
    allow_waiting: bool = False,
    latest_time_s: float | None = None,
    h_latest_time_s: float | None = None,
    replan_existing_v_ids: Iterable[str] = (),
    static_context=None,
) -> tuple[tuple[DescentObservation, ...], tuple[MainlineObservation, ...]]:
    """Convert current directed traffic state into C-MLPM observations.

    A state committed to ``node_id`` is a vertical request; every other state
    supplied for this node is protected mainline traffic.  Event bounds come
    from the bounded-acceleration reachability model, never from SRCM ETAs.
    """

    uses_by_uav = _actual_uses_by_uav(actual_resource_uses)
    route_index = static_context.routes if static_context else build_route_index(network)
    replan_existing_v_ids = {str(value) for value in replan_existing_v_ids}
    fallback_fifo_ranks = {
        state.uav_id: float(rank)
        for layer in {state.layer for state in traffic_states}
        for rank, state in enumerate(sorted(
            (item for item in traffic_states if item.layer == layer),
            key=lambda item: (-float(item.s_m), item.uav_id),
        ))
    }
    descents: list[DescentObservation] = []
    mainline: list[MainlineObservation] = []
    for state in traffic_states:
        limits = motion_limits_by_type.get(state.vehicle_type)
        if limits is None:
            raise ValueError(f"MISSING_MOTION_LIMITS:{state.vehicle_type}")
        interface = _interface(network, node_id, state.layer, static_context)
        if str(interface["direction"]) != state.direction:
            raise ValueError(f"TRAFFIC_DIRECTION_NODE_MISMATCH:{state.uav_id}")
        plan = state.current_motion_plan
        source_state_id = f"{state.uav_id}:event-version:{state.event_version}"
        frozen_nonrelease = (
            state.commit_status == "FROZEN"
            and state.state in {FlightState.DEFERRED, FlightState.MOTION_INFEASIBLE}
        )
        if state.assigned_node == node_id and not frozen_nonrelease:
            if (str(getattr(state.state, "value", state.state)) in {"TRANSITION", "VERTICAL"}
                    and state.uav_id not in replan_existing_v_ids):
                raise ValueError(f"MISSING_EXISTING_V_CONTINUATION:{state.uav_id}")
            if not state.assigned_route:
                raise ValueError(f"SELECTED_ROUTE_NODE_MISSING:{state.uav_id}")
            try:
                resolved_route = resolve_route_identity(
                    network,
                    state.assigned_route,
                    node_id=node_id,
                    direction=state.direction,
                    source_layer=state.layer,
                    index=route_index,
                )
            except RouteIdentityError as exc:
                raise ValueError(
                    f"SELECTED_ROUTE_NODE_MISMATCH:{state.uav_id}:{exc.code}"
                ) from exc
            if resolved_route.interface_id != str(interface["interface_id"]):
                raise ValueError(f"SELECTED_ROUTE_NODE_MISMATCH:{state.uav_id}")
            entry_station = plan.get("resource_entry_station_m", plan.get("e_station_m"))
            if entry_station is None:
                raise ValueError(f"ASSIGNMENT_RESOURCE_ENTRY_MISSING:{state.uav_id}")
            entry_station = float(entry_station)
            # A failed/rejected active plan may be observed after the old E
            # station has already been crossed.  The old target is discarded
            # for this round, so the new reachability problem starts at the
            # measured position rather than passing a negative distance to
            # the stop/start envelope.
            remaining = max(0.0, entry_station - float(state.s_m))
            entry_speed = min(
                float(plan.get("e_entry_speed_mps", 7.0)),
                float(limits.max_speed_mps),
            )
            # The request may be observed while the thin executor is braking
            # after a failed handoff.  Its instantaneous speed can be below
            # the nominal cruise floor; that is a valid measured state and
            # must not be rejected before the E-time optimization.
            observed_speed = max(1e-6, float(state.speed_mps))
            effective_v_min = min(
                float(entry_speed),
                float(stop_start_limits(state, limits).min_speed_mps),
                observed_speed,
            )
            domain_reason = None
            try:
                window = published_reachability_window(state,
                    t_now=t_now,
                    length_m=remaining,
                    v_now=float(state.speed_mps),
                    v_min=effective_v_min,
                    v_max=limits.max_speed_mps,
                    a_max=limits.max_abs_acceleration_mps2,
                    b_max=limits.max_abs_acceleration_mps2,
                    v_terminal=entry_speed,
                    source_state_id=source_state_id,
                    allow_stop_start=stop_start_limits(state,limits).min_speed_mps == 0.,
                    latest_time_s=latest_time_s,
                )
                if not window.feasible and window.failure_code != "EMPTY_EVENT_TIME_DOMAIN":
                    raise ReachabilityError(window.failure_code or window.status, state.uav_id)
                if not window.feasible:
                    domain_reason = window.failure_code or window.status
            except ReachabilityError as error:
                # Only a proved physical empty domain can become wait-only.
                # Invalid inputs/unknown numerical failures remain errors.
                if not allow_waiting or error.code != STATUS_INFEASIBLE_TERMINAL_SPEED:
                    raise
                window = None
                domain_reason = error.code
            e_to_j = plan.get("e_to_j_s")
            if e_to_j is None or float(e_to_j) <= 0:
                raise ValueError(f"MISSING_FIXED_E_TO_J_TIME:{state.uav_id}")
            fifo_rank = plan.get("fifo_rank")
            if fifo_rank is None and state.uav_id in replan_existing_v_ids:
                fifo_rank = fallback_fifo_ranks[state.uav_id]
            if fifo_rank is None:
                raise ValueError(f"MISSING_AUTHORITATIVE_FIFO:{state.uav_id}")
            descents.append(DescentObservation(
                uav_id=state.uav_id,
                vehicle_type=state.vehicle_type,
                source_layer=state.layer,
                fifo_rank=float(fifo_rank),
                earliest_control_s=None if window is None else window.t_lb,
                latest_control_s=None if window is None else window.t_ub,
                committed_e_time_s=(None if state.uav_id in replan_existing_v_ids
                                    else plan.get("committed_e_time_s")),
                e_to_j_s=float(e_to_j),
                fifo_queue_id=str(plan.get("fifo_queue_id", f"{node_id}:{state.layer}")),
                time_domain_reason=domain_reason,
                # Feasible requests already use the necessary lower bound.
                # Empty-domain waiting has no predicted executable E time;
                # use the existing nominal-distance proxy, with any previous
                # request baseline inherited unchanged below.
                nominal_control_s=(window.t_lb if window is not None else
                    t_now+remaining/float(state.nominal_speed_mps or limits.max_speed_mps)),
            ))
        else:
            mainline_uses = tuple(row for row in uses_by_uav.get(state.uav_id, ()) if row.get("role") == "M")
            if len(mainline_uses) != 1:
                raise ValueError(f"MISSING_ACTUAL_MAINLINE_RESOURCE_USE:{state.uav_id}")
            use = mainline_uses[0]
            if use.get("anchor_event_id") not in {f"{state.uav_id}:resource", f"{state.uav_id}:E"} or abs(float(use["start_offset"])) > 1e-12:
                raise ValueError(f"ACTUAL_MAINLINE_RESOURCE_ANCHOR_INVALID:{state.uav_id}")
            station = plan.get("resource_entry_station_m")
            if station is None:
                raise ValueError(f"MISSING_RESOURCE_ENTRY_STATION:{state.uav_id}")
            duration = float(use["end_offset"]) - float(use["start_offset"])
            nominal_speed = state.nominal_speed_mps
            if nominal_speed is None or float(nominal_speed) <= 0:
                raise ValueError(f"MISSING_NORMAL_CRUISE_SPEED:{state.uav_id}")
            nominal_entry = t_now + (float(station) - float(state.s_m)) / float(nominal_speed)
            nominal_exit = nominal_entry + duration
            allowed_exit_ub = plan.get("allowed_exit_time_ub_s")
            if allowed_exit_ub is None:
                raise ValueError(f"MISSING_ALLOWED_EXIT_TIME_UB:{state.uav_id}")
            allowed_exit_ub = float(allowed_exit_ub)
            committed_entry = None
            committed_exit = None
            committed_source = None
            if plan.get("committed_resource_entry_s") is not None:
                committed_entry=float(plan["committed_resource_entry_s"])
                committed_exit=float(plan["committed_resource_exit_s"])
                if abs((committed_exit-committed_entry)-duration)>1e-6:
                    raise ValueError(f"H_COMMITTED_OCCUPANCY_DURATION_MISMATCH:{state.uav_id}")
                committed_source="CERTIFIED_TIMED_SPEED_CURVE"
            if committed_entry is not None:
                # A fixed historical target is not a current reachability
                # assertion or a new decision. Keep its exact original value.
                # These singleton bounds represent the committed target only;
                # actual deviations are measured by the execution auditor.
                entry_lb, entry_ub = committed_entry, committed_entry
                nominal_entry=committed_entry
                nominal_exit=committed_exit
                allowed_exit_ub=committed_exit
                committed_source = "PUBLISHED_TARGET_NOT_REACHABILITY_PROOF"
            else:
                if h_latest_time_s is None:
                    entry_lb = float(plan["h_entry_time_lb_s"])
                    entry_ub = float(plan["h_entry_time_ub_s"])
                else:
                    window = bounded_reachability_window(
                        t_now=t_now, length_m=float(station) - float(state.s_m),
                        v_now=float(state.speed_mps),
                        v_min=min(float(limits.min_speed_mps), max(1e-6, float(state.speed_mps))),
                        v_max=limits.max_speed_mps, a_max=limits.max_abs_acceleration_mps2,
                        b_max=limits.max_abs_acceleration_mps2, source_state_id=source_state_id,
                        allow_stop_start=stop_start_limits(state,limits).min_speed_mps == 0.,
                        latest_time_s=h_latest_time_s,
                    )
                    entry_lb, entry_ub = window.t_lb, window.t_ub
                if not max(nominal_exit, entry_lb + duration) - 1e-9 <= allowed_exit_ub <= entry_ub + duration + 1e-9:
                    raise ValueError(f"INVALID_ALLOWED_EXIT_TIME_UB:{state.uav_id}")
            mainline.append(MainlineObservation(
                state.uav_id,
                state.layer,
                nominal_entry,
                duration,
                allowed_exit_ub - nominal_exit,
                str(use["resource_id"]),
                entry_lb,
                entry_ub,
                allowed_exit_ub,
                committed_entry,
                committed_exit,
                committed_source,
            ))
    return tuple(descents), tuple(mainline)


def _interface(network: RegisteredG25, node_id: str, layer: str, static_context=None) -> dict[str, Any]:
    if static_context is not None:
        return static_context.interfaces[(node_id, layer)]
    matches = [
        item for item in network.interfaces
        if item["service_node_id"] == node_id and item["source_layer"] == layer
    ]
    if len(matches) != 1:
        raise ValueError(f"G25_INTERFACE_CARDINALITY:{node_id}:{layer}:{len(matches)}")
    return dict(matches[0])


def _transition_duration_s(interface: dict[str, Any]) -> float:
    route = interface["route_template"]
    speed = float(route["ellipse_speed"])
    lengths = (
        float(interface["prefix_path"]["length_m"]),
        float(interface["controlled_approach_path"]["length_m"]),
        float(interface["transition_path"]["length_m"]),
    )
    if speed <= 0 or any(value <= 0 for value in lengths):
        raise ValueError("ROUTE_TIME_UNAVAILABLE")
    return sum(lengths) / speed


def _resource_lengths(network: RegisteredG25) -> dict[str, float]:
    return {str(item["resource_id"]): float(item["length_m"]) for item in network.resources}


def build_node_snapshot_payload(
    network: RegisteredG25,
    *,
    node_id: str,
    t_now: float,
    dt_s: float,
    evaluation_time_bounds: Mapping[str, float],
    input_mode: str = "real_traffic",
    traffic_states: Iterable[UAVState] | None = None,
    motion_limits_by_type: Mapping[str, MotionLimits] | None = None,
    actual_resource_uses: Iterable[Mapping[str, Any]] | None = None,
    actual_vv_constraints: Iterable[Mapping[str, Any]] | None = None,
    actual_vh_separation: Mapping[str, Mapping[str, Any]] | None = None,
    frozen_reservations: Iterable[dict[str, Any]] | None = None,
    frozen_vv_constraints: Iterable[dict[str, Any]] | None = None,
    existing_v_continuations: Iterable[Any] | None = None,
    replan_existing_v_ids: Iterable[str] = (),
    frozen_mainline_e_times: Mapping[str, float] | None = None,
    min_mainline_gap_m: float = 50.,
    runtime_provenance: Mapping[str, Any] | None = None,
    following_traffic_states: Iterable[UAVState] | None = None,
    waiting_next_check_s: float | None = None,
    waiting_parameters: Mapping[str, Any] | None = None,
    static_context=None,
) -> dict[str, Any]:
    """Construct the current model from one physical state and immutable commitments.

    Kinematic windows, zero-gap FIFO, dynamic necessary relations and shared
    resource safety have distinct contracts. Waiting retains the request;
    aircraft confirmation is required before any atomic publication.
    """
    if static_context is not None:
        static_context.require_network(network)
        network = static_context.network
    if input_mode != "real_traffic":
        raise ValueError("HISTORICAL_PARAMETRIC_INPUT_FORBIDDEN")
    required_time_fields = ("t_commit",)
    missing_time_fields = [key for key in required_time_fields if key not in evaluation_time_bounds]
    if missing_time_fields:
        raise ValueError(f"MISSING_APPROVED_EVALUATION_TIME:{','.join(missing_time_fields)}")
    t_commit = float(evaluation_time_bounds["t_commit"])
    t_request = float(evaluation_time_bounds["t_request"]) if "t_request" in evaluation_time_bounds else None
    t_clear = float(evaluation_time_bounds["t_clear"]) if "t_clear" in evaluation_time_bounds else None
    if not all(math.isfinite(value) for value in (t_now, t_commit)) or (
        t_request is not None and not math.isfinite(t_request)
    ) or (
        t_clear is not None and not math.isfinite(t_clear)
    ):
        raise ValueError("NONFINITE_APPROVED_EVALUATION_TIME")
    if not t_now <= t_commit or (t_request is not None and t_commit > t_request) or (
        t_clear is not None and (t_request if t_request is not None else t_commit) > t_clear
    ):
        raise ValueError("INVALID_APPROVED_EVALUATION_TIME_ORDER")

    if traffic_states is None:
        raise ValueError("MISSING_AUTHORITATIVE_TRAFFIC_SNAPSHOT")
    traffic_states = tuple(traffic_states or ())
    physical_states = tuple(following_traffic_states) if following_traffic_states is not None else traffic_states
    replan_existing_v_ids = {str(value) for value in replan_existing_v_ids}
    supplied_uses = tuple(actual_resource_uses or ())
    continuations: tuple[Any, ...] = ()
    continued_ids: set[str] = set()
    frozen_mainline: tuple[UAVState, ...] = ()
    if motion_limits_by_type is None:
        raise ValueError("MISSING_MOTION_LIMITS")
    if any(value is None for value in (actual_resource_uses, actual_vv_constraints, actual_vh_separation)):
        raise ValueError("MISSING_ACTUAL_RESOURCE_OR_SAFETY_CONTRACT")
    if frozen_reservations is None or frozen_vv_constraints is None:
        raise ValueError("MISSING_ACTUAL_FROZEN_LEDGER_CONTRACT")
    frozen_reservations = tuple(frozen_reservations)
    required_provenance = {
        "state_version", "state_semantic_sha256", "srcm_state_version",
        "kinematic_state_version", "safety_state_version", "frozen_ledger_version",
        "srcm_evaluation_id", "motion_parameter_source", "fifo_source",
        "input_generation_version",
    }
    if runtime_provenance is None:
        raise ValueError("MISSING_RUNTIME_INPUT_PROVENANCE")
    missing_provenance = sorted(required_provenance - set(runtime_provenance))
    if missing_provenance:
        raise ValueError(f"MISSING_RUNTIME_INPUT_PROVENANCE:{','.join(missing_provenance)}")
    state_version = int(runtime_provenance["state_version"])
    branch_versions = {
        int(runtime_provenance["srcm_state_version"]),
        int(runtime_provenance["kinematic_state_version"]),
        int(runtime_provenance["safety_state_version"]),
    }
    if branch_versions != {state_version}:
        raise ValueError("RUNTIME_INPUT_STATE_VERSION_MISMATCH")
    continuations = tuple(existing_v_continuations or ())
    for item in continuations:
        if item.node_id != node_id:
            raise ValueError(f"EXISTING_V_CONTINUATION_NODE_MISMATCH:{item.uav_id}")
        if int(item.state_version) != state_version:
            raise ValueError(
                f"EXISTING_V_CONTINUATION_STATE_VERSION_MISMATCH:{item.uav_id}"
            )
        continued_ids.add(item.uav_id)
    frozen_mainline = tuple(s for s in traffic_states
        if s.uav_id in continued_ids and s.state == FlightState.SCHEDULED
        and s.uav_id in (frozen_mainline_e_times or {})
        and float(frozen_mainline_e_times[s.uav_id]) >= t_now-1e-9)
    if continued_ids & {row.uav_id for row in traffic_states}:
        # A continued UAV is protected through its frozen occupancy; it is
        # never re-read as an optimizable new V or re-counted as node H.
        traffic_states = tuple(
            row for row in traffic_states if row.uav_id not in continued_ids
        )
    descents, mainline = _observations_from_traffic_states(
        network,
        node_id=node_id,
        t_now=t_now,
        t_commit=t_commit,
        traffic_states=traffic_states,
        motion_limits_by_type=motion_limits_by_type,
        actual_resource_uses=supplied_uses,
        allow_waiting=waiting_next_check_s is not None,
        latest_time_s=t_request,
        h_latest_time_s=t_clear,
        replan_existing_v_ids=replan_existing_v_ids,
        static_context=static_context,
    )
    # A replan can combine an old published rank with newly reconstructed
    # rows.  The solver contract requires ranks to be unique within each FIFO
    # queue; preserve all ranks when they are already valid, and repair only
    # the affected queue using the current physical order (front first).
    state_by_id = {state.uav_id: state for state in traffic_states}
    by_queue: dict[str, list[DescentObservation]] = {}
    for item in descents:
        queue_id = str(item.fifo_queue_id or f"{node_id}:{item.source_layer}")
        by_queue.setdefault(queue_id, []).append(item)
    repaired_descents = list(descents)
    for queue_rows in by_queue.values():
        ranks = [float(item.fifo_rank) for item in queue_rows]
        if len(ranks) == len(set(ranks)) and all(math.isfinite(rank) and rank >= 0.0 for rank in ranks):
            continue
        ordered = sorted(
            queue_rows,
            key=lambda item: (
                -float(state_by_id[item.uav_id].s_m)
                if item.uav_id in state_by_id else math.inf,
                item.uav_id,
            ),
        )
        repaired = {
            item.uav_id: replace(item, fifo_rank=float(rank))
            for rank, item in enumerate(ordered)
        }
        repaired_descents = [repaired.get(item.uav_id, item) for item in repaired_descents]
    descents = tuple(repaired_descents)
    if dt_s <= 0:
        raise ValueError("INVALID_NUMERICAL_SNAPSHOT_PARAMETER")
    if len({item.uav_id for item in descents}) != len(descents):
        raise ValueError("DUPLICATE_DESCENT_UAV")
    if {item.uav_id for item in descents} & {item.uav_id for item in mainline}:
        raise ValueError("PHYSICAL_UAV_DUPLICATED_AS_V_AND_H")

    resource_lengths = static_context.resource_lengths if static_context else _resource_lengths(network)
    events: list[dict[str, Any]] = []
    arcs: list[dict[str, Any]] = []
    descent_rows: list[dict[str, Any]] = []
    mainline_rows: list[dict[str, Any]] = []
    uses: list[dict[str, Any]] = []
    legal_paths: dict[str, list[str]] = {}
    empty_domains: dict[str, dict[str, Any]] = {}

    # Stop/start can make the physical upper bound infinite. Give the MILP
    # finite variable domains using the current events and their separations.
    # The bound allows serialization after all existing traffic obligations.
    if t_request is None:
        latest_fixed = max(
            [t_commit]
            + [x for item in descents for x in (item.earliest_control_s, item.latest_control_s,
                                               item.committed_e_time_s)
               if x is not None and math.isfinite(x)]
            + [item.allowed_exit_time_ub_s for item in mainline if item.allowed_exit_time_ub_s is not None]
            + [float(row["occupancy_end"]) for row in frozen_reservations]
            + [float(row["occupancy_end"]) for item in continuations for row in item.frozen_reservations]
        )
        gaps = [float(row[key]) for row in actual_vv_constraints
                for key in ("first_before_second_gap", "second_before_first_gap")]
        gaps.extend(float(row[key]) for row in actual_vh_separation.values()
                    for key in ("first_to_second", "second_to_first"))
        serial_time = sum(max(abs(float(row["start_offset"])), abs(float(row["end_offset"])))
                          for row in supplied_uses)
        # A same-lane departure condition includes time to recover 50 m.
        slowest = min(limit.max_speed_mps for limit in motion_limits_by_type.values())
        weakest = min(limit.max_abs_acceleration_mps2 for limit in motion_limits_by_type.values())
        following_allowance = float(min_mainline_gap_m)/slowest + slowest/weakest
        finite_e_upper = latest_fixed + serial_time + max(1, len(descents)) * (
            max([2.5, *gaps]) + following_allowance + dt_s)

    for item in descents:
        interface = _interface(network, node_id, item.source_layer, static_context)
        registered_chain = [str(value) for value in interface["route_template"]["resource_chain"]]
        chain = list(registered_chain)
        vertical_uses = tuple(row for row in supplied_uses
                             if row["uav_id"] == item.uav_id and row["role"] == "V")
        if item.uav_id in replan_existing_v_ids and vertical_uses:
            chain = [str(row["resource_id"]) for row in sorted(
                vertical_uses, key=lambda row: int(row.get("route_order", 0)))]
        if any(resource_id not in resource_lengths for resource_id in chain):
            raise ValueError("INCOMPLETE_REGISTERED_RESOURCE_CHAIN")
        existing = legal_paths.setdefault(item.source_layer, registered_chain)
        if existing != registered_chain:
            raise ValueError("LAYER_PATH_DRIFT_WITHIN_NODE")
        transition_s = float(item.e_to_j_s) if item.e_to_j_s is not None else _transition_duration_s(interface)
        entry_id = f"{item.uav_id}:control"
        # E is the sole C-MLPM timing event.  Upstream G and downstream J are
        # implementation-layer geometry, never solver events.
        e_id = f"{item.uav_id}:E"
        if item.earliest_control_s is not None and item.latest_control_s is not None:
            latest_control = (finite_e_upper if t_request is None and item.latest_control_s == math.inf
                              else float(item.latest_control_s))
            if not all(math.isfinite(x) for x in (item.earliest_control_s, latest_control)):
                raise ValueError(f"NONFINITE_DESCENT_TIME_DOMAIN:{item.uav_id}")
            control_time = max(float(item.earliest_control_s), t_now + dt_s)
        else:
            control_time = latest_control = None
        empty = (item.time_domain_reason is not None or control_time is None
                 or control_time > latest_control)
        if empty:
            if waiting_next_check_s is None or item.committed_e_time_s is not None:
                raise ValueError(f"EMPTY_EVENT_TIME_DOMAIN:{item.uav_id}:{item.time_domain_reason}")
            empty_domains[item.uav_id] = {
                "status": "EMPTY", "reason": item.time_domain_reason or "EMPTY_EVENT_TIME_DOMAIN",
                "original_lower_s": item.earliest_control_s, "original_upper_s": item.latest_control_s,
                "effective_lower_s": control_time, "certification_level": "NECESSARY_ONLY"}
        e_lb, e_ub = control_time, latest_control
        committed_e = item.committed_e_time_s
        committed_lb, committed_ub = e_lb, e_ub
        if committed_e is not None and not committed_lb <= committed_e <= committed_ub:
            raise ValueError(f"COMMITTED_E_OUTSIDE_REACHABLE_WINDOW:{item.uav_id}")
        if not empty:
            events.extend((
                {"event_id": entry_id, "uav_id": item.uav_id, "phase": "MAINLINE", "section_id": item.source_layer,
                 "time_lb": t_now, "time_ub": t_now, "nominal_time": t_now, "activation": "completion", "resource_id": None, "committed_time": t_now},
                {"event_id": e_id, "uav_id": item.uav_id, "phase": "RESOURCE_ENTRY", "section_id": chain[0],
                 "time_lb": e_lb, "time_ub": e_ub, "nominal_time": e_lb, "activation": "completion", "resource_id": chain[0], "committed_time": committed_e},
            ))
            arcs.extend((
                    {"uav_id": item.uav_id, "predecessor_id": entry_id, "successor_id": e_id,
                     "travel_min": control_time - t_now, "travel_max": latest_control - t_now},
            ))
        ordered_resources = [row["resource_id"] for row in sorted(vertical_uses, key=lambda row: int(row.get("route_order", 0)))]
        if ordered_resources != chain:
            raise ValueError(f"ACTUAL_RESOURCE_PATH_MISMATCH:{item.uav_id}")
        expected_anchor = e_id
        if any(row["anchor_event_id"] != expected_anchor for row in vertical_uses):
            raise ValueError(f"ACTUAL_RESOURCE_ANCHOR_NOT_E:{item.uav_id}")
        offset = max(float(row["end_offset"]) for row in vertical_uses)
        descent_rows.append(
            {"uav_id": item.uav_id, "source_layer": item.source_layer, "entry_event_id": e_id,
             "service_offset": offset,
             "nominal_service_time": (control_time if not empty else
                                      item.nominal_control_s if item.nominal_control_s is not None
                                      else float(item.earliest_control_s)) + offset,
             "fifo_rank": item.fifo_rank,
             "fifo_queue_id": item.fifo_queue_id or f"{node_id}:{item.source_layer}"}
        )

    mainline_by_resource: dict[str, list[MainlineObservation]] = {}
    for item in mainline:
        interface = _interface(network, node_id, item.source_layer, static_context)
        resource_id = item.resource_id or str(interface["route_template"]["resource_chain"][0])
        entry_id = f"{item.uav_id}:entry"
        supplied_mainline_uses = tuple(row for row in supplied_uses
                                       if row["uav_id"] == item.uav_id and row["role"] == "M")
        legacy_resource_anchor = bool(supplied_mainline_uses) and all(
            row["anchor_event_id"] == f"{item.uav_id}:resource"
            for row in supplied_mainline_uses
        )
        resource_event = f"{item.uav_id}:resource" if legacy_resource_anchor else f"{item.uav_id}:E"
        out_id = f"{item.uav_id}:out"
        eta = float(item.nominal_resource_entry_s)
        duration = float(item.resource_duration_s)
        resource_lb = float(item.resource_entry_time_lb_s) if item.resource_entry_time_lb_s is not None else eta
        resource_ub = (
            float(item.resource_entry_time_ub_s)
            if item.resource_entry_time_ub_s is not None
            else eta + float(item.max_delay_s)
        )
        nominal_exit = eta + duration
        allowed_exit_ub = (
            float(item.allowed_exit_time_ub_s)
            if item.allowed_exit_time_ub_s is not None
            else nominal_exit + float(item.max_delay_s)
        )
        max_delay = allowed_exit_ub - nominal_exit
        historical_target = item.committed_prefix_source == "PUBLISHED_TARGET_NOT_REACHABILITY_PROOF"
        origin_time = min(t_now,resource_lb) if historical_target else t_now
        if ((resource_lb < t_now and not historical_target) or duration <= 0 or resource_ub < resource_lb
                or max_delay < 0
                or allowed_exit_ub < resource_lb + duration - 1e-9
                or allowed_exit_ub > resource_ub + duration + 1e-9):
            raise ValueError(f"INVALID_MAINLINE_OBSERVATION:{item.uav_id}")
        events.extend(
            (
                {"event_id": entry_id, "uav_id": item.uav_id, "phase": "MAINLINE", "section_id": item.source_layer,
                 "time_lb": origin_time, "time_ub": origin_time, "nominal_time": origin_time, "activation": "always", "resource_id": None, "committed_time": origin_time},
                {"event_id": resource_event, "uav_id": item.uav_id, "phase": "MAINLINE", "section_id": resource_id,
                 "time_lb": resource_lb, "time_ub": resource_ub, "nominal_time": eta, "activation": "always", "resource_id": resource_id,
                 "committed_time": item.committed_resource_entry_s},
                {"event_id": out_id, "uav_id": item.uav_id, "phase": "MAINLINE", "section_id": "OUT",
                 "time_lb": resource_lb + duration, "time_ub": resource_ub + duration, "nominal_time": nominal_exit,
                 "activation": "always", "resource_id": None, "committed_time": item.committed_resource_exit_s},
            )
        )
        arcs.extend(
            (
                {"uav_id": item.uav_id, "predecessor_id": entry_id, "successor_id": resource_event,
                 "travel_min": resource_lb - origin_time, "travel_max": resource_ub - origin_time},
                {"uav_id": item.uav_id, "predecessor_id": resource_event, "successor_id": out_id,
                 "travel_min": duration, "travel_max": duration},
            )
        )
        mainline_rows.append(
            {"uav_id": item.uav_id, "exit_event_id": out_id,
             "nominal_exit_time": nominal_exit, "max_delay": max_delay}
        )
        mainline_by_resource.setdefault(resource_id, []).append(item)

    paths_by_uav = {
        item.uav_id: set(_interface(network, node_id, item.source_layer, static_context)["route_template"]["resource_chain"])
        for item in descents
    }
    committed_mainline = {
        item.uav_id: item for item in mainline
        if item.committed_prefix_source is not None
    }
    committed_mainline_reservations: list[dict[str, Any]] = []
    mainline_rows = [
        row for row in mainline_rows if row["uav_id"] not in committed_mainline
    ]
    uses = [
        dict(row) for row in supplied_uses
        if not (row["role"] == "M" and row["uav_id"] in committed_mainline)
    ]
    for uav_id, item in committed_mainline.items():
        resource_id = item.resource_id or str(
            _interface(network, node_id, item.source_layer, static_context)["route_template"]["resource_chain"][0]
        )
        committed_mainline_reservations.append({
            "reservation_id": f"{uav_id}:{resource_id}:COMMITTED_MAINLINE_PREFIX",
            "uav_id": uav_id,
            "resource_id": resource_id,
            "role": "M",
            "occupancy_start": item.committed_resource_entry_s,
            "occupancy_end": item.committed_resource_exit_s,
            "version": item.committed_prefix_source,
            "source_layer": item.source_layer,
        })
    # A published H is deliberately absent from ``mainline`` above: it must
    # not re-enter the decision set.  Its frozen resource reservation still
    # needs a fixed resource-entry event, however.  The event is the bridge
    # by which the next round can reconstruct H/H FIFO and the necessary
    # dynamic-following relations against newly scheduled aircraft.
    physical_by_id = {state.uav_id: state for state in physical_states}
    existing_mainline_events = {
        (event["uav_id"], event["resource_id"]): event
        for event in events
        if event.get("phase") == "MAINLINE" and event.get("resource_id") is not None
    }
    fixed_mainline_event_rows: list[dict[str, Any]] = []
    for reservation in frozen_reservations:
        if reservation.get("role") != "M":
            continue
        uav_id = str(reservation["uav_id"])
        resource_id = str(reservation["resource_id"])
        state = physical_by_id.get(uav_id)
        if state is None:
            raise ValueError(f"FIXED_MAINLINE_STATE_MISSING:{uav_id}")
        occupancy_start = float(reservation["occupancy_start"])
        occupancy_end = float(reservation["occupancy_end"])
        if (not math.isfinite(occupancy_start) or not math.isfinite(occupancy_end)
                or occupancy_end <= occupancy_start):
            raise ValueError(f"INVALID_FIXED_MAINLINE_RESERVATION:{uav_id}:{resource_id}")
        entry_station = state.current_motion_plan.get("resource_entry_station_m")
        if entry_station is None or not math.isfinite(float(entry_station)):
            raise ValueError(f"MISSING_RESOURCE_ENTRY_STATION:{uav_id}")

        existing = existing_mainline_events.get((uav_id, resource_id))
        if existing is not None:
            committed_time = existing.get("committed_time")
            if (committed_time is None
                    or not math.isclose(float(committed_time), occupancy_start,
                                        rel_tol=0.0, abs_tol=MAX_COMMITTED_TIME_RECONCILIATION_S)):
                raise ValueError(f"FIXED_MAINLINE_EVENT_CONFLICT:{uav_id}:{resource_id}")
            continue

        event_id = f"{uav_id}:fixed-mainline:{resource_id}:entry"
        if any(event["event_id"] == event_id for event in events):
            raise ValueError(f"DUPLICATE_FIXED_MAINLINE_EVENT:{event_id}")
        event = {
            "event_id": event_id,
            "uav_id": uav_id,
            "phase": "MAINLINE",
            "section_id": str(reservation.get("source_layer") or resource_id),
            "time_lb": occupancy_start,
            "time_ub": occupancy_start,
            "nominal_time": occupancy_start,
            "activation": "always",
            "resource_id": resource_id,
            "committed_time": occupancy_start,
        }
        events.append(event)
        fixed_mainline_event_rows.append({
            "event_id": event_id,
            "uav_id": uav_id,
            "resource_id": resource_id,
            "committed_time_s": occupancy_start,
            "occupancy_end_s": occupancy_end,
            "source": reservation.get("version"),
        })
    vv = [dict(row) for row in actual_vv_constraints or ()]

    roles: dict[str, set[str]] = {}
    for row in uses:
        roles.setdefault(row["resource_id"], set()).add(row["role"])
    vh = {str(key): dict(value) for key, value in (actual_vh_separation or {}).items()}
    payload = {
        "node_id": node_id, "t_now": t_now, "t_commit": t_commit,
        **({"t_request": t_request} if t_request is not None else {}),
        **({"t_clear": t_clear} if t_clear is not None else {}),
        "events": events, "arcs": arcs, "descents": descent_rows,
        "mainline_flows": mainline_rows, "resource_uses": uses,
        "mainline_fifo": [], "vv_constraints": vv, "vh_separation": vh,
        "frozen_reservations": [
            *list(frozen_reservations or ()),
            *committed_mainline_reservations,
            *(row for item in continuations for row in item.frozen_reservations),
        ],
        "frozen_vv_constraints": list(frozen_vv_constraints or ()),
        "lambda_v": 1.0, "lambda_h": 1.0, "tolerance": 2e-6,
        "srcm_version": "SRCM_CROSSING_V3_0_1",
        "metadata": {
            "legal_paths": legal_paths,
            "adapter_version": "REAL_TRAFFIC_REACHABILITY_V1",
            "network_contract": network.contract_version,
            "network_geometry_hash": network.geometry_hash,
            "d2_scenario_id": D2_SCENARIO_ID,
            "vertical_speed_mps": 3.0,
            "parameter_status": "AUTHORITATIVE_RUNTIME_INPUT",
            "interval_includes_guard": True,
            "additional_guard_s": 0.0,
            "q_event_semantics": "LEGACY_ALIAS_ONLY",
            "entry_event_semantics": "E_SHARED_RESOURCE_ENTRY_PRIMARY",
            "g_event_in_cmlpm": False,
            "j_event_in_cmlpm": False,
            "e_entry_speed_cap_mps": float(next(
                (state.current_motion_plan.get("e_entry_speed_cap_mps")
                 for state in traffic_states
                 if state.current_motion_plan.get("e_entry_speed_cap_mps") is not None), 7.0)),
            "e_entry_speed_actual_mps": {
                state.uav_id: float(state.current_motion_plan["e_entry_speed_mps"])
                for state in traffic_states
                if state.current_motion_plan.get("e_entry_speed_mps") is not None},
            "event_window_source": "BOUNDED_REACHABILITY_MODEL",
            "h_nominal_exit_source": "NORMAL_CRUISE_SPEED",
            "h_max_delay_source": "SELECTED_ALLOWED_EXIT_UPPER_BOUND",
            "committed_mainline_prefix": {
                item.uav_id: {
                    "source": item.committed_prefix_source,
                    "resource_entry_time_s": item.committed_resource_entry_s,
                    "resource_exit_time_s": item.committed_resource_exit_s,
                }
                for item in mainline
                if item.committed_prefix_source is not None
            },
            "fixed_mainline_events": fixed_mainline_event_rows,
            "existing_v_continuation_count": len(continuations),
            "event_time_domains": empty_domains,
            "existing_v_continuations": [
                {
                    "uav_id": item.uav_id,
                    "phase": item.phase,
                    "plan_version": item.plan_version,
                    "freeze_record_id": item.freeze_record_id,
                    "released": list(item.released),
                    "active": [row[0] for row in item.active],
                    "future": [row[0] for row in item.future],
                    "q_reference_time": item.provenance["q_reference_time"],
                }
                for item in continuations
            ],
            **({
                key: runtime_provenance[key]
                for key in sorted(required_provenance)
            } if runtime_provenance is not None else {}),
        },
    }
    # Frozen V leave the decision set, not the physical lane. Their published
    # events enter the dynamic contract as constants below.
    if (runtime_provenance or {}).get("following_control") != "MEASURED_KINEMATIC_EXECUTOR_V1":
        raise ValueError("CURRENT_FOLLOWING_CONTROL_REQUIRED")
    payload["metadata"]["following_control"] = "MEASURED_KINEMATIC_EXECUTOR_V1"
    # Same-lane traversal order is topology/FIFO, not a distance headway.
    # Only identical resource-entry locations are ordered here; longitudinal
    # distance control and V/H approach interaction use local joint certification.
    # FIFO must be reconstructed from the complete physical event set, not
    # from optimizable resource uses.  Published H has no resource-use row in
    # this round, but its fixed event above is still a FIFO participant.
    resource_groups: dict[str, list[dict[str, Any]]] = {}
    for event in events:
        if event.get("phase") == "MAINLINE" and event.get("resource_id") is not None:
            uav_id = str(event["uav_id"])
            if uav_id not in physical_by_id:
                raise ValueError(f"MAINLINE_EVENT_STATE_MISSING:{uav_id}")
            resource_groups.setdefault(str(event["resource_id"]), []).append(event)
    fifo = []
    for events_at_resource in resource_groups.values():
        ordered = sorted(
            events_at_resource,
            key=lambda event: (-physical_by_id[event["uav_id"]].s_m, event["uav_id"]),
        )
        for leader,follower in combinations(ordered, 2):
            from .following_time import physical_lane
            if physical_lane(physical_by_id[leader["uav_id"]]) == physical_lane(physical_by_id[follower["uav_id"]]):
                fifo.append({
                    "leader_id": leader["uav_id"],
                    "follower_id": follower["uav_id"],
                    "leader_event_id": leader["event_id"],
                    "follower_event_id": follower["event_id"],
                })
    payload["mainline_fifo"] = fifo
    if waiting_next_check_s is not None:
        if waiting_parameters is None:
            raise ValueError("MISSING_EXPLICIT_WAITING_PARAMETERS")
        by_id = {s.uav_id:s for s in traffic_states}
        # An unpromised H behind a pending V shares that V's release decision:
        # while V waits, H remains physical following traffic, not a fictitious
        # resource crossing. Prior passage commitments were removed from the
        # adjustable H rows above and must NEVER be disabled this way.
        decision_ids = {d["uav_id"] for d in descent_rows}
        for flow in payload["mainline_flows"]:
            state = by_id[flow["uav_id"]]
            ahead = [by_id[uid] for uid in decision_ids
                     if by_id[uid].lane_id == state.lane_id and by_id[uid].s_m > state.s_m]
            if ahead:
                flow["waiting_leader_id"] = min(ahead, key=lambda v:v.s_m).uav_id
        unavailable = set()
        pending_rows = []
        previous, new = [], []
        for descent in descent_rows:
            uid = descent["uav_id"]
            state = by_id[uid]
            old = state.cmlpm_pending
            baseline=state.cmlpm_request_baseline
            if baseline is not None and (baseline['node_id']!=node_id or
                    baseline['request_id']!=(state.request_id or f"CMLPM:{node_id}:{uid}")):
                raise ValueError("CMLPM_REQUEST_BASELINE_KEY_MISMATCH:"+uid)
            nominal = (baseline['nominal_service_time_s'] if baseline else
                       old.nominal_service_time_s if old else descent["nominal_service_time"])
            descent["nominal_service_time"] = nominal
            e = next((event for event in events if event["event_id"] == descent["entry_event_id"]), None)
            available = (uid not in empty_domains and e is not None
                and (t_request is None
                     or float(e["time_lb"]) + float(descent["service_offset"]) <= t_request+1e-9))
            if not available:
                unavailable.add(uid)
                # An unavailable V is removed from this round's optimizable
                # event set; no legacy G/J aliases are manufactured.
                descent.update(entry_event_id=None)
            (previous if old else new).append(uid)
            limits = motion_limits_by_type[state.vehicle_type]
            entry_station = float(state.current_motion_plan.get(
                "resource_entry_station_m",
                state.current_motion_plan.get("e_station_m"),
            ))
            # Waiting is a local retry hover, not a reservation to stop at G or
            # at an E-upstream parking line.  The next round observes the
            # actual bounded braking result and rebuilds the reachability
            # window from that state.
            can_hold = (
                math.isfinite(float(state.speed_mps))
                and 0.0 <= float(state.speed_mps) <= float(limits.max_speed_mps) + 1e-9
                and float(state.s_m) + float(state.speed_mps)**2 /
                    (2.0*float(limits.max_abs_acceleration_mps2)) < entry_station - 1e-6
            )
            restart_lb = 0.
            if can_hold:
                wait_dt = float(waiting_next_check_s)-t_now
                speed = max(0.0, float(state.speed_mps))
                braking_time = min(wait_dt, speed / float(limits.max_abs_acceleration_mps2)) if speed else 0.0
                next_speed = max(0.0, speed - float(limits.max_abs_acceleration_mps2) * wait_dt)
                next_position = float(state.s_m) + speed * braking_time - 0.5 * float(limits.max_abs_acceleration_mps2) * braking_time ** 2
                restart_length = max(0.0, entry_station-next_position)
                restart_latest = t_request
                # The waiting record is only an optional lower-bound cost.  A
                # request may already have crossed the stale entry station, or
                # the approved evaluation horizon may end before the next
                # retry round.  Neither case is an invalid physical input to
                # the main C-MLPM snapshot; it simply means that this round
                # has no proved restart envelope.
                if restart_latest is not None and restart_latest <= float(waiting_next_check_s):
                    payload["metadata"].setdefault("restart_domain_failures", {})[uid] = (
                        "NO_FUTURE_RESTART_HORIZON"
                    )
                    pending_rows.append({
                        "uav_id":uid, "request_id":old.request_id if old else state.request_id or f"CMLPM:{node_id}:{uid}",
                        "nominal_service_time_s":nominal,
                        "first_eligible_time_s":(baseline['first_eligible_time_s'] if baseline else
                                                 old.first_eligible_time_s if old else t_now),
                        "wait_rounds":old.wait_rounds if old else 0,
                        "restart_time_lb_s":restart_lb,
                        "can_hold":can_hold, "timing_available":available,
                        "resource_chain":legal_paths[descent["source_layer"]],
                    })
                    continue
                try:
                    projected=replace(state,s_m=next_position,speed_mps=next_speed)
                    restart = published_reachability_window(projected,t_now=float(waiting_next_check_s),
                        length_m=restart_length,
                        v_now=next_speed,v_min=limits.min_speed_mps,v_max=limits.max_speed_mps,
                        a_max=limits.max_abs_acceleration_mps2,b_max=limits.max_abs_acceleration_mps2,
                        v_terminal=float(state.current_motion_plan.get(
                            "e_entry_speed_mps", state.current_motion_plan.get("e_entry_speed_cap_mps", 7.0))),
                        allow_stop_start=True,latest_time_s=(
                            float(waiting_next_check_s)+(t_request-t_now) if t_request is not None else None))
                    restart_lb = restart.travel_time_lb+float(state.current_motion_plan.get(
                        "e_to_j_s", 0.0))+float(descent["service_offset"])
                    if not restart.feasible:
                        payload["metadata"].setdefault("restart_domain_failures", {})[uid] = restart.failure_code
                except ReachabilityError as error:
                    if error.code not in {
                        STATUS_INFEASIBLE_TERMINAL_SPEED,
                        "INPUT_SPEED_DOMAIN_INVALID",
                        "INPUT_LENGTH_INVALID",
                    }:
                        raise
                    # Holding safely does not prove a future restart. Zero is
                    # an optimistic cost lower bound, not a motion certificate.
                    payload["metadata"].setdefault("restart_domain_failures", {})[uid] = error.code
            pending_rows.append({
                "uav_id":uid, "request_id":old.request_id if old else state.request_id or f"CMLPM:{node_id}:{uid}",
                "nominal_service_time_s":nominal,
                "first_eligible_time_s":(baseline['first_eligible_time_s'] if baseline else
                                         old.first_eligible_time_s if old else t_now),
                "wait_rounds":old.wait_rounds if old else 0,
                "restart_time_lb_s":restart_lb,
                "can_hold":can_hold, "timing_available":available,
                "resource_chain":legal_paths[descent["source_layer"]],
            })
        payload["events"] = [e for e in events if e["uav_id"] not in unavailable]
        payload["arcs"] = [e for e in arcs if e["uav_id"] not in unavailable]
        payload["resource_uses"] = [e for e in uses if e["uav_id"] not in unavailable]
        payload["vv_constraints"] = [e for e in vv if not {e["first_id"],e["second_id"]}&unavailable]
        payload["mainline_fifo"] = [
            e for e in payload.get("mainline_fifo", ())
            if not {e["leader_id"], e["follower_id"]}&unavailable]
        payload["frozen_vv_constraints"] = [e for e in payload["frozen_vv_constraints"] if e["new_uav_id"] not in unavailable]
        payload["waiting_policy"] = {
            "next_check_time_s":float(waiting_next_check_s),
            **{k:float(waiting_parameters[k]) for k in ("wait_step_weight","wait_age_weight","full_attempt_fraction")},
            "requests":pending_rows,
            "previous_pending_ids":sorted(previous),"newly_eligible_ids":sorted(new),
        }
        payload["metadata"]["h_wait_dependency_source"] = "NEAREST_PENDING_V_IN_PHYSICAL_LANE"
        payload["metadata"]["h_wait_cost_semantics"] = "NO_NEW_PASSAGE_NO_C9_PASSAGE_DELAY_TERM; ACTUAL_FOLLOWING_DELAY_REMAINS_PHYSICAL"
    from .following_time import build_following_time_contract
    physical = {s.uav_id:s for s in physical_states}
    physical.update({s.uav_id:s for s in (*traffic_states, *frozen_mainline)})
    # The active E-anchor path does not reconstruct an upstream departure
    # point. Immutable published E times are the only timing evidence passed
    # to the following-time module.
    build_following_time_contract(payload, states=physical.values(),
        limits_by_type=motion_limits_by_type,
        published_e_times=frozen_mainline_e_times or {}, min_gap_m=min_mainline_gap_m,
        include_uav_ids=(
            [row["uav_id"] for row in payload["descents"]]
            + [row["uav_id"] for row in payload["mainline_flows"]]
        ),
        suppress_published_ids=replan_existing_v_ids,
    )
    build_complete_snapshot(payload)
    return payload

