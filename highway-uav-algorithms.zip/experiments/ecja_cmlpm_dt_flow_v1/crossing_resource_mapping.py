"""Verified physical mapping between SRCM crossing resources and C-MLPM resources.

The frozen SRCM (``SRCM_CROSSING_V3_0_1``) identifies resource competition at
*crossing* resources: the physical intersection of one vertical shaft with one
directed mainline.  C-MLPM schedules on the registered G25 vertical column
segments.  This module derives both representations from the same registered
G25 network, verifies their geometric correspondence, and fails closed when
the SRCM crossing registry cannot be reproduced from the registered geometry.

Established correspondence (all derived, not assumed):

* One physical shaft == one G25 column == one (node, direction) service site.
  The 21 registered crossings, 21 column segments and 21 accepted interfaces
  are in exact 1:1:1 correspondence.
* The crossing at layer ``L`` (shaft cylinder slice inside the layer-L mainline
  band) is represented by the column segment that starts at the layer-L
  altitude, i.e. ``resource_chain[0]`` of the (node, L) interface.  For the
  registered geometry the below-centreline half of every crossing band lies
  wholly inside that segment (L3 crossing 105-110 m inside V32 90-110 m;
  L2 crossing below-half 85-90 m inside V21 70-90 m; L1 crossing below-half
  65-70 m inside V10 50-70 m).
* A V descending from source layer ``S`` traverses the crossings at ``S,
  S-1, ..., L1`` in that order; the interface chain lists them as ordered
  column segments anchored at the shaft entry event J.
* An H cruising at layer ``L`` occupies the crossing at ``L`` and is therefore
  represented by the same column segment (``chain[0]`` of the (node, L)
  interface).  This matches the frozen M1R resource map, whose R1/R2/R3
  crossing resources are exactly the per-layer crossing accesses.

Provenance split (the ``SYNTHETIC_TEST_ONLY`` markers never apply to the
registered geometry itself):

* Registered geometry lineage: shaft axis from ``origin_gate_xyz``; mainline
  bands and altitudes from ``mainlines``; column segment z-ranges from
  ``resources``; gate z from ``origin_gate_xyz``.  Fully traceable to
  ``network_contracts/g25_planar_realized_v1_3/network.json``.
* Declared synthetic parameters: shaft cross-section radius (10 m,
  ``cross_section_provenance = SYNTHETIC_TEST_ONLY``) and all motion speeds
  (``motion_parameter_provenance = SYNTHETIC_TEST_ONLY``).  The parameterized
  research simulation may use them, but only with this explicit declaration.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
import math
from pathlib import Path
from typing import Any, Iterable, Mapping, Sequence

from g25_param_env.crossings import build_crossing_resources
from g25_param_env.extractor import project_station_xy

from .network_loader import REPO_ROOT, RegisteredG25, to_ecja_g25_source


CROSSING_SHAFT_RADIUS_M = 10.0
CROSSING_MAP_VERSION = "CMLPM_CROSSING_RESOURCE_MAP_V1"
_REGISTERED_NETWORK_PATH = REPO_ROOT / "network_contracts/g25_planar_realized_v1_3/network.json"
_LAYER_ORDER = {"L1": 1, "L2": 2, "L3": 3}


class CrossingMappingError(ValueError):
    """Structured fail-closed error at the crossing-mapping seam."""

    def __init__(self, code: str, detail: str):
        super().__init__(f"{code}:{detail}")
        self.code = code
        self.detail = detail


@dataclass(frozen=True)
class ColumnSegment:
    resource_id: str
    column_id: str
    segment: str
    z_low_m: float
    z_high_m: float
    length_m: float
    axis_xy: tuple[float, float]


@dataclass(frozen=True)
class CrossingResourceMap:
    """One SRCM crossing resource and its verified C-MLPM representation."""

    crossing_id: str
    node_id: str
    direction: str
    layer: str
    layer_index: int
    mainline_id: str
    physical_shaft_id: str
    axis_xy: tuple[float, float]
    z_low_m: float
    z_high_m: float
    shaft_radius_m: float
    gate_station_m: float
    entry_station_m: float
    exit_station_m: float
    segment_resource_id: str
    column_id: str
    segment_z_low_m: float
    segment_z_high_m: float
    segment_overlap_low_m: float
    segment_overlap_high_m: float
    interface_id: str
    route_id: str
    resource_chain: tuple[str, ...]
    associated_node_ids: tuple[str, ...]
    source_interface_ids: tuple[str, ...]
    geometry_hash: str

    @property
    def is_h_resource(self) -> bool:
        """True when this crossing is the H-accessible resource at its layer."""

        return self.segment_resource_id == (
            self.resource_chain[0] if self.resource_chain else None
        )


def _canonical_hash(value: Any) -> str:
    payload = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def _distance_to_polyline_xy(
    point: tuple[float, float], polyline: Iterable[Iterable[float]]
) -> float:
    def segment_distance_sq(px: float, py: float, a: Sequence[float], b: Sequence[float]) -> float:
        vx, vy = b[0] - a[0], b[1] - a[1]
        wx, wy = px - a[0], py - a[1]
        length_sq = vx * vx + vy * vy
        if length_sq == 0.0:
            return wx * wx + wy * wy
        ratio = max(0.0, min(1.0, (wx * vx + wy * vy) / length_sq))
        dx, dy = px - (a[0] + ratio * vx), py - (a[1] + ratio * vy)
        return dx * dx + dy * dy

    rows = [list(item) for item in polyline]
    if len(rows) < 2:
        return math.inf
    return math.sqrt(
        min(segment_distance_sq(point[0], point[1], a, b) for a, b in zip(rows, rows[1:]))
    )


def layer_altitudes(network: RegisteredG25) -> dict[tuple[str, str], float]:
    """Registered mainline centre altitudes keyed by (direction, layer)."""

    return {
        (str(row["direction"]), str(row["paper_layer"])): float(row["center_altitude_m"])
        for row in network.mainlines
    }


def mainline_bands(network: RegisteredG25) -> dict[tuple[str, str], tuple[float, float]]:
    """Registered mainline vertical bands keyed by (direction, layer)."""

    bands: dict[tuple[str, str], tuple[float, float]] = {}
    for row in network.mainlines:
        key = (str(row["direction"]), str(row["paper_layer"]))
        centre = float(row["center_altitude_m"])
        half = float(row["height_m"]) / 2.0
        bands[key] = (centre - half, centre + half)
    return bands


def column_segments(network: RegisteredG25) -> dict[str, tuple[ColumnSegment, ...]]:
    """Registered column segments grouped by column id."""

    grouped: dict[str, list[ColumnSegment]] = {}
    for row in network.resources:
        start_xyz = [float(value) for value in row["start_xyz"]]
        end_xyz = [float(value) for value in row["end_xyz"]]
        if abs(start_xyz[0] - end_xyz[0]) > 1e-9 or abs(start_xyz[1] - end_xyz[1]) > 1e-9:
            raise CrossingMappingError(
                "COLUMN_SEGMENT_NOT_VERTICAL", str(row["resource_id"])
            )
        grouped.setdefault(str(row["column_id"]), []).append(
            ColumnSegment(
                resource_id=str(row["resource_id"]),
                column_id=str(row["column_id"]),
                segment=str(row["segment"]),
                z_low_m=min(start_xyz[2], end_xyz[2]),
                z_high_m=max(start_xyz[2], end_xyz[2]),
                length_m=float(row["length_m"]),
                axis_xy=(start_xyz[0], start_xyz[1]),
            )
        )
    return {
        column_id: tuple(sorted(items, key=lambda item: -item.z_high_m))
        for column_id, items in grouped.items()
    }


def interface_for(network: RegisteredG25, node_id: str, layer: str) -> Mapping[str, Any]:
    matches = [
        row for row in network.interfaces
        if str(row["service_node_id"]) == node_id and str(row["source_layer"]) == layer
    ]
    if len(matches) != 1:
        raise CrossingMappingError(
            "INTERFACE_CARDINALITY", f"{node_id}:{layer}:{len(matches)}"
        )
    return matches[0]


def h_resource_id(network: RegisteredG25, node_id: str, layer: str) -> str:
    """Column segment representing the H crossing resource at (node, layer)."""

    interface = interface_for(network, node_id, layer)
    chain = interface["route_template"]["resource_chain"]
    if not chain:
        raise CrossingMappingError("EMPTY_RESOURCE_CHAIN", str(interface["interface_id"]))
    return str(chain[0])


def mainline_crossing_stations(
    network: RegisteredG25,
) -> dict[tuple[str, str], tuple[tuple[str, float, float], ...]]:
    """Execution crossings keyed by directed mainline identity.

    Each row is ``(resource_id, entry_station_m, exit_station_m)`` and is
    derived from the same registered crossing geometry used by SRCM/C-MLPM.
    """

    grouped: dict[tuple[str, str], list[tuple[str, float, float]]] = {}
    for item in build_crossing_resource_maps(network).values():
        grouped.setdefault((item.direction, item.layer), []).append(
            (item.segment_resource_id, item.entry_station_m, item.exit_station_m)
        )
        frame = network.formal_geometry[item.interface_id]
        ascent = frame.get('reentry_ascent')
        if ascent:
            offset = float(ascent['column_separation_m'])
            grouped[(item.direction,item.layer)].append((
                ascent['resource_ids'][item.segment_resource_id],
                item.entry_station_m+offset,item.exit_station_m+offset))
    return {
        key: tuple(sorted(rows, key=lambda row: (row[1], row[0])))
        for key, rows in grouped.items()
    }


def _shaft_groups(
    network: RegisteredG25,
) -> dict[tuple[str, tuple[float, float]], list[Mapping[str, Any]]]:
    grouped: dict[tuple[str, tuple[float, float]], list[Mapping[str, Any]]] = {}
    for interface in network.interfaces:
        gate = interface["origin_gate_xyz"]
        key = (str(interface["direction"]), (float(gate[0]), float(gate[1])))
        grouped.setdefault(key, []).append(interface)
    return grouped


def _shaft_id(direction: str, axis_xy: tuple[float, float], source_refs: list[str]) -> str:
    key = _canonical_hash(
        {"direction_id": direction, "axis_xy": list(axis_xy), "source_shaft_refs": source_refs}
    )[:24]
    return "G25-S10:shaft:" + key


def build_crossing_resource_maps(
    network: RegisteredG25, *, shaft_radius_m: float = CROSSING_SHAFT_RADIUS_M
) -> dict[str, CrossingResourceMap]:
    """Derive the crossing resource maps from the registered G25 geometry.

    The derivation intentionally mirrors the frozen ``g25_param_env`` crossing
    construction (same shaft grouping, same finite-cylinder slice, same id and
    geometry-hash scheme) so that ``verify_against_srcm_registry`` can compare
    the derived registry against the frozen SRCM registry element by element.
    """

    if shaft_radius_m <= 0.0:
        raise CrossingMappingError("INVALID_SHAFT_RADIUS", str(shaft_radius_m))
    altitudes = layer_altitudes(network)
    bands = mainline_bands(network)
    segments_by_column = column_segments(network)
    mainlines = {
        (str(row["direction"]), str(row["paper_layer"])): row for row in network.mainlines
    }
    maps: dict[str, CrossingResourceMap] = {}

    for (direction, axis_xy), interfaces in sorted(_shaft_groups(network).items()):
        node_ids = sorted({str(item["service_node_id"]) for item in interfaces})
        if len(node_ids) != 1:
            raise CrossingMappingError(
                "SHAFT_NODE_CARDINALITY", f"{direction}:{axis_xy}:{node_ids}"
            )
        node_id = node_ids[0]
        column_ids = sorted({str(item["column_id"]) for item in interfaces})
        if len(column_ids) != 1:
            raise CrossingMappingError(
                "SHAFT_COLUMN_CARDINALITY", f"{node_id}:{column_ids}"
            )
        segments = segments_by_column[column_ids[0]]
        shaft_z_low = min(item.z_low_m for item in segments)
        shaft_z_high = max(item.z_high_m for item in segments)
        source_refs = sorted(
            {str(value) for item in interfaces for value in item["route_template"]["resource_chain"]}
        )
        shaft_id = _shaft_id(direction, axis_xy, source_refs)

        for (mainline_direction, layer), mainline in sorted(mainlines.items()):
            if mainline_direction != direction:
                continue
            band_low, band_high = bands[(mainline_direction, layer)]
            z_low = max(shaft_z_low, band_low)
            z_high = min(shaft_z_high, band_high)
            if z_high <= z_low:
                continue
            half_width = float(mainline["width_m"]) / 2.0
            distance = _distance_to_polyline_xy(axis_xy, mainline["path"]["centerline_xyz"])
            if distance > half_width + shaft_radius_m:
                continue
            if distance + shaft_radius_m > half_width + 1e-7:
                raise CrossingMappingError(
                    "UNSUPPORTED_CROSSING_GEOMETRY",
                    f"{node_id}:{layer}:distance={distance}",
                )
            audited_distance = 0.0 if distance <= 1e-7 else distance
            gate_station, projection_error, _, _ = project_station_xy(
                mainline["path"]["centerline_xyz"], list(axis_xy)
            )
            if projection_error > 1e-5:
                raise CrossingMappingError(
                    "CROSSING_AXIS_PROJECTION_FAILED", f"{node_id}:{layer}"
                )
            interface = interface_for(network, node_id, layer)
            chain = tuple(str(value) for value in interface["route_template"]["resource_chain"])
            layer_altitude = altitudes[(direction, layer)]
            segment = next(
                (item for item in segments if abs(item.z_high_m - layer_altitude) <= 1e-9),
                None,
            )
            if segment is None:
                raise CrossingMappingError(
                    "LAYER_SEGMENT_MISSING", f"{node_id}:{layer}:{layer_altitude}"
                )
            geometry = {
                "type": "FINITE_CYLINDER",
                "axis_xy": list(axis_xy),
                "radius_m": float(shaft_radius_m),
                "z_min_m": z_low,
                "z_max_m": z_high,
                "representation": "EXACT_FULL_SHAFT_SECTION_WITHIN_MAINLINE_SWEEP",
                "cross_section_provenance": "SYNTHETIC_TEST_ONLY",
                "mainline_axis_distance_m": audited_distance,
                "numeric_tolerance_m": 1e-7,
            }
            crossing_id = "G25-S10:crossing:{}:{}".format(shaft_id, mainline["mainline_id"])
            overlap_low = max(z_low, segment.z_low_m)
            overlap_high = min(z_high, segment.z_high_m)
            if overlap_high < overlap_low:
                raise CrossingMappingError(
                    "CROSSING_SEGMENT_DISJOINT", f"{crossing_id}"
                )
            maps[crossing_id] = CrossingResourceMap(
                crossing_id=crossing_id,
                node_id=node_id,
                direction=direction,
                layer=layer,
                layer_index=_LAYER_ORDER[layer],
                mainline_id=str(mainline["mainline_id"]),
                physical_shaft_id=shaft_id,
                axis_xy=axis_xy,
                z_low_m=z_low,
                z_high_m=z_high,
                shaft_radius_m=float(shaft_radius_m),
                gate_station_m=float(gate_station),
                entry_station_m=float(gate_station) - float(shaft_radius_m),
                exit_station_m=float(gate_station) + float(shaft_radius_m),
                segment_resource_id=segment.resource_id,
                column_id=segment.column_id,
                segment_z_low_m=segment.z_low_m,
                segment_z_high_m=segment.z_high_m,
                segment_overlap_low_m=overlap_low,
                segment_overlap_high_m=overlap_high,
                interface_id=str(interface["interface_id"]),
                route_id=str(interface["route_id"]),
                resource_chain=chain,
                associated_node_ids=tuple(node_ids),
                source_interface_ids=tuple(
                    sorted(str(item["interface_id"]) for item in interfaces)
                ),
                geometry_hash=_canonical_hash(geometry),
            )
    return maps


def crossing_map_for_node_layer(
    maps: Mapping[str, CrossingResourceMap],
    node_id: str,
    direction: str,
    layer: str,
) -> CrossingResourceMap:
    """Look up the crossing map for one (node, direction, layer) triple."""

    matches = [
        item for item in maps.values()
        if item.node_id == node_id and item.direction == direction and item.layer == layer
    ]
    if len(matches) != 1:
        raise CrossingMappingError(
            "CROSSING_CARDINALITY", f"{node_id}:{direction}:{layer}:{len(matches)}"
        )
    return matches[0]


def verify_registered_geometry(network: RegisteredG25) -> dict[str, Any]:
    """Fail-closed consistency checks on the registered G25 geometry.

    Every check derives its expectation from the registered network itself;
    nothing is hard-coded from an external assumption.
    """

    checks: list[dict[str, Any]] = []
    altitudes = layer_altitudes(network)
    bands = mainline_bands(network)
    segments_by_column = column_segments(network)

    def record(name: str, passed: bool, detail: str) -> None:
        checks.append({"check": name, "passed": passed, "detail": detail})
        if not passed:
            raise CrossingMappingError(name, detail)

    for interface in network.interfaces:
        node_id = str(interface["service_node_id"])
        layer = str(interface["source_layer"])
        direction = str(interface["direction"])
        gate = [float(value) for value in interface["origin_gate_xyz"]]
        layer_altitude = altitudes.get((direction, layer))
        record(
            "GATE_Z_MATCHES_LAYER_ALTITUDE",
            layer_altitude is not None and abs(gate[2] - layer_altitude) <= 1e-9,
            f"{interface['interface_id']}:gate_z={gate[2]}:layer_z={layer_altitude}",
        )
        chain = [str(value) for value in interface["route_template"]["resource_chain"]]
        segments = segments_by_column[str(interface["column_id"])]
        segment_ids = {item.resource_id for item in segments}
        record(
            "CHAIN_RESOURCES_REGISTERED",
            set(chain) <= segment_ids,
            f"{interface['interface_id']}:{sorted(set(chain) - segment_ids)}",
        )
        layer_segment = next(
            (item for item in segments if abs(item.z_high_m - layer_altitude) <= 1e-9),
            None,
        )
        record(
            "CHAIN0_IS_LAYER_SEGMENT",
            layer_segment is not None and chain and chain[0] == layer_segment.resource_id,
            f"{interface['interface_id']}:chain0={chain[0] if chain else None}",
        )
        expected_chain = [
            item.resource_id for item in segments
            if item.z_high_m <= layer_altitude + 1e-9
        ]
        record(
            "CHAIN_IS_ORDERED_DESCENT",
            chain == expected_chain,
            f"{interface['interface_id']}:{chain}!={expected_chain}",
        )
        axis_xy = (gate[0], gate[1])
        half_width = None
        distance = None
        for row in network.mainlines:
            if str(row["direction"]) == direction and str(row["paper_layer"]) == layer:
                half_width = float(row["width_m"]) / 2.0
                distance = _distance_to_polyline_xy(axis_xy, row["path"]["centerline_xyz"])
        record(
            "AXIS_WITHIN_MAINLINE_SWEEP",
            half_width is not None
            and distance is not None
            and distance + CROSSING_SHAFT_RADIUS_M <= half_width + 1e-7,
            f"{interface['interface_id']}:distance={distance}",
        )
        gate_station, projection_error, _, _ = project_station_xy(
            next(
                row["path"]["centerline_xyz"] for row in network.mainlines
                if str(row["direction"]) == direction and str(row["paper_layer"]) == layer
            ),
            axis_xy,
        )
        from .network_loader import formal_g_station
        fork_station = formal_g_station(network, interface)
        record(
            "GATE_DOWNSTREAM_OF_FORK",
            projection_error <= 1e-5
            and fork_station < gate_station < fork_station + 200.0,
            f"{interface['interface_id']}:fork={fork_station}:gate={gate_station}",
        )

    for column_id, segments in segments_by_column.items():
        record(
            "COLUMN_SEGMENT_COUNT",
            len(segments) == 3,
            f"{column_id}:{len(segments)}",
        )
        for lower, upper in zip(segments[1:], segments[:-1]):
            record(
                "COLUMN_SEGMENTS_CONTIGUOUS",
                abs(upper.z_low_m - lower.z_high_m) <= 1e-9,
                f"{column_id}:{upper.segment}->{lower.segment}",
            )
        bottom = segments[-1]
        record(
            "COLUMN_BOTTOM_AT_SCOPE_END",
            abs(bottom.z_low_m - 50.0) <= 1e-9,
            f"{column_id}:bottom_z={bottom.z_low_m}",
        )
        top = segments[0]
        max_altitude = max(
            altitude for (direction, layer), altitude in altitudes.items()
            if direction == column_id.rsplit(":", 1)[-1]
        )
        record(
            "COLUMN_TOP_AT_HIGHEST_LAYER",
            abs(top.z_high_m - max_altitude) <= 1e-9,
            f"{column_id}:top_z={top.z_high_m}:max_layer_z={max_altitude}",
        )

    for (direction, layer), (band_low, band_high) in sorted(bands.items()):
        record(
            "MAINLINE_BAND_SANITY",
            band_high > band_low and band_low > 0.0,
            f"{direction}:{layer}:{band_low}-{band_high}",
        )

    maps = build_crossing_resource_maps(network)
    record(
        "CROSSING_COVERAGE_COMPLETE",
        len(maps) == len(network.interfaces),
        f"crossings={len(maps)}:interfaces={len(network.interfaces)}",
    )
    for item in maps.values():
        record(
            "CROSSING_NODE_UNIQUE",
            len(item.associated_node_ids) == 1 and item.associated_node_ids[0] == item.node_id,
            item.crossing_id,
        )
        record(
            "CROSSING_BELOW_HALF_WITHIN_SEGMENT",
            item.segment_z_low_m <= item.z_low_m + 1e-9
            and item.segment_z_high_m >= (item.z_low_m + item.z_high_m) / 2.0 - 1e-9,
            f"{item.crossing_id}:segment={item.segment_z_low_m}-{item.segment_z_high_m}",
        )
    return {
        "version": CROSSING_MAP_VERSION,
        "network_sha256": network.source_sha256,
        "checks": checks,
        "status": "PASS",
    }


def verify_against_srcm_registry(
    network: RegisteredG25,
    maps: Mapping[str, CrossingResourceMap] | None = None,
) -> dict[str, Any]:
    """Reproduce the frozen SRCM registry from the registered geometry.

    Builds the ECJA G25 source projection, runs the frozen
    ``g25_param_env.crossings.build_crossing_resources``, and compares every
    crossing element (identity, axis, cylinder z-range, radius, associated
    nodes, source interfaces, geometry hash) against the derived map.  Any
    mismatch fails closed.
    """

    if maps is None:
        maps = build_crossing_resource_maps(network)
    source = to_ecja_g25_source(network)
    registry = build_crossing_resources(source, CROSSING_SHAFT_RADIUS_M)
    registry_by_id = {str(item["crossing_id"]): item for item in registry}

    missing = sorted(set(registry_by_id) - set(maps))
    extra = sorted(set(maps) - set(registry_by_id))
    if missing or extra:
        raise CrossingMappingError(
            "CROSSING_ID_SET_MISMATCH",
            f"missing={missing}:extra={extra}",
        )
    for crossing_id, derived in sorted(maps.items()):
        registered = registry_by_id[crossing_id]
        geometry = registered["geometry"]
        if abs(float(geometry["radius_m"]) - derived.shaft_radius_m) > 1e-12:
            raise CrossingMappingError("CROSSING_RADIUS_MISMATCH", crossing_id)
        if abs(float(geometry["z_min_m"]) - derived.z_low_m) > 1e-9 or abs(
            float(geometry["z_max_m"]) - derived.z_high_m
        ) > 1e-9:
            raise CrossingMappingError("CROSSING_Z_RANGE_MISMATCH", crossing_id)
        axis = [float(value) for value in geometry["axis_xy"]]
        if abs(axis[0] - derived.axis_xy[0]) > 1e-9 or abs(axis[1] - derived.axis_xy[1]) > 1e-9:
            raise CrossingMappingError("CROSSING_AXIS_MISMATCH", crossing_id)
        if str(registered["physical_shaft_id"]) != derived.physical_shaft_id:
            raise CrossingMappingError("CROSSING_SHAFT_ID_MISMATCH", crossing_id)
        if str(registered["mainline_id"]) != derived.mainline_id:
            raise CrossingMappingError("CROSSING_MAINLINE_MISMATCH", crossing_id)
        if tuple(sorted(str(value) for value in registered["associated_node_ids"])) != derived.associated_node_ids:
            raise CrossingMappingError("CROSSING_NODE_MISMATCH", crossing_id)
        if str(registered["source_registry_id"]) != ";".join(derived.source_interface_ids):
            raise CrossingMappingError("CROSSING_SOURCE_REGISTRY_MISMATCH", crossing_id)
        if str(registered.get("segment_resource_id")) != derived.segment_resource_id:
            raise CrossingMappingError("CROSSING_SEGMENT_RESOURCE_MISMATCH", crossing_id)
        if str(registered.get("resource_id")) != derived.segment_resource_id:
            raise CrossingMappingError("CROSSING_RESOURCE_IDENTITY_MISMATCH", crossing_id)
        if str(registered.get("column_id")) != derived.column_id:
            raise CrossingMappingError("CROSSING_COLUMN_ID_MISMATCH", crossing_id)
        if tuple(str(value) for value in registered.get("resource_chain", ())) != derived.resource_chain:
            raise CrossingMappingError("CROSSING_RESOURCE_CHAIN_MISMATCH", crossing_id)
        if str(registered["geometry_hash"]) != derived.geometry_hash:
            raise CrossingMappingError("CROSSING_GEOMETRY_HASH_MISMATCH", crossing_id)
    return {
        "version": CROSSING_MAP_VERSION,
        "registry_size": len(registry_by_id),
        "derived_size": len(maps),
        "resource_identity_size": sum(
            1
            for item in registry
            if item.get("segment_resource_id") and item.get("resource_id")
        ),
        "status": "PASS",
    }


def crossing_provenance(network: RegisteredG25) -> dict[str, Any]:
    """Trace the SYNTHETIC_TEST_ONLY markers to their exact scope.

    Registered geometry (axis, bands, segment z-ranges, gate z) is traceable
    to the registered network file.  The synthetic markers cover only the
    declared shaft radius and the declared motion speeds.
    """

    maps = build_crossing_resource_maps(network)
    registry_check = verify_against_srcm_registry(network, maps)
    geometry_check = verify_registered_geometry(network)
    return {
        "version": CROSSING_MAP_VERSION,
        "network_path": str(_REGISTERED_NETWORK_PATH),
        "network_sha256": network.source_sha256,
        "geometry_hash": network.geometry_hash,
        "registered_geometry_lineage": {
            "shaft_axis": "interfaces.origin_gate_xyz (registered)",
            "mainline_bands": "mainlines.center_altitude_m/height_m (registered)",
            "column_segment_z_ranges": "resources.start_xyz/end_xyz (registered)",
            "gate_altitude": "interfaces.origin_gate_xyz (registered)",
            "reproduced_crossing_registry": registry_check["status"],
            "registered_geometry_checks": geometry_check["status"],
        },
        "synthetic_declared_parameters": {
            "shaft_radius_m": {
                "value": CROSSING_SHAFT_RADIUS_M,
                "marker": "SYNTHETIC_TEST_ONLY",
                "scope": "cross_section_provenance on every crossing geometry",
            },
            "motion_speeds": {
                "marker": "SYNTHETIC_TEST_ONLY",
                "scope": "motion_parameter_provenance on generated plans; descent speed 3 m/s",
            },
        },
        "crossing_count": len(maps),
        "status": "PASS",
    }


def load_default_crossing_maps() -> dict[str, CrossingResourceMap]:
    """Convenience loader for the registered v1.3 network."""

    from .network_loader import load_registered_g25

    return build_crossing_resource_maps(load_registered_g25(_REGISTERED_NETWORK_PATH))
