"""Measured upstream congestion propagation for pre-C-MLPM traffic.

This module deliberately does not create a C-MLPM timing decision.  A boundary
UAV becomes a congestion source only when its measured execution state shows
deceleration or an explicit stop/wait state.  Upstream traffic receives a
short-lived following signal and remains ordinary mainline traffic until it
enters the C-MLPM read interval.
"""

from __future__ import annotations

from dataclasses import replace
from typing import Iterable

from .following_time import physical_lane
from .simulation_state import FlightState, UAVState


PROPAGATION_VERSION = "UPSTREAM_CONGESTION_PROPAGATION_V1"
SOURCE_KEY = "congestion_source"
FOLLOWING_KEY = "upstream_congestion"
FOLLOWING_MODE_KEY = "congestion_following_mode"

_TERMINAL = frozenset(
    {FlightState.COMPLETED, FlightState.EXITED, FlightState.HORIZON_CENSORED}
)
_NON_MAINLINE = frozenset(
    {FlightState.TRANSITION, FlightState.VERTICAL,
     FlightState.SERVICING, FlightState.REENTRY_HOLD,
     FlightState.REENTRY_CLIMB, FlightState.REENTRY_LAND_TO_GROUND,
     FlightState.REENTRY_ASCENT_TO_50M, FlightState.REENTRY_STAGING_HOLD,
     FlightState.REENTRY_FINAL_APPROACH}
)


def _is_boundary_candidate(state: UAVState) -> bool:
    plan = state.current_motion_plan
    return (
        plan.get("schedule_result") in {"RELEASED", "WAITING"}
        or plan.get("execution_mode") == "CMLPM_RETRY_HOLD"
    )


def _is_active_source(before: UAVState, after: UAVState, *, min_speed_drop_mps: float) -> bool:
    if not _is_boundary_candidate(after):
        return False
    speed_drop = float(before.speed_mps) - float(after.speed_mps)
    stopped = float(after.speed_mps) <= 1e-8
    return speed_drop >= float(min_speed_drop_mps) or stopped


def propagate_upstream_congestion(
    before_states: Iterable[UAVState],
    after_states: Iterable[UAVState],
    *,
    observed_at_s: float,
    min_speed_drop_mps: float = 0.05,
) -> tuple[UAVState, ...]:
    """Attach measured congestion/following state to one motion step.

    The returned states preserve all scheduling fields.  Only the two
    propagation metadata fields are refreshed.  A source is considered only
    when it already carries a released/waiting boundary plan and its measured
    speed dropped (or it is stopped).  Upstream states are selected by the
    registered physical lane, so no cross-layer or opposite-direction signal
    is created.
    """

    before = {state.uav_id: state for state in before_states}
    after = tuple(after_states)
    sources = []
    for state in after:
        prior = before.get(state.uav_id)
        if prior is None or state.state in _TERMINAL or state.state in _NON_MAINLINE:
            continue
        if not _is_active_source(
            prior, state, min_speed_drop_mps=min_speed_drop_mps
        ):
            continue
        sources.append(state)

    source_lanes = {state.uav_id: physical_lane(state) for state in sources}
    refreshed = []
    for state in after:
        plan = dict(state.current_motion_plan)
        plan.pop(SOURCE_KEY, None)
        plan.pop(FOLLOWING_KEY, None)
        plan.pop(FOLLOWING_MODE_KEY, None)

        candidates = [
            candidate
            for candidate in sources
            if candidate.uav_id != state.uav_id
            and source_lanes[candidate.uav_id] == physical_lane(state)
            and float(candidate.s_m) > float(state.s_m) + 1e-9
        ]
        source = min(
            candidates,
            key=lambda candidate: float(candidate.s_m) - float(state.s_m),
            default=None,
        )
        if source is not None:
            gap = float(source.s_m) - float(state.s_m)
            if gap > 0.0:
                plan[FOLLOWING_KEY] = {
                    "version": PROPAGATION_VERSION,
                    "source_uav_id": source.uav_id,
                    "source_station_m": float(source.s_m),
                    "source_speed_mps": float(source.speed_mps),
                    "gap_m": gap,
                    "observed_at_s": float(observed_at_s),
                    "active": True,
                }
                plan[FOLLOWING_MODE_KEY] = "DYNAMIC_LEADER_FOLLOWING"
        if state.uav_id in source_lanes:
            plan[SOURCE_KEY] = {
                "version": PROPAGATION_VERSION,
                "source_uav_id": state.uav_id,
                "station_m": float(state.s_m),
                "speed_mps": float(state.speed_mps),
                "observed_at_s": float(observed_at_s),
                "active": True,
            }
        refreshed.append(replace(state, current_motion_plan=plan))
    return tuple(refreshed)

