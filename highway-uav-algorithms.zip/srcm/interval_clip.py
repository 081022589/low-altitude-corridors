"""Analytic line-segment clipping for finite cylinders and convex halfspaces."""

from __future__ import annotations

import math
from typing import Any, Dict, Optional, Sequence, Tuple


Interval = Optional[Tuple[float, float]]


def _linear_leq(value0: float, delta: float, upper: float, low: float, high: float, tolerance: float) -> Interval:
    if abs(delta) <= tolerance:
        return (low, high) if value0 <= upper + tolerance else None
    boundary = (upper - value0) / delta
    if delta > 0.0:
        high = min(high, boundary)
    else:
        low = max(low, boundary)
    return (low, high) if high >= low - tolerance else None


def _slab(value0: float, delta: float, minimum: float, maximum: float, low: float, high: float, tolerance: float) -> Interval:
    first = _linear_leq(value0, delta, maximum, low, high, tolerance)
    if first is None:
        return None
    return _linear_leq(-value0, -delta, -minimum, first[0], first[1], tolerance)


def clip_segment(point0: Sequence[float], point1: Sequence[float], geometry: Dict[str, Any], tolerance: float = 1e-12) -> Interval:
    low, high = 0.0, 1.0
    kind = geometry.get("type")
    delta = [point1[index] - point0[index] for index in range(3)]
    if kind == "FINITE_CYLINDER":
        cx, cy = geometry["axis_xy"]
        dx, dy = point0[0] - cx, point0[1] - cy
        a = delta[0] * delta[0] + delta[1] * delta[1]
        b = 2.0 * (dx * delta[0] + dy * delta[1])
        c = dx * dx + dy * dy - float(geometry["radius_m"]) ** 2
        if a <= tolerance:
            if c > tolerance:
                return None
        else:
            discriminant = b * b - 4.0 * a * c
            if discriminant < -tolerance:
                return None
            root = math.sqrt(max(0.0, discriminant))
            radial_low, radial_high = sorted(((-b - root) / (2.0 * a), (-b + root) / (2.0 * a)))
            low, high = max(low, radial_low), min(high, radial_high)
            if high < low - tolerance:
                return None
        clipped = _slab(point0[2], delta[2], float(geometry["z_min_m"]), float(geometry["z_max_m"]), low, high, tolerance)
        if clipped is None:
            return None
        low, high = clipped
    elif kind == "CONVEX_HALFSPACES":
        for plane in geometry["halfspaces"]:
            normal = plane["normal"]
            value0 = sum(normal[index] * point0[index] for index in range(3))
            change = sum(normal[index] * delta[index] for index in range(3))
            clipped = _linear_leq(value0, change, float(plane["offset"]), low, high, tolerance)
            if clipped is None:
                return None
            low, high = clipped
    else:
        raise ValueError("UNSUPPORTED_CROSSING_GEOMETRY: " + str(kind))
    low, high = max(0.0, low), min(1.0, high)
    if high - low <= tolerance:
        return None
    return low, high
