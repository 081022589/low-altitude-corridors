"""Validated spatial-path to time mapping for SRCM occupancy prediction.

The representation deliberately keeps geometry and timing separate.  Callers
provide spatial phase paths plus either a constant speed or a monotone
arc-length/time table; absolute timestamps are produced lazily from one
snapshot-aligned anchor.
"""

from __future__ import annotations

import bisect
import math
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Tuple


PATH_TIME_MODEL_VERSION = "SRCM_PATH_TIME_V1"
_TOLERANCE = 1e-9


def _finite(values: Iterable[float]) -> bool:
    return all(math.isfinite(float(value)) for value in values)


def _path_stations(points: Sequence[Sequence[float]]) -> List[float]:
    stations = [0.0]
    for first, second in zip(points, points[1:]):
        stations.append(stations[-1] + math.dist(first, second))
    return stations


def _strictly_increasing(values: Sequence[float]) -> bool:
    return all(second > first for first, second in zip(values, values[1:]))


def validate_path_time_prediction(prediction: Mapping[str, Any]) -> List[str]:
    errors: List[str] = []
    if prediction.get("model_version") != PATH_TIME_MODEL_VERSION:
        return ["UNSUPPORTED_PATH_TIME_MODEL"]
    try:
        anchor = float(prediction["anchor_time_s"])
        current = prediction["current_state"]
        current_position = list(map(float, current["position_xyz"]))
        current_speed = float(current["speed_mps"])
        phases = list(prediction["phases"])
    except (KeyError, TypeError, ValueError):
        return ["INVALID_PATH_TIME_STRUCTURE"]
    valid_current_state = (
        len(current_position) == 3
        and _finite([anchor, current_speed, *current_position])
        and current_speed >= 0.0
    )
    if not valid_current_state:
        errors.append("INVALID_CURRENT_STATE")
    if not phases:
        errors.append("EMPTY_PATH_TIME_PHASES")
        return errors

    previous_end = None
    elapsed_cursor = 0.0
    for index, phase in enumerate(phases):
        try:
            points = [list(map(float, point)) for point in phase["path_xyz"]]
            timing = phase["timing"]
            phase_id = str(phase["phase_id"])
            phase_type = str(phase["phase_type"])
        except (KeyError, TypeError, ValueError):
            errors.append("INVALID_PATH_TIME_PHASE")
            continue
        if not phase_id or not phase_type or len(points) < 2 or any(len(point) != 3 or not _finite(point) for point in points):
            errors.append("INVALID_PATH_TIME_GEOMETRY")
            continue
        if index == 0 and valid_current_state and math.dist(points[0], current_position) > _TOLERANCE:
            errors.append("CURRENT_STATE_PATH_MISMATCH")
        if previous_end is not None and math.dist(points[0], previous_end) > _TOLERANCE:
            errors.append("DISCONNECTED_PATH_TIME_PHASES")
        previous_end = points[-1]
        stations = _path_stations(points)
        if stations[-1] <= _TOLERANCE or not _strictly_increasing(stations):
            errors.append("DEGENERATE_PATH_TIME_GEOMETRY")
            continue
        try:
            start_offset = float(phase.get("start_offset_s", elapsed_cursor))
        except (TypeError, ValueError):
            errors.append("INVALID_PATH_TIME_OFFSET")
            continue
        if start_offset < elapsed_cursor - _TOLERANCE or not math.isfinite(start_offset):
            errors.append("NONMONOTONE_PATH_TIME_PHASE")
            continue
        model = timing.get("model")
        if model == "CONSTANT_SPEED":
            try:
                speed = float(timing["speed_mps"])
            except (KeyError, TypeError, ValueError):
                errors.append("INVALID_CONSTANT_SPEED_PROFILE")
                continue
            if not math.isfinite(speed) or speed <= 0.0:
                errors.append("INVALID_CONSTANT_SPEED_PROFILE")
                continue
            duration = stations[-1] / speed
        elif model == "ARC_TIME_TABLE":
            try:
                table_stations = list(map(float, timing["arc_stations_m"]))
                table_times = list(map(float, timing["elapsed_s"]))
            except (KeyError, TypeError, ValueError):
                errors.append("INVALID_ARC_TIME_TABLE")
                continue
            if (
                len(table_stations) < 2
                or len(table_stations) != len(table_times)
                or not _finite([*table_stations, *table_times])
                or abs(table_stations[0]) > _TOLERANCE
                or abs(table_times[0]) > _TOLERANCE
                or abs(table_stations[-1] - stations[-1]) > 1e-6
                or not _strictly_increasing(table_stations)
                or not _strictly_increasing(table_times)
            ):
                errors.append("INVALID_ARC_TIME_TABLE")
                continue
            duration = table_times[-1]
        else:
            errors.append("UNSUPPORTED_PATH_TIME_PROFILE")
            continue
        elapsed_cursor = start_offset + duration
    return errors


def _interpolate_table(xs: Sequence[float], ys: Sequence[float], value: float) -> float:
    if value <= xs[0]:
        return ys[0]
    if value >= xs[-1]:
        return ys[-1]
    index = bisect.bisect_left(xs, value)
    lower = index - 1
    ratio = (value - xs[lower]) / (xs[index] - xs[lower])
    return ys[lower] + ratio * (ys[index] - ys[lower])


def _point_at_station(
    points: Sequence[Sequence[float]], stations: Sequence[float], value: float
) -> List[float]:
    if value <= stations[0]:
        return list(points[0])
    if value >= stations[-1]:
        return list(points[-1])
    index = bisect.bisect_left(stations, value)
    lower = index - 1
    ratio = (value - stations[lower]) / (stations[index] - stations[lower])
    return [
        points[lower][axis] + ratio * (points[index][axis] - points[lower][axis])
        for axis in range(3)
    ]


def _merged_stations(*station_sets: Sequence[float]) -> List[float]:
    merged: List[float] = []
    for value in sorted(value for values in station_sets for value in values):
        if not merged or value - merged[-1] > _TOLERANCE:
            merged.append(value)
    return merged


def iter_timed_path_segments(prediction: Mapping[str, Any]) -> Iterable[Tuple[Dict[str, Any], List[float], List[float], float, float]]:
    errors = validate_path_time_prediction(prediction)
    if errors:
        raise ValueError("INVALID_PATH_TIME_PREDICTION: " + ",".join(sorted(set(errors))))
    anchor = float(prediction["anchor_time_s"])
    elapsed_cursor = 0.0
    for raw_phase in prediction["phases"]:
        phase = dict(raw_phase)
        points = [list(map(float, point)) for point in phase["path_xyz"]]
        stations = _path_stations(points)
        timing = phase["timing"]
        start_offset = float(phase.get("start_offset_s", elapsed_cursor))
        if timing["model"] == "CONSTANT_SPEED":
            speed = float(timing["speed_mps"])
            breakpoints = stations
            times = [station / speed for station in breakpoints]
        else:
            table_stations = list(map(float, timing["arc_stations_m"]))
            table_times = list(map(float, timing["elapsed_s"]))
            # Split at both geometric vertices and timing knots.  Otherwise a
            # coarse straight path with a nonlinear speed table would silently
            # revert to linear-in-time clipping between its endpoints.
            breakpoints = _merged_stations(stations, table_stations)
            times = [_interpolate_table(table_stations, table_times, station) for station in breakpoints]
        timed_points = [_point_at_station(points, stations, station) for station in breakpoints]
        for index, (first, second) in enumerate(zip(timed_points, timed_points[1:])):
            yield phase, first, second, anchor + start_offset + times[index], anchor + start_offset + times[index + 1]
        elapsed_cursor = start_offset + times[-1]


def prediction_end_time(prediction: Mapping[str, Any]) -> float:
    last = None
    for _, _, _, _, end in iter_timed_path_segments(prediction):
        last = end
    if last is None:
        raise ValueError("EMPTY_PATH_TIME_PREDICTION")
    return last
