"""Deterministic JSON/CSV handoff export for downstream MMKP readers."""

from __future__ import annotations

import csv
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Sequence, Union

from .models import HANDOFF_SCHEMA_VERSION, RESOURCE_REGISTRY_VERSION, SRCM_VERSION


CSV_FIELDS = {
    "crossing_resource_uses.csv": (
        "crossing_id", "enter_s", "exit_s", "local_role", "phase_ids", "role_segments", "use_id", "snapshot_id", "scenario_hash", "resource_registry_version",
        "uav_id", "plan_id", "interval_index", "guarded_enter_s", "guarded_exit_s", "truncated_at_horizon",
        "coverage_status", "source_layer_id",
    ),
    "crossing_competition_events.csv": (
        "event_id", "snapshot_id", "scenario_hash", "resource_registry_version", "plan_a_id", "plan_b_id", "uav_a_id", "uav_b_id", "crossing_id",
        "competition_type", "role_a", "role_b", "overlap_start_s", "overlap_end_s", "guarded_overlap_start_s", "guarded_overlap_end_s", "nominal_overlap_s",
        "guarded_overlap_s", "overlap_class", "use_a_id", "use_b_id", "coverage_status",
    ),
    "plan_pair_evaluation.csv": (
        "pair_key", "pair_evaluation_id", "snapshot_id", "scenario_hash", "resource_registry_version", "plan_a_id", "plan_b_id", "pair_type",
        "evaluation_status", "coverage_complete", "event_ids", "unknown_intervals", "error_code",
    ),
}


def _canonical_hash(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _file_hash(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _write_json(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def _write_csv(path: Path, rows: Sequence[Dict[str, Any]], fields: Sequence[str]) -> None:
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields)
        writer.writeheader()
        for row in rows:
            encoded = {}
            for key in fields:
                value = row.get(key)
                encoded[key] = json.dumps(value, ensure_ascii=False, sort_keys=True) if isinstance(value, (list, dict)) else value
            writer.writerow(encoded)


def export_srcm_handoff(result: Dict[str, Any], output_dir: Union[str, Path]) -> Dict[str, Any]:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    use_ids_by_plan: Dict[str, List[str]] = {}
    for use in result["uses"]:
        use_ids_by_plan.setdefault(use["plan_id"], []).append(use["use_id"])
    evaluations = {item["plan_a_id"]: [] for item in result["pair_evaluations"]}
    for item in result["pair_evaluations"]:
        evaluations.setdefault(item["plan_a_id"], []).append(item["evaluation_status"])
        evaluations.setdefault(item["plan_b_id"], []).append(item["evaluation_status"])
    candidates, fixed = [], []
    identity = {
        "snapshot_id": result["snapshot_id"],
        "scenario_hash": result.get("scenario_hash"),
        "resource_registry_version": RESOURCE_REGISTRY_VERSION,
    }
    for plan in result["plans"]:
        common = {
            **identity,
            "uav_id": plan["uav_id"],
            "plan_id": plan["plan_id"],
            "source_layer_id": plan.get("source_layer_id"),
            "source_mainline_id": plan.get("source_mainline_id"),
            "service_node_id": plan.get("service_node_id"),
            "option_group_id": plan.get("option_group_id"),
            "is_current_assignment": bool(plan.get("is_current_assignment")),
            "committed": bool(plan.get("committed")),
            "trajectory_coverage_status": plan.get("trajectory_coverage_status"),
            "plan_validity": "VALID",
            "evaluation_status": "UNKNOWN" if "UNKNOWN" in evaluations.get(plan["plan_id"], []) else "EVALUATED",
            "crossing_use_ids": sorted(use_ids_by_plan.get(plan["plan_id"], [])),
        }
        if plan["plan_status"] == "CANDIDATE":
            candidates.append(common)
        else:
            fixed.append(
                {
                    **identity,
                    "uav_id": plan["uav_id"],
                    "plan_id": plan["plan_id"],
                    "mode": plan.get("mode"),
                    "committed": bool(plan.get("committed")),
                    "activity_window": [plan.get("activity_start_s"), plan.get("activity_end_s")],
                    "trajectory_coverage_status": plan.get("trajectory_coverage_status"),
                    "termination_reason": plan.get("termination_reason"),
                    "crossing_use_ids": common["crossing_use_ids"],
                }
            )
    registry_hash = _canonical_hash(result["resources"])
    trajectory_hash = _canonical_hash([{key: plan.get(key) for key in ("plan_id", "trajectory", "phases")} for plan in result["plans"]])
    registry = []
    for item in result["resources"]:
        record = dict(item)
        record.update(identity)
        registry.append(record)
    summary = {
        "schema_version": HANDOFF_SCHEMA_VERSION,
        "srcm_version": SRCM_VERSION,
        "snapshot_id": result["snapshot_id"],
        "scenario_hash": result.get("scenario_hash"),
        "resource_registry_version": RESOURCE_REGISTRY_VERSION,
        "resource_registry_hash": registry_hash,
        "trajectory_hash": trajectory_hash,
        "candidate_count": len(candidates),
        "fixed_count": len(fixed),
        "resource_count": len(registry),
        "use_count": len(result["uses"]),
        "vv_event_count": sum(event["competition_type"] == "VV" for event in result["events"]),
        "vh_event_count": sum(event["competition_type"] == "VH" for event in result["events"]),
        "unique_plan_pair_count": len({item["pair_key"] for item in result["pair_evaluations"]}),
        "unique_uav_pair_count": len({tuple(sorted((event["uav_a_id"], event["uav_b_id"]))) for event in result["events"]}),
        "unknown_pair_count": sum(item["evaluation_status"] == "UNKNOWN" for item in result["pair_evaluations"]),
        "timing": result["timing"],
        "performance_ms": {
            "p50": result["timing"]["total_s"] * 1000.0,
            "p95": result["timing"]["total_s"] * 1000.0,
            "p99": result["timing"]["total_s"] * 1000.0,
            "sample_count": 1,
            "interpretation": "single-run package timing; multi-run acceptance benchmark is reported separately"
        },
        "resource_keys": sorted(item["crossing_id"] for item in registry),
    }
    json_outputs = {
        "crossing_resource_registry.json": registry,
        "candidate_plan_manifest.json": sorted(candidates, key=lambda item: item["plan_id"]),
        "fixed_plan_manifest.json": sorted(fixed, key=lambda item: item["plan_id"]),
        "crossing_resource_uses.json": result["uses"],
        "crossing_competition_events.json": result["events"],
        "plan_pair_evaluation.json": result["pair_evaluations"],
        "srcm_summary.json": summary,
    }
    for name, value in json_outputs.items():
        _write_json(output / name, value)
    csv_outputs = {
        "crossing_resource_uses.csv": result["uses"],
        "crossing_competition_events.csv": result["events"],
        "plan_pair_evaluation.csv": result["pair_evaluations"],
    }
    for name, rows in csv_outputs.items():
        _write_csv(output / name, rows, CSV_FIELDS[name])
    files = []
    for name in sorted(list(json_outputs) + list(csv_outputs)):
        path = output / name
        if path.suffix == ".json":
            value = json.loads(path.read_text(encoding="utf-8"))
            row_count = len(value) if isinstance(value, list) else 1
        else:
            row_count = max(0, len(path.read_text(encoding="utf-8").splitlines()) - 1) if path.stat().st_size else 0
        files.append({"path": name, "sha256": _file_hash(path), "row_count": row_count})
    manifest = {
        "schema_version": HANDOFF_SCHEMA_VERSION,
        "srcm_version": SRCM_VERSION,
        "snapshot_id": result["snapshot_id"],
        "scenario_hash": result.get("scenario_hash"),
        "resource_registry_version": RESOURCE_REGISTRY_VERSION,
        "resource_registry_hash": registry_hash,
        "trajectory_hash": trajectory_hash,
        "files": files,
        "reference_integrity": "UNVALIDATED",
        "status": "UNVALIDATED",
    }
    _write_json(output / "srcm_handoff_manifest.json", manifest)
    from .handoff import validate_srcm_handoff

    validation = validate_srcm_handoff(output)
    if validation["status"] == "VALIDATED":
        manifest["reference_integrity"] = "VALIDATED"
        manifest["status"] = "VALIDATED"
        manifest["validation_errors"] = []
    else:
        manifest["reference_integrity"] = "FAILED"
        manifest["status"] = "FAILED"
        manifest["validation_errors"] = validation["errors"]
    _write_json(output / "srcm_handoff_manifest.json", manifest)
    return manifest
