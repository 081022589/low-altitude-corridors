"""Conditional V-V/V-H competition detection on canonical crossing windows."""

from __future__ import annotations

import hashlib
import itertools
import time
from typing import Any, Dict, List, Optional, Tuple

from .crossing_registry import build_crossing_registry
from .models import COMPLETE_COVERAGE, RESOURCE_REGISTRY_VERSION, SRCM_VERSION
from .uses import compute_crossing_uses
from .validation import validate_srcm_input
from .snapshot import resolve_snapshot_context


def _stable_id(prefix: str, *values: str) -> str:
    digest = hashlib.sha256("|".join(values).encode("utf-8")).hexdigest()[:24]
    return prefix + ":" + digest


def _pair_type(first: Dict[str, Any], second: Dict[str, Any]) -> Optional[str]:
    if first["uav_id"] == second["uav_id"]:
        return None
    statuses = {first["plan_status"], second["plan_status"]}
    if statuses == {"CANDIDATE", "FIXED"}:
        return "CANDIDATE_FIXED"
    if statuses == {"CANDIDATE"}:
        return "CANDIDATE_CANDIDATE"
    return None


def _competition_type(role_a: str, role_b: str, source_a: str, source_b: str, resource_layer: str, layer_order: Dict[str, int]) -> Optional[str]:
    vertical_roles = {"VERTICAL_USER", "SOURCE_ENTRY"}
    if role_a in vertical_roles and role_b in vertical_roles:
        return "VV"
    if role_a == "VERTICAL_USER" and role_b == "MAINLINE_USER" and layer_order.get(source_a, -1) > layer_order.get(resource_layer, -1):
        return "VH"
    if role_b == "VERTICAL_USER" and role_a == "MAINLINE_USER" and layer_order.get(source_b, -1) > layer_order.get(resource_layer, -1):
        return "VH"
    return None


def _overlap(start_a: float, end_a: float, start_b: float, end_b: float) -> Tuple[float, float, float]:
    start, end = max(start_a, start_b), min(end_a, end_b)
    return start, end, max(0.0, end - start)


def detect_crossing_competitions(scene_bundle: Dict[str, Any], snapshot: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    started = time.perf_counter()
    validation = validate_srcm_input(scene_bundle)
    if validation["status"] != "VALID":
        codes = {item["code"] for item in validation["errors"]}
        if "MISSING_CROSSING_RESOURCE" in codes:
            raise ValueError("MISSING_CROSSING_RESOURCE")
        raise ValueError("INVALID_SRCM_INPUT: " + ",".join(sorted(codes)))
    snapshot = resolve_snapshot_context(scene_bundle, snapshot)
    resources = build_crossing_registry(scene_bundle)
    resource_by_id = {item["crossing_id"]: item for item in resources}
    layer_order = {item["layer_id"]: int(item["layer_order"]) for item in scene_bundle["layers"]}
    guard = float(scene_bundle["time_profile"].get("optional_guard_s", 0.0) or 0.0)
    tolerance = float(scene_bundle["time_profile"].get("numeric_tolerance_s", 1e-9))
    use_started = time.perf_counter()
    uses_by_plan: Dict[str, List[Dict[str, Any]]] = {
        plan["plan_id"]: compute_crossing_uses(plan, scene_bundle, snapshot) for plan in scene_bundle["plans"]
    }
    use_elapsed = time.perf_counter() - use_started
    events: List[Dict[str, Any]] = []
    evaluations: List[Dict[str, Any]] = []
    compare_started = time.perf_counter()
    plans = sorted(scene_bundle["plans"], key=lambda item: item["plan_id"])
    for first, second in itertools.combinations(plans, 2):
        pair_type = _pair_type(first, second)
        if pair_type is None:
            continue
        plan_a, plan_b = (first, second) if first["plan_id"] < second["plan_id"] else (second, first)
        pair_key = plan_a["plan_id"] + "|" + plan_b["plan_id"]
        pair_events: List[Dict[str, Any]] = []
        for use_a in uses_by_plan[plan_a["plan_id"]]:
            for use_b in uses_by_plan[plan_b["plan_id"]]:
                if use_a["crossing_id"] != use_b["crossing_id"]:
                    continue
                resource = resource_by_id[use_a["crossing_id"]]
                for role_a in use_a["role_segments"]:
                    for role_b in use_b["role_segments"]:
                        kind = _competition_type(
                            role_a["role"], role_b["role"], plan_a.get("source_layer_id"), plan_b.get("source_layer_id"), resource["layer_id"], layer_order
                        )
                        if kind is None:
                            continue
                        nominal_start, nominal_end, nominal = _overlap(role_a["enter_s"], role_a["exit_s"], role_b["enter_s"], role_b["exit_s"])
                        guarded_start, guarded_end, guarded = _overlap(
                            role_a["enter_s"] - guard,
                            role_a["exit_s"] + guard,
                            role_b["enter_s"] - guard,
                            role_b["exit_s"] + guard,
                        )
                        if nominal <= tolerance and guarded <= tolerance:
                            continue
                        overlap_class = "NOMINAL_COMPETITION" if nominal > tolerance else "GUARD_ONLY_COMPETITION"
                        overlap_start = nominal_start if nominal > tolerance else guarded_start
                        overlap_end = nominal_end if nominal > tolerance else guarded_end
                        event_key = (snapshot["snapshot_id"], pair_key, resource["crossing_id"], kind, round(overlap_start, 12), round(overlap_end, 12), overlap_class)
                        if any(existing["_dedup_key"] == event_key for existing in pair_events):
                            continue
                        pair_events.append(
                            {
                                "_dedup_key": event_key,
                                "event_id": _stable_id("event", *map(str, event_key)),
                                "snapshot_id": snapshot["snapshot_id"],
                                "scenario_hash": scene_bundle["meta"].get("scenario_hash"),
                                "resource_registry_version": RESOURCE_REGISTRY_VERSION,
                                "plan_a_id": plan_a["plan_id"],
                                "plan_b_id": plan_b["plan_id"],
                                "uav_a_id": plan_a["uav_id"],
                                "uav_b_id": plan_b["uav_id"],
                                "crossing_id": resource["crossing_id"],
                                "competition_type": kind,
                                "role_a": role_a["role"],
                                "role_b": role_b["role"],
                                "overlap_start_s": overlap_start,
                                "overlap_end_s": overlap_end,
                                "guarded_overlap_start_s": guarded_start,
                                "guarded_overlap_end_s": guarded_end,
                                "nominal_overlap_s": nominal,
                                "guarded_overlap_s": guarded,
                                "overlap_class": overlap_class,
                                "use_a_id": use_a["use_id"],
                                "use_b_id": use_b["use_id"],
                                "coverage_status": "KNOWN",
                            }
                        )
        for event in pair_events:
            event.pop("_dedup_key", None)
        events.extend(pair_events)
        coverage_complete = all(
            plan.get("trajectory_coverage_status") in COMPLETE_COVERAGE for plan in (plan_a, plan_b)
        )
        event_ids = sorted(event["event_id"] for event in pair_events)
        status = "UNKNOWN" if not coverage_complete else ("COMPLETE_WITH_EVENT" if event_ids else "COMPLETE_NO_EVENT")
        evaluations.append(
            {
                "pair_key": pair_key,
                "pair_evaluation_id": _stable_id("pair", snapshot["snapshot_id"], pair_key),
                "snapshot_id": snapshot["snapshot_id"],
                "scenario_hash": scene_bundle["meta"].get("scenario_hash"),
                "resource_registry_version": RESOURCE_REGISTRY_VERSION,
                "plan_a_id": plan_a["plan_id"],
                "plan_b_id": plan_b["plan_id"],
                "pair_type": pair_type,
                "evaluation_status": status,
                "coverage_complete": coverage_complete,
                "event_ids": event_ids,
                "unknown_intervals": [] if coverage_complete else [plan.get("coverage_window") for plan in (plan_a, plan_b) if plan.get("trajectory_coverage_status") not in COMPLETE_COVERAGE],
                "error_code": None if coverage_complete else "UNKNOWN_COVERAGE",
            }
        )
    comparison_elapsed = time.perf_counter() - compare_started
    all_uses = sorted((item for values in uses_by_plan.values() for item in values), key=lambda item: item["use_id"])
    events.sort(key=lambda item: item["event_id"])
    evaluations.sort(key=lambda item: item["pair_key"])
    return {
        "srcm_version": SRCM_VERSION,
        "snapshot_id": snapshot["snapshot_id"],
        "scenario_hash": scene_bundle["meta"].get("scenario_hash"),
        "resource_registry_version": RESOURCE_REGISTRY_VERSION,
        "resources": resources,
        "uses": all_uses,
        "events": events,
        "pair_evaluations": evaluations,
        "plans": plans,
        "validation": validation,
        "timing": {"window_computation_s": use_elapsed, "overlap_comparison_s": comparison_elapsed, "total_s": time.perf_counter() - started},
    }
