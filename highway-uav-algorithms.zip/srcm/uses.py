"""Compute crossing-resource windows from legacy 4-D or path-time motion."""

from __future__ import annotations

import hashlib
import math
from typing import Any, Dict, List

from .crossing_registry import build_crossing_registry
from .interval_clip import clip_segment
from .models import PHASE_ROLES, RESOURCE_REGISTRY_VERSION
from .plan_motion import (
    is_formally_frozen_v_plan,
    iter_plan_motion_segments,
    iter_historical_resource_passages,
    resource_passage_state,
)
from .path_time import iter_timed_path_segments
from .snapshot import resolve_snapshot_context

def _stable_id(*values: str) -> str:
    return hashlib.sha256("|".join(values).encode("utf-8")).hexdigest()[:20]


# NOTE: reconstructed after an accidental deletion during a refactor attempt.
# Behaviour is derived from the surrounding contract and must be re-verified
# against the C-MLPM regression suite before this file is treated as frozen.
def _committed_summary_uses(
    plan: Dict[str, Any],
    scene_bundle: Dict[str, Any],
    snapshot: Dict[str, Any],
    coverage: Dict[tuple[str, str, str | None], Dict[str, Any]] | None = None,
) -> List[Dict[str, Any]]:
    """Materialize C-MLPM's current occupancy projection for a fixed plan."""

    if plan.get("plan_status") != "FIXED":
        return []
    now_s = float(snapshot.get("t0_s", scene_bundle["meta"].get("t0_s", 0.0)))
    rows = [
        row
        for row in iter_historical_resource_passages(plan, now_s=now_s)
        if row.get("crossing_id") is not None
    ]
    if not rows:
        return []
    resource_ids = {
        str(item["crossing_id"])
        for item in build_crossing_registry(scene_bundle)
    }
    tolerance = float(scene_bundle.get("time_profile", {}).get("numeric_tolerance_s", 1e-9))
    guard = float(scene_bundle.get("time_profile", {}).get("optional_guard_s", 0.0) or 0.0)
    horizon_start = float(snapshot.get("t0_s", scene_bundle["meta"].get("t0_s", 0.0)))
    horizon_value = float(snapshot.get("horizon_s", scene_bundle["meta"].get("horizon_s", 0.0)))
    horizon_end = horizon_start + horizon_value if snapshot.get("horizon_end_s") is None else float(snapshot["horizon_end_s"])
    fragments: List[Dict[str, Any]] = []
    for raw in rows:
        crossing_id = str(raw["crossing_id"])
        if crossing_id not in resource_ids:
            raise ValueError("ECJA_OCCUPANCY_SUMMARY_UNKNOWN_CROSSING:" + crossing_id)
        role = str(raw["role"])
        role = {"V": "VERTICAL_USER", "M": "MAINLINE_USER"}.get(role, role)
        if role not in {"VERTICAL_USER", "SOURCE_ENTRY", "MAINLINE_USER"}:
            raise ValueError("ECJA_OCCUPANCY_SUMMARY_UNKNOWN_ROLE:" + role)
        state = resource_passage_state(plan, raw, now_s=now_s)
        if state == "RELEASED" or raw.get("status") == "RELEASED":
            continue
        if (state == "ENTERED_ACTIVE" and not _has_published_commitment(plan, raw)
                and raw.get('source') != 'MEASURED_RESOURCE_FORECAST'):
            # A measured historical window is no longer the future forecast.
            # The remaining occupancy is rebuilt from the current runtime
            # prediction below.
            continue
        if coverage is not None:
            matching = _coverage_rows_for(
                coverage, crossing_id, role, resource_id=raw.get("resource_id"),
                passage_id=raw.get("passage_id"),
            )
            if any(item.get("status") == "RELEASED" for item in matching):
                continue
        enter = max(float(raw["enter_s"]), horizon_start)
        exit_ = min(float(raw["exit_s"]), horizon_end)
        if exit_ - enter <= tolerance:
            continue
        fragments.append(
            {
                "crossing_id": crossing_id,
                "role": role,
                "phase_id": str(raw.get("phase_id", "RESOURCE_TIMING:" + crossing_id)),
                "enter_s": enter,
                "exit_s": exit_,
                "source": str(raw.get("source", "CMLPM_COMMITTED_RESOURCE_PASSAGE")),
            }
        )
    fragments.sort(key=lambda item: (item["crossing_id"], item["enter_s"], item["exit_s"], item["role"]))
    merged: List[Dict[str, Any]] = []
    for fragment in fragments:
        if merged and merged[-1]["crossing_id"] == fragment["crossing_id"] and fragment["enter_s"] <= merged[-1]["exit_s"] + tolerance:
            current = merged[-1]
            current["exit_s"] = max(current["exit_s"], fragment["exit_s"])
            current["role_segments"].append({"role": fragment["role"], "phase_id": fragment["phase_id"], "enter_s": fragment["enter_s"], "exit_s": fragment["exit_s"]})
            current["phase_ids"] = sorted(set(current["phase_ids"] + [fragment["phase_id"]]))
            roles = sorted({segment["role"] for segment in current["role_segments"]})
            current["local_role"] = roles[0] if len(roles) == 1 else "COMPOSITE"
        else:
            merged.append(
                {
                    "crossing_id": fragment["crossing_id"],
                    "enter_s": fragment["enter_s"],
                    "exit_s": fragment["exit_s"],
                    "local_role": fragment["role"],
                    "phase_ids": [fragment["phase_id"]],
                    "role_segments": [{"role": fragment["role"], "phase_id": fragment["phase_id"], "enter_s": fragment["enter_s"], "exit_s": fragment["exit_s"]}],
                    "occupancy_source": fragment["source"],
                }
            )
    counts: Dict[str, int] = {}
    for item in merged:
        index = counts.get(item["crossing_id"], 0)
        counts[item["crossing_id"]] = index + 1
        item.update(
            {
                "use_id": "use:" + _stable_id(snapshot["snapshot_id"], plan["plan_id"], item["crossing_id"], str(index)),
                "snapshot_id": snapshot["snapshot_id"],
                "scenario_hash": scene_bundle["meta"].get("scenario_hash"),
                "resource_registry_version": RESOURCE_REGISTRY_VERSION,
                "uav_id": plan["uav_id"],
                "plan_id": plan["plan_id"],
                "interval_index": index,
                "guarded_enter_s": max(horizon_start, item["enter_s"] - guard),
                "guarded_exit_s": min(horizon_end, item["exit_s"] + guard),
                "truncated_at_horizon": item["exit_s"] >= horizon_end - tolerance,
                "coverage_status": plan.get("trajectory_coverage_status", "UNKNOWN_COVERAGE"),
                "source_layer_id": plan.get("source_layer_id"),
                "occupancy_source": item.get("occupancy_source", "CMLPM_COMMITTED_RESOURCE_PASSAGE"),
            }
        )
    return merged


# The transfer curve is fixed by the access interface and the vehicle type, so
# the windows where it enters and leaves each registered crossing are identical
# for every candidate that uses that interface.  Computing them once and
# shifting by the candidate's transfer start keeps the frozen window semantics
# while removing the per-candidate segment-by-segment clipping.
_TRANSFER_WINDOW_CACHE: Dict[tuple, tuple] = {}


def _transfer_phase_windows(
    plan: Dict[str, Any], scene_bundle: Dict[str, Any]
) -> tuple | None:
    """(phase_start_s, [window rows]) for the fixed transfer phase, or ``None``."""

    prediction = plan.get("motion_prediction") or {}
    route_id = plan.get("route_id")
    vehicle_type = (plan.get("formal_motion_contract") or {}).get("vehicle_type")
    if not prediction or not route_id or not vehicle_type:
        return None
    phase = next(
        (item for item in prediction.get("phases", ()) if item.get("phase_type") == "SOURCE_EXIT"),
        None,
    )
    if phase is None or (phase.get("timing") or {}).get("model") != "ARC_TIME_TABLE":
        return None
    key = (str(scene_bundle["meta"].get("scenario_hash")), str(route_id), str(vehicle_type))
    anchor = float(prediction.get("anchor_time_s", 0.0))
    phase_start = anchor + float(phase.get("start_offset_s", 0.0))
    cached = _TRANSFER_WINDOW_CACHE.get(key)
    if cached is not None:
        return phase_start, cached
    tolerance = float(scene_bundle.get("time_profile", {}).get("numeric_tolerance_s", 1e-9))
    resources = list(build_crossing_registry(scene_bundle))
    rows: List[Dict[str, Any]] = []
    for segment_phase, point0, point1, start_s, end_s in iter_timed_path_segments(prediction):
        if segment_phase.get("phase_id") != phase["phase_id"]:
            continue
        for resource in resources:
            clipped = clip_segment(list(point0), list(point1), resource["geometry"], tolerance=1e-12)
            if clipped is None:
                continue
            enter = start_s + clipped[0] * (end_s - start_s) - phase_start
            exit_ = start_s + clipped[1] * (end_s - start_s) - phase_start
            if exit_ - enter <= tolerance:
                continue
            rows.append(
                {
                    "crossing_id": str(resource["crossing_id"]),
                    "role": PHASE_ROLES.get("SOURCE_EXIT", "SOURCE_ENTRY"),
                    "phase_id": str(phase["phase_id"]),
                    "enter_offset_s": enter,
                    "exit_offset_s": exit_,
                }
            )
    _TRANSFER_WINDOW_CACHE[key] = rows
    return phase_start, rows


def _predicted_crossing_uses(
    plan: Dict[str, Any], scene_bundle: Dict[str, Any], snapshot: Dict[str, Any]
) -> List[Dict[str, Any]]:
    """Predict uses from the current fixed path when no certified row covers them."""

    tolerance = float(scene_bundle.get("time_profile", {}).get("numeric_tolerance_s", 1e-9))
    guard = float(scene_bundle.get("time_profile", {}).get("optional_guard_s", 0.0) or 0.0)
    horizon_start = float(snapshot.get("t0_s", scene_bundle["meta"].get("t0_s", 0.0)))
    horizon_value = float(snapshot.get("horizon_s", scene_bundle["meta"].get("horizon_s", 0.0)))
    horizon_end = horizon_start + horizon_value if snapshot.get("horizon_end_s") is None else float(snapshot["horizon_end_s"])
    fragments: List[Dict[str, Any]] = []
    segment_records = list(iter_plan_motion_segments(plan))
    resource_timings = list(iter_historical_resource_passages(plan, now_s=horizon_start))
    coverage = _authoritative_coverage(plan)
    geometry_roles = {
        PHASE_ROLES.get(segment["phase_type"], "UNKNOWN_ROLE")
        for segment in segment_records
    }
    # A candidate with no published passage and no authoritative coverage has
    # purely predicted occupancy.  Its transfer phase is interface-fixed, so the
    # windows are shifted from the cached table instead of being re-clipped.
    transfer = (
        _transfer_phase_windows(plan, scene_bundle)
        if plan.get("plan_status") == "CANDIDATE" and not resource_timings and not coverage
        else None
    )
    if transfer is not None:
        transfer_start, transfer_rows = transfer
        for row in transfer_rows:
            enter = max(transfer_start + row["enter_offset_s"], float(plan["activity_start_s"]), horizon_start)
            exit_ = min(transfer_start + row["exit_offset_s"], float(plan["activity_end_s"]), horizon_end)
            if exit_ - enter <= tolerance:
                continue
            fragments.append(
                {
                    "crossing_id": row["crossing_id"],
                    "role": row["role"],
                    "phase_id": row["phase_id"],
                    "enter_s": enter,
                    "exit_s": exit_,
                    "source": "PREDICTED_CURRENT_TRAFFIC_STATE",
                }
            )
    for resource in build_crossing_registry(scene_bundle):
        released_rows = [
            item
            for role in geometry_roles
            for item in _coverage_rows_for(
                coverage, str(resource["crossing_id"]), role,
                resource_id=resource.get("segment_resource_id"),
            )
            if item.get("status") == "RELEASED"
        ]
        if released_rows:
            continue
        published_timings = _resource_passage_timings(
            resource, resource_timings, plan=plan
        )
        used_published_timing = False
        for published_timing in published_timings:
            state = resource_passage_state(plan, published_timing, now_s=horizon_start)
            # A released row or a verified release event is itself evidence
            # that the old path must not re-create this occupancy.
            if published_timing.get("status") == "RELEASED" or state == "RELEASED":
                continue
            if state == "ENTERED_ACTIVE" and not _has_published_commitment(plan, published_timing):
                continue
            timing_enter = max(float(published_timing["enter_s"]), horizon_start)
            timing_exit = min(float(published_timing["exit_s"]), horizon_end)
            if timing_exit - timing_enter <= tolerance:
                continue
            fragments.append(
                {
                    "crossing_id": resource["crossing_id"],
                    "role": published_timing["role"],
                    "phase_id": published_timing.get(
                        "phase_id",
                        "RESOURCE_TIMING:" + resource["crossing_id"],
                    ),
                    "enter_s": timing_enter,
                    "exit_s": timing_exit,
                    "source": published_timing["source"],
                }
            )
            used_published_timing = True
        if used_published_timing:
            # Published rows are authoritative for their own passage.  The
            # geometric fallback remains below only when every published row
            # was released or represented an active non-committed history row.
            if not any(
                resource_passage_state(plan, row, now_s=horizon_start) == "ENTERED_ACTIVE"
                and not _has_published_commitment(plan, row)
                for row in published_timings
            ):
                continue
        has_released_timing = any(
            row.get("status") == "RELEASED"
            or resource_passage_state(plan, row, now_s=horizon_start) == "RELEASED"
            for row in published_timings
        )
        has_uncommitted_active = any(
            resource_passage_state(plan, row, now_s=horizon_start) == "ENTERED_ACTIVE"
            and not _has_published_commitment(plan, row)
            for row in published_timings
        )
        if has_released_timing and not has_uncommitted_active:
            continue
        for segment in segment_records:
            if transfer is not None and segment["phase_type"] == "SOURCE_EXIT":
                continue
            segment_start = segment["start_s"]
            segment_end = segment["end_s"]
            spatial0 = segment["point0_xyz"]
            spatial1 = segment["point1_xyz"]
            active_start = max(segment_start, float(plan["activity_start_s"]), horizon_start)
            active_end = min(segment_end, float(plan["activity_end_s"]), horizon_end)
            if active_end - active_start <= tolerance:
                continue
            ratio0 = (active_start - segment_start) / (segment_end - segment_start)
            ratio1 = (active_end - segment_start) / (segment_end - segment_start)
            sub0 = [spatial0[index] + ratio0 * (spatial1[index] - spatial0[index]) for index in range(3)]
            sub1 = [spatial0[index] + ratio1 * (spatial1[index] - spatial0[index]) for index in range(3)]
            clipped = clip_segment(sub0, sub1, resource["geometry"], tolerance=1e-12)
            if clipped is None:
                continue
            enter = active_start + clipped[0] * (active_end - active_start)
            exit_ = active_start + clipped[1] * (active_end - active_start)
            if exit_ - enter <= tolerance:
                continue
            fragments.append(
                {
                    "crossing_id": resource["crossing_id"],
                    "role": PHASE_ROLES.get(segment["phase_type"], "UNKNOWN_ROLE"),
                    "phase_id": segment["phase_id"],
                    "enter_s": enter,
                    "exit_s": exit_,
                    "source": "PREDICTED_CURRENT_TRAFFIC_STATE",
                }
            )
    fragments.sort(key=lambda item: (item["crossing_id"], item["enter_s"], item["exit_s"], item["role"]))
    merged: List[Dict[str, Any]] = []
    for fragment in fragments:
        if merged and merged[-1]["crossing_id"] == fragment["crossing_id"] and fragment["enter_s"] <= merged[-1]["exit_s"] + tolerance:
            current = merged[-1]
            current["exit_s"] = max(current["exit_s"], fragment["exit_s"])
            current["role_segments"].append({"role": fragment["role"], "phase_id": fragment["phase_id"], "enter_s": fragment["enter_s"], "exit_s": fragment["exit_s"]})
            current["phase_ids"] = sorted(set(current["phase_ids"] + [fragment["phase_id"]]))
            roles = sorted({segment["role"] for segment in current["role_segments"]})
            current["local_role"] = roles[0] if len(roles) == 1 else "COMPOSITE"
        else:
            merged.append(
                {
                    "crossing_id": fragment["crossing_id"],
                    "enter_s": fragment["enter_s"],
                    "exit_s": fragment["exit_s"],
                    "local_role": fragment["role"],
                    "phase_ids": [fragment["phase_id"]],
                    "role_segments": [{"role": fragment["role"], "phase_id": fragment["phase_id"], "enter_s": fragment["enter_s"], "exit_s": fragment["exit_s"]}],
                    "occupancy_source": fragment["source"],
                }
            )
    counts: Dict[str, int] = {}
    for item in merged:
        index = counts.get(item["crossing_id"], 0)
        counts[item["crossing_id"]] = index + 1
        item.update(
            {
                "use_id": "use:" + _stable_id(snapshot["snapshot_id"], plan["plan_id"], item["crossing_id"], str(index)),
                "snapshot_id": snapshot["snapshot_id"],
                "scenario_hash": scene_bundle["meta"].get("scenario_hash"),
                "resource_registry_version": RESOURCE_REGISTRY_VERSION,
                "uav_id": plan["uav_id"],
                "plan_id": plan["plan_id"],
                "interval_index": index,
                "guarded_enter_s": max(horizon_start, item["enter_s"] - guard),
                "guarded_exit_s": min(horizon_end, item["exit_s"] + guard),
                "truncated_at_horizon": item["exit_s"] >= horizon_end - tolerance,
                "coverage_status": plan.get("trajectory_coverage_status", "UNKNOWN_COVERAGE"),
                "source_layer_id": plan.get("source_layer_id"),
                "occupancy_source": item.get("occupancy_source", "PREDICTED_CURRENT_TRAFFIC_STATE"),
            }
        )
    return merged


def _normalized_role(role: Any) -> str:
    return {
        "V": "VERTICAL_USER",
        "M": "MAINLINE_USER",
        "VERTICAL_USER": "VERTICAL_USER",
        "SOURCE_ENTRY": "SOURCE_ENTRY",
        "MAINLINE_USER": "MAINLINE_USER",
        "COMPOSITE": "COMPOSITE",
    }.get(str(role), str(role))


def _use_roles(use: Dict[str, Any]) -> set[str]:
    roles = {_normalized_role(use.get("local_role", ""))}
    roles.update(_normalized_role(item.get("role", "")) for item in use.get("role_segments", ()))
    return roles


def _has_published_commitment(
    plan: Dict[str, Any], row: Dict[str, Any]
) -> bool:
    """Whether a row's future window is protected against live re-prediction."""

    role = _normalized_role(row.get("role", ""))
    if role == "VERTICAL_USER" and is_formally_frozen_v_plan(plan):
        return True
    return str(row.get("source", "")).startswith("CMLPM_")


def _coverage_rows_for(
    coverage: Dict[tuple[str, str, str | None], Dict[str, Any]],
    crossing_id: str,
    role: str,
    *,
    resource_id: Any = None,
    passage_id: Any = None,
) -> List[Dict[str, Any]]:
    role = _normalized_role(role)
    rows = [
        item
        for (item_crossing, item_role, item_passage), item in coverage.items()
        if item_crossing == str(crossing_id)
        and item_role == role
        and (passage_id is None or item_passage in {None, str(passage_id)})
    ]
    if resource_id is not None:
        rows = [
            item for item in rows
            if item.get("resource_id") in {None, str(resource_id)}
        ]
    return rows


def _authoritative_coverage(plan: Dict[str, Any]) -> Dict[tuple[str, str, str | None], Dict[str, Any]]:
    """Return the lifecycle state from the one C-MLPM passage interface."""

    coverage: Dict[tuple[str, str, str | None], Dict[str, Any]] = {}
    for raw in plan.get("cmlpm_resource_passages", ()):
        if not isinstance(raw, dict):
            continue
        crossing_id = str(raw.get("crossing_id", ""))
        if not crossing_id:
            continue
        role = _normalized_role(raw.get("role", ""))
        passage_id = (
            str(raw.get("passage_id"))
            if raw.get("passage_id") is not None
            else (str(raw.get("interval_index")) if raw.get("interval_index") is not None else None)
        )
        key = (crossing_id, role, passage_id)
        item = dict(raw)
        item["role"] = role
        item["status"] = str(raw.get("status", "")).upper()
        if key in coverage:
            prior = coverage[key]
            if any(
                prior.get(field) is not None
                and item.get(field) is not None
                and abs(float(prior[field]) - float(item[field])) > 1e-9
                for field in ("enter_s", "exit_s")
            ) or prior.get("status") != item.get("status"):
                raise ValueError(
                    "ECJA_RESOURCE_PASSAGE_DUPLICATE_CONFLICT:" + crossing_id
                )
        coverage[key] = item
    return coverage


def _frozen_v_resource_windows(plan: Dict[str, Any]) -> Dict[str, tuple[float, float]]:
    """Return immutable C-MLPM V entry/exit windows."""

    if not is_formally_frozen_v_plan(plan):
        return {}
    windows: Dict[str, tuple[float, float]] = {}
    for window in plan["resource_windows"]:
        if isinstance(window, dict):
            resource_id = window.get("resource_id")
            enter_s = window.get("enter_s", window.get("start_s"))
            exit_s = window.get("exit_s", window.get("end_s"))
        else:
            resource_id, enter_s, exit_s = window
        if resource_id is None or enter_s is None or exit_s is None:
            raise ValueError("ECJA_FROZEN_V_RESOURCE_WINDOW_INVALID")
        enter_s = float(enter_s)
        exit_s = float(exit_s)
        if not math.isfinite(enter_s) or not math.isfinite(exit_s) or exit_s <= enter_s:
            raise ValueError("ECJA_FROZEN_V_RESOURCE_WINDOW_INVALID")
        key = str(resource_id)
        prior = windows.get(key)
        if prior is not None and any(
            abs(left - right) > 1e-9 for left, right in zip(prior, (enter_s, exit_s))
        ):
            raise ValueError("ECJA_FROZEN_V_RESOURCE_WINDOW_DUPLICATE_CONFLICT:" + key)
        windows[key] = (enter_s, exit_s)
    return windows


def _frozen_v_resource_exits(plan: Dict[str, Any]) -> Dict[str, float]:
    return {resource_id: window[1] for resource_id, window in _frozen_v_resource_windows(plan).items()}


def _resource_passage_timings(
    resource: Dict[str, Any],
    timings: List[Dict[str, Any]],
    *,
    plan: Dict[str, Any] | None = None,
) -> List[Dict[str, Any]]:
    """Find canonical C-MLPM timings for one crossing resource.

    The historical interface guarantees a crossing identity for every row.
    Alias-only rows are rejected because accepting them would recreate the old
    dual-identity interface that caused the C-MLPM/SRCM conflict.
    """

    crossing_id = str(resource.get("crossing_id", ""))
    aliases = {
        str(value)
        for value in (
            resource.get("crossing_id"),
            resource.get("segment_resource_id"),
            resource.get("resource_id"),
        )
        if value is not None
    }
    explicit = [row for row in timings if row.get("crossing_id") == crossing_id]
    for row in explicit:
        if row.get("resource_id") is not None and row.get("resource_id") not in aliases:
            raise ValueError(
                "ECJA_RESOURCE_PASSAGE_IDENTITY_CONFLICT:" + crossing_id
            )
    candidates = explicit
    if not candidates:
        return []
    unique: list[Dict[str, Any]] = []
    for row in candidates:
        if any(
            existing.get("enter_s") == row.get("enter_s")
            and existing.get("exit_s") == row.get("exit_s")
            and existing.get("role") == row.get("role")
            and existing.get("passage_id") == row.get("passage_id")
            for existing in unique
        ):
            continue
        unique.append(row)
    if len(unique) > 1 and not (
        all(row.get("crossing_id") == crossing_id for row in unique)
        and all(row.get("passage_id") is not None for row in unique)
        and len({row.get("passage_id") for row in unique}) == len(unique)
    ):
        raise ValueError(
            "ECJA_AMBIGUOUS_RESOURCE_ALIAS:" + str(plan.get("uav_id") if plan else "")
            + ":" + crossing_id + ":" + ",".join(sorted(aliases))
        )
    return sorted(
        unique,
        key=lambda row: (
            float(row["enter_s"]),
            float(row["exit_s"]),
            str(row.get("passage_id") or ""),
        ),
    )


def _resource_passage_timing(
    resource: Dict[str, Any],
    timings: List[Dict[str, Any]],
    *,
    plan: Dict[str, Any] | None = None,
) -> Dict[str, Any] | None:
    """Compatibility wrapper for callers that expect one passage."""

    rows = _resource_passage_timings(resource, timings, plan=plan)
    if len(rows) > 1:
        raise ValueError(
            "ECJA_RESOURCE_PASSAGE_DUPLICATE_CONFLICT:"
            + str(resource.get("crossing_id"))
        )
    return rows[0] if rows else None


def _validate_frozen_v_windows(
    plan: Dict[str, Any],
    timings: List[Dict[str, Any]],
    coverage: Dict[tuple[str, str, str | None], Dict[str, Any]],
    *,
    now_s: float,
    tolerance: float,
) -> None:
    frozen = _frozen_v_resource_windows(plan)
    if not frozen:
        return
    for resource_id, (expected_enter, expected_exit) in frozen.items():
        candidates = [
            row for row in timings
            if row.get("role") == "VERTICAL_USER"
            and row.get("resource_id") == resource_id
        ]
        if not candidates:
            raise ValueError(
                "ECJA_FROZEN_V_RESOURCE_TIMING_MISSING:" + str(plan.get("uav_id")) + ":" + resource_id
            )
        for row in candidates:
            if (
                abs(float(row["enter_s"]) - expected_enter) > tolerance
                or abs(float(row["exit_s"]) - expected_exit) > tolerance
            ):
                raise ValueError(
                    "ECJA_FROZEN_V_RESOURCE_WINDOW_MISMATCH:"
                    + str(plan.get("uav_id")) + ":" + resource_id
                )
            crossing_id = row.get("crossing_id")
            if crossing_id is None:
                continue
            matching = _coverage_rows_for(
                coverage, str(crossing_id), "VERTICAL_USER", resource_id=resource_id
            )
            if expected_exit > now_s + tolerance and not matching:
                raise ValueError(
                    "ECJA_ACTIVE_RESOURCE_OCCUPANCY_MISSING:"
                    + str(plan.get("uav_id")) + ":" + str(crossing_id)
                )
            for item in matching:
                for field, expected in (("enter_s", expected_enter), ("exit_s", expected_exit)):
                    if item.get(field) is not None and abs(float(item[field]) - expected) > tolerance:
                        raise ValueError(
                            "ECJA_FROZEN_V_RESOURCE_WINDOW_MISMATCH:"
                            + str(plan.get("uav_id")) + ":" + resource_id
                        )
                if expected_exit > now_s + tolerance and item.get("status") == "RELEASED":
                    raise ValueError(
                        "ECJA_RESOURCE_STATE_CONFLICT:" + str(plan.get("uav_id")) + ":" + resource_id
                    )


def _validate_active_coverage(
    plan: Dict[str, Any],
    timings: List[Dict[str, Any]],
    coverage: Dict[tuple[str, str, str | None], Dict[str, Any]],
    *,
    now_s: float,
    tolerance: float,
) -> None:
    for item in coverage.values():
        status = str(item.get("status", "")).upper()
        crossing_id = str(item.get("crossing_id", ""))
        role = _normalized_role(item.get("role", ""))
        if status not in {"CERTIFIED", "IN_PROGRESS"}:
            continue
        timing = next(
            (
                row for row in timings
                if row.get("crossing_id") == crossing_id
                and _normalized_role(row.get("role")) == role
            ),
            None,
        )
        if (
            timing is None
            and role == "VERTICAL_USER"
            and is_formally_frozen_v_plan(plan)
        ):
            raise ValueError(
                "ECJA_ACTIVE_RESOURCE_OCCUPANCY_MISSING:"
                + str(plan.get("uav_id")) + ":" + crossing_id
            )
        if timing is None:
            raise ValueError(
                "ECJA_ACTIVE_RESOURCE_OCCUPANCY_MISSING:"
                + str(plan.get("uav_id")) + ":" + crossing_id
            )
        for field in ("enter_s", "exit_s"):
            if item.get(field) is not None and abs(float(item[field]) - float(timing[field])) > tolerance:
                raise ValueError(
                    "ECJA_RESOURCE_STATE_CONFLICT:" + str(plan.get("uav_id")) + ":" + crossing_id
                )


def compute_crossing_uses(plan: Dict[str, Any], scene_bundle: Dict[str, Any], snapshot: Dict[str, Any]) -> List[Dict[str, Any]]:
    snapshot = resolve_snapshot_context(scene_bundle, snapshot)
    coverage = _authoritative_coverage(plan)
    now_s = float(snapshot["t0_s"])
    resource_timings = list(iter_historical_resource_passages(plan, now_s=now_s))
    tolerance = float(scene_bundle.get("time_profile", {}).get("numeric_tolerance_s", 1e-9))
    has_cmlpm_history = (
        plan.get("plan_status") == "FIXED"
        and "cmlpm_resource_passages" in plan
    )
    if has_cmlpm_history:
        # Apply the read-time lifecycle transition before validating active
        # coverage.  A frozen V resource is released by its published C-MLPM
        # exit time; an actual RESOURCE_EXIT event is not required for this
        # protected flow.  The published window itself is never rewritten.
        frozen_v_exits = _frozen_v_resource_exits(plan)
        for item in coverage.values():
            resource_id = item.get("resource_id")
            planned_exit = (
                frozen_v_exits.get(str(resource_id))
                if _normalized_role(item.get("role", "")) == "VERTICAL_USER"
                and resource_id is not None
                else None
            )
            if planned_exit is not None:
                previous_exit = item.get("exit_s")
                if previous_exit is not None and abs(float(previous_exit) - planned_exit) > tolerance:
                    raise ValueError(
                        "ECJA_FROZEN_V_RESOURCE_WINDOW_MISMATCH:"
                        + str(plan.get("uav_id")) + ":" + str(resource_id)
                    )
                item["exit_s"] = planned_exit
                if planned_exit <= now_s + tolerance:
                    item["status"] = "RELEASED"
                    item["source"] = "FROZEN_V_PLANNED_EXIT"
                elif item.get("status") == "RELEASED":
                    item["status"] = "CERTIFIED"
                    item["source"] = "CMLPM_COMMITTED_RESOURCE_PASSAGE"
                continue
            if (
                item.get("status") in {"CERTIFIED", "IN_PROGRESS"}
                and item.get("exit_s") is not None
                and float(item["exit_s"]) <= now_s + tolerance
            ):
                if resource_passage_state(plan, item, now_s=now_s) != "RELEASED":
                    raise ValueError(
                        "ECJA_CERTIFIED_RESOURCE_EXIT_NOT_OBSERVED:"
                        + str(plan.get("uav_id")) + ":"
                        + str(item.get("crossing_id"))
                    )
                item["status"] = "RELEASED"
                item["source"] = "OBSERVED_RESOURCE_EXIT"
        _validate_frozen_v_windows(
            plan, resource_timings, coverage, now_s=now_s, tolerance=tolerance
        )
        _validate_active_coverage(
            plan, resource_timings, coverage, now_s=now_s, tolerance=tolerance
        )
    summary_uses = _committed_summary_uses(
        plan, scene_bundle, snapshot, coverage=coverage
    )
    if has_cmlpm_history:
        predicted = _predicted_crossing_uses(plan, scene_bundle, snapshot)
        summary_keys = {
            (str(use["crossing_id"]), _normalized_role(use.get("local_role", "")))
            for use in summary_uses
        }
        merged = list(summary_uses)
        for use in predicted:
            crossing_id = str(use["crossing_id"])
            roles = _use_roles(use)
            covered = [
                item
                for role in roles
                for item in _coverage_rows_for(coverage, crossing_id, role)
            ]
            if any(item.get("status") == "RELEASED" for item in covered):
                continue
            if covered:
                continue
            if (crossing_id, _normalized_role(use.get("local_role", ""))) in summary_keys:
                continue
            # A certified row covers only its own resource/role.  Missing
            # rows remain eligible for a current-state prediction, which is
            # the required partial-coverage behavior.
            merged.append(use)
        merged.sort(key=lambda item: (item["crossing_id"], item["enter_s"], item["exit_s"], item.get("local_role", "")))
        return merged
    if summary_uses:
        return summary_uses
    return _predicted_crossing_uses(plan, scene_bundle, snapshot)
