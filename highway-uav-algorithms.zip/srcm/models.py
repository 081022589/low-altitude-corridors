SRCM_VERSION = "SRCM_CROSSING_V3_0_1"
HANDOFF_SCHEMA_VERSION = "SRCM_HANDOFF_V3_0_1"
RESOURCE_REGISTRY_VERSION = "SRCM_CROSSING_RESOURCE_REGISTRY_V1"

PHASE_ROLES = {
    "H_CRUISE": "MAINLINE_USER",
    "SOURCE_EXIT": "SOURCE_ENTRY",
    "V_DESCENT": "VERTICAL_USER",
    # Input role aliases for the new, geometrically measured re-entry phases.
    # Competition formulas and the existing three physical role classes stay
    # unchanged. These aliases do not turn ascent into an optimized request.
    "REENTRY_CLIMB": "VERTICAL_USER",
    "REENTRY_TRANSFER": "SOURCE_ENTRY",
}

COMPLETE_COVERAGE = {
    "COMPLETE_FOR_HORIZON",
    "COMPLETE_TO_ENGINEERING_BOUNDARY",
    "LEFT_MONITORED_REGION",
}
