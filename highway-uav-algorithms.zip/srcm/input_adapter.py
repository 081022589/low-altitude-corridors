import json
from pathlib import Path
from typing import Any, Dict, Union


def load_srcm_input(scene_path: Union[str, Path]) -> Dict[str, Any]:
    with Path(scene_path).open("r", encoding="utf-8") as stream:
        return json.load(stream)
