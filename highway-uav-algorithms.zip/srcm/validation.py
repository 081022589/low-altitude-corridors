"""Structural validation without mutating the environment bundle."""

from typing import Any, Dict, List

from .path_time import validate_path_time_prediction


REQUIRED_TOP_LEVEL = {
    "meta",
    "source_lineage",
    "layers",
    "mainlines",
    "service_nodes",
    "physical_shafts",
    "access_interfaces",
    "access_routes",
    "crossing_resources",
    "plans",
    "time_profile",
    "traffic_profile",
}


def validate_srcm_input(scene_bundle: Dict[str, Any]) -> Dict[str, Any]:
    errors: List[Dict[str, Any]] = []
    missing = sorted(REQUIRED_TOP_LEVEL - set(scene_bundle))
    if missing:
        errors.append({"code": "INVALID", "detail": "missing top-level keys", "items": missing})
        return {"status": "INVALID", "errors": errors}
    crossing_ids = [item.get("crossing_id") for item in scene_bundle["crossing_resources"]]
    if len(crossing_ids) != len(set(crossing_ids)):
        errors.append({"code": "DUPLICATE_CROSSING_ID", "detail": "crossing_id values must be unique"})
    statuses: Dict[str, set] = {}
    mainlines = {item.get("mainline_id"): item for item in scene_bundle["mainlines"]}
    shafts = {item.get("physical_shaft_id") for item in scene_bundle["physical_shafts"]}
    layers = {item.get("layer_id") for item in scene_bundle["layers"]}
    for resource in scene_bundle["crossing_resources"]:
        mainline = mainlines.get(resource.get("mainline_id"))
        if mainline is None or resource.get("physical_shaft_id") not in shafts or resource.get("layer_id") not in layers:
            errors.append({"code": "UNKNOWN_RESOURCE_REFERENCE", "detail": resource.get("crossing_id")})
        elif mainline.get("layer_id") != resource.get("layer_id") or mainline.get("direction_id") != resource.get("direction_id"):
            errors.append({"code": "CROSSING_MAINLINE_IDENTITY_MISMATCH", "detail": resource.get("crossing_id")})
    plan_ids = set()
    for plan in scene_bundle["plans"]:
        if plan.get("plan_id") in plan_ids:
            errors.append({"code": "DUPLICATE_PLAN_ID", "detail": plan.get("plan_id")})
        plan_ids.add(plan.get("plan_id"))
        statuses.setdefault(plan.get("uav_id"), set()).add(plan.get("plan_status"))
        trajectory = plan.get("trajectory")
        prediction = plan.get("motion_prediction")
        if trajectory and prediction:
            errors.append({"code": "AMBIGUOUS_MOTION_REPRESENTATION", "detail": plan.get("plan_id")})
        elif prediction:
            prediction_errors = validate_path_time_prediction(prediction)
            for code in sorted(set(prediction_errors)):
                errors.append({"code": code, "detail": plan.get("plan_id")})
            try:
                anchor_time = float(prediction["anchor_time_s"])
                activity_start = float(plan["activity_start_s"])
            except (KeyError, TypeError, ValueError):
                pass
            else:
                if abs(anchor_time - activity_start) > 1e-9:
                    errors.append({"code": "MOTION_ANCHOR_ACTIVITY_MISMATCH", "detail": plan.get("plan_id")})
        elif plan.get("trajectory_coverage_status") == "ROUTE_ONLY_NO_MOTION_AUTHORITY":
            # ECJA route-only candidates intentionally have no trajectory.
            # C-MLPM creates the E-anchor timing after node assignment.
            pass
        else:
            times = [point[0] for point in trajectory or []]
            if len(times) < 2 or any(second <= first for first, second in zip(times, times[1:])):
                errors.append({"code": "INVALID_TRAJECTORY_TIME", "detail": plan.get("plan_id")})
    for uav_id, values in statuses.items():
        if "FIXED" in values and "CANDIDATE" in values:
            errors.append({"code": "FIXED_CANDIDATE_IDENTITY_COLLISION", "detail": uav_id})
    known = set(crossing_ids)
    for route in scene_bundle["access_routes"]:
        absent = sorted(set(route.get("crossing_ids_ordered", [])) - known)
        if absent:
            errors.append({"code": "MISSING_CROSSING_RESOURCE", "detail": route.get("route_id"), "items": absent})
    if scene_bundle.get("meta", {}).get("profile_type") != "ANALYTIC_MICRO":
        route_ids = {item.get("route_id") for item in scene_bundle["access_routes"]}
        for plan in scene_bundle["plans"]:
            if plan.get("plan_status") == "CANDIDATE" and plan.get("route_id") not in route_ids:
                errors.append({"code": "INVALID_ROUTE", "detail": plan.get("plan_id")})
    status = "VALID" if not errors else "INVALID"
    return {"status": status, "errors": errors}
