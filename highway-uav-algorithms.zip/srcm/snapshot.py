"""Resolve one immutable, unambiguous prediction snapshot for an SRCM run."""

from __future__ import annotations

from typing import Any, Dict, Mapping, Optional


def resolve_snapshot_context(scene_bundle: Mapping[str, Any], snapshot: Optional[Mapping[str, Any]] = None) -> Dict[str, Any]:
    meta = scene_bundle["meta"]
    supplied = dict(snapshot or {})
    base_id = str(meta["snapshot_id"])
    base_start = float(meta.get("t0_s", 0.0))
    base_horizon = float(meta.get("horizon_s", 0.0))
    base_end = base_start + base_horizon

    start = float(supplied.get("t0_s", base_start))
    if supplied.get("horizon_end_s") is not None:
        end = float(supplied["horizon_end_s"])
        if "horizon_s" in supplied and abs(end - (start + float(supplied["horizon_s"]))) > 1e-9:
            raise ValueError("INCONSISTENT_SNAPSHOT_HORIZON")
        horizon = end - start
    else:
        horizon = float(supplied.get("horizon_s", base_horizon))
        end = start + horizon
    if horizon <= 0.0 or end <= start:
        raise ValueError("INVALID_SNAPSHOT_HORIZON")

    time_changed = abs(start - base_start) > 1e-9 or abs(end - base_end) > 1e-9
    supplied_id = supplied.get("snapshot_id")
    if time_changed and (not supplied_id or str(supplied_id) == base_id):
        raise ValueError("SNAPSHOT_ID_REQUIRED_FOR_TIME_OVERRIDE")
    effective_id = str(supplied_id or base_id)
    if not effective_id.strip():
        raise ValueError("INVALID_SNAPSHOT_ID")
    return {
        "snapshot_id": effective_id,
        "t0_s": start,
        "horizon_s": horizon,
        "horizon_end_s": end,
    }
