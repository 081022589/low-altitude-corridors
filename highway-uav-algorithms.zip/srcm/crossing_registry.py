"""Canonicalize physical aliases and reject false resource sharing."""

import copy
from typing import Any, Dict, List, Tuple


def _normalize_resource_identity(item: Dict[str, Any]) -> Tuple[Any, ...]:
    """Normalize and validate the identity of the segment at this crossing.

    A full ``resource_chain`` describes a route, not the physical resource
    represented by this crossing.  Only the explicit segment identity fields
    may define the current resource.
    """

    crossing_id = str(item.get("crossing_id", ""))
    segment = item.get("segment_resource_id")
    resource = item.get("resource_id")
    if segment is None and resource is not None:
        segment = str(resource)
        item["segment_resource_id"] = segment
    elif segment is not None:
        segment = str(segment)
        item["segment_resource_id"] = segment
    if resource is None and segment is not None:
        resource = segment
        item["resource_id"] = resource
    elif resource is not None:
        resource = str(resource)
        item["resource_id"] = resource
    if segment is not None and resource is not None and segment != resource:
        raise ValueError("CROSSING_RESOURCE_IDENTITY_CONFLICT: " + crossing_id)

    chain = item.get("resource_chain")
    normalized_chain = tuple(str(value) for value in chain) if chain else ()
    if normalized_chain and segment is not None and normalized_chain[0] != segment:
        raise ValueError("CROSSING_RESOURCE_CHAIN_HEAD_CONFLICT: " + crossing_id)
    if normalized_chain:
        item["resource_chain"] = list(normalized_chain)

    column_id = item.get("column_id")
    if column_id is not None:
        column_id = str(column_id)
        item["column_id"] = column_id
        if segment is not None and not (
            segment == column_id or segment.startswith(column_id + ":")
        ):
            raise ValueError("CROSSING_COLUMN_RESOURCE_CONFLICT: " + crossing_id)
    return segment, resource, column_id, normalized_chain


def build_crossing_registry(scene_bundle: Dict[str, Any]) -> List[Dict[str, Any]]:
    by_physical: Dict[Tuple[str, str], Dict[str, Any]] = {}
    id_signatures: Dict[str, Tuple[str, str, str, Tuple[Any, ...]]] = {}
    for raw in sorted(scene_bundle.get("crossing_resources", []), key=lambda value: value.get("crossing_id", "")):
        item = copy.deepcopy(raw)
        identity = _normalize_resource_identity(item)
        signature = (item["physical_shaft_id"], item["mainline_id"], item["geometry_hash"], identity)
        previous = id_signatures.get(item["crossing_id"])
        if previous is not None and previous != signature:
            if previous[:3] == signature[:3] and previous[3] != signature[3]:
                raise ValueError("CROSSING_ALIAS_RESOURCE_IDENTITY_CONFLICT: " + item["crossing_id"])
            raise ValueError("CROSSING_ALIAS_GEOMETRY_CONFLICT: " + item["crossing_id"])
        id_signatures[item["crossing_id"]] = signature
        key = (item["physical_shaft_id"], item["mainline_id"])
        if key in by_physical:
            existing = by_physical[key]
            if existing["geometry_hash"] != item["geometry_hash"] or existing.get("geometry") != item.get("geometry"):
                raise ValueError("PHYSICAL_CROSSING_GEOMETRY_CONFLICT: " + item["crossing_id"])
            existing_identity = _normalize_resource_identity(existing)
            if existing_identity != identity:
                raise ValueError("PHYSICAL_CROSSING_RESOURCE_IDENTITY_CONFLICT: " + item["crossing_id"])
            existing["associated_node_ids"] = sorted(set(existing.get("associated_node_ids", [])) | set(item.get("associated_node_ids", [])))
            continue
        by_physical[key] = item
    return sorted(by_physical.values(), key=lambda item: item["crossing_id"])
