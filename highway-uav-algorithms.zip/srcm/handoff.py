"""Independent, read-only validation of an exported SRCM handoff package."""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
from pathlib import Path
from typing import Any, Dict, Iterable, List, Mapping, Sequence, Union

from .models import RESOURCE_REGISTRY_VERSION
from .reporting import CSV_FIELDS


JSON_FILES = (
    "crossing_resource_registry.json", "candidate_plan_manifest.json", "fixed_plan_manifest.json",
    "crossing_resource_uses.json", "crossing_competition_events.json", "plan_pair_evaluation.json", "srcm_summary.json",
)
CSV_FILES = tuple(CSV_FIELDS)
REQUIRED_FILES = JSON_FILES + CSV_FILES
SCHEMA_FILES = {
    "SRCM_HANDOFF_V3_0": "srcm_crossing_handoff_v3.schema.json",
    "SRCM_HANDOFF_V3_0_1": "srcm_crossing_handoff_v3_0_1.schema.json",
}


def _hash(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _canonical_hash(value: Any) -> str:
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()


def _error(errors: List[Dict[str, Any]], code: str, path: str = "", detail: str = "") -> None:
    record: Dict[str, Any] = {"code": code}
    if path:
        record["path"] = path
    if detail:
        record["detail"] = detail
    errors.append(record)


def _matches_type(value: Any, expected: str) -> bool:
    checks = {
        "object": lambda item: isinstance(item, dict), "array": lambda item: isinstance(item, list),
        "string": lambda item: isinstance(item, str), "null": lambda item: item is None,
        "boolean": lambda item: isinstance(item, bool),
        "integer": lambda item: isinstance(item, int) and not isinstance(item, bool),
        "number": lambda item: isinstance(item, (int, float)) and not isinstance(item, bool),
    }
    return expected in checks and checks[expected](value)


def _schema_violations(value: Any, schema: Mapping[str, Any], path: str) -> List[str]:
    violations: List[str] = []
    expected = schema.get("type")
    if expected is not None:
        choices = expected if isinstance(expected, list) else [expected]
        if not any(_matches_type(value, choice) for choice in choices):
            return [path + ": expected " + "/".join(choices)]
    if "const" in schema and value != schema["const"]:
        violations.append(path + ": const mismatch")
    if "enum" in schema and value not in schema["enum"]:
        violations.append(path + ": enum mismatch")
    if isinstance(value, dict):
        for key in schema.get("required", []):
            if key not in value:
                violations.append(path + ": missing " + key)
        for key, child in schema.get("properties", {}).items():
            if key in value:
                violations.extend(_schema_violations(value[key], child, path + "." + key))
    if isinstance(value, list) and "items" in schema:
        for index, item in enumerate(value):
            violations.extend(_schema_violations(item, schema["items"], "%s[%d]" % (path, index)))
    return violations


def _duplicates(values: Iterable[Any]) -> List[str]:
    seen, duplicates = set(), set()
    for value in values:
        marker = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
        if marker in seen:
            duplicates.add(marker)
        seen.add(marker)
    return sorted(duplicates)


def _identity_errors(records: Sequence[Mapping[str, Any]], manifest: Mapping[str, Any], path: str, errors: List[Dict[str, Any]]) -> None:
    expected = (manifest.get("snapshot_id"), manifest.get("scenario_hash"), manifest.get("resource_registry_version"))
    for index, record in enumerate(records):
        actual = (record.get("snapshot_id"), record.get("scenario_hash"), record.get("resource_registry_version"))
        if actual != expected:
            _error(errors, "IDENTITY_MISMATCH", "%s[%d]" % (path, index), "expected snapshot/scenario/registry identity")


def _safe_json(root: Path, name: str, errors: List[Dict[str, Any]]) -> Any:
    path = root / name
    if not path.is_file():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        _error(errors, "INVALID_JSON", name, str(exc))
        return None


def _empty_report(errors: List[Dict[str, Any]]) -> Dict[str, Any]:
    return {"status": "FAILED", "errors": errors, "candidate_count": 0, "fixed_count": 0, "resource_count": 0, "use_count": 0, "event_count": 0, "pair_count": 0}


def validate_srcm_handoff(output_dir: Union[str, Path]) -> Dict[str, Any]:
    root = Path(output_dir)
    errors: List[Dict[str, Any]] = []
    manifest_path = root / "srcm_handoff_manifest.json"
    if not manifest_path.is_file():
        _error(errors, "MISSING_FILE", "srcm_handoff_manifest.json")
        return _empty_report(errors)
    try:
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        _error(errors, "INVALID_JSON", "srcm_handoff_manifest.json", str(exc))
        return _empty_report(errors)

    schema_version = manifest.get("schema_version")
    schema_name = SCHEMA_FILES.get(schema_version)
    if schema_name is None:
        _error(errors, "UNSUPPORTED_SCHEMA_VERSION", "srcm_handoff_manifest.json", str(schema_version))
        return _empty_report(errors)
    schema = json.loads((Path(__file__).resolve().parents[1] / "schemas" / schema_name).read_text(encoding="utf-8"))
    manifest_schema = schema.get("$defs", {}).get("manifest", schema)
    for detail in _schema_violations(manifest, manifest_schema, "srcm_handoff_manifest.json"):
        _error(errors, "SCHEMA_ERROR", "srcm_handoff_manifest.json", detail)

    declared_list = manifest.get("files", []) if isinstance(manifest.get("files"), list) else []
    declared: Dict[str, Mapping[str, Any]] = {}
    for item in declared_list:
        if not isinstance(item, dict) or not isinstance(item.get("path"), str):
            _error(errors, "SCHEMA_ERROR", "srcm_handoff_manifest.json", "invalid files entry")
            continue
        if item["path"] in declared:
            _error(errors, "DUPLICATE_FILE_ENTRY", item["path"])
        declared[item["path"]] = item
    for name in REQUIRED_FILES:
        path = root / name
        if name not in declared:
            _error(errors, "MISSING_FILE_DECLARATION", name)
        if not path.is_file():
            _error(errors, "MISSING_FILE", name)
        elif name in declared and _hash(path) != declared[name].get("sha256"):
            _error(errors, "HASH_MISMATCH", name)

    data = {name: _safe_json(root, name, errors) for name in JSON_FILES}
    is_current = schema_version == "SRCM_HANDOFF_V3_0_1"
    if is_current:
        for name, definition_name in schema.get("fileSchemas", {}).items():
            if data.get(name) is None:
                continue
            definition = schema.get("$defs", {}).get(definition_name, {})
            for detail in _schema_violations(data[name], definition, name):
                _error(errors, "SCHEMA_ERROR", name, detail)

    csv_rows: Dict[str, List[Dict[str, str]]] = {}
    for name in CSV_FILES:
        path = root / name
        if not path.is_file():
            continue
        try:
            with path.open("r", encoding="utf-8", newline="") as stream:
                reader = csv.DictReader(stream)
                rows = list(reader)
                csv_rows[name] = rows
                if is_current and reader.fieldnames != list(CSV_FIELDS[name]):
                    _error(errors, "CSV_HEADER_MISMATCH", name)
        except (OSError, UnicodeError, csv.Error) as exc:
            _error(errors, "INVALID_CSV", name, str(exc))

    if is_current:
        csv_to_json = {
            "crossing_resource_uses.csv": "crossing_resource_uses.json",
            "crossing_competition_events.csv": "crossing_competition_events.json",
            "plan_pair_evaluation.csv": "plan_pair_evaluation.json",
        }
        for csv_name, json_name in csv_to_json.items():
            if csv_name not in csv_rows or not isinstance(data.get(json_name), list):
                continue
            expected_rows = []
            for record in data[json_name]:
                encoded = {}
                for field in CSV_FIELDS[csv_name]:
                    value = record.get(field)
                    if isinstance(value, (list, dict)):
                        encoded[field] = json.dumps(value, ensure_ascii=False, sort_keys=True)
                    elif value is None:
                        encoded[field] = ""
                    else:
                        encoded[field] = str(value)
                expected_rows.append(encoded)
            if csv_rows[csv_name] != expected_rows:
                _error(errors, "CSV_JSON_CONTENT_MISMATCH", csv_name)

    for name, item in declared.items():
        if name not in REQUIRED_FILES or not isinstance(item, dict):
            continue
        value = data.get(name) if name.endswith(".json") else csv_rows.get(name)
        if value is None:
            continue
        actual_count = len(value) if isinstance(value, list) else 1
        if item.get("row_count") != actual_count:
            _error(errors, "ROW_COUNT_MISMATCH", name, "manifest=%s actual=%s" % (item.get("row_count"), actual_count))

    resources = data.get("crossing_resource_registry.json") or []
    candidates = data.get("candidate_plan_manifest.json") or []
    fixed = data.get("fixed_plan_manifest.json") or []
    uses = data.get("crossing_resource_uses.json") or []
    events = data.get("crossing_competition_events.json") or []
    pairs = data.get("plan_pair_evaluation.json") or []
    summary = data.get("srcm_summary.json") or {}
    collections = (resources, candidates, fixed, uses, events, pairs)
    if not all(isinstance(value, list) for value in collections) or not isinstance(summary, dict):
        return _empty_report(errors or [{"code": "SCHEMA_ERROR", "detail": "top-level output shapes"}])
    if any(not isinstance(item, dict) for collection in collections for item in collection):
        return _empty_report(errors or [{"code": "SCHEMA_ERROR", "detail": "record must be an object"}])
    if is_current and any(item["code"] in {"SCHEMA_ERROR", "INVALID_JSON"} for item in errors):
        return {
            "status": "FAILED", "errors": errors, "candidate_count": len(candidates), "fixed_count": len(fixed),
            "resource_count": len(resources), "use_count": len(uses), "event_count": len(events), "pair_count": len(pairs),
        }

    resource_ids = {item.get("crossing_id") for item in resources if isinstance(item, dict)}
    plan_records = [item for item in candidates + fixed if isinstance(item, dict)]
    plan_ids = {item.get("plan_id") for item in plan_records}
    use_ids = {item.get("use_id") for item in uses if isinstance(item, dict)}
    event_ids = {item.get("event_id") for item in events if isinstance(item, dict)}
    for label, values in (
        ("RESOURCE", [item.get("crossing_id") for item in resources]), ("PLAN", [item.get("plan_id") for item in plan_records]),
        ("USE", [item.get("use_id") for item in uses]), ("EVENT", [item.get("event_id") for item in events]),
        ("PAIR", [item.get("pair_evaluation_id", item.get("pair_key")) for item in pairs]),
    ):
        duplicates = _duplicates(values)
        if duplicates:
            _error(errors, "DUPLICATE_%s_ID" % label, detail=",".join(map(str, duplicates)))
    normalized_pairs = [tuple(sorted((item.get("plan_a_id"), item.get("plan_b_id")))) for item in pairs]
    if _duplicates(normalized_pairs):
        _error(errors, "DUPLICATE_PLAN_PAIR")

    if any(item.get("crossing_id") not in resource_ids or item.get("plan_id") not in plan_ids for item in uses):
        _error(errors, "USE_REFERENCE_ERROR")
    if any(item.get("crossing_id") not in resource_ids or item.get("plan_a_id") not in plan_ids or item.get("plan_b_id") not in plan_ids or item.get("use_a_id") not in use_ids or item.get("use_b_id") not in use_ids for item in events):
        _error(errors, "EVENT_USE_REFERENCE_ERROR")
    if any(item.get("plan_a_id") not in plan_ids or item.get("plan_b_id") not in plan_ids or set(item.get("event_ids", [])) - event_ids for item in pairs):
        _error(errors, "PAIR_EVENT_REFERENCE_ERROR")
    if any(set(item.get("crossing_use_ids", [])) - use_ids for item in plan_records):
        _error(errors, "PLAN_USE_REFERENCE_ERROR")

    if is_current:
        for name, records in (
            ("crossing_resource_registry.json", resources), ("candidate_plan_manifest.json", candidates),
            ("fixed_plan_manifest.json", fixed), ("crossing_resource_uses.json", uses),
            ("crossing_competition_events.json", events), ("plan_pair_evaluation.json", pairs),
        ):
            _identity_errors(records, manifest, name, errors)
        expected_identity = (manifest.get("snapshot_id"), manifest.get("scenario_hash"), manifest.get("resource_registry_version"))
        actual_summary_identity = (summary.get("snapshot_id"), summary.get("scenario_hash"), summary.get("resource_registry_version"))
        if actual_summary_identity != expected_identity:
            _error(errors, "IDENTITY_MISMATCH", "srcm_summary.json")
        raw_registry = [{key: value for key, value in item.items() if key not in {"snapshot_id", "scenario_hash", "resource_registry_version"}} for item in resources]
        if _canonical_hash(raw_registry) != manifest.get("resource_registry_hash") or summary.get("resource_registry_hash") != manifest.get("resource_registry_hash"):
            _error(errors, "RESOURCE_REGISTRY_HASH_MISMATCH")
        if summary.get("trajectory_hash") != manifest.get("trajectory_hash"):
            _error(errors, "TRAJECTORY_HASH_MISMATCH")
        expected_counts = {
            "candidate_count": len(candidates), "fixed_count": len(fixed), "resource_count": len(resources),
            "use_count": len(uses), "unknown_pair_count": sum(item.get("evaluation_status") == "UNKNOWN" for item in pairs),
        }
        if any(summary.get(key) != value for key, value in expected_counts.items()):
            _error(errors, "SUMMARY_COUNT_MISMATCH")
        if manifest.get("resource_registry_version") != RESOURCE_REGISTRY_VERSION:
            _error(errors, "RESOURCE_REGISTRY_VERSION_MISMATCH")

    return {
        "status": "VALIDATED" if not errors else "FAILED", "errors": errors,
        "candidate_count": len(candidates), "fixed_count": len(fixed), "resource_count": len(resources),
        "use_count": len(uses), "event_count": len(events), "pair_count": len(pairs),
    }


def main(argv=None):
    parser = argparse.ArgumentParser(prog="srcm.handoff")
    parser.add_argument("--input", required=True)
    args = parser.parse_args(argv)
    report = validate_srcm_handoff(args.input)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "VALIDATED" else 2


if __name__ == "__main__":
    raise SystemExit(main())
