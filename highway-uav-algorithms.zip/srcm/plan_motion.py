"""Representation-neutral access to plan motion.

Callers use this module instead of indexing either legacy absolute-time 4-D
trajectory points or the path-time prediction schema directly.
"""

from __future__ import annotations

import hashlib
import json
import math
from contextlib import contextmanager
from contextvars import ContextVar
from copy import deepcopy
from typing import Any, Dict, Iterable, Mapping, Sequence

from .path_time import iter_timed_path_segments


_SEGMENT_EVALUATION_CACHE = ContextVar("srcm_segment_evaluation_cache", default=None)


@contextmanager
def motion_evaluation_scope():
    """Reuse pure motion expansion within one decision, never across snapshots.

    Content keys bind the entire prediction, including current state/anchor.
    Published passages are deliberately read independently by their own seam.
    ContextVar isolation also covers exceptions, nested calls and worker threads.
    """
    token = _SEGMENT_EVALUATION_CACHE.set({})
    try:
        yield
    finally:
        _SEGMENT_EVALUATION_CACHE.reset(token)


def _resource_timing_row(
    raw: Mapping[str, Any],
    *,
    source: str,
    default_role: str,
) -> Dict[str, Any]:
    """Normalize one published resource passage-time record.

    The spatial path remains the plan's geometry.  Resource timing is a
    separate, per-resource contract because C-MLPM can publish a resource
    entry/exit pair without changing the path geometry.  Keeping this
    normalization here gives SRCM one read seam for both C-MLPM and runtime
    projections.
    """

    resource_id = raw.get("resource_id")
    crossing_id = raw.get("crossing_id")
    if resource_id is None and crossing_id is None:
        raise ValueError("INVALID_RESOURCE_PASSAGE_TIMING_ID")
    resource_id = None if resource_id is None else str(resource_id).strip()
    crossing_id = None if crossing_id is None else str(crossing_id).strip()
    if resource_id == "":
        resource_id = None
    if crossing_id == "":
        crossing_id = None
    if resource_id is None and crossing_id is None:
        raise ValueError("INVALID_RESOURCE_PASSAGE_TIMING_ID")
    enter = raw.get("enter_s", raw.get("start_s", raw.get("entry_time_s")))
    exit_ = raw.get("exit_s", raw.get("end_s", raw.get("exit_time_s")))
    if enter is None or exit_ is None:
        raise ValueError("INVALID_RESOURCE_PASSAGE_TIMING_WINDOW")
    try:
        enter_s = float(enter)
        exit_s = float(exit_)
    except (TypeError, ValueError) as error:
        raise ValueError("INVALID_RESOURCE_PASSAGE_TIMING_WINDOW") from error
    if not math.isfinite(enter_s) or not math.isfinite(exit_s) or exit_s <= enter_s:
        raise ValueError("INVALID_RESOURCE_PASSAGE_TIMING_WINDOW")
    role = str(raw.get("role", default_role)).strip()
    role = {"V": "VERTICAL_USER", "M": "MAINLINE_USER"}.get(role, role)
    if role not in {"VERTICAL_USER", "MAINLINE_USER", "SOURCE_ENTRY"}:
        raise ValueError("INVALID_RESOURCE_PASSAGE_TIMING_ROLE:" + role)
    status = str(raw.get("status", "CERTIFIED")).upper()
    if status not in {"PREDICTED", "CERTIFIED", "IN_PROGRESS", "RELEASED"}:
        raise ValueError("INVALID_RESOURCE_PASSAGE_TIMING_STATUS:" + status)
    return {
        "resource_id": resource_id,
        "crossing_id": crossing_id,
        "enter_s": enter_s,
        "exit_s": exit_s,
        "role": role,
        "phase_id": str(raw.get("phase_id", "")) or None,
        "status": status,
        "source": str(raw.get("source", source)),
        "passage_id": (
            str(raw.get("passage_id"))
            if raw.get("passage_id") is not None
            else (str(raw.get("interval_index")) if raw.get("interval_index") is not None else None)
        ),
    }


def iter_historical_resource_passages(
    plan: Mapping[str, Any], *, now_s: float | None = None
) -> Iterable[Dict[str, Any]]:
    """Yield the only historical resource passage interface.

    ``cmlpm_resource_passages`` is published atomically with the C-MLPM
    result.  It is already canonicalized to one physical resource identity
    and one crossing identity.  Raw motion commands (``timed_resource_targets``)
    and immutable plan windows (``resource_windows``) remain available to the
    motion executor, but are deliberately not historical SRCM inputs.

    Released rows are retained in the interface so a released resource cannot
    be re-created by a geometric prediction in the same plan.
    """

    rows: list[Dict[str, Any]] = []
    seen: dict[tuple[str | None, str | None, str, str | None], Dict[str, Any]] = {}

    for raw in plan.get("cmlpm_resource_passages", ()) or ():
        if not isinstance(raw, Mapping):
            raise ValueError("INVALID_CMLPM_RESOURCE_PASSAGE_RECORD")
        row = _resource_timing_row(
            raw,
            source="CMLPM_COMMITTED_RESOURCE_PASSAGE",
            default_role="VERTICAL_USER",
        )
        key = (
            row["resource_id"],
            row["crossing_id"],
            row["role"],
            row.get("passage_id"),
        )
        prior = seen.get(key)
        if prior is not None:
            same_window = (
                math.isclose(prior["enter_s"], row["enter_s"], rel_tol=0.0, abs_tol=1e-9)
                and math.isclose(prior["exit_s"], row["exit_s"], rel_tol=0.0, abs_tol=1e-9)
                and prior["status"] == row["status"]
            )
            if not same_window:
                raise ValueError(
                    "ECJA_RESOURCE_PASSAGE_DUPLICATE_CONFLICT:"
                    + str(row.get("crossing_id") or row.get("resource_id"))
                )
            continue
        seen[key] = row
        rows.append(row)

    if now_s is not None:
        for row in rows:
            row["resource_state"] = resource_passage_state(
                plan, row, now_s=float(now_s)
            )
            if row["resource_state"] == "RELEASED":
                row["status"] = "RELEASED"
    yield from rows


def is_formally_frozen_v_plan(plan: Mapping[str, Any]) -> bool:
    """Return whether the plan carries an immutable, released C-MLPM V result."""

    return bool(
        plan.get("cmlpm_managed")
        and plan.get("commit_status") == "FROZEN"
        and plan.get("frozen") is True
        and plan.get("schedule_result") == "RELEASED"
        and plan.get("checker_evidence")
        and plan.get("resource_windows")
    )


def resource_passage_state(
    plan: Mapping[str, Any], row: Mapping[str, Any], *, now_s: float
) -> str:
    """Classify one normalized passage without changing its published window.

    The classification is read-time state.  It intentionally does not rewrite
    ``enter_s``/``exit_s``: released rows are filtered, active rows retain
    their commitment, frozen future rows retain the C-MLPM window, and only
    uncovered non-frozen rows are eligible for geometric prediction.
    """

    resource_id = row.get("resource_id")
    crossing_id = row.get("crossing_id")
    aliases = {str(value) for value in (resource_id, crossing_id) if value is not None}
    events = [
        item
        for item in plan.get("motion_observed_events", ()) or ()
        if isinstance(item, Mapping) and str(item.get("resource_id")) in aliases
    ]
    has_enter = any(str(item.get("event_type")) == "RESOURCE_ENTER" for item in events)
    has_exit = any(str(item.get("event_type")) == "RESOURCE_EXIT" for item in events)
    role = {"V": "VERTICAL_USER", "M": "MAINLINE_USER"}.get(
        str(row.get("role")), str(row.get("role"))
    )
    frozen_v = is_formally_frozen_v_plan(plan) and role == "VERTICAL_USER"
    if frozen_v and float(row["exit_s"]) <= float(now_s) + 1e-9:
        return "RELEASED"
    if has_exit:
        # A frozen plan cannot be released by an early physical event.  The
        # formal plan remains protected until its published exit time.
        if frozen_v:
            return "ENTERED_ACTIVE" if has_enter else "FROZEN_FUTURE"
        return "RELEASED"
    if has_enter:
        return "ENTERED_ACTIVE"
    if frozen_v:
        return "FROZEN_FUTURE"
    return "PREDICTED_FUTURE"


def _project_on_polyline(
    points: Sequence[Sequence[float]], position: Sequence[float]
) -> tuple[int, float, float]:
    best: tuple[float, int, float] | None = None
    for index, (first, second) in enumerate(zip(points, points[1:])):
        vector = [float(second[axis]) - float(first[axis]) for axis in range(3)]
        length_sq = sum(value * value for value in vector)
        if length_sq <= 1e-18:
            ratio = 0.0
        else:
            ratio = sum(
                (float(position[axis]) - float(first[axis])) * vector[axis]
                for axis in range(3)
            ) / length_sq
            ratio = min(1.0, max(0.0, ratio))
        projected = [float(first[axis]) + ratio * vector[axis] for axis in range(3)]
        distance_sq = sum(
            (float(position[axis]) - projected[axis]) ** 2 for axis in range(3)
        )
        candidate = (distance_sq, index, ratio)
        if best is None or candidate < best:
            best = candidate
    if best is None:
        raise ValueError("ECJA_STALE_MOTION_PREDICTION:EMPTY_PATH")
    return best[1], best[2], math.sqrt(best[0])


def refresh_motion_prediction(
    plan: Mapping[str, Any],
    *,
    position_xyz: Sequence[float],
    speed_mps: float,
    now_s: float,
    tolerance_m: float = 1e-5,
) -> dict[str, Any]:
    """Rebase an unfrozen path-time forecast on the current runtime state.

    This is a prediction producer seam, not a SRCM geometry implementation.
    It keeps the selected path and registered downstream phase timing, while
    rebuilding the remaining approach from the current position and speed.
    """

    prediction = plan.get("motion_prediction")
    if not prediction:
        return deepcopy(dict(plan))
    if not math.isfinite(float(speed_mps)) or float(speed_mps) <= 0.0:
        raise ValueError("ECJA_STALE_MOTION_PREDICTION:NONPOSITIVE_CURRENT_SPEED")
    phases = [deepcopy(dict(item)) for item in prediction.get("phases", ())]
    if not phases:
        raise ValueError("ECJA_STALE_MOTION_PREDICTION:EMPTY_PHASES")

    current_phase_index = None
    current_phase_ratio = 0.0
    current_distance = math.inf
    for index, phase in enumerate(phases):
        points = phase.get("path_xyz", ())
        if len(points) < 2:
            continue
        _, ratio, distance = _project_on_polyline(points, position_xyz)
        if distance < current_distance:
            current_phase_index = index
            current_phase_ratio = ratio
            current_distance = distance
    if current_phase_index is None or current_distance > tolerance_m:
        raise ValueError("ECJA_STALE_MOTION_PREDICTION:CURRENT_POSITION_OFF_PATH")

    refreshed: list[dict[str, Any]] = []
    for index, phase in enumerate(phases):
        if index < current_phase_index:
            continue
        points = [list(map(float, point)) for point in phase["path_xyz"]]
        if index == current_phase_index:
            segment_index, _, _ = _project_on_polyline(points, position_xyz)
            first = [
                float(points[segment_index][axis])
                + current_phase_ratio
                * (float(points[segment_index + 1][axis]) - float(points[segment_index][axis]))
                for axis in range(3)
            ]
            points = [first, *points[segment_index + 1 :]]
            if math.dist(points[0], points[-1]) <= 1e-9:
                continue
        timing = deepcopy(dict(phase["timing"]))
        if index == current_phase_index and str(phase.get("phase_type")) == "H_CRUISE":
            timing = {"model": "CONSTANT_SPEED", "speed_mps": float(speed_mps)}
        elif index == current_phase_index and timing.get("model") == "ARC_TIME_TABLE":
            original_stations = [0.0]
            for first_point, second_point in zip(
                [list(map(float, point)) for point in phase["path_xyz"]],
                [list(map(float, point)) for point in phase["path_xyz"]][1:],
            ):
                original_stations.append(
                    original_stations[-1] + math.dist(first_point, second_point)
                )
            segment_index, ratio, _ = _project_on_polyline(
                [list(map(float, point)) for point in phase["path_xyz"]], position_xyz
            )
            current_station = original_stations[segment_index] + ratio * (
                original_stations[segment_index + 1] - original_stations[segment_index]
            )
            table_stations = list(map(float, timing["arc_stations_m"]))
            table_times = list(map(float, timing["elapsed_s"]))

            def interpolate(value: float) -> float:
                if value <= table_stations[0]:
                    return table_times[0]
                if value >= table_stations[-1]:
                    return table_times[-1]
                for left, right, left_time, right_time in zip(
                    table_stations, table_stations[1:], table_times, table_times[1:]
                ):
                    if left <= value <= right:
                        ratio = (value - left) / (right - left)
                        return left_time + ratio * (right_time - left_time)
                return table_times[-1]

            new_stations = [0.0]
            for first_point, second_point in zip(points, points[1:]):
                new_stations.append(new_stations[-1] + math.dist(first_point, second_point))
            current_time = interpolate(current_station)
            timing["arc_stations_m"] = new_stations
            timing["elapsed_s"] = [
                max(0.0, interpolate(current_station + station) - current_time)
                for station in new_stations
            ]
        refreshed.append({
            "phase_id": str(phase["phase_id"]),
            "phase_type": str(phase["phase_type"]),
            "path_xyz": points,
            "timing": timing,
        })

    if not refreshed:
        raise ValueError("ECJA_STALE_MOTION_PREDICTION:NO_REMAINING_PATH")
    elapsed = 0.0
    for phase in refreshed:
        phase["start_offset_s"] = elapsed
        points = phase["path_xyz"]
        distance = sum(math.dist(a, b) for a, b in zip(points, points[1:]))
        if phase["timing"]["model"] == "CONSTANT_SPEED":
            duration = distance / float(phase["timing"]["speed_mps"])
        else:
            table = phase["timing"]
            duration = float(table["elapsed_s"][-1])
        elapsed += duration
    refreshed_prediction = {
        "model_version": prediction.get("model_version", "SRCM_PATH_TIME_V1"),
        "anchor_time_s": float(now_s),
        "current_state": {
            "position_xyz": list(map(float, position_xyz)),
            "speed_mps": float(speed_mps),
        },
        "phases": refreshed,
    }
    result = deepcopy(dict(plan))
    result["motion_prediction"] = refreshed_prediction
    result["activity_start_s"] = float(now_s)
    result["activity_end_s"] = float(now_s) + elapsed
    result["prediction_source"] = "ECJA_RUNTIME_CURRENT_STATE"
    return result


def _interpolate(first: Sequence[float], second: Sequence[float], ratio: float) -> list[float]:
    return [float(left + ratio * (right - left)) for left, right in zip(first, second)]


def iter_plan_motion_segments(plan: Mapping[str, Any]) -> Iterable[Dict[str, Any]]:
    """Yield phase-owned spatial segments for either supported input.

    Resource passage times are intentionally not inferred here when a plan
    publishes them.  Callers that calculate resource occupancy must consume
    :func:`iter_historical_resource_passages` at the same seam.  This keeps the
    geometry representation and the per-resource timing contract separate,
    while preventing callers from silently falling back to stale path timing.
    """
    prediction = plan.get("motion_prediction")
    if prediction:
        cache = _SEGMENT_EVALUATION_CACHE.get()
        if cache is None:
            segments = iter_timed_path_segments(prediction)
        else:
            key = motion_sha256(plan)
            if key not in cache:
                cache[key] = tuple(iter_timed_path_segments(prediction))
            segments = cache[key]
        for phase, point0, point1, start_s, end_s in segments:
            yield {
                "phase_id": phase["phase_id"],
                "phase_type": phase["phase_type"],
                "start_s": float(start_s),
                "end_s": float(end_s),
                "point0_xyz": list(map(float, point0)),
                "point1_xyz": list(map(float, point1)),
            }
        return

    trajectory = plan.get("trajectory", [])
    for phase in plan.get("phases", []):
        phase_start = float(phase["start_s"])
        phase_end = float(phase["end_s"])
        for point0, point1 in zip(trajectory, trajectory[1:]):
            segment_start = float(point0[0])
            segment_end = float(point1[0])
            active_start = max(segment_start, phase_start)
            active_end = min(segment_end, phase_end)
            if active_end <= active_start:
                continue
            ratio0 = (active_start - segment_start) / (segment_end - segment_start)
            ratio1 = (active_end - segment_start) / (segment_end - segment_start)
            yield {
                "phase_id": phase["phase_id"],
                "phase_type": phase["phase_type"],
                "start_s": active_start,
                "end_s": active_end,
                "point0_xyz": _interpolate(point0[1:4], point1[1:4], ratio0),
                "point1_xyz": _interpolate(point0[1:4], point1[1:4], ratio1),
            }


def phase_time_bounds(plan: Mapping[str, Any], phase_type: str) -> tuple[float, float]:
    segments = [item for item in iter_plan_motion_segments(plan) if item["phase_type"] == phase_type]
    if not segments:
        raise ValueError("MISSING_" + phase_type + "_PHASE")
    return min(item["start_s"] for item in segments), max(item["end_s"] for item in segments)


def phase_types(plan: Mapping[str, Any]) -> tuple[str, ...]:
    """Return motion phase types in traversal order for either representation."""
    phases = (
        plan["motion_prediction"].get("phases", [])
        if plan.get("motion_prediction")
        else plan.get("phases", [])
    )
    return tuple(str(phase.get("phase_type")) for phase in phases)


def motion_distance_m(plan: Mapping[str, Any]) -> float:
    """Return three-dimensional path length without materializing a 4-D path."""
    if plan.get("trajectory"):
        points = [point[1:4] for point in plan["trajectory"]]
        return sum(math.dist(first, second) for first, second in zip(points, points[1:]))
    return sum(
        math.dist(segment["point0_xyz"], segment["point1_xyz"])
        for segment in iter_plan_motion_segments(plan)
    )


def position_at_time(plan: Mapping[str, Any], time_s: float) -> list[float]:
    tolerance = 1e-9
    for segment in iter_plan_motion_segments(plan):
        start_s, end_s = segment["start_s"], segment["end_s"]
        if start_s - tolerance <= time_s <= end_s + tolerance:
            ratio = min(1.0, max(0.0, (time_s - start_s) / (end_s - start_s)))
            return _interpolate(segment["point0_xyz"], segment["point1_xyz"], ratio)
    raise ValueError("TIME_OUTSIDE_PLAN_MOTION")


def motion_sha256(plan: Mapping[str, Any]) -> str:
    payload = plan.get("motion_prediction") if plan.get("motion_prediction") else {
        "trajectory": plan.get("trajectory", []),
        "phases": plan.get("phases", []),
    }
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)
    return hashlib.sha256(raw.encode("utf-8")).hexdigest()
